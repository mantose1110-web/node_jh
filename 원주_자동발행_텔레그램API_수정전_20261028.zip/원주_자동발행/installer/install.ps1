﻿#Requires -Version 5.1
# JH-NODE 광고·SNS 운영 솔루션 - 한 번에 설치·빌드 (설치.bat 이 실행)
# 1) Python 3.12~3.14 x64 확인 → 없으면 winget → 실패하면 python.org 설치 파일로 조용히 설치
# 2) 프로그램 파일 복사 3) 가상환경 4) 패키지 5) 브라우저(playwright) 6) exe 빌드 7) 설치 점검 8) 바탕화면 바로가기·실행
# 단계마다 오류가 나면 쉬운 말로 원인과 해결 방법을 보여 주고 멈춤. 기록: %LOCALAPPDATA%\WonjuAutopost\install_log.txt

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:PIP_DISABLE_PIP_VERSION_CHECK = '1'

# A second installer can delete src while the first PyInstaller process reads it.
$installMutex = [Threading.Mutex]::new($false, 'Local\JH-NODE-Installer')
if (-not $installMutex.WaitOne(0)) {
    Write-Host 'JH-NODE 설치가 이미 진행 중이에요. 먼저 실행한 설치가 끝난 뒤 다시 시도해 주세요.' -ForegroundColor Yellow
    exit 3
}

$Src = Split-Path -Parent $PSScriptRoot
$App = Join-Path $env:LOCALAPPDATA 'JH-NODE'
$Log = Join-Path $App 'install_log.txt'
$Venv = Join-Path $App 'venv'
$VPy = Join-Path $Venv 'Scripts\python.exe'
$Browsers = Join-Path $App 'ms-playwright'
$Dist = Join-Path $App 'app'
$Exe = Join-Path $Dist 'JH-NODE\JH-NODE.exe'
$PyVersion = '3.12.10'
$Total = 8

New-Item -ItemType Directory -Force -Path $App | Out-Null
"==== 설치 시작 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ====" | Out-File -FilePath $Log -Encoding utf8
"Windows: $([Environment]::OSVersion.VersionString) / 64비트: $([Environment]::Is64BitOperatingSystem) / 원본: $Src" | Add-Content -Path $Log -Encoding utf8

function Write-Log([string]$m) { Add-Content -Path $Log -Value $m -Encoding utf8 }
function Say([string]$m, [string]$color = 'Gray') { Write-Host $m -ForegroundColor $color; Write-Log $m }

function Assert-AppChild([string]$target) {
    $root = [IO.Path]::GetFullPath($App).TrimEnd('\') + '\'
    if (-not [IO.Path]::GetFullPath($target).StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
        throw "설치 폴더 밖의 경로를 변경할 수 없어요: $target"
    }
}

function Stop-JHNode {
    $running = Get-Process -Name 'JH-NODE', 'WonjuAutopost' -ErrorAction SilentlyContinue
    if (-not $running) { return }
    # Prefer the app's own shutdown API. It also works when the existing
    # process was started with a higher Windows integrity level.
    try {
        $base = 'http://127.0.0.1:5858'
        $ping = Invoke-RestMethod -Uri "$base/api/ping" -TimeoutSec 2
        if ($ping.app -eq 'wonju-autopost') {
            $page = Invoke-WebRequest -UseBasicParsing -Uri "$base/" -TimeoutSec 3
            $token = [regex]::Match($page.Content, 'name="csrf" content="([^"]+)"').Groups[1].Value
            if ($token) {
                Invoke-RestMethod -Uri "$base/api/quit" -Method Post -Headers @{ 'X-CSRF-Token' = $token } `
                    -ContentType 'application/json' -Body '{}' -TimeoutSec 3 | Out-Null
            }
        }
    } catch { Write-Log "실행 중인 앱에 종료 요청을 보내지 못했어요: $($_.Exception.Message)" }
    $until = (Get-Date).AddSeconds(10)
    while ((Get-Process -Name 'JH-NODE', 'WonjuAutopost' -ErrorAction SilentlyContinue) -and (Get-Date) -lt $until) {
        Start-Sleep -Milliseconds 500
    }
    $running = Get-Process -Name 'JH-NODE', 'WonjuAutopost' -ErrorAction SilentlyContinue
    if ($running) {
        try { $running | Stop-Process -Force -ErrorAction Stop }
        catch { throw '실행 중인 JH-NODE를 종료할 권한이 없어요. 작업 표시줄 알림 영역의 JH-NODE 아이콘에서 [종료]를 누르고 설치를 다시 실행하세요.' }
    }
}

function Copy-LogBack {
    try { Copy-Item -Path $Log -Destination (Join-Path $Src '설치_기록.txt') -Force } catch {}
}

function Fail([string]$title, [string]$why, [string]$fix) {
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host " 설치가 멈췄어요: $title" -ForegroundColor Red
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host " 원인: $why" -ForegroundColor Yellow
    Write-Host " 해결 방법: $fix" -ForegroundColor Cyan
    Write-Host " 자세한 기록: $Log" -ForegroundColor Gray
    Write-Log "[실패] $title / 원인: $why / 해결: $fix"
    Copy-LogBack
    Write-Host ''
    Read-Host '엔터를 누르면 창이 닫혀요'
    exit 2
}

function Quote-Arg([string]$a) {
    if ($a -eq '') { return '""' }
    if ($a -notmatch '[\s"]') { return $a }
    return '"' + ($a -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

# 외부 프로그램 실행 (출력은 기록 파일로). 실패하면 예외
function Run([string]$exe, [string[]]$argv, [string]$what, [string]$workdir = $App, [int[]]$okCodes = @(0)) {
    $out = [IO.Path]::GetTempFileName()
    $err = [IO.Path]::GetTempFileName()
    $argStr = ($argv | ForEach-Object { Quote-Arg $_ }) -join ' '
    Write-Log "> $exe $argStr"
    $p = Start-Process -FilePath $exe -ArgumentList $argStr -WorkingDirectory $workdir -NoNewWindow -Wait -PassThru `
        -RedirectStandardOutput $out -RedirectStandardError $err
    $o = Get-Content -Path $out -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
    $e = Get-Content -Path $err -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
    if ($o) { Write-Log $o }
    if ($e) { Write-Log $e }
    Remove-Item $out, $err -Force -ErrorAction SilentlyContinue
    if ($okCodes -notcontains $p.ExitCode) {
        $tail = (($e + "`n" + $o) -split "`n" | Where-Object { $_.Trim() } | Select-Object -Last 4) -join ' / '
        throw "$what 실패 (종료 코드 $($p.ExitCode)): $tail"
    }
    return $o
}

function Step([int]$n, [string]$title) {
    Write-Host ''
    Say "[$n/$Total] $title" 'White'
}

# ---------------------------------------------------------------- 0. 준비 확인
if ($Src -match '\\AppData\\Local\\Temp\\' -and $Src -match '\.zip') {
    Fail '압축 파일 안에서 실행됨' 'zip 파일을 풀지 않고 안에서 바로 실행했어요.' 'zip 파일을 마우스 오른쪽 버튼 → [압축 풀기] 한 다음, 풀린 폴더 안의 설치.bat 을 다시 실행하세요.'
}
foreach ($need in @('autopost\main.py', 'requirements.txt', 'WonjuAutopost.spec', 'config.json')) {
    if (-not (Test-Path (Join-Path $Src $need))) {
        Fail '프로그램 파일이 없음' "$need 파일을 찾지 못했어요." 'zip 파일을 처음부터 다시 풀고, 폴더 구조를 바꾸지 말고 설치.bat 을 실행하세요.'
    }
}
if (-not [Environment]::Is64BitOperatingSystem) {
    Fail '32비트 Windows' '이 프로그램은 64비트 Windows 10/11 이 필요해요.' '64비트 Windows PC에서 설치해 주세요.'
}
try {
    $free = (Get-PSDrive -Name ($App.Substring(0, 1))).Free
    if ($free -lt 2GB) { Fail '디스크 공간 부족' "남은 공간이 $([math]::Round($free / 1GB, 1))GB 예요. 최소 2GB 가 필요해요." '필요 없는 파일을 지우고 다시 실행하세요.' }
} catch {}

# ---------------------------------------------------------------- 1. Python
function Test-Python([string]$exe, [string[]]$pre = @()) {
    try {
        $code = 'import sys,struct,platform;print("%d.%d|%d|%s|%s"%(sys.version_info[0],sys.version_info[1],struct.calcsize("P")*8,platform.machine(),sys.executable))'
        $o = Run $exe ($pre + @('-c', $code)) 'Python 확인'
        $parts = ($o.Trim() -split "`n")[-1].Trim() -split '\|'
        $v = [version]$parts[0]
        if ($v -ge [version]'3.12' -and $v -le [version]'3.14' -and $parts[1] -eq '64' -and $parts[2] -match 'AMD64|x86_64') { return $parts[3].Trim() }
        Write-Log "  제외: $exe $($pre -join ' ') → $($parts -join ' ')"
    } catch { Write-Log "  없음: $exe $($pre -join ' ') ($($_.Exception.Message))" }
    return $null
}

function Find-Python {
    $cands = @()
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) { foreach ($v in @('3.12', '3.13', '3.14')) { $cands += , @($py.Source, @("-$v")) } }
    foreach ($c in (Get-Command python.exe -All -ErrorAction SilentlyContinue)) {
        if ($c.Source -notlike '*WindowsApps*') { $cands += , @($c.Source, @()) }
    }
    foreach ($v in @('312', '313', '314')) {
        foreach ($base in @("$env:LOCALAPPDATA\Programs\Python\Python$v", "$env:ProgramFiles\Python$v")) {
            $p = Join-Path $base 'python.exe'
            if (Test-Path $p) { $cands += , @($p, @()) }
        }
    }
    foreach ($c in $cands) {
        $r = Test-Python $c[0] $c[1]
        if ($r) { return $r }
    }
    return $null
}

function Refresh-Path {
    $m = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $u = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$m;$u"
}

Step 1 'Python 확인 (3.12 ~ 3.14, 64비트 x64)'
$Py = Find-Python
if (-not $Py) {
    Say '  Python 이 없어서 자동으로 설치해요 (몇 분 걸려요)…' 'Yellow'
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        try {
            Run $winget.Source @('install', '-e', '--id', 'Python.Python.3.12', '--scope', 'user', '--silent',
                '--accept-package-agreements', '--accept-source-agreements', '--disable-interactivity') 'winget 으로 Python 설치' $App @(0, -1978335189, -1978335135) | Out-Null
        } catch { Say "  winget 설치 실패 → python.org 설치 파일로 다시 시도해요 ($($_.Exception.Message))" 'Yellow' }
        Refresh-Path
        $Py = Find-Python
    } else {
        Say '  winget 이 없어서 python.org 설치 파일로 설치해요' 'Yellow'
    }
    if (-not $Py) {
        $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
        $url = "https://www.python.org/ftp/python/$PyVersion/python-$PyVersion-$arch.exe"
        $inst = Join-Path $env:TEMP "python-$PyVersion-$arch.exe"
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Say "  내려받는 중: $url"
            Invoke-WebRequest -Uri $url -OutFile $inst -UseBasicParsing -TimeoutSec 600
        } catch {
            Fail 'Python 내려받기' "python.org 에서 설치 파일을 받지 못했어요 ($($_.Exception.Message))" '인터넷 연결을 확인하고 다시 실행하세요. 회사·학교 PC라면 보안 프로그램이 막았을 수 있어요. https://www.python.org 에서 Python 3.12 를 직접 설치한 뒤 다시 실행해도 돼요.'
        }
        $sig = Get-AuthenticodeSignature -FilePath $inst
        if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
            Remove-Item $inst -Force -ErrorAction SilentlyContinue
            Fail 'Python 설치 파일 확인' '내려받은 파일의 서명이 Python 공식 서명이 아니에요(파일이 손상되었거나 바뀜).' '잠시 후 다시 실행하세요. 계속되면 https://www.python.org 에서 직접 설치하세요.'
        }
        try {
            Run $inst @('/quiet', 'InstallAllUsers=0', 'PrependPath=1', 'Include_launcher=1', 'InstallLauncherAllUsers=0',
                'Include_test=0', 'Include_doc=0', 'Shortcuts=0') 'Python 설치' $env:TEMP @(0, 3010) | Out-Null
        } catch {
            Fail 'Python 설치' $_.Exception.Message 'PC를 다시 시작한 뒤 설치.bat 을 다시 실행하세요. 계속되면 https://www.python.org 에서 Python 3.12 를 직접 설치하세요.'
        }
        Refresh-Path
        $Py = Find-Python
    }
    if (-not $Py) {
        Fail 'Python 설치 확인' 'Python 을 설치했지만 찾지 못했어요.' 'PC를 다시 시작한 뒤 설치.bat 을 다시 실행하세요.'
    }
}
Say "  사용할 Python: $Py" 'Green'

# ---------------------------------------------------------------- 2. 파일 복사
Step 2 '프로그램 파일 복사'
try {
    Stop-JHNode
    Start-Sleep -Seconds 1
    $SrcCopy = Join-Path $App 'src'
    Assert-AppChild $SrcCopy
    if (Test-Path $SrcCopy) { Remove-Item -LiteralPath $SrcCopy -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $SrcCopy | Out-Null
    foreach ($item in @('autopost', 'styles', 'assets', 'config.json', 'keywords.csv', 'keywords.sample.csv', 'requirements.txt', 'run_app.py', 'WonjuAutopost.spec')) {
        $from = Join-Path $Src $item
        if (Test-Path $from) { Copy-Item -Path $from -Destination $SrcCopy -Recurse -Force }
    }
    if (-not (Test-Path (Join-Path $SrcCopy 'run_app.py'))) { throw 'run_app.py 복사가 완료되지 않았어요' }
    Get-ChildItem -Path $SrcCopy -Recurse -Directory -Filter '__pycache__' | Remove-Item -Recurse -Force
    Get-ChildItem -Path $SrcCopy -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
} catch {
    Fail '파일 복사' $_.Exception.Message "프로그램이 켜져 있으면 끄고(트레이 아이콘 → 종료) 다시 실행하세요. 폴더: $App"
}
Say '  완료' 'Green'

# ---------------------------------------------------------------- 3. 가상환경
Step 3 '가상환경 만들기'
try {
    if (Test-Path $VPy) {
        $ok = Test-Python $VPy
        if (-not $ok) { Say '  예전 가상환경을 지우고 새로 만들어요'; Assert-AppChild $Venv; Remove-Item -LiteralPath $Venv -Recurse -Force }
    }
    if (-not (Test-Path $VPy)) { Run $Py @('-m', 'venv', $Venv) '가상환경 만들기' | Out-Null }
    if (-not (Test-Path $VPy)) { throw '가상환경의 python.exe 가 만들어지지 않았어요' }
} catch {
    Fail '가상환경 만들기' $_.Exception.Message "백신 프로그램이 막았을 수 있어요. 폴더 $Venv 를 지우고 다시 실행하세요."
}
Say '  완료' 'Green'

# ---------------------------------------------------------------- 4. 패키지
Step 4 '필요한 패키지 설치 (인터넷 필요, 3~10분)'
$req = Join-Path $SrcCopy 'requirements.txt'
$done = $false
for ($i = 1; $i -le 3 -and -not $done; $i++) {
    try {
        Run $VPy @('-m', 'pip', 'install', '--upgrade', 'pip') 'pip 업데이트' $App | Out-Null
    } catch { Write-Log "pip 업데이트 건너뜀: $($_.Exception.Message)" }
    try {
        # ONNX Runtime contains native wheels. Install it alone first so an
        # unsupported Python version/CPU gets a direct diagnosis instead of
        # the resolver's confusing "from versions: none" message.
        Run $VPy @('-m', 'pip', 'install', '--only-binary=:all:', 'onnxruntime>=1.24.1,<2') 'OCR 엔진(ONNX Runtime) 설치' $App | Out-Null
        Run $VPy @('-m', 'pip', 'install', '--prefer-binary', '-r', $req) '패키지 설치' $App | Out-Null
        $done = $true
    } catch {
        $last = $_.Exception.Message
        Say "  패키지 설치 실패($i/3) → 다시 시도해요" 'Yellow'
        Start-Sleep -Seconds (5 * $i)
    }
}
if (-not $done) {
    Fail '패키지 설치' $last '이 OCR 기능은 Python 3.12~3.14 x64와 64비트 Windows가 필요해요. 설치 기록의 “사용할 Python” 버전과 ONNX Runtime 오류를 확인하고, 기존 JH-NODE 폴더의 venv를 지운 뒤 설치.bat을 다시 실행하세요. 회사 PC라면 pypi.org 방화벽도 확인해 주세요.'
}
Say '  완료' 'Green'
try {   # 아이폰 HEIC 사진 읽기 (선택: 설치가 안 돼도 나머지는 정상 동작)
    Run $VPy @('-m', 'pip', 'install', '--prefer-binary', '--only-binary=:all:', 'pillow-heif') '아이폰 사진(HEIC) 지원' $App | Out-Null
    Say '  아이폰 사진(HEIC) 지원 설치됨' 'Green'
} catch { Say '  아이폰 사진(HEIC) 지원은 건너뜀 (JPG·PNG 는 정상)' 'Yellow'; Write-Log "pillow-heif 건너뜀: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 5. 브라우저
Step 5 '발행용 브라우저 준비 (playwright)'
$env:PLAYWRIGHT_BROWSERS_PATH = $Browsers
$haveChrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
try {
    Run $VPy @('-m', 'playwright', 'install', 'chromium') '브라우저 설치' $App | Out-Null
    Say '  완료' 'Green'
} catch {
    if ($haveChrome) {
        Say "  크로미움 설치는 실패했지만, 이 PC의 크롬/엣지를 쓰면 돼요: $haveChrome" 'Yellow'
    } else {
        Fail '브라우저 설치' $_.Exception.Message '인터넷 연결을 확인하고 다시 실행하세요. 또는 크롬(https://www.google.com/chrome)을 설치한 뒤 다시 실행하세요.'
    }
}
if ($haveChrome) { Say "  로그인·발행에는 이 브라우저를 써요: $haveChrome" }

# ---------------------------------------------------------------- 6. exe 빌드
Step 6 '프로그램(exe) 만들기 (2~5분)'
$buildStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$buildWork = Join-Path $App "build-$buildStamp"
$stagedDist = Join-Path $App "app-new-$buildStamp"
$backupDist = Join-Path $App "app-backup-$buildStamp"
try {
    # The installed executable is JH-NODE.exe. A running copy keeps bundled
    # .pyd files open, so close both current and legacy executable names.
    Stop-JHNode
    $stopDeadline = (Get-Date).AddSeconds(15)
    while ((Get-Process -Name 'JH-NODE', 'WonjuAutopost' -ErrorAction SilentlyContinue) -and
           (Get-Date) -lt $stopDeadline) {
        Start-Sleep -Milliseconds 500
    }
    if (Get-Process -Name 'JH-NODE', 'WonjuAutopost' -ErrorAction SilentlyContinue) {
        throw '실행 중인 JH-NODE를 종료하지 못했어요. 프로그램을 닫고 다시 설치해 주세요.'
    }
    Assert-AppChild $Dist
    Assert-AppChild $buildWork
    Assert-AppChild $stagedDist
    Assert-AppChild $backupDist
    # A fresh build directory avoids locked .pyd files from a previous build.
    # Build beside the installed app so a failed build leaves the old exe intact.
    Run $VPy @('-m', 'PyInstaller', '--noconfirm', '--distpath', $stagedDist, '--workpath', $buildWork, 'WonjuAutopost.spec') 'exe 빌드' $SrcCopy | Out-Null
    if (-not (Test-Path (Join-Path $stagedDist 'JH-NODE\JH-NODE.exe'))) { throw 'exe 파일이 만들어지지 않았어요' }
    if (Test-Path -LiteralPath $Dist) { Move-Item -LiteralPath $Dist -Destination $backupDist -ErrorAction Stop }
    try { Move-Item -LiteralPath $stagedDist -Destination $Dist -ErrorAction Stop }
    catch {
        if (Test-Path -LiteralPath $backupDist) { Move-Item -LiteralPath $backupDist -Destination $Dist -ErrorAction SilentlyContinue }
        throw
    }
    if (-not (Test-Path $Exe)) { throw 'exe 파일이 만들어지지 않았어요' }
} catch {
    Fail 'exe 만들기' $_.Exception.Message '기존 프로그램은 보존했어요. 실행 중인 JH-NODE를 닫고 다시 설치해 주세요. 계속 실패하면 기록 파일에서 접근 거부 경로를 확인해 주세요.'
}
Say "  완료: $Exe" 'Green'

# ---------------------------------------------------------------- 7. 설치 점검
Step 7 '설치 점검 (서버·화면·테스트 글·보안·브라우저)'
$report = Join-Path $App 'smoke_report.txt'
Remove-Item $report -Force -ErrorAction SilentlyContinue
try {
    $p = Start-Process -FilePath $Exe -ArgumentList @('--smoke', '--report', (Quote-Arg $report)) -WorkingDirectory (Split-Path $Exe) -Wait -PassThru
    $txt = if (Test-Path $report) { Get-Content $report -Raw -Encoding UTF8 } else { '' }
    Write-Log $txt
    if ($p.ExitCode -ne 0 -or $txt -notmatch 'RESULT=OK') {
        $bad = ($txt -split "`n" | Where-Object { $_ -match 'FAIL' }) -join ' / '
        throw "점검 실패: $bad"
    }
} catch {
    $smokeErr = $_.Exception.Message
    if (Test-Path -LiteralPath $backupDist) {
        try {
            $failedDist = Join-Path $App "app-failed-$buildStamp"
            Assert-AppChild $failedDist
            Move-Item -LiteralPath $Dist -Destination $failedDist -ErrorAction Stop
            Move-Item -LiteralPath $backupDist -Destination $Dist -ErrorAction Stop
            Say '  설치 점검에 실패해 이전 프로그램을 복원했어요.' 'Yellow'
        } catch { Write-Log "이전 프로그램 복원 실패: $($_.Exception.Message)" }
    }
    Fail '설치 점검' $smokeErr "기록 파일($report)을 확인해 주세요. 5899 포트를 다른 프로그램이 쓰고 있으면 그 프로그램을 끄고 다시 실행하세요."
}
Say '  모든 점검 통과' 'Green'

# ---------------------------------------------------------------- 8. 바로가기·실행
Step 8 '바탕화면 바로가기 만들고 실행'
try {
    $ws = New-Object -ComObject WScript.Shell
    $desk = [Environment]::GetFolderPath('Desktop')
    foreach ($dir in @($desk, (Join-Path ([Environment]::GetFolderPath('Programs')) ''))) {
        $lnk = $ws.CreateShortcut((Join-Path $dir 'JH-NODE.lnk'))
        $lnk.TargetPath = $Exe
        $lnk.WorkingDirectory = Split-Path $Exe
        $lnk.IconLocation = "$Exe,0"
        $lnk.Description = 'JH-NODE 광고·SNS 운영 솔루션'
        $lnk.Save()
    }
} catch {
    Fail '바로가기 만들기' $_.Exception.Message "프로그램은 설치됐어요. $Exe 를 직접 실행해도 돼요."
}
Start-Process -FilePath $Exe -WorkingDirectory (Split-Path $Exe)
Say ''
Say '============================================================' 'Green'
Say ' 설치 완료! 잠시 후 브라우저에 대시보드(http://127.0.0.1:5858)가 열려요.' 'Green'
Say ' 다음부터는 바탕화면의 [JH-NODE] 아이콘을 두 번 누르세요.' 'Green'
Say '============================================================' 'Green'
Copy-LogBack
Start-Sleep -Seconds 8
exit 0
