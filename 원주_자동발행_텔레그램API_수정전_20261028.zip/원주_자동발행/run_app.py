# PyInstaller 진입점
import sys
from autopost.main import main

if __name__ == "__main__":
    sys.exit(main())
