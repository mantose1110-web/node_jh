# -*- mode: python ; coding: utf-8 -*-
# PyInstaller 빌드 설정 (설치.bat 이 자동으로 실행):  python -m PyInstaller --noconfirm WonjuAutopost.spec
import os, sys
from PyInstaller.utils.hooks import collect_all, collect_data_files, collect_submodules

NAME = "JH-NODE"
WIN = sys.platform.startswith("win")

datas = [("autopost/ui", "autopost/ui"), ("styles", "styles"), ("assets/ci", "assets/ci"), ("assets/ocr_models", "assets/ocr_models"), ("config.json", "."), ("keywords.csv", "."), ("keywords.sample.csv", ".")]
datas += collect_data_files("playwright")           # Playwright 드라이버(node + 패키지)
binaries = []
hidden = ["playwright.sync_api", "werkzeug.serving", "PIL.ImageOps"]
for package in ("rapidocr", "onnxruntime", "mss", "pyautogui", "pyperclip"):
    try:
        package_datas, package_binaries, package_hidden = collect_all(package)
        datas += package_datas
        binaries += package_binaries
        hidden += package_hidden
    except Exception:
        pass
for mod in ("pystray", "telethon"):
    try:
        hidden += collect_submodules(mod)           # 트레이 아이콘(Windows 백엔드는 동적으로 불러옴)
    except Exception:
        pass
if not WIN:
    hidden += ["cryptography.fernet"]              # 윈도우가 아닐 때만 쓰는 암호화(윈도우는 DPAPI)

a = Analysis(["run_app.py"], pathex=["."], binaries=binaries, datas=datas, hiddenimports=hidden,
             excludes=["matplotlib", "pytest", "IPython"], noarchive=False)
pyz = PYZ(a.pure)
icon = "assets/app.ico" if os.path.exists("assets/app.ico") else None
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name=NAME, console=not WIN, icon=icon, upx=False)
coll = COLLECT(exe, a.binaries, a.datas, name=NAME, upx=False)
