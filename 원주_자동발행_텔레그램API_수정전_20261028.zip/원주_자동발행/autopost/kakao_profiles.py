# -*- coding: utf-8 -*-
"""Local KakaoTalk account labels and per-account room rules.

KakaoTalk credentials are never stored. A profile is bound to the PC client
only after the user logs in there and explicitly selects that profile.
"""
import copy
import uuid

from .util import load_config, save_config

KINDS = {"normal", "open", "group"}


def _root(cfg):
    root = cfg.get("kakaoTalk")
    if isinstance(root, dict) and isinstance(root.get("accounts"), list) and root["accounts"]:
        return root
    legacy = cfg.get("kakaoAutoReply") or {}
    migrated = []
    for item in legacy.get("rooms") or []:
        if isinstance(item, dict) and item.get("name"):
            migrated.append({**item, "kind": "group"})
    return {"accounts": [{"id": "default", "label": "기본 계정", "rooms": migrated,
                          "intervalValue": legacy.get("intervalValue", 1),
                          "intervalUnit": legacy.get("intervalUnit", "minutes")} ]}


def list_accounts():
    root = _root(load_config())
    return [{"id": a["id"], "label": a["label"], "roomCount": len(a.get("rooms") or [])}
            for a in root["accounts"]]


def get_account(account_id):
    for account in _root(load_config())["accounts"]:
        if account.get("id") == account_id:
            return copy.deepcopy(account)
    raise ValueError("저장된 카카오톡 계정을 찾지 못했어요")


def create_account(label):
    label = str(label or "").strip()[:50]
    if not label:
        raise ValueError("계정 이름을 입력해 주세요")
    cfg = load_config()
    root = _root(cfg)
    if len(root["accounts"]) >= 10:
        raise ValueError("카카오톡 계정 설정은 최대 10개까지 저장할 수 있어요")
    if any(a["label"].casefold() == label.casefold() for a in root["accounts"]):
        raise ValueError("같은 이름의 계정 설정이 이미 있어요")
    account = {"id": uuid.uuid4().hex[:12], "label": label, "rooms": [],
               "intervalValue": 1, "intervalUnit": "minutes"}
    root["accounts"].append(account)
    cfg["kakaoTalk"] = root
    save_config(cfg)
    return copy.deepcopy(account)


def delete_account(account_id):
    cfg = load_config()
    root = _root(cfg)
    if len(root["accounts"]) == 1:
        raise ValueError("마지막 계정 설정은 삭제할 수 없어요")
    kept = [a for a in root["accounts"] if a.get("id") != account_id]
    if len(kept) == len(root["accounts"]):
        raise ValueError("저장된 카카오톡 계정을 찾지 못했어요")
    root["accounts"] = kept
    cfg["kakaoTalk"] = root
    save_config(cfg)
    return list_accounts()


def save_account(account_id, value):
    cfg = load_config()
    root = _root(cfg)
    account = next((a for a in root["accounts"] if a.get("id") == account_id), None)
    if account is None:
        raise ValueError("저장된 카카오톡 계정을 찾지 못했어요")
    rooms = []
    seen = set()
    for item in (value.get("rooms") or [])[:300]:
        name = str(item.get("name") or "").strip()[:80]
        key = name.casefold()
        if not name or key in seen:
            continue
        seen.add(key)
        kind = item.get("kind") if item.get("kind") in KINDS else "normal"
        mode = item.get("mode") if item.get("mode") in ("all", "keywords") else "all"
        keywords = [str(k).strip()[:60] for k in (item.get("keywords") or []) if str(k).strip()][:30]
        reply = str(item.get("reply") or "")[:1000]
        enabled = bool(item.get("enabled"))
        if enabled and mode == "keywords" and not keywords:
            raise ValueError(f"{name}: 키워드 응답을 선택한 방에 키워드를 입력해 주세요")
        rooms.append({"name": name, "kind": kind, "enabled": enabled,
                      "mode": mode, "keywords": keywords, "reply": reply})
    unit = value.get("intervalUnit") if value.get("intervalUnit") in ("minutes", "hours") else "minutes"
    try:
        interval = int(value.get("intervalValue", 1))
    except (TypeError, ValueError):
        raise ValueError("중복 방지 시간을 숫자로 입력해 주세요")
    interval = max(1, min(24 if unit == "hours" else 1440, interval))
    account.update({"rooms": rooms, "intervalValue": interval, "intervalUnit": unit})
    cfg["kakaoTalk"] = root
    save_config(cfg)
    return copy.deepcopy(account)
