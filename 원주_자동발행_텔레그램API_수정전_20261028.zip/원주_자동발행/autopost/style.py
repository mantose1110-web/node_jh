# -*- coding: utf-8 -*-
"""기존 글 스타일 학습: 그 계정에 이미 올라간 글 2~5개를 읽고 글버릇(말투·줄바꿈·이모지·문단 길이)을 정리 → 새 글 프롬프트에 반영

- 네이버 블로그·손님용 블로그: 공개 RSS(rss.blog.naver.com/{아이디}.xml) + 모바일 글 화면에서 본문을 읽음 (로그인 불필요)
- 티스토리: 공개 RSS({블로그}.tistory.com/rss)
- 카페·기타: 사장님이 기존 글을 붙여넣기
- 문장은 저장하지 않고 '특징'만 저장 (베끼지 않게). Claude 키가 있으면 특징을 사람 말로 요약
"""
import html as H
import os
import re
from datetime import datetime

from .util import log

EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF☀-➿⭐❤]")
STYLE_TOOL = {"name": "submit_style", "description": "블로그 글버릇 요약 제출", "input_schema": {"type": "object", "properties": {
    "summary": {"type": "string", "description": "이 블로그 글버릇 4~7줄 (말투, 문장 길이, 줄바꿈, 이모지·기호, 소제목·목록 습관, 자주 쓰는 마무리). 원문 문장 인용 금지"}},
    "required": ["summary"]}}
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36"}


def _clean(t):
    t = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", t, flags=re.S | re.I)
    t = re.sub(r"<br\s*/?>|</(p|div|li|h\d)>", "\n", t, flags=re.I)
    t = H.unescape(re.sub(r"<[^>]+>", "", t)).replace("​", "")
    return "\n".join(ln.strip() for ln in t.split("\n")).strip()


def analyze(texts):
    """글 목록 → 숫자 특징. 말투는 TONES 이름으로"""
    texts = [t for t in (x.strip() for x in texts) if len(t) >= 40]
    if not texts:
        raise ValueError("분석할 글이 없어요 (글 하나에 40자 이상 필요)")
    allt = "\n\n".join(texts)
    sents = [s for s in re.split(r"(?<=[.!?~])\s+|\n+", allt) if len(s.strip()) > 3]
    ends = {"haeyo": 0, "hamnida": 0, "diary": 0}
    for s in sents:
        s = re.sub(r"[\s.!?~^ㅎㅋ" + EMOJI_RE.pattern[1:-1] + r"]+$", "", s.strip())
        if re.search(r"(니다|니까)$", s):
            ends["hamnida"] += 1
        elif re.search(r"(요|죠|용)$", s):
            ends["haeyo"] += 1
        elif re.search(r"(다|었다|했다|이다|네|군)$", s):
            ends["diary"] += 1
    from .generator import TONES
    tone = {"haeyo": TONES[0], "hamnida": TONES[3], "diary": TONES[1]}[max(ends, key=ends.get)]
    paras = [p for p in re.split(r"\n\s*\n|\n", allt) if p.strip()]
    per_para = len(sents) / max(len(paras), 1)
    chars = sum(len(re.sub(r"\s", "", t)) for t in texts)
    emoji = len(EMOJI_RE.findall(allt))
    return {"tone": tone, "toneCounts": ends, "sentPerPara": round(per_para, 1), "avgSentChars": round(chars / max(len(sents), 1)),
            "avgChars": round(chars / len(texts)), "emojiPer200": round(emoji / max(chars, 1) * 200, 2),
            "hashtags": round(len(re.findall(r"#[^\s#]{2,}", allt)) / len(texts), 1),
            "lists": round(len(re.findall(r"^\s*([•\-·▶✔✅]|\d+[.)])\s", allt, flags=re.M)) / len(texts), 1), "samples": len(texts)}


def rule_summary(st):
    em = st["emojiPer200"]
    lines = [f"- 말투: {st['tone']} 위주",
             f"- 문단: 평균 {st['sentPerPara']}문장마다 줄바꿈, 한 문장 평균 {st['avgSentChars']}자 안팎",
             f"- 글 길이: 평균 {st['avgChars']}자 안팎",
             f"- 이모지: 200자당 약 {em}개" + (" (거의 안 씀)" if em < 0.3 else " (자주 씀)" if em > 2 else ""),
             f"- 목록 표시: 글마다 {st['lists']}개 정도" + (", 해시태그 글마다 약 %s개" % st["hashtags"] if st["hashtags"] else "")]
    return "\n".join(lines)


def _get(url, timeout=15):
    import requests
    r = requests.get(url, headers=UA, timeout=timeout)
    r.raise_for_status()
    r.encoding = r.encoding or "utf-8"
    return r.text


def fetch_posts(ch, handle, n=3):
    """공개 글 본문 n개 (최신순). 네이버: RSS → 모바일 글 화면, 티스토리: RSS 본문"""
    if not handle:
        raise ValueError("블로그 아이디(주소)가 없어요")
    if ch in ("naver", "guide"):
        rss = (os.environ.get("AUTOPOST_NAVER_RSS_URL") or "https://rss.blog.naver.com/{id}.xml").replace("{id}", handle)
    elif ch == "tistory":
        rss = (os.environ.get("AUTOPOST_TISTORY_RSS_URL") or "https://{id}.tistory.com/rss").replace("{id}", handle)
    else:
        raise ValueError("이 채널은 기존 글을 붙여넣어 학습해 주세요")
    x = _get(rss)
    items = re.findall(r"<item>(.*?)</item>", x, flags=re.S)[:n]
    if not items:
        raise ValueError("공개된 글을 찾지 못했어요 (블로그 아이디·공개 설정 확인)")
    out = []
    for it in items:
        link = _clean(re.search(r"<link>(.*?)</link>", it, flags=re.S).group(1)) if "<link>" in it else ""
        desc = re.search(r"<description>(.*?)</description>", it, flags=re.S)
        desc = _clean(re.sub(r"^<!\[CDATA\[|\]\]>$", "", desc.group(1).strip())) if desc else ""
        body = ""
        m = re.search(r"/(\d{9,})", link)
        if ch in ("naver", "guide") and m:
            u = (os.environ.get("AUTOPOST_NAVER_POST_URL") or "https://m.blog.naver.com/{id}/{no}").replace("{id}", handle).replace("{no}", m.group(1))
            try:
                page = _get(u)
                paras = re.findall(r'<p class="se-text-paragraph[^"]*"[^>]*>(.*?)</p>', page, flags=re.S)
                body = "\n".join(_clean(p) for p in paras).strip() or _clean(page.split("se-main-container", 1)[-1])[:6000]
            except Exception as e:  # noqa: BLE001
                log("WARN", f"[스타일 학습] 글 본문을 못 읽어 요약으로 대신: {str(e)[:80]}")
        out.append(body if len(body) > len(desc) else desc)
    return out


def learn(cfg, ch, acc, texts=None, use_ai=True):
    """acc(계정 dict)의 style 을 채워 돌려줌. texts 없으면 공개 글을 읽음"""
    from . import llm
    source = "paste" if texts else "blog"
    texts = texts or fetch_posts(ch, acc.get("handle", ""))
    st = analyze(texts)
    summary = rule_summary(st)
    if use_ai and llm.api_key():
        try:
            sample = "\n\n---\n\n".join(t[:2500] for t in texts[:5])
            out, _ = llm.call_tool(cfg, "", "아래는 한 블로그의 기존 글들입니다. 새 글을 같은 사람이 쓴 것처럼 맞추기 위해 글버릇만 정리해 주세요. "
                                   f"숫자 분석: {summary}\n\n{sample}", STYLE_TOOL, 1200, "text", {"channel": ch, "keyword": "스타일 학습"})
            if str(out.get("summary") or "").strip():
                summary = str(out["summary"]).strip()[:900]
        except Exception as e:  # noqa: BLE001
            log("WARN", f"[스타일 학습] AI 요약 실패 → 숫자 분석만 사용: {str(e)[:100]}")
    style = {**st, "summary": summary, "source": source, "learnedAt": datetime.now().isoformat(timespec="seconds")}
    acc["style"] = style
    log("INFO", f"[스타일 학습] {ch} {acc.get('label', acc.get('id'))}: 글 {st['samples']}개 분석 → {st['tone']}, 이모지 {st['emojiPer200']}/200자")
    return style


def due_accounts(cfg, now=None, days=7):
    """블로그 글로 학습한 계정은 7일마다 다시 학습 (붙여넣기로 학습한 계정은 그대로)"""
    from . import accounts as A
    now = now or datetime.now()
    out = []
    for ch in ("naver", "guide", "tistory"):
        for a in A.list_accounts(cfg, ch):
            s = a.get("style") or {}
            if s.get("source") == "blog" and a.get("handle"):
                try:
                    old = (now - datetime.fromisoformat(s.get("learnedAt"))).days >= days
                except (TypeError, ValueError):
                    old = True
                if old:
                    out.append((ch, a["id"]))
    return out
