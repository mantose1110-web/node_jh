# -*- coding: utf-8 -*-
"""작업 대기열 (SQLite 'jobs' 표)

상태 흐름
  생성 대기 ─(시간 됨)→ [계정 연결 확인] ─안 됨→ 연결 필요 (글을 만들지 않음 = 토큰 낭비 없음)
                                       └됨→ 생성 중 → 발행 대기 → 발행 중 → 완료 / 테스트 완료
  생성 실패 : 글 만들기 실패 → '다시 만들기'
  검토 필요 : 규정 위반·다른 계정 글과 비슷함 → 자동 발행 안 함 → '다시 만들기'
  발행 실패 : 만든 글은 그대로 두고 '다시 시도'하면 발행만 다시 (자동으로도 2번까지 10분 간격 재시도)
  연결 필요 : 로그인이 풀리면 만든 글은 그대로 두고 기다렸다가, 다시 연결되면 자동으로 이어서 발행
"""
import json, os, re, time
from datetime import datetime, timedelta
from . import generator as g
from .util import CH_NAME, BROWSER_CHANNELS, NON_BLOG, REVIEW_CHANNELS, load_config, is_dry, log

S_WAIT, S_GEN, S_NEED, S_READY, S_PUB = "생성 대기", "생성 중", "연결 필요", "발행 대기", "발행 중"
S_DONE, S_TEST, S_GEN_FAIL, S_PUB_FAIL, S_REVIEW, S_CANCEL = "완료", "테스트 완료", "생성 실패", "발행 실패", "검토 필요", "취소"
S_HOLD = "생성됨"   # '작업 설정'에서 '등록은 직접 시작'으로 만든 작업: 글 확인 후 '등록 시작'을 누르면 발행 대기로
FINAL = (S_DONE, S_TEST, S_CANCEL)
COLS = ("id", "created", "channel", "account_id", "account_label", "auto", "status", "keyword", "title", "body_html", "caption",
        "hashtags", "tags", "images", "settings", "scheduled_at", "pub_after", "attempts", "provider", "url", "error", "shot",
        "published_at", "dry", "preview")
JSON_COLS = ("hashtags", "tags", "images", "settings", "preview")
_listeners = []


def on_change(fn):
    _listeners.append(fn)


def _notify():
    for fn in _listeners:
        try:
            fn()
        except Exception:  # noqa: BLE001
            pass


def now_s():
    return datetime.now().isoformat(timespec="seconds")


def _con():
    con = g.db()
    con.execute("""CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY, created TEXT, channel TEXT, account_id TEXT, account_label TEXT,
        auto INTEGER DEFAULT 0, status TEXT, keyword TEXT DEFAULT '', title TEXT DEFAULT '', body_html TEXT DEFAULT '', caption TEXT DEFAULT '',
        hashtags TEXT DEFAULT '[]', tags TEXT DEFAULT '[]', images TEXT DEFAULT '[]', settings TEXT DEFAULT '{}', scheduled_at TEXT DEFAULT '',
        pub_after TEXT DEFAULT '', attempts INTEGER DEFAULT 0, provider TEXT DEFAULT '', url TEXT DEFAULT '', error TEXT DEFAULT '',
        shot TEXT DEFAULT '', published_at TEXT DEFAULT '', dry INTEGER DEFAULT 1, preview TEXT DEFAULT '{}')""")
    con.execute("CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status)")
    return con


def _row(r):
    d = dict(zip(COLS, r))
    for k in JSON_COLS:
        try:
            d[k] = json.loads(d[k] or ("{}" if k in ("settings", "preview") else "[]"))
        except ValueError:
            d[k] = {} if k in ("settings", "preview") else []
    return d


def list_jobs(limit=200, where="", args=()):
    con = _con()
    try:
        return [_row(r) for r in con.execute(f"SELECT {','.join(COLS)} FROM jobs {where} ORDER BY id DESC LIMIT ?", (*args, limit))]
    finally:
        con.close()


def get(jid):
    con = _con()
    try:
        r = con.execute(f"SELECT {','.join(COLS)} FROM jobs WHERE id=?", (jid,)).fetchone()
        return _row(r) if r else None
    finally:
        con.close()


def add(channel, account_id, account_label="", auto=False, scheduled_at="", keyword="", settings=None):
    con = _con()
    try:
        cur = con.execute("INSERT INTO jobs(created,channel,account_id,account_label,auto,status,keyword,settings,scheduled_at) VALUES(?,?,?,?,?,?,?,?,?)",
                          (now_s(), channel, account_id, account_label, int(bool(auto)), S_WAIT, keyword or "",
                           json.dumps(settings or {}, ensure_ascii=False), scheduled_at or now_s()))
        con.commit()
        jid = cur.lastrowid
    finally:
        con.close()
    _notify()
    return jid


def update(jid, **kw):
    allowed = {k: v for k, v in kw.items() if k in COLS and k != "id"}
    for k in JSON_COLS:
        if k in allowed and not isinstance(allowed[k], str):
            allowed[k] = json.dumps(allowed[k], ensure_ascii=False)
    if not allowed:
        return
    con = _con()
    try:
        con.execute(f"UPDATE jobs SET {','.join(k + '=?' for k in allowed)} WHERE id=?", (*allowed.values(), jid))
        con.commit()
    finally:
        con.close()


def set_status_if(jid, expect, new, **kw):
    """상태가 expect 중 하나일 때만 바꿈 (두 곳에서 동시에 같은 작업을 집지 않게)"""
    con = _con()
    try:
        cur = con.execute(f"UPDATE jobs SET status=? WHERE id=? AND status IN ({','.join('?' * len(expect))})", (new, jid, *expect))
        con.commit()
        ok = cur.rowcount == 1
    finally:
        con.close()
    if ok and kw:
        update(jid, **kw)
    return ok


def delete(jid):
    con = _con()
    try:
        con.execute("DELETE FROM jobs WHERE id=? AND status NOT IN (?,?)", (jid, S_GEN, S_PUB))
        con.commit()
    finally:
        con.close()
    _notify()


def recover_after_restart():
    """프로그램이 중간에 꺼졌을 때 '생성 중/발행 중'으로 남은 작업 정리"""
    con = _con()
    try:
        con.execute("UPDATE jobs SET status=?, error='프로그램이 다시 시작되어 이어서 만들어요' WHERE status=?", (S_WAIT, S_GEN))
        con.execute("UPDATE jobs SET status=?, error='발행 도중 프로그램이 꺼졌어요. 블로그에 올라갔는지 확인 후 다시 시도하세요' WHERE status=?",
                    (S_PUB_FAIL, S_PUB))
        con.commit()
    finally:
        con.close()


# ---------------- 조회 ----------------
def due_generation(now=None, limit=5, lead_minutes=0):
    """만들 차례인 작업. lead_minutes: 예약 시간보다 미리 글을 만들어 두고, 발행은 예약 시간에 (늦지 않게)"""
    now = ((now or datetime.now()) + timedelta(minutes=lead_minutes)).isoformat(timespec="seconds")
    con = _con()
    try:
        return [r[0] for r in con.execute("SELECT id FROM jobs WHERE status=? AND scheduled_at<=? ORDER BY scheduled_at, id LIMIT ?", (S_WAIT, now, limit))]
    finally:
        con.close()


def ready_to_publish(now=None):
    now = (now or datetime.now()).isoformat(timespec="seconds")
    con = _con()
    try:
        return [r[0] for r in con.execute("SELECT id FROM jobs WHERE status=? AND (pub_after='' OR pub_after<=?) ORDER BY id", (S_READY, now))]
    finally:
        con.close()


def last_published(channel, account_id):
    con = _con()
    try:
        r = con.execute("SELECT MAX(published_at) FROM jobs WHERE channel=? AND account_id=? AND status=? AND published_at!=''",
                        (channel, account_id, S_DONE)).fetchone()
        return r[0] or ""
    finally:
        con.close()


def last_live_publish():
    con = _con()
    try:
        r = con.execute("SELECT MAX(published_at) FROM jobs WHERE status=? AND channel IN ('naver','guide','cafe','tistory')", (S_DONE,)).fetchone()
        return r[0] or ""
    finally:
        con.close()


def counts_today(auto_only=True):
    """오늘 계정별로 이미 시작된(생성 이후 단계) 자동 작업 수"""
    day = datetime.now().strftime("%Y-%m-%d")
    con = _con()
    try:
        q = "SELECT channel, account_id, COUNT(*) FROM jobs WHERE scheduled_at>=? AND status NOT IN (?,?)" + (" AND auto=1" if auto_only else "") + " GROUP BY channel, account_id"
        return {(c, a): n for c, a, n in con.execute(q, (day, S_WAIT, S_CANCEL))}
    finally:
        con.close()


def cancel_stale(day=None):
    """지난 날짜의 자동 작업 중 시작 못 한 것은 취소 (PC가 꺼져 있던 경우 한꺼번에 몰리지 않게)"""
    day = day or datetime.now().strftime("%Y-%m-%d")
    con = _con()
    try:
        cur = con.execute("UPDATE jobs SET status=?, error='예약 날짜가 지나 취소' WHERE auto=1 AND status=? AND scheduled_at<?", (S_CANCEL, S_WAIT, day))
        n = cur.rowcount
        # 글을 만들기 전에 '연결 필요'로 멈춘 지난 자동 작업은 오늘 계획으로 대신함 (만든 글이 있는 작업은 그대로 보관)
        cur = con.execute("UPDATE jobs SET status=?, error='연결되지 않은 채 날짜가 지나 취소(오늘 계획으로 대신)' WHERE auto=1 AND status=? AND title='' AND scheduled_at<?",
                          (S_CANCEL, S_NEED, day))
        con.commit()
        return n + cur.rowcount
    finally:
        con.close()


def cancel_pending_auto(day=None):
    day = day or datetime.now().strftime("%Y-%m-%d")
    con = _con()
    try:
        cur = con.execute("DELETE FROM jobs WHERE auto=1 AND status=? AND scheduled_at>=?", (S_WAIT, day))
        con.commit()
        return cur.rowcount
    finally:
        con.close()


# ---------------- 글 만들기 ----------------
def job_defaults(acc):
    """계정에 정해 둔 작업 기본값 (작업에서 따로 고르면 그것이 우선)"""
    acc = acc or {}
    return {"block": acc.get("block", "basic"), "position": acc.get("position", "bottom"), "place": bool(acc.get("place", True)),
            "private": bool(acc.get("private", False)), "prompt": acc.get("prompt", ""), "category": (acc.get("categories") or [""])[0],
            "summary": bool(acc.get("summary", True)),
            **({"hold": True} if acc.get("hold") else {})}


def generate_job(jid):
    from . import accounts as A
    from .readiness import account_ready
    from .compliance import check_text
    t = get(jid)
    if not t or t["status"] not in (S_WAIT,):
        return t
    cfg = load_config()
    acc = A.get(cfg, t["channel"], t["account_id"])
    if not acc:
        update(jid, status=S_CANCEL, error="계정이 삭제되었어요")
        return get(jid)
    dry = is_dry(cfg)
    if not dry or t["auto"]:   # 실제 발행이거나 자동 작업이면: 연결 안 된 계정은 글을 만들지 않음
        st = account_ready(cfg, t["channel"], t["account_id"])
        if not st["ok"]:
            update(jid, status=S_NEED, error=st["text"])
            log("INFO", f"[작업 {jid}] {CH_NAME[t['channel']]} {acc['label']} 연결 안 됨 → 글을 만들지 않고 '연결 필요'로 대기")
            _notify()
            return get(jid)
    if not set_status_if(jid, (S_WAIT,), S_GEN, error=""):
        return get(jid)
    _notify()
    try:
        st = {**job_defaults(acc), **(t["settings"] or {})}
        post = g.generate(t["channel"], dry=dry, keyword=t["keyword"] or None, account_obj=acc, prompt_id=st.get("prompt") or None,
                          daily=st.get("daily"))
        from . import blocks
        kind = (st.get("daily") or {}).get("kind")
        visit = kind in g.PERSONAL_KINDS   # 방문기·개인 일상: 가게 홍보 없음
        if visit and (st.get("daily") or {}).get("sign"):   # 사장님이 고른 경우만: 끝에 가게 서명 한 줄
            post["body_html"] += f"<p>— {cfg['shop'].get('region', '아산').replace('충청남도 ', '')} 온천동에서 통닭 튀기는 {cfg['shop']['name']} 사장 🍗</p>"
        if t["channel"] in REVIEW_CHANNELS:    # 카페·밴드(커뮤니티)·수동 원고는 항상 사장님이 글을 보고 '등록'을 눌러야 올라감
            st["hold"] = True
        light = post.get("promo") in ("light", "none")   # 생활 에세이·팁 같은 '광고 적은 글'은 홍보 블록·한눈에 보기·지도 없이
        if visit or light or t["channel"] in ("cafe",) + NON_BLOG:   # 카페·SNS·밴드·방문기: 홍보 블록·우리 가게 지도 카드 없음
            st["place"] = False
        elif t["channel"] not in NON_BLOG:
            post["body_html"] = blocks.apply(post["body_html"], t["channel"], cfg["shop"],
                                             blocks.get(cfg, blocks.resolve(cfg, st.get("block"), (post.get("style") or {}).get("topic"))),
                                             st.get("position") or "bottom", bool(st.get("place", True)),
                                             summary=bool(st.get("summary", True)))
        ci_i = next((n for n, im in enumerate(post.get("images") or []) if im.get("ci")), None)
        if ci_i is not None:   # 기업 CI는 마케팅 블록·지도까지 다 붙인 뒤 글 맨 끝(또는 맨 위)
            from . import library as lib
            mk = f"[[IMG:{ci_i}]]"
            body = post["body_html"].replace(mk, "")
            post["body_html"] = (mk + body) if lib.ci_settings(cfg).get("position") == "top" else (body + mk)
        issues = [i for i in check_text(g.strip_html(post["body_html"]) + " " + post["title"] + " " + post.get("caption", ""))
                  if not (visit and i in g.VISIT_OK)]
        issues += [i for i in post.get("quality_issues") or [] if i.startswith("[") and i not in issues]
        imgs = [{k: i.get(k) for k in ("path", "name", "hash", "photoId", "labels", "caption", "public_url", "ci") if k in i} for i in post.get("images") or []]
        update(jid, status=S_REVIEW if issues else (S_HOLD if st.get("hold") else S_READY), keyword=post["keyword"], title=post["title"], body_html=post["body_html"],
               caption=post.get("caption", ""), hashtags=post.get("hashtags", []), tags=post.get("tags", []), images=imgs,
               provider=post.get("provider", ""), error="; ".join(issues), attempts=0,
               pub_after=max(now_s(), t["scheduled_at"] or "") if not str(t["scheduled_at"] or "").startswith("9999") else now_s(),
               settings={**st, "category": st.get("category") or (acc.get("categories") or [""])[0],
                         "style": post.get("style"), "model": post.get("model"), "voice": post.get("voice"), "promptUsed": post.get("prompt")})
        log("INFO", f"[작업 {jid}] {CH_NAME[t['channel']]} {acc['label']} 글 생성: {post['title']} (키워드 {post['keyword']}, 사진 {len(imgs)}장)"
            + (f" → 검토 필요: {issues}" if issues else ""))
    except Exception as e:  # noqa: BLE001
        update(jid, status=S_GEN_FAIL, error=str(e)[:300])
        log("ERROR", f"[작업 {jid}] 글 생성 실패: {e}")
    _notify()
    return get(jid)


# ---------------- 발행 ----------------
def check_images(images, body_html):
    """발행 전에 사진 파일이 실제로 있는지 확인. 경로가 바뀌었으면 자료함에서 다시 찾고, 없어진 사진은 빼고 자리 번호를 다시 맞춤"""
    import os, re
    from . import library as lib
    keep, remap, missing = [], {}, []
    for n, im in enumerate(images or []):
        path = im.get("path") or ""
        if not os.path.exists(path):
            p = lib.get_photo(im["photoId"]) if im.get("photoId") else None
            alt = os.path.join(lib.lib_dir(), im.get("name") or "")
            path = p["path"] if p and os.path.exists(p["path"]) else (alt if im.get("name") and os.path.exists(alt) else "")
            if path and p and path == p["path"]:   # 사본이 없어졌으면 원본으로 새 사본을 만듦 (글마다 다른 파일 유지)
                path, nm = lib.make_variant(path)
                im = {**im, "name": nm}
        if path:
            remap[n] = len(keep)
            keep.append({**im, "path": path})
        else:
            missing.append(im.get("name") or str(n))
    if missing:
        log("WARN", f"사진 파일 {len(missing)}장이 없어져 그 사진만 빼고 올려요: {', '.join(missing)}")

    def sub(m):
        i = int(m.group(1))
        return f"[[IMG:{remap[i]}]]" if i in remap else ""
    return keep, re.sub(r"\[\[IMG:(\d+)\]\]", sub, body_html or ""), missing


def post_from_job(t, acc=None):
    st = {**job_defaults(acc), **(t["settings"] or {})}
    imgs, body, _ = check_images(t["images"], t["body_html"])
    tags = list(t["tags"] or []) or ([t["keyword"]] if t["keyword"] else [])
    return {"title": t["title"], "body_html": body, "caption": t["caption"], "hashtags": t["hashtags"], "tags": tags,
            "images": imgs, "keyword": t["keyword"], "category": "" if st.get("category") == "__none__" else st.get("category", ""), "place": bool(st.get("place", True)),
            "private": bool(st.get("private"))}


def files_in_use():
    """아직 올리지 않은 작업이 쓰는 사진 파일 이름"""
    names = set()
    for t in list_jobs(1000, "WHERE status NOT IN (?,?,?)", (S_DONE, S_TEST, S_CANCEL)):
        names |= {i.get("name") for i in t["images"] or [] if i.get("name")}
    return names


def publish_job(jid, cfg=None):
    """엔진(한 번에 하나)에서만 부름. 호출 전에 BROWSER_LOCK·profile_lock 을 잡을 것"""
    from . import accounts as A
    from .publishers import PUBLISHERS
    from .connect import LoginRequired, mark_expired
    cfg = cfg or load_config()
    t = get(jid)
    if not t or t["status"] != S_READY:
        return t
    acc = A.get(cfg, t["channel"], t["account_id"])
    if not acc:
        update(jid, status=S_CANCEL, error="계정이 삭제되었어요")
        return get(jid)
    dry = is_dry(cfg)
    if not dry and t["provider"] == "mock":   # 테스트용 예시 글은 절대 실제로 올리지 않음
        update(jid, status=S_WAIT, title="", body_html="", scheduled_at=now_s(), error="테스트용 예시 글이라 AI로 다시 만들어요")
        return get(jid)
    if not set_status_if(jid, (S_READY,), S_PUB):
        return get(jid)
    _notify()
    post = post_from_job(t, acc)
    st0 = t["settings"] or {}
    if st0.get("pubUncertain") and not dry:   # 지난번에 '발행 버튼'까지 누르고 실패 → 이미 올라갔는지 먼저 확인 (중복 발행 방지)
        state, info = already_published(t, acc)
        if state == "yes":
            update(jid, status=S_DONE, url=info, error="", published_at=now_s(), settings={**st0, "pubUncertain": False})
            log("INFO", f"[작업 {jid}] 지난번 시도 때 이미 올라가 있어서 다시 올리지 않았어요: {info}")
            _notify()
            return get(jid)
        if state == "unknown" and not st0.get("forceRetry"):
            update(jid, status=S_PUB_FAIL, error=f"발행 버튼을 누른 뒤 확인이 안 됐어요({info}). 중복을 막으려고 멈췄어요 - "
                                                  "블로그·카페에 글이 없으면 '발행 다시 시도'를 눌러 주세요")
            _notify()
            return get(jid)
    try:
        r = PUBLISHERS[t["channel"]].publish(post, dry, cfg, account=acc, channel=t["channel"])
        update(jid, status=S_TEST if dry else S_DONE, url=r.get("url") or r.get("file") or "", error="", shot="", dry=int(dry),
               published_at=now_s(), preview=r.get("preview") or {})
        log("INFO", f"[작업 {jid}] {CH_NAME[t['channel']]} {acc['label']} {'테스트 등록(실제로 올리지 않음)' if dry else '발행 완료 ' + (r.get('url') or '')}")
    except LoginRequired as e:
        if t["channel"] in BROWSER_CHANNELS:
            mark_expired(t["channel"], t["account_id"])
        update(jid, status=S_NEED, error=f"로그인 필요: {e}")
        log("WARN", f"[작업 {jid}] {CH_NAME[t['channel']]} {acc['label']} 로그인 풀림 → 글은 그대로 두고 '연결 필요'로 대기")
    except Exception as e:  # noqa: BLE001
        msg = str(e)[:400]
        browser_crash = any(k in msg for k in ("has been closed", "ERR_ABORTED", "frame was detached", "Target page"))
        if browser_crash and t["channel"] in BROWSER_CHANNELS:
            try:
                from .browser import profile_dir, kill_profile_processes
                prof = A.profile_name(t["channel"], t["account_id"])
                kill_profile_processes(profile_dir(prof), prof)
            except Exception as cleanup_error:  # noqa: BLE001
                log("WARN", f"브라우저 정리 실패: {type(cleanup_error).__name__}")
        shot_path = msg.rsplit("스크린샷: ", 1)[-1].rstrip(")") if "스크린샷: " in msg else ""
        n = int(t["attempts"] or 0) + 1
        auto_max = int(cfg.get("schedule", {}).get("autoRetries", 2))
        if any(k in msg for k in FINAL_STEPS):   # 발행 버튼까지 눌렀음 → 올라갔을 수도 있음: 다음 시도 전에 확인
            update(jid, settings={**(t["settings"] or {}), "pubUncertain": True, "forceRetry": False})
            t = get(jid)
        if n <= auto_max:
            wait = (max(2, int(cfg.get("schedule", {}).get("browserCrashRetryMinutes", 2))) if browser_crash
                    else int(cfg.get("schedule", {}).get("retryMinutes", 10)) * n)
            update(jid, status=S_READY, attempts=n, error=f"발행 실패({n}회) → {wait}분 뒤 자동 재시도: {msg}", shot=shot_path,
                   pub_after=(datetime.now() + timedelta(minutes=wait)).isoformat(timespec="seconds"))
        else:
            update(jid, status=S_PUB_FAIL, attempts=n, error=msg, shot=shot_path)
        log("ERROR", f"[작업 {jid}] 발행 실패: {msg}")
    _notify()
    return get(jid)


# ---------------- 중복 발행 막기 ----------------
FINAL_STEPS = ("'발행 버튼'", "'등록 버튼'", "글 주소로 넘어가지 않았어요", "글 화면으로 넘어가지 않았어요", "Read timed out", "timed out")


def already_published(t, acc):
    """'발행 버튼'을 누른 뒤 실패한 글: 블로그 공개 RSS에서 같은 제목을 찾아봄 → ('yes', 주소) / ('no', '') / ('unknown', 이유)"""
    import html as H
    import requests
    ch = t["channel"]
    if (t["settings"] or {}).get("private"):
        return "unknown", "비공개 글은 자동 확인이 안 돼요"
    h = acc.get("handle") or ""
    if ch in ("naver", "guide") and h:
        url = (os.environ.get("AUTOPOST_NAVER_RSS_URL") or "https://rss.blog.naver.com/{id}.xml").replace("{id}", h)
    elif ch == "tistory" and h:
        url = (os.environ.get("AUTOPOST_TISTORY_RSS_URL") or "https://{id}.tistory.com/rss").replace("{id}", h)
    else:
        return "unknown", "이 채널은 자동 확인이 안 돼요"
    try:
        r = requests.get(url, timeout=20, headers={"User-Agent": "Mozilla/5.0"})
        r.raise_for_status()
        x = r.text
    except Exception as e:  # noqa: BLE001
        return "unknown", f"블로그 확인 실패: {str(e)[:80]}"
    norm = lambda v: re.sub(r"\s+", "", H.unescape(re.sub(r"<!\[CDATA\[|\]\]>", "", v or "")))
    want = norm(t["title"])
    for it in re.findall(r"<item>(.*?)</item>", x, flags=re.S)[:30]:
        ti = re.search(r"<title>(.*?)</title>", it, flags=re.S)
        if ti and norm(ti.group(1)) == want:
            ln = re.search(r"<link>(.*?)</link>", it, flags=re.S)
            return "yes", norm(ln.group(1)) if ln else ""
    return "no", ""


# ---------------- 사용자 동작 ----------------
def retry_publish(jid):
    """발행 실패/연결 필요(글 있음) → 만든 글 그대로 발행만 다시"""
    t = get(jid)
    if not t or t["status"] not in (S_PUB_FAIL, S_NEED, S_READY) or not t["title"]:
        return False
    st = t["settings"] or {}
    # 사장님이 직접 '다시 시도'를 누름: 블로그 RSS로 확인 가능한 채널은 그래도 먼저 확인, 확인이 안 되는 채널은 사장님 판단대로 진행
    update(jid, status=S_READY, attempts=0, error="", pub_after=now_s(), settings={**st, "forceRetry": True})
    _notify()
    return True


def start_generation(jid):
    """'글 생성 시작': 기다리는 작업을 지금 바로 만들게 함"""
    t = get(jid)
    if not t or t["status"] != S_WAIT:
        return False
    update(jid, scheduled_at=now_s())
    _notify()
    return True


def release(jid):
    """'등록 시작': 생성됨(확인 대기) → 발행 대기"""
    t = get(jid)
    if not t or t["status"] not in (S_HOLD,):
        return False
    sat = str(t["scheduled_at"] or "")
    update(jid, status=S_READY, pub_after=max(now_s(), sat) if sat and not sat.startswith("9999") else now_s(), error="")   # 예약 시간이 남았으면 그때
    _notify()
    return True


def regenerate(jid):
    t = get(jid)
    if not t or t["status"] not in (S_GEN_FAIL, S_REVIEW, S_NEED, S_HOLD, S_TEST):
        return False
    update(jid, status=S_WAIT, title="", body_html="", caption="", images=[], error="", scheduled_at=now_s())
    _notify()
    return True


def on_connected(channel, account_id):
    """계정이 다시 연결되면 기다리던 작업을 이어서 진행"""
    cutoff = (datetime.now() - timedelta(days=2)).isoformat(timespec="seconds")
    n = 0
    for t in list_jobs(500, "WHERE status=? AND channel=? AND account_id=?", (S_NEED, channel, account_id)):
        if t["created"] < cutoff:
            update(t["id"], status=S_CANCEL, error="2일 넘게 연결되지 않아 취소")
        elif t["title"]:
            update(t["id"], status=S_READY, error="", pub_after=now_s(), attempts=0)
            n += 1
        else:
            update(t["id"], status=S_WAIT, error="", scheduled_at=now_s())
            n += 1
    if n:
        log("INFO", f"[{CH_NAME.get(channel, channel)} {account_id}] 다시 연결됨 → 기다리던 작업 {n}건 이어서 진행")
    _notify()
    return n
