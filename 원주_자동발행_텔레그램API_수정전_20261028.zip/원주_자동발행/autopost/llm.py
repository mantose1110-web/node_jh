# -*- coding: utf-8 -*-
"""Claude API 호출 (모델 이름을 코드에 고정하지 않음)

1) GET /v1/models 로 이 API 키가 실제로 쓸 수 있는 모델 목록을 받아 캐시(6시간)
2) 용도별 순위: 글쓰기 = 최신 Sonnet → Opus → Haiku, 사진 라벨 = 최신 Haiku → Sonnet → Opus
   (대시보드에서 모델을 직접 고르면 그 모델을 먼저 시도)
3) 호출 중 404(모델 없음)나 '모델이 올바르지 않음' 400 이 나면 그 모델을 빼고 다음 모델로 자동 재시도
   → 모든 후보가 실패하면 모델 목록을 새로 받아 한 번 더 시도
4) 답은 tool_use(JSON 스키마 강제)로 받아 JSON 깨짐 문제를 없앰
"""
import hashlib, json, os, time, urllib.error, urllib.request
from datetime import datetime, timedelta
from . import generator as g

API_VERSION = "2023-06-01"
CACHE_HOURS = 6
_bad_models = {}      # 이번 실행에서 404가 난 모델 → 시각


class ClaudeError(RuntimeError):
    def __init__(self, msg, status=None, etype=""):
        super().__init__(msg)
        self.status, self.etype = status, etype


def base_url():
    return (os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com").rstrip("/")


def api_key():
    from . import secure
    return secure.get("ANTHROPIC_API_KEY") or ""


def _key_tag(key):
    return hashlib.sha256(key.encode()).hexdigest()[:12]   # 키 자체는 저장하지 않음


def _request(method, path, key, payload=None, timeout=180):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(base_url() + path, data=data, method=method,
                                 headers={"x-api-key": key, "anthropic-version": API_VERSION, "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        try:
            err = json.loads(body).get("error") or {}
        except ValueError:
            err = {}
        msg = err.get("message") or body[:200]
        raise ClaudeError(f"Claude API 오류 {e.code}: {msg}", e.code, err.get("type", "")) from None
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ClaudeError(f"Claude API에 연결하지 못했어요(인터넷 확인): {getattr(e, 'reason', e)}", None, "network") from None


# ---------------- 모델 목록 ----------------
def _cache_path():
    return os.path.join(g.ROOT, "data", "llm_models.json")


def models_cache():
    try:
        with open(_cache_path(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_cache(c):
    os.makedirs(os.path.dirname(_cache_path()), exist_ok=True)
    with open(_cache_path(), "w", encoding="utf-8") as f:
        json.dump(c, f, ensure_ascii=False, indent=1)


def list_models(force=False):
    """[{id, display_name, created_at}] - 이 키로 쓸 수 있는 Claude 모델"""
    key = api_key()
    if not key:
        raise ClaudeError("Claude API 키가 없어요. 'AI 설정'에서 키를 입력해 주세요", None, "no_key")
    c = models_cache()
    fresh = c.get("checkedAt", "") >= (datetime.now() - timedelta(hours=CACHE_HOURS)).isoformat()
    if not force and c.get("key") == _key_tag(key) and c.get("models") and fresh:
        return c["models"]
    models, after = [], None
    for _ in range(10):  # 페이지 넘김
        q = "/v1/models?limit=100" + (f"&after_id={after}" if after else "")
        try:
            j = _request("GET", q, key, timeout=30)
        except ClaudeError as e:
            if e.status == 401:
                raise ClaudeError("Claude API 키가 올바르지 않아요(401). 키를 다시 확인해 주세요", 401, "auth") from None
            if c.get("key") == _key_tag(key) and c.get("models"):   # 일시 오류: 예전 목록 사용
                return c["models"]
            raise
        for m in j.get("data") or []:
            if str(m.get("id", "")).startswith("claude"):
                models.append({"id": m["id"], "display_name": m.get("display_name") or m["id"], "created_at": m.get("created_at") or ""})
        if not j.get("has_more"):
            break
        after = j.get("last_id") or (j.get("data") or [{}])[-1].get("id")
    _save_cache({"key": _key_tag(key), "models": models, "checkedAt": datetime.now().isoformat(timespec="seconds"),
                 "bad": {k: v for k, v in (c.get("bad") or {}).items() if time.time() - v < 86400} if c.get("key") == _key_tag(key) else {}})
    from .util import log
    log("INFO", f"Claude 모델 목록 확인: {len(models)}개 ({', '.join(m['id'] for m in rank(models, 'text')[:3])} …)")
    return models


def _family(mid, purpose):
    order = ("haiku", "sonnet", "opus") if purpose == "vision" else ("sonnet", "opus", "haiku")
    for i, f in enumerate(order):
        if f in mid:
            return i
    return len(order)


def rank(models, purpose="text"):
    """용도별 순위 (같은 계열은 최신 created_at 먼저)"""
    newest_first = sorted(models, key=lambda m: (m.get("created_at") or "", m["id"]), reverse=True)
    return sorted(newest_first, key=lambda m: _family(m["id"], purpose))  # 안정 정렬 → 계열 안에서 최신순 유지


def pinned_model(cfg):
    m = str((cfg.get("llm") or {}).get("model") or "").strip()
    return "" if m in ("", "auto") else m


def _mark_bad(model):
    """404 가 난 모델은 하루 동안 후보에서 뺌 (프로그램을 다시 켜도 유지)"""
    _bad_models[model] = time.time()
    c = models_cache()
    bad = {k: v for k, v in (c.get("bad") or {}).items() if time.time() - v < 86400}
    bad[model] = time.time()
    c["bad"] = bad
    _save_cache(c)


def _is_bad(model):
    t = max(_bad_models.get(model, 0), (models_cache().get("bad") or {}).get(model, 0))
    return time.time() - t < 86400


def candidates(cfg, purpose="text", force=False):
    models = list_models(force=force)
    ids = [m["id"] for m in rank(models, purpose)]
    pin = pinned_model(cfg) if purpose == "text" else ""
    if pin:
        ids = [pin] + [i for i in ids if i != pin]
    good = [i for i in ids if not _is_bad(i)]
    return good or ids


def chosen_model(cfg, purpose="text"):
    try:
        c = candidates(cfg, purpose)
        return c[0] if c else ""
    except ClaudeError:
        return ""


def _is_model_error(e):
    if e.status == 404:
        return True
    m = str(e).lower()
    return e.status == 400 and "model" in m and any(w in m for w in ("not found", "invalid", "does not exist", "not supported", "unknown"))


def record_usage(model, usage, channel="", account="", keyword=""):
    con = g.db()
    try:
        con.execute("INSERT INTO llm_usage(ts,provider,model,channel,account,keyword,input_tokens,output_tokens,cache_write,cache_read) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (datetime.now().isoformat(timespec="seconds"), "anthropic", model, channel, account, keyword,
                     int(usage.get("input_tokens") or 0), int(usage.get("output_tokens") or 0),
                     int(usage.get("cache_creation_input_tokens") or 0), int(usage.get("cache_read_input_tokens") or 0)))
        con.commit()
    finally:
        con.close()


MAX_OUT = 16000


def _send(key, payload, model):
    """요청 1번 (서버가 바쁘면 2번 더). 모델이 없으면(404) None"""
    from .util import log
    waits = (5, 15, 30)
    for attempt in range(len(waits) + 1):
        try:
            return _request("POST", "/v1/messages", key, payload)
        except ClaudeError as e:
            if _is_model_error(e):
                _mark_bad(model)
                log("WARN", f"Claude 모델 {model} 사용 불가({e.status}) → 다음 모델로 다시 시도")
                return None
            if (e.status in (408, 409, 429, 500, 502, 503, 504, 529) or e.etype == "network") and attempt < len(waits):
                wait = waits[attempt] / max(1.0, float(os.environ.get("AUTOPOST_TIME_SCALE") or 1))
                log("WARN", f"Claude 서버가 바쁘거나 연결이 끊겼어요({e.status or '인터넷'}) → {wait:.0f}초 뒤 다시 시도")
                time.sleep(wait)
                continue
            raise


def call_tool(cfg, system, content, tool, max_tokens=4096, purpose="text", meta=None):
    """tool_use 로 구조화된 답(dict) 받기. 반환: (input dict, 사용 모델)"""
    from .util import log
    key = api_key()
    if not key:
        raise ClaudeError("Claude API 키가 없어요. 'AI 설정'에서 키를 입력해 주세요", None, "no_key")
    tried = []
    for round_ in range(2):
        if round_ == 1:   # 모든 후보 실패 → 목록을 새로 받고, 아직 안 해 본 모델만 시도
            _bad_models.clear()
        cands = [m for m in candidates(cfg, purpose, force=(round_ == 1)) if m not in tried]
        for model in cands:
            tried.append(model)
            budgets = list(dict.fromkeys([int(max_tokens), min(int(max_tokens) * 2, MAX_OUT), MAX_OUT]))
            for bi, mt in enumerate(budgets):     # 글이 잘리면(최대 토큰 도달) 더 큰 한도로 처음부터 다시 → 잘린 글은 절대 쓰지 않음
                payload = {"model": model, "max_tokens": mt, "messages": [{"role": "user", "content": content}],
                           "tools": [tool], "tool_choice": {"type": "tool", "name": tool["name"]}}
                if system:
                    payload["system"] = [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}]
                r = _send(key, payload, model)
                if r is None:
                    break
                m = meta or {}
                record_usage(r.get("model") or model, r.get("usage") or {}, m.get("channel", ""), m.get("account", ""), m.get("keyword", ""))
                if r.get("stop_reason") == "max_tokens":
                    if bi + 1 < len(budgets):
                        log("WARN", f"글이 최대 토큰({mt})에서 잘려 {budgets[bi + 1]} 토큰으로 다시 만들어요")
                        continue
                    raise ClaudeError(f"글이 최대 토큰({mt})에서도 잘렸어요. 글 분량을 줄이는 프롬프트로 바꿔 주세요", None, "max_tokens")
                for b in r.get("content") or []:
                    if b.get("type") == "tool_use" and b.get("name") == tool["name"]:
                        return b.get("input") or {}, r.get("model") or model
                raise ClaudeError("Claude 응답에 결과가 없어요(형식 오류)", None, "format")
    raise ClaudeError("이 API 키로 쓸 수 있는 Claude 모델을 찾지 못했어요. 'AI 설정 > 모델 목록 새로고침'을 눌러 주세요", None, "no_model")


def status(cfg):
    key = api_key()
    c = models_cache()
    out = {"hasKey": bool(key), "pinned": pinned_model(cfg), "checkedAt": c.get("checkedAt"), "error": ""}
    models = c.get("models") if key and c.get("key") == _key_tag(key) else []
    out["models"] = [[m["id"], m.get("display_name") or m["id"]] for m in rank(models or [], "text")]
    ok = [m[0] for m in out["models"] if not _is_bad(m[0])]
    out["bad"] = [m[0] for m in out["models"] if _is_bad(m[0])]
    out["chosen"] = ((out["pinned"] if out["pinned"] and not _is_bad(out["pinned"]) else "") or (ok[0] if ok else "")) if key else ""
    return out
