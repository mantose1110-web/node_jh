# -*- coding: utf-8 -*-
"""Find and capture only top-level windows owned by KakaoTalk.exe."""
import ctypes
from ctypes import wintypes
import os
import time
import unicodedata


def windows(include_hidden=False):
    if os.name != "nt":
        return []
    import psutil

    user32 = ctypes.windll.user32
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.EnumWindows.argtypes = [ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM), wintypes.LPARAM]
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    found = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    allowed = set()
    for proc in psutil.process_iter(["pid", "name", "exe"]):
        try:
            if (proc.info["name"] or "").casefold() == "kakaotalk.exe" and (proc.info["exe"] or "").casefold().endswith("\\kakaotalk.exe"):
                allowed.add(proc.info["pid"])
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            continue

    def visit(hwnd, _):
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value not in allowed:
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length == 0:
            return True
        title = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, title, length + 1)
        if not user32.IsWindowVisible(hwnd) and not (include_hidden and title.value.strip().casefold() in ("카카오톡", "kakaotalk")):
            return True
        rect = wintypes.RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return True
        width, height = rect.right - rect.left, rect.bottom - rect.top
        minimized = bool(user32.IsIconic(hwnd))
        if minimized or (width >= 280 and height >= 250):
            found.append({"hwnd": int(hwnd), "pid": pid.value, "title": title.value,
                          "left": rect.left, "top": rect.top, "width": width, "height": height})
        return True

    user32.EnumWindows(callback_type(visit), 0)
    return found


def main_window():
    candidates = [w for w in windows(include_hidden=True) if w["title"].strip().casefold() in ("카카오톡", "kakaotalk")]
    return max(candidates, key=lambda w: w["width"] * w["height"], default=None)


def room_window(name, exclude=()):
    target = unicodedata.normalize("NFKC", name.strip()).casefold()
    matches = [w for w in windows() if w["hwnd"] not in exclude and
               (unicodedata.normalize("NFKC", w["title"].strip()).casefold() == target or
                unicodedata.normalize("NFKC", w["title"].strip()).casefold().startswith(target + " ("))]
    return max(matches, key=lambda w: w["width"] * w["height"], default=None)


def close_room(window, name):
    """Close only the verified KakaoTalk room window, never its main window."""
    main = main_window()
    current = room_window(name, exclude=(main["hwnd"],) if main else ())
    if (not current or current["hwnd"] != window["hwnd"] or
            current["pid"] != window["pid"] or
            (main and current["hwnd"] == main["hwnd"])):
        raise RuntimeError(f"{name} 발송 후 채팅창을 확인하지 못해 다음 발송을 중단했어요")
    user32 = ctypes.windll.user32
    user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    if not user32.PostMessageW(current["hwnd"], 0x0010, 0, 0):
        raise RuntimeError(f"{name} 채팅창을 닫지 못해 다음 발송을 중단했어요")
    for _ in range(20):
        if current["hwnd"] not in {w["hwnd"] for w in windows()}:
            return
        time.sleep(.1)
    raise RuntimeError(f"{name} 채팅창이 닫히지 않아 다음 발송을 중단했어요")


def dock_right(window, width=540):
    """Put a Kakao window at the right edge of its monitor's work area."""
    if window["hwnd"] not in {w["hwnd"] for w in windows()}:
        raise RuntimeError("카카오톡 프로세스의 창이 아니어서 위치를 바꾸지 않았어요")
    user32 = ctypes.windll.user32
    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
                    ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]
    user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
    user32.MonitorFromWindow.restype = wintypes.HMONITOR
    user32.GetMonitorInfoW.argtypes = [wintypes.HMONITOR, ctypes.POINTER(MONITORINFO)]
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int,
                                   ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    monitor = user32.MonitorFromWindow(window["hwnd"], 2)
    info = MONITORINFO()
    info.cbSize = ctypes.sizeof(info)
    if not monitor or not user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
        raise RuntimeError("모니터의 작업 영역을 찾지 못했어요")
    area = info.rcWork
    work_width = area.right - area.left
    # Keep an already readable Kakao width. Resizing on every scan changes
    # chat-row coordinates and can invalidate the OCR layout just observed.
    if 380 <= window["width"] <= width:
        width = window["width"]
    width = min(width, max(360, int(work_width * .42)))
    width = min(width, work_width)
    height = area.bottom - area.top
    if not user32.SetWindowPos(window["hwnd"], 0, area.right - width, area.top,
                               width, height, 0x0004 | 0x0010):
        raise RuntimeError("카카오톡 창을 오른쪽에 배치하지 못했어요")
    return next(w for w in windows() if w["hwnd"] == window["hwnd"])


def set_topmost(window, enabled):
    if window["hwnd"] not in {w["hwnd"] for w in windows()}:
        raise RuntimeError("카카오톡 창을 찾지 못했어요")
    user32 = ctypes.windll.user32
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int,
                                   ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    if not user32.SetWindowPos(window["hwnd"], -1 if enabled else -2,
                               0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010):
        raise RuntimeError("카카오톡 창을 화면 앞으로 가져오지 못했어요")


def point_belongs(window, x, y):
    """Guard input against another window, including another Kakao chat."""
    user32 = ctypes.windll.user32
    user32.WindowFromPoint.argtypes = [wintypes.POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    hwnd = user32.WindowFromPoint(wintypes.POINT(int(x), int(y)))
    if not hwnd:
        return False
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value == window["pid"] and int(user32.GetAncestor(hwnd, 2)) == window["hwnd"]


def capture(window):
    """Window-handle capture never includes pixels from another application."""
    if window["hwnd"] not in {w["hwnd"] for w in windows()}:
        raise RuntimeError("카카오톡 창이 닫혔어요")
    from PIL import ImageGrab
    image = ImageGrab.grab(window=window["hwnd"]).convert("RGB")
    if image.width < 280 or image.height < 250:
        raise RuntimeError("카카오톡 창 캡처 크기가 너무 작아요")
    extrema = image.convert("L").getextrema()
    if extrema[1] - extrema[0] < 12:
        raise RuntimeError("카카오톡 창 캡처가 비어 있어요. 창을 열고 다시 시도해 주세요")
    return image
