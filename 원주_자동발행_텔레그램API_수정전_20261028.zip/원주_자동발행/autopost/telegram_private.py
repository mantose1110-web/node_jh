# -*- coding: utf-8 -*-
"""Manual, opt-in messages to explicitly selected Telegram users."""
import asyncio
import hashlib
import time
import uuid


class TelegramPrivateSender:
    def __init__(self, get_client):
        self.get_client = get_client
        self.directories = {}
        self.jobs = {}
        self.tasks = {}
        self.stop_events = {}
        self.recent = {}

    async def refresh(self, account_id):
        client = self.get_client(account_id)
        if client is None:
            raise ValueError("텔레그램 개인 계정을 먼저 연결해 주세요")
        from telethon.tl.functions.contacts import GetContactsRequest
        from telethon.tl.types import User

        me = await client.get_me()
        found = {}

        def add(user, source):
            if not isinstance(user, User) or user.bot or user.deleted or user.is_self or user.id == me.id:
                return
            uid = str(user.id)
            name = " ".join(x for x in (user.first_name, user.last_name) if x).strip()
            name = name or ("@" + user.username if user.username else uid)
            if uid in found:
                found[uid]["sources"].add(source)
                return
            found[uid] = {"id": uid, "name": name[:100],
                          "username": (user.username or "")[:40], "sources": {source}, "entity": user}

        async for dialog in client.iter_dialogs(limit=500):
            if dialog.is_user:
                add(dialog.entity, "대화")
        warning = ""
        try:
            contacts = await client(GetContactsRequest(hash=0), flood_sleep_threshold=0)
            for user in getattr(contacts, "users", ()):
                add(user, "연락처")
        except Exception as exc:
            if type(exc).__name__ in ("FloodWaitError", "FloodPremiumWaitError"):
                wait = int(getattr(exc, "seconds", 60))
                warning = f"연락처 새로고침은 텔레그램 제한으로 {wait}초 뒤에 다시 시도해 주세요"
            else:
                warning = "연락처를 불러오지 못해 기존 1:1 대화만 표시합니다"
        self.directories[account_id] = found
        rows = [{"id": x["id"], "name": x["name"], "username": x["username"],
                 "sources": sorted(x["sources"])} for x in found.values()]
        rows.sort(key=lambda x: (x["name"].casefold(), x["id"]))
        return {"ok": True, "recipients": rows, "total": len(rows), "warning": warning}

    def status(self, account_id):
        job = self.jobs.get(account_id)
        if not job:
            return {"ok": True, "phase": "idle", "message": "보낸 기록이 없어요", "running": False,
                    "total": 0, "done": 0, "sent": 0, "failed": 0, "results": []}
        return {"ok": True, "phase": job["phase"], "message": job["message"],
                "running": job["phase"] in ("running", "waiting", "stopping") and self._active(account_id),
                "total": len(job["items"]),
                "done": sum(x["status"] in ("sent", "failed", "unknown") for x in job["items"]),
                "sent": sum(x["status"] == "sent" for x in job["items"]),
                "failed": sum(x["status"] in ("failed", "unknown") for x in job["items"]),
                "results": [{"id": x["id"], "name": x["name"], "status": x["status"],
                             "message": x["message"]} for x in job["items"]]}

    def _active(self, account_id):
        task = self.tasks.get(account_id)
        return bool(task and not task.done())

    async def send(self, account_id, ids, text, format_mode="plain", template_values=None):
        client = self.get_client(account_id)
        if client is None:
            raise ValueError("텔레그램 개인 계정을 먼저 연결해 주세요")
        if self._active(account_id):
            raise ValueError("이 계정에서 이미 개인 메시지를 보내는 중이에요")
        if not isinstance(ids, list) or not 1 <= len(ids) <= 30:
            raise ValueError("받는 사람을 1~30명 선택해 주세요")
        if len({str(x) for x in ids}) != len(ids):
            raise ValueError("받는 사람 목록에 중복이 있어요")
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 2000:
            raise ValueError("메시지는 1~2,000자로 입력해 주세요")
        text = text.strip()
        directory = self.directories.get(account_id) or {}
        if not directory or any(not isinstance(uid, str) or uid not in directory for uid in ids):
            raise ValueError("받는 사람 목록을 새로고침한 뒤 선택해 주세요")
        cutoff = time.time() - 600
        self.recent = {key: when for key, when in self.recent.items() if when > cutoff}
        digest = hashlib.sha256((account_id + "\0" + text + "\0" + ",".join(sorted(ids))).encode()).hexdigest()
        if self.recent.get((account_id, digest), 0) > cutoff:
            raise ValueError("같은 메시지를 같은 사람들에게 최근에 보냈어요. 중복 발송을 막았습니다")
        items = [{"id": uid, "name": directory[uid]["name"], "entity": directory[uid]["entity"],
                  "status": "pending", "message": "대기 중"} for uid in ids]
        self.jobs[account_id] = {"id": uuid.uuid4().hex, "phase": "running", "message": "선택한 사람에게 보내는 중",
                                 "items": items}
        self.stop_events[account_id] = asyncio.Event()
        self.recent[(account_id, digest)] = time.time()
        self.tasks[account_id] = asyncio.create_task(self._run(account_id, text, format_mode, template_values or {}))
        return self.status(account_id)

    async def stop(self, account_id):
        if self._active(account_id):
            self.jobs[account_id].update(phase="stopping", message="현재 요청을 마친 뒤 중지합니다")
            self.stop_events[account_id].set()
        return self.status(account_id)

    async def _run(self, account_id, text, format_mode="plain", template_values=None):
        job = self.jobs[account_id]
        stopped = self.stop_events[account_id]
        client = self.get_client(account_id)
        try:
            for index, item in enumerate(job["items"]):
                if stopped.is_set():
                    break
                while not stopped.is_set():
                    item["status"] = "sending"
                    item["message"] = "발송 중"
                    try:
                        from .telegram_format import format_message
                        body, parse_mode = format_message(text, format_mode, template_values or {},
                                                          {"이름": item["name"]})
                        await asyncio.wait_for(client.send_message(item["entity"], body,
                                                                   parse_mode=parse_mode), timeout=60)
                        item.update(status="sent", message="발송 완료")
                        job["message"] = f"{index + 1}/{len(job['items'])}명 처리"
                        break
                    except Exception as exc:
                        name = type(exc).__name__
                        if name in ("FloodWaitError", "FloodPremiumWaitError"):
                            wait = max(1, int(getattr(exc, "seconds", 60)))
                            item.update(status="pending", message=f"텔레그램 제한으로 {wait}초 대기")
                            job.update(phase="waiting", message=f"텔레그램 제한으로 {wait}초 대기 후 이어갑니다")
                            try:
                                await asyncio.wait_for(stopped.wait(), timeout=wait + 1)
                            except asyncio.TimeoutError:
                                pass
                            if not stopped.is_set():
                                job["phase"] = "running"
                            continue
                        if name in ("PeerFloodError", "UserRestrictedError"):
                            item.update(status="failed", message="계정 발송 제한으로 중단")
                            job["message"] = "텔레그램이 계정 발송을 제한했어요"
                            stopped.set()
                        elif isinstance(exc, (OSError, asyncio.TimeoutError)):
                            item.update(status="unknown", message="결과를 확인할 수 없어 중단. 텔레그램 앱에서 확인해 주세요")
                            job["message"] = "연결이 끊겼어요. 실제 발송 여부를 확인해 주세요"
                            stopped.set()
                        else:
                            label = {"UserIsBlockedError": "상대가 이 계정을 차단했어요",
                                     "ChatWriteForbiddenError": "메시지를 보낼 권한이 없어요",
                                     "PrivacyPremiumRequiredError": "상대의 수신 제한으로 보내지 못했어요"}.get(
                                         name, "발송 실패. 상대방의 수신 설정을 확인해 주세요")
                            item.update(status="failed", message=label)
                        break
                if stopped.is_set():
                    break
                if index + 1 < len(job["items"]):
                    job.update(phase="waiting", message="다음 발송까지 30초 대기 중")
                    try:
                        await asyncio.wait_for(stopped.wait(), timeout=30)
                    except asyncio.TimeoutError:
                        pass
                    if not stopped.is_set():
                        job["phase"] = "running"
            if stopped.is_set():
                job["phase"] = "stopped"
                if job["message"].startswith("선택한 사람"):
                    job["message"] = "발송을 중지했어요"
            else:
                job.update(phase="complete", message="선택한 사람에게 보내기를 마쳤어요")
        except asyncio.CancelledError:
            for item in job["items"]:
                if item["status"] == "sending":
                    item.update(status="unknown", message="종료 전 발송 여부를 텔레그램 앱에서 확인해 주세요")
            job.update(phase="stopped", message="프로그램 종료로 발송을 중지했어요")
            raise
        except Exception:
            job.update(phase="stopped", message="발송 작업이 중단됐어요. 텔레그램 앱에서 발송 여부를 확인해 주세요")

    async def close(self, account_id=None):
        ids = [account_id] if account_id is not None else list(self.tasks)
        for aid in ids:
            task = self.tasks.pop(aid, None)
            if task and not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            self.stop_events.pop(aid, None)
            self.directories.pop(aid, None)
            self.jobs.pop(aid, None)
        if account_id is not None:
            for key in list(self.recent):
                if key[0] == account_id:
                    self.recent.pop(key, None)
