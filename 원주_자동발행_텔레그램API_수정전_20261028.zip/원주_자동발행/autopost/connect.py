# -*- coding: utf-8 -*-
"""채널 연결

네이버·티스토리 로그인 (오류 B 해결)
  1) 계정 전용 프로필 폴더로 '일반 크롬'을 그냥 실행 (자동화 표시 없음, 비밀번호는 프로그램이 절대 보지 않음)
     - 크롬에 로컬 디버깅 포트(127.0.0.1)만 열어 두고, 프로그램은 쿠키 '이름'과 페이지 주소만 확인
  2) 로그인 쿠키(네이버: NID_AUT + NID_SES 둘 다 / 티스토리: TSSESSION)가 생기면
     → 같은 창에서 '실제 글쓰기 페이지'를 열어 편집기가 뜨는지 확인 (로그인 페이지로 튕기면 아직 로그인 아님)
  3) 확인되면 쿠키(세션 쿠키 포함)를 암호화 저장하고 창을 정상 종료 → '연결됨'
  4) 발행은 같은 프로필 + 같은 크롬 실행 파일 + 저장 쿠키 복원으로 같은 세션을 이어 씀
인스타그램: 단기 토큰 → 60일 장기 토큰 교환, 만료 10일 전 자동 갱신 (Graph API)
"""
import json, os, re, subprocess, threading, time
from datetime import datetime, timedelta
from urllib.parse import urlparse
import requests
from . import generator as g, secure
from .browser import (BROWSER_LOCK, profile_lock, profile_dir, profile_in_use, wait_profile_free, system_browser, remember_browser,
                      free_port, save_cookies, restore_cookies, launch_profile, safe_goto, shot, work_page,
                      LOGIN_ACTIVE, ProfileBusy, ensure_profile_free, kill_profile_processes, profile_processes)
from .util import log, platform

LOGIN = {
    "naver": {"url": "https://nid.naver.com/nidlogin.login?mode=form&url=https%3A%2F%2Fblog.naver.com%2FMyBlog.naver",
              "cookies": ["NID_AUT", "NID_SES"], "domains": ["naver.com"], "login_hosts": ["nid.naver.com"]},
    "tistory": {"url": "https://www.tistory.com/auth/login",
                "cookies": ["TSSESSION"], "domains": ["tistory.com", "kakao.com"], "login_hosts": ["accounts.kakao.com", "www.tistory.com/auth"]},
}
LOGIN_TIMEOUT = int(os.environ.get("AUTOPOST_LOGIN_TIMEOUT") or 600)
_running, _done, _procs = {}, {}, {}


class LoginRequired(RuntimeError):
    """발행하려는데 로그인이 풀려 있음 → 작업은 '연결 필요'로 기다림"""


def spec(ch):
    """검증용 가짜 서버는 환경변수로만 바꿀 수 있음(대시보드에서는 못 바꿈)"""
    ch = platform(ch)
    s = dict(LOGIN[ch])
    e, C = os.environ, ch.upper()
    if e.get(f"AUTOPOST_LOGIN_URL_{C}"):
        s["url"] = e[f"AUTOPOST_LOGIN_URL_{C}"]
    if e.get(f"AUTOPOST_LOGIN_DOMAIN_{C}"):
        s["domains"] = e[f"AUTOPOST_LOGIN_DOMAIN_{C}"].split(",")
    if e.get(f"AUTOPOST_LOGIN_HOSTS_{C}"):
        s["login_hosts"] = e[f"AUTOPOST_LOGIN_HOSTS_{C}"].split(",")
    return s


def cafe_url_ok(u):
    """카페 계정 주소: 네이버 카페 글쓰기 화면 주소만 (검증용 가짜 서버 주소는 환경변수로만 허용)"""
    try:
        p = urlparse(u)
    except ValueError:
        return False
    hosts = ["cafe.naver.com", "m.cafe.naver.com"] + [h for h in (os.environ.get("AUTOPOST_CAFE_HOSTS") or "").split(",") if h]
    return p.scheme in ("https", "http") and (p.hostname or "") in hosts and (p.scheme == "https" or p.hostname not in ("cafe.naver.com", "m.cafe.naver.com"))


def write_url(ch, handle):
    if ch == "cafe":
        return handle
    ch = platform(ch)
    if ch == "naver":
        return (os.environ.get("AUTOPOST_NAVER_WRITE_URL") or "https://blog.naver.com/{id}?Redirect=Write").replace("{id}", handle)
    return (os.environ.get("AUTOPOST_TISTORY_WRITE_URL") or "https://{blog}.tistory.com/manage/newpost/").replace("{blog}", handle)


def myblog_url():
    return os.environ.get("AUTOPOST_NAVER_MYBLOG_URL") or "https://blog.naver.com/MyBlog.naver"


# ---------------- 상태 저장 (비밀 아님: 연결 여부만) ----------------
def _status_file():
    return os.path.join(g.ROOT, "data", "sessions.json")


_slock = threading.Lock()


def session_status():
    try:
        with open(_status_file(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def set_state(name, **kw):
    with _slock:
        s = session_status()
        s[name] = {**kw, "at": datetime.now().isoformat(timespec="seconds")}
        os.makedirs(os.path.dirname(_status_file()), exist_ok=True)
        tmp = _status_file() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
        os.replace(tmp, _status_file())


def is_waiting(prof):
    return bool(_running.get(prof))


def has_login_cookies(cookies, ch):
    ch = platform(ch)
    sp = spec(ch)
    names = {c["name"] for c in cookies if any(c.get("domain", "").lstrip(".").endswith(d) for d in sp["domains"])}
    return all(n in names for n in sp["cookies"])


def _on_login_page(url, ch):
    ch = platform(ch)
    return any(h in url for h in spec(ch)["login_hosts"])


# ---------------- 글쓰기 페이지로 '진짜 로그인' 확인 ----------------
def detect_naver_id(page):
    safe_goto(page, myblog_url(), timeout=30000)
    end = time.time() + 15
    while time.time() < end:
        u = page.url
        if _on_login_page(u, "naver"):
            return None
        p = urlparse(u).path.rstrip("/")
        last = p.rsplit("/", 1)[-1] if p else ""
        if last and last.lower() not in ("myblog.naver", "postlist.naver", "prologue") and re.fullmatch(r"[A-Za-z0-9_\-]{3,50}", last):
            return last
        q = re.search(r"blogId=([A-Za-z0-9_\-]{3,50})", u)
        if q:
            return q.group(1)
        page.wait_for_timeout(500)
    return None


def editor_frame(page, ch, timeout=40):
    """편집기가 있는 프레임(네이버는 보통 iframe#mainFrame). 없으면 None. 로그인 페이지로 가면 LoginRequired"""
    ch = platform(ch)
    sel = ".se-documentTitle, .se-title-text, .se-component, textarea.textarea_input" if ch == "naver" else "#post-title-inp, textarea[placeholder*='제목']"
    end = time.time() + timeout
    while time.time() < end:
        if _on_login_page(page.url, ch):
            raise LoginRequired("로그인이 풀려 있어요")
        for fr in [page.main_frame] + [f for f in page.frames if f != page.main_frame]:
            try:
                if fr.locator(sel).count() > 0:
                    return fr
            except Exception:  # noqa: BLE001 (프레임 이동 중)
                pass
        page.wait_for_timeout(700)
    return None


def check_write_page(page, ch, handle):
    """(성공 여부, 이유, 블로그 아이디)"""
    if ch == "cafe" and not cafe_url_ok(handle or ""):
        return False, "카페 글쓰기 주소를 먼저 넣어 주세요", handle
    orig, ch = ch, platform(ch)
    if ch == "naver" and not handle and orig != "cafe":
        handle = detect_naver_id(page)
        if not handle:
            if _on_login_page(page.url, ch):
                return False, "login", None
            return False, "블로그 아이디를 찾지 못했어요(블로그를 먼저 만들었는지 확인)", None
    if not handle:
        return False, "블로그 주소(아이디)를 입력해 주세요", None
    if orig == "cafe":   # 카페 주소만 넣어도: 카페 번호를 찾아 글쓰기 화면으로
        from .publishers import cafe as C
        try:
            cid = C.resolve_club(page, handle)
        except Exception as e:  # noqa: BLE001
            if _on_login_page(page.url, ch):
                return False, "login", handle
            return False, str(e)[:150], handle
        safe_goto(page, C.write_page_url(cid, C.parse_handle(handle)[2]))
    else:
        safe_goto(page, write_url(orig, handle))
    try:
        fr = editor_frame(page, ch, 40)
    except LoginRequired:
        return False, "login", handle
    if not fr:
        return False, "글쓰기 화면이 열리지 않았어요", handle
    return True, "", handle


# ---------------- 로그인 창 ----------------
def _set_handle(ch, aid, handle):
    from . import accounts as A
    from .util import load_config, save_config
    cfg = load_config()
    a = A.get(cfg, ch, aid)
    if a and not a.get("handle") and handle:
        a["handle"] = handle
        A.sync_legacy(cfg)
        save_config(cfg)
        log("INFO", f"[{ch} {aid}] 블로그 아이디 자동 입력: {handle}")


def _close_proc(proc, wait=15):
    if proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T"], capture_output=True, timeout=10)
        else:
            proc.terminate()
        proc.wait(wait)
    except Exception:  # noqa: BLE001
        try:
            proc.kill()
            proc.wait(5)
        except Exception:  # noqa: BLE001
            pass


def login_done(ch, aid="main"):
    """대시보드 '로그인 다 했어요' 버튼 → 바로 확인"""
    from . import accounts as A
    prof = A.profile_name(ch, aid)
    ev = _done.get(prof)
    if not ev or not _running.get(prof):
        return {"ok": False, "message": "열려 있는 로그인 창이 없어요"}
    ev.set()
    return {"ok": True}


def connect_login(ch, cfg, aid="main", timeout=None):
    from . import accounts as A
    if platform(ch) not in LOGIN:
        raise ValueError("알 수 없는 채널")
    acc = A.get(cfg, ch, aid)
    if not acc:
        raise ValueError("계정을 찾을 수 없어요")
    prof = A.profile_name(ch, aid)
    if _running.get(prof):
        return {"started": False, "message": "이미 로그인 창이 열려 있어요"}
    plock = profile_lock(prof)
    if not plock.acquire(blocking=False):
        return {"started": False, "message": "지금 이 계정으로 발행·확인 중이에요. 1~2분 뒤 다시 눌러 주세요"}
    try:
        d = profile_dir(prof)
        os.makedirs(d, exist_ok=True)
        if profile_in_use(d) and not ensure_profile_free(d, prof, 3):
            plock.release()
            return {"started": False, "message": "이 계정의 크롬이 꺼지지 않아요. 작업 관리자에서 크롬을 닫고 다시 눌러 주세요"}
        kind, exe = system_browser(cfg)
        remember_browser(prof, kind, exe)   # 발행 때 같은 실행 파일 사용
        port = free_port()
        cmd = [exe, f"--user-data-dir={d}", f"--remote-debugging-port={port}", "--no-first-run", "--no-default-browser-check", "--new-window"]
        if os.name != "nt":
            cmd.append("--password-store=basic")
        if os.environ.get("AUTOPOST_LOGIN_HEADLESS") == "1":   # 자동 테스트 전용
            cmd += ["--headless=new", "--no-sandbox"]
        cmd.append(spec(ch)["url"])
        flags = 0x00000200 if os.name == "nt" else 0
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                                creationflags=flags, start_new_session=(os.name != "nt"))
    except Exception:
        plock.release()
        raise
    _running[prof] = True
    LOGIN_ACTIVE.add(prof)
    _done[prof] = ev = threading.Event()
    _procs[prof] = proc
    set_state(prof, ok=False, state="waiting")
    log("INFO", f"[{prof}] 로그인 창 열림({kind}) - 직접 로그인하세요. 로그인하면 자동으로 확인 후 창이 닫혀요")
    threading.Thread(target=_watch_login, args=(ch, aid, prof, proc, port, ev, plock, timeout or LOGIN_TIMEOUT),
                     daemon=True, name=f"login-{prof}").start()
    return {"started": True, "browser": kind}


def _watch_login(ch, aid, prof, proc, port, ev, plock, timeout):
    from playwright.sync_api import sync_playwright
    from . import accounts as A
    from .util import load_config
    sp = spec(ch)
    state, err, why = "notfound", "", ""
    start = time.time()
    try:
        with sync_playwright() as pw:
            browser = None
            last_cookies = []
            end = time.time() + timeout
            last_check = 0
            while time.time() < end:
                if browser is None:
                    # 실행한 크롬 프로세스가 바로 끝나도(윈도우에서 크롬이 스스로 다시 실행하는 경우 등) 창은 떠 있을 수 있음
                    # → 프로세스 대신 디버깅 연결로 판단. 25초 안에 연결이 안 되면 그때 '닫힘'
                    if proc.poll() is not None and time.time() - start > 25:
                        why = "closed" if not profile_processes(profile_dir(prof)) else "handoff"
                        break
                    try:
                        browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}", timeout=5000)
                    except Exception:  # noqa: BLE001 (크롬이 아직 뜨는 중)
                        time.sleep(1)
                        continue
                try:
                    ctx = browser.contexts[0]
                    cookies = ctx.cookies()
                except Exception:  # noqa: BLE001 (창 닫힘)
                    why = "closed_loggedin" if has_login_cookies(last_cookies, ch) else "closed"
                    break
                last_cookies = cookies
                pressed = ev.is_set()
                if has_login_cookies(cookies, ch) and (pressed or time.time() - last_check > 8):
                    ev.clear()
                    last_check = time.time()
                    save_cookies(prof, cookies, sp["domains"])
                    set_state(prof, ok=False, state="verifying")
                    acc = A.get(load_config(), ch, aid) or {}
                    try:
                        page = ctx.new_page()
                        ok, reason, handle = check_write_page(page, ch, acc.get("handle", ""))
                    except Exception as e:  # noqa: BLE001 (확인 도중 사장님이 창을 닫음)
                        if "closed" not in str(e) and "Target" not in str(e):
                            raise
                        why = "closed_loggedin"
                        break
                    finally:
                        try:
                            page.close()
                        except Exception:  # noqa: BLE001
                            pass
                    if ok:
                        save_cookies(prof, ctx.cookies(), sp["domains"])
                        _set_handle(ch, aid, handle)
                        state, why = "connected", "verified"
                        break
                    if reason == "login":
                        set_state(prof, ok=False, state="waiting")   # 2단계 인증 등 아직 진행 중
                    else:
                        state, err, why = "failed", reason, "write-page"
                        break
                elif pressed:
                    ev.clear()
                    set_state(prof, ok=False, state="waiting", error="아직 로그인 쿠키가 없어요. 로그인을 끝까지 해 주세요")
                ev.wait(1.5)
            else:
                why = "timeout"
            if browser is not None and proc.poll() is None:
                try:   # 정상 종료 요청 → 쿠키가 디스크에 저장됨
                    browser.new_browser_cdp_session().send("Browser.close")
                except Exception:  # noqa: BLE001
                    pass
            try:
                if browser is not None:
                    browser.close()
            except Exception:  # noqa: BLE001
                pass
        try:
            proc.wait(15)
        except Exception:  # noqa: BLE001
            _close_proc(proc, 5)
        LOGIN_ACTIVE.discard(prof)
        if not wait_profile_free(profile_dir(prof), 10):   # 로그인 창이 덜 꺼짐 → 정리 (다음 발행·확인이 막히지 않게)
            kill_profile_processes(profile_dir(prof), prof)
        if why == "closed_loggedin":   # 로그인은 했는데 확인 전에 창이 닫힘 → 저장한 로그인으로 직접 확인
            save_cookies(prof, last_cookies, sp["domains"])
            log("INFO", f"[{prof}] 로그인 후 창이 닫혀서, 저장한 로그인으로 글쓰기 화면을 확인할게요")
            ok, reason = _verify_inline(ch, aid, prof)
            state, err = ("connected", "") if ok else ("expired" if reason == "login" else "failed", "" if reason == "login" else reason)
        if state != "connected" and state != "failed" and state != "expired":
            state = {"timeout": "timeout", "closed": "cancelled"}.get(why, "notfound")
            if why == "handoff":
                err, state = "로그인 창이 이미 떠 있던 크롬에 붙어 버렸어요. 남은 크롬을 정리했으니 '연결하기'를 한 번 더 눌러 주세요", "failed"
        log("INFO", f"[{prof}] 로그인 {'성공 - 글쓰기 화면 확인, 세션 저장' if state == 'connected' else '확인 안 됨: ' + (err or why)} ({int(time.time() - start)}초)")
    except Exception as e:  # noqa: BLE001
        err, state = str(e)[:200], "failed"
        log("ERROR", f"[{prof}] 로그인 창 오류: {e}")
        _close_proc(proc, 5)
    finally:
        LOGIN_ACTIVE.discard(prof)
        _running[prof] = False
        _done.pop(prof, None)
        _procs.pop(prof, None)
        set_state(prof, ok=state == "connected", state=state, **({"error": err} if err else {}))
        plock.release()
        if state == "connected":
            try:
                from . import tasks
                tasks.on_connected(ch, aid)
            except Exception as e:  # noqa: BLE001
                log("WARN", f"연결 후 대기 작업 재개 실패: {e}")


def _verify_inline(ch, aid, prof):
    """로그인 감시 스레드 안에서 (이미 이 프로필 잠금을 잡고 있음) 저장한 로그인으로 글쓰기 화면 확인"""
    from playwright.sync_api import sync_playwright
    from . import accounts as A
    from .util import load_config
    cfg = load_config()
    acc = A.get(cfg, ch, aid) or {}
    try:
        with BROWSER_LOCK, sync_playwright() as pw:
            ctx = launch_profile(pw, prof, cfg)
            try:
                restore_cookies(ctx, prof)
                page = work_page(ctx)
                from .browser import fix_headless_ua
                fix_headless_ua(ctx, page)
                ok, reason, handle = check_write_page(page, ch, acc.get("handle", ""))
                if ok:
                    save_cookies(prof, ctx.cookies(), spec(ch)["domains"])
                    _set_handle(ch, aid, handle)
                return ok, reason
            finally:
                ctx.close()
    except Exception as e:  # noqa: BLE001
        return False, str(e)[:200]


def verify_session(ch, cfg, aid="main"):
    """저장된 세션으로 글쓰기 화면이 열리는지 확인 (창 없이/설정에 따라). 발행 중이면 기다렸다가 확인"""
    from playwright.sync_api import sync_playwright
    from . import accounts as A
    prof = A.profile_name(ch, aid)
    if _running.get(prof):
        return {"ok": False, "state": "waiting", "message": "로그인 창이 열려 있어요"}
    acc = A.get(cfg, ch, aid) or {}
    if not os.path.isdir(profile_dir(prof)):
        set_state(prof, ok=False, state="none")
        return {"ok": False, "state": "none", "message": "아직 연결한 적이 없어요"}
    prev = dict(session_status().get(prof, {}))
    with BROWSER_LOCK, profile_lock(prof):
        set_state(prof, ok=False, state="verifying")
        ok, reason = False, ""
        try:
            with sync_playwright() as pw:
                ctx = launch_profile(pw, prof, cfg)
                try:
                    restore_cookies(ctx, prof)
                    page = work_page(ctx)
                    from .browser import fix_headless_ua
                    fix_headless_ua(ctx, page)
                    ok, reason, handle = check_write_page(page, ch, acc.get("handle", ""))
                    if ok:
                        save_cookies(prof, ctx.cookies(), spec(ch)["domains"])
                        _set_handle(ch, aid, handle)
                    elif reason != "login":
                        shot(page, f"{prof}-verify")
                finally:
                    ctx.close()
        except ProfileBusy as e:   # 크롬이 쓰는 중일 뿐 → 연결 상태는 그대로 두고 알려만 줌
            log("WARN", f"[{prof}] 연결 확인 못 함: {e}")
            set_state(prof, **{k: v for k, v in prev.items() if k != "at"} or {"ok": False, "state": "none"})
            return {"ok": bool(prev.get("ok")), "state": prev.get("state", "none"), "message": str(e)}
        except Exception as e:  # noqa: BLE001
            reason = str(e)[:200]
        state = "connected" if ok else ("expired" if reason == "login" else "failed")
        set_state(prof, ok=ok, state=state, **({"error": reason} if reason and reason != "login" else {}))
    if ok:
        from . import tasks
        tasks.on_connected(ch, aid)
    log("INFO", f"[{prof}] 연결 확인: {'정상' if ok else state + ' ' + reason}")
    return {"ok": ok, "state": state, "message": "" if ok else ("로그인이 풀렸어요. '연결하기'를 다시 눌러 주세요" if reason == "login" else reason)}


def mark_expired(ch, aid):
    from . import accounts as A
    set_state(A.profile_name(ch, aid), ok=False, state="expired")


def shutdown_logins():
    for p in list(_procs.values()):
        _close_proc(p, 5)


# ---------- 인스타그램 ----------
def _gv():
    return secure.get("IG_GRAPH_VERSION") or "v21.0"


def graph_base():
    return (os.environ.get("AUTOPOST_GRAPH_BASE") or "https://graph.facebook.com").rstrip("/")


def _get(url, params, s):
    r = s.get(url, params=params, timeout=30)
    try:
        j = r.json()
    except ValueError:
        j = {}
    if r.status_code >= 400 or "error" in j:
        raise RuntimeError(j.get("error", {}).get("message", f"HTTP {r.status_code}"))
    return j


def exchange_instagram_token(short_token, session=None, aid="main"):
    """단기 토큰 → 60일 장기 토큰 + 인스타 비즈니스 계정 ID 자동 찾기 (계정별 암호화 저장)"""
    from .accounts import env_key
    s, e = session or requests, secure.all_values()
    if not e.get("META_APP_ID") or not e.get("META_APP_SECRET"):
        raise RuntimeError("Meta 앱 ID와 앱 시크릿을 먼저 저장해 주세요")
    t = _get(f"{graph_base()}/{_gv()}/oauth/access_token",
             {"grant_type": "fb_exchange_token", "client_id": e["META_APP_ID"], "client_secret": e["META_APP_SECRET"], "fb_exchange_token": short_token}, s)
    expires = (datetime.now() + timedelta(seconds=int(t.get("expires_in") or 60 * 86400))).isoformat(timespec="seconds")
    ig_id = e.get(env_key("IG_USER_ID", aid))
    if not ig_id:
        taken = {v for k, v in e.items() if k.startswith("IG_USER_ID")}
        pages = _get(f"{graph_base()}/{_gv()}/me/accounts", {"fields": "name,instagram_business_account", "access_token": t["access_token"]}, s)
        ig_id = next((p["instagram_business_account"]["id"] for p in pages.get("data", []) if p.get("instagram_business_account")
                      and p["instagram_business_account"]["id"] not in taken), None)
    secure.set_many({env_key("IG_ACCESS_TOKEN", aid): t["access_token"], env_key("IG_TOKEN_EXPIRES", aid): expires,
                     **({env_key("IG_USER_ID", aid): ig_id} if ig_id else {})})
    log("INFO", f"[instagram {aid}] 장기 토큰 저장 (만료 {expires[:10]})" + ("" if ig_id else " - 인스타 비즈니스 계정을 찾지 못함"))
    if ig_id:
        from . import tasks
        tasks.on_connected("instagram", aid)
    return {"ok": bool(ig_id), "expires": expires, "igUserId": ig_id,
            **({} if ig_id else {"error": "토큰은 저장했지만 페이스북 페이지에 연결된 인스타 비즈니스 계정을 찾지 못했어요"})}


def refresh_instagram_if_needed(days=10, session=None):
    from .accounts import env_key
    e, out = secure.all_values(), {}
    aids = ["main"] + sorted(k.split("__", 1)[1] for k in e if k.startswith("IG_ACCESS_TOKEN__"))
    for aid in aids:
        tok, exp = e.get(env_key("IG_ACCESS_TOKEN", aid)), e.get(env_key("IG_TOKEN_EXPIRES", aid))
        if not tok or not exp:
            continue
        try:
            left = (datetime.fromisoformat(exp) - datetime.now()).days
        except ValueError:
            left = 0
        if left > days:
            continue
        try:
            out[aid] = exchange_instagram_token(tok, session, aid)
        except Exception as err:  # noqa: BLE001
            log("ERROR", f"[instagram {aid}] 토큰 자동 갱신 실패: {err}")
            out[aid] = {"ok": False}
    return out


def check_instagram(session=None, aid="main"):
    from .accounts import env_key
    e = secure.all_values()
    uid, tok = e.get(env_key("IG_USER_ID", aid)), e.get(env_key("IG_ACCESS_TOKEN", aid))
    if not uid or not tok:
        return {"ok": False, "state": "none"}
    try:
        j = _get(f"{graph_base()}/{_gv()}/{uid}", {"fields": "username", "access_token": tok}, session or requests)
        return {"ok": True, "username": j.get("username"), "expires": e.get(env_key("IG_TOKEN_EXPIRES", aid))}
    except Exception as err:  # noqa: BLE001
        return {"ok": False, "state": "error", "error": str(err)[:150]}
