# -*- coding: utf-8 -*-
"""채널별 계정 (네이버 블로그·티스토리·인스타: 여러 개 / 원주.kr: 1개)
계정마다: 브라우저 프로필(또는 토큰), 하루 발행 수, 카테고리, 전용 키워드(선택), 목소리(선택)"""
import re

MULTI = ("naver", "guide", "cafe", "tistory", "instagram", "x", "threads", "facebook", "band", "manual")
ALL = ("naver", "guide", "cafe", "tistory", "wonju", "instagram", "x", "threads", "facebook", "band", "manual")
MAX_ACCOUNTS = {"naver": 10, "guide": 10, "cafe": 10, "tistory": 10, "instagram": 10, "x": 10, "threads": 10, "facebook": 10, "band": 10, "manual": 10, "wonju": 1}
IG_ENV = ("IG_USER_ID", "IG_ACCESS_TOKEN", "IG_TOKEN_EXPIRES")
X_ENV = ("X_ACCESS_TOKEN", "X_ACCESS_SECRET")
# 계정마다 정할 수 있는 값 (비우면 전체 기본값 사용)
ACCOUNT_DEFAULTS = {"handle": "", "postsPerDay": 1, "enabled": True, "categories": [], "keywords": [], "voice": "", "prompt": "",
                    "private": False, "place": True, "block": "basic", "position": "bottom",
                    "topics": [], "style": {}}


def _main_from_legacy(cfg, ch):
    c = cfg.get("channels", {}).get(ch, {})
    a = new_account("main", "ID 1")
    a.update(handle=c.get("blogId") or c.get("blogName") or ("원주.kr" if ch == "wonju" else ""),
             postsPerDay=int(c.get("postsPerDay") or 0) if ch not in ("guide", "cafe", "x", "threads", "facebook", "band", "manual") else 0, enabled=bool(c.get("enabled", True)),
             categories=list(cfg.get("accounts", {}).get(ch, {}).get("categories", [])))
    return a


def new_account(aid, label):
    return {"id": aid, "label": label, **{k: (list(v) if isinstance(v, list) else v) for k, v in ACCOUNT_DEFAULTS.items()}}


def list_accounts(cfg, ch):
    a = cfg.setdefault("accounts", {}).setdefault(ch, {})
    if not a.get("list"):
        a["list"] = [_main_from_legacy(cfg, ch)]
    for x in a["list"]:
        # 예전 기본값으로 들어 있던 카테고리('가게 이야기' 등)는 블로그에 없는 경우가 많아 발행이 멈췄음 → 사장님이 직접 고른 게 아니면 비움
        if not x.get("catConfirmed") and x.get("categories") in (["가게 이야기", "메뉴 소개", "동네 이야기"], ["가게 이야기"]):
            x["categories"] = []
        x.setdefault("hold", ch in ("cafe", "band", "manual"))
        if ch in ("cafe", "band", "manual"):   # 커뮤니티·수동 채널은 항상 '확인 후 등록'
            x["hold"] = True
        for k, v in ACCOUNT_DEFAULTS.items():
            x.setdefault(k, list(v) if isinstance(v, list) else v)
    return a["list"]


def get(cfg, ch, aid):
    return next((x for x in list_accounts(cfg, ch) if x["id"] == (aid or "main")), None)


def profile_name(ch, aid):
    """브라우저 프로필 폴더 이름 = 계정 식별자 (ID 1 은 예전과 같은 이름 → 기존 로그인 유지)"""
    return ch if (aid or "main") == "main" else f"{ch}-{aid}"


def split_profile(prof):
    ch, _, aid = prof.partition("-")
    return ch, aid or "main"


def env_key(base, aid):
    return base if (aid or "main") == "main" else f"{base}__{aid}"


def valid_id(aid):
    return aid == "main" or bool(re.fullmatch(r"a[0-9]{1,3}", aid or ""))


def new_id(cfg, ch):
    ids = {x["id"] for x in list_accounts(cfg, ch)}
    n = 2
    while f"a{n}" in ids:
        n += 1
    return f"a{n}"


def sync_legacy(cfg):
    """예전 필드(channels.*.postsPerDay/enabled)를 계정 목록 기준으로 맞춤"""
    for ch in ALL:
        lst = list_accounts(cfg, ch)
        c = cfg.setdefault("channels", {}).setdefault(ch, {})
        c["postsPerDay"] = sum(int(x.get("postsPerDay") or 0) for x in lst if x.get("enabled", True))
        c["enabled"] = c["postsPerDay"] > 0
    return cfg


def label(cfg, ch, aid):
    a = get(cfg, ch, aid)
    if not a:
        return aid or ""
    return f"{a['label']}" + (f" ({a['handle']})" if a.get("handle") and ch != "wonju" else "")
