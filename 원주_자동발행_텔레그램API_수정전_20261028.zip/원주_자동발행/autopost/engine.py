# -*- coding: utf-8 -*-
"""자동 발행 엔진 (스레드 1개가 순서대로 처리 → 동시 실행 충돌 없음)

매 주기(기본 20초)마다:
  1) 자동 모드면 오늘 계획 세우기: 계정별 하루 발행 수만큼 '생성 대기' 작업을 활동 시간 안에 무작위·간격 두고 배치
  2) 시간이 된 작업: 계정 연결 확인 → 안 되어 있으면 '연결 필요'(글 안 만듦) / 되어 있으면 글 생성
  3) 발행 대기 작업 1건 발행: 브라우저는 한 번에 하나, 같은 계정은 최소 N분(기본 5분) 간격
  4) 하루 1번: 인스타 토큰 갱신 / 1주 1번: 네이버 플레이스 가게 정보·사진 갱신
"""
import hashlib, json, os, random, threading
from datetime import datetime, timedelta
from . import generator as g, tasks as T, accounts as A
from .util import CHANNELS, CH_NAME, BROWSER_CHANNELS, load_config, is_dry, log


def plan_accounts(slots, window, gap, rnd=random.random):
    """slots: [계정id …](하루 발행 수만큼 반복), window: (시작분, 끝분), gap: 글 사이 최소 간격(분)
    → [(분, 계정id)] 모든 글이 gap 이상 떨어지고 같은 계정이 연달아 오지 않게 무작위 배치. 모자라면 들어가는 만큼만"""
    start, end = window
    span = end - start
    n = len(slots)
    while n > 1 and (n - 1) * gap > span:
        n -= 1
    order = _interleave(slots, rnd)
    keep, dropped = order[:n], order[n:]
    slack = span - (n - 1) * gap if n else 0
    pts = sorted(rnd() * slack for _ in range(n))
    return [(int(start + p + i * gap), a) for i, (p, a) in enumerate(zip(pts, keep))], dropped


def _interleave(slots, rnd):
    left = {}
    for a in slots:
        left[a] = left.get(a, 0) + 1
    out = []
    while left:
        cands = sorted(left, key=lambda a: (-left[a], rnd()))
        pick = next((a for a in cands if not out or a != out[-1]), cands[0])
        out.append(pick)
        left[pick] -= 1
        if not left[pick]:
            del left[pick]
    return out


def _state_path():
    return os.path.join(g.ROOT, "data", "engine_state.json")


def _state():
    try:
        with open(_state_path(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_state(s):
    os.makedirs(os.path.dirname(_state_path()), exist_ok=True)
    with open(_state_path(), "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=1)


def plan_signature(cfg):
    sch = cfg.get("schedule", {})
    acc = {ch: [(a["id"], int(a.get("postsPerDay") or 0), bool(a.get("enabled", True))) for a in A.list_accounts(cfg, ch)] for ch in CHANNELS}
    raw = json.dumps([acc, sch.get("activeHours"), sch.get("accountGapMinutes"), bool(cfg.get("auto"))], sort_keys=True)
    return hashlib.sha1(raw.encode()).hexdigest()[:12]


def plan_today(cfg=None, now=None, force=False, rnd=random.random):
    """오늘 남은 시간에 자동 작업 배치. 설정이 바뀌면 아직 시작 안 한 자동 작업만 다시 배치"""
    cfg = cfg or load_config()
    now = now or datetime.now()
    day = now.strftime("%Y-%m-%d")
    st = _state()
    sig = plan_signature(cfg)
    if not force and st.get("planDay") == day and st.get("planSig") == sig:
        return st.get("plan", [])
    T.cancel_stale(day)
    removed = T.cancel_pending_auto(day)
    plan = []
    if cfg.get("auto"):
        sch = cfg.get("schedule", {})
        h0, h1 = tuple(sch.get("activeHours", [9, 21]))
        gap = max(1, int(sch.get("accountGapMinutes", 90)))
        w0 = (max(h0 * 60, now.hour * 60 + now.minute + 1), h1 * 60)
        done = T.counts_today()
        base = now.replace(hour=0, minute=0, second=0, microsecond=0)
        for ch in CHANNELS:
            slots = []
            for a in A.list_accounts(cfg, ch):
                if a.get("enabled", True):
                    slots += [a["id"]] * max(0, int(a.get("postsPerDay") or 0) - done.get((ch, a["id"]), 0))
            if not slots or w0[0] >= w0[1]:
                continue
            planned, dropped = plan_accounts(slots, w0, gap, rnd)
            if dropped:
                log("WARN", f"[{CH_NAME[ch]}] 남은 시간에 {gap}분 간격을 지키며 넣을 수 없어 {len(dropped)}건은 오늘 건너뜀")
            for m, aid in planned:
                at = base + timedelta(minutes=m, seconds=int(rnd() * 50))
                acc = A.get(cfg, ch, aid)
                jid = T.add(ch, aid, A.label(cfg, ch, aid), auto=True, scheduled_at=at.isoformat(timespec="seconds"),
                            settings=T.job_defaults(acc))
                plan.append({"id": jid, "channel": ch, "account": aid, "at": at.isoformat(timespec="seconds")})
        log("INFO", f"오늘 자동 발행 계획: {len(plan)}건" + (f" (이전 미시작 {removed}건 다시 배치)" if removed else ""))
    elif removed:
        log("INFO", f"자동 모드 꺼짐 → 아직 시작 안 한 자동 작업 {removed}건 취소")
    st.update(planDay=day, planSig=sig, plan=plan)
    _save_state(st)
    return plan


def _gap_ok(cfg, ch, aid, now):
    """같은 계정은 최소 N분, 브라우저 발행은 전체적으로 최소 M초 간격"""
    sch = cfg.get("schedule", {})
    scale = max(1.0, float(os.environ.get("AUTOPOST_TIME_SCALE") or 1))
    last = T.last_published(ch, aid)
    if last and now < datetime.fromisoformat(last) + timedelta(minutes=float(sch.get("sameAccountGapMinutes", 5)) / scale):
        return False
    if ch in BROWSER_CHANNELS:
        lg = T.last_live_publish()
        if lg and now < datetime.fromisoformat(lg) + timedelta(seconds=float(sch.get("browserGapSeconds", 60)) / scale):
            return False
    return True


class Engine:
    def __init__(self, tick=None):
        self.tick_s = float(tick or os.environ.get("AUTOPOST_TICK") or 20)
        self.wake = threading.Event()
        self.stop_ev = threading.Event()
        self.thread = None
        self.busy = ""
        T.on_change(lambda: None)

    def start(self):
        T.recover_after_restart()
        self.thread = threading.Thread(target=self._loop, daemon=True, name="engine")
        self.thread.start()
        log("INFO", "자동 발행 엔진 시작")

    def poke(self):
        self.wake.set()

    def shutdown(self):
        self.stop_ev.set()
        self.wake.set()
        if self.thread:
            self.thread.join(30)

    def _loop(self):
        while not self.stop_ev.is_set():
            try:
                self.tick()
            except Exception as e:  # noqa: BLE001
                log("ERROR", f"엔진 오류(계속 실행): {e}")
            self.wake.wait(self.tick_s)
            self.wake.clear()

    def tick(self, now=None):
        cfg = load_config()
        now = now or datetime.now()
        plan_today(cfg, now)
        self.publish_one(cfg, now)        # 시간이 된 발행부터 (글 만들기 때문에 늦어지지 않게)
        lead = float((cfg.get("schedule") or {}).get("pregenMinutes", 15))
        for jid in T.due_generation(now, lead_minutes=lead):
            if self.stop_ev.is_set():
                return
            self.busy = f"글 생성 #{jid}"
            T.generate_job(jid)
            self.busy = ""
            self.publish_one(cfg, datetime.now())   # 글 하나 만들 때마다 시간이 된 발행을 바로 처리
        self.busy = ""
        self.maintenance(cfg, now)

    def publish_one(self, cfg=None, now=None):
        from .browser import BROWSER_LOCK, profile_lock
        from .readiness import account_ready
        cfg = cfg or load_config()
        now = now or datetime.now()
        dry = is_dry(cfg)
        for jid in T.ready_to_publish(now):
            t = T.get(jid)
            if not t:
                continue
            ch, aid = t["channel"], t["account_id"]
            if not dry:
                st = account_ready(cfg, ch, aid)
                if not st["ok"]:
                    T.update(jid, status=T.S_NEED, error=st["text"])
                    continue
                if not _gap_ok(cfg, ch, aid, now):
                    continue
            plock = profile_lock(A.profile_name(ch, aid))
            if not plock.acquire(blocking=False):   # 로그인 창·연결 확인 중인 계정은 건너뜀
                continue
            try:
                with BROWSER_LOCK:
                    if not dry and not _gap_ok(cfg, ch, aid, datetime.now()):   # 잠금을 잡은 뒤 간격을 다시 확인
                        continue
                    self.busy = f"발행 #{jid} ({CH_NAME[ch]})"
                    T.publish_job(jid, cfg)
            finally:
                plock.release()
                self.busy = ""
            return jid   # 한 주기에 한 건만 → 다음 건은 간격을 두고
        return None

    def maintenance(self, cfg, now):
        st = _state()
        day = now.strftime("%Y-%m-%d")
        if st.get("tokenDay") != day and now.hour >= 4:
            st["tokenDay"] = day
            _save_state(st)
            try:
                from .connect import refresh_instagram_if_needed
                refresh_instagram_if_needed()
            except Exception as e:  # noqa: BLE001
                log("WARN", f"인스타 토큰 갱신 확인 실패: {e}")
            try:
                from .library import cleanup_variants
                cleanup_variants()
            except Exception as e:  # noqa: BLE001
                log("WARN", f"사진 사본 정리 실패: {e}")
        pid = cfg["shop"].get("naverPlaceId")
        last = st.get("placeAt", "")
        if pid and cfg.get("place", {}).get("autoRefresh", True) and cfg.get("auto") and \
                (not last or datetime.fromisoformat(last) < now - timedelta(days=7)) and 5 <= now.hour < 9:
            st["placeAt"] = now.isoformat(timespec="seconds")
            _save_state(st)
            try:
                from . import place, library
                self.busy = "플레이스 정보 갱신"
                place.import_place(pid, cfg, apply=True, download=True)
                library.import_place_photos(load_config())
            except Exception as e:  # noqa: BLE001
                log("WARN", f"[플레이스 갱신] {e}")
            finally:
                self.busy = ""

        if st.get("styleDay") != day and cfg.get("styleAutoLearn", True):
            st["styleDay"] = day
            _save_state(st)
            from . import style, accounts as A
            from .util import save_config
            for ch, aid in style.due_accounts(cfg, now)[:5]:
                try:
                    self.busy = "기존 글 스타일 다시 학습"
                    c2 = load_config()
                    acc = A.get(c2, ch, aid)
                    style.learn(c2, ch, acc)
                    save_config(c2)
                except Exception as e:  # noqa: BLE001
                    log("WARN", f"[스타일 학습] {ch} {aid}: {str(e)[:120]}")
                finally:
                    self.busy = ""

    def status(self):
        st = _state()
        return {"busy": self.busy, "plan": st.get("plan", []), "planDay": st.get("planDay")}
