# -*- coding: utf-8 -*-
"""원주.kr 홈페이지(닷홈): 글을 HTML 파일로 만들어 FTP 로 업로드
- 글: /html/blog/날짜-키워드.html  (목록 index.html 도 갱신)
- 사진: /html/photos/  (EXIF 지운 자료함 사진)
"""
import html as H, json, os, re, shutil
from datetime import datetime
from .. import generator as g, images as imgmod


def slugify(post):
    base = re.sub(r"[^\w]+", "-", post.get("keyword") or "post").strip("-")[:40] or "post"
    return f"{datetime.now():%Y-%m-%d-%H%M}-{base}"


def render_html(post, cfg):
    e = H.escape
    desc = e(g.strip_html(post["body_html"])[:150])
    body = imgmod.render_markers(post["body_html"], post.get("images") or [], "relative")
    shop = cfg["shop"]
    ld = {"@context": "https://schema.org", "@type": "BlogPosting", "headline": post["title"], "datePublished": datetime.now().isoformat(timespec="seconds"),
          "author": {"@type": "Person", "name": f"{shop['name']} 사장"}, "publisher": {"@type": "Restaurant", "name": shop["name"], "address": shop.get("address", "")}}
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(post['title'])} | {e(shop['name'])}</title><meta name="description" content="{desc}">
<meta property="og:title" content="{e(post['title'])}"><meta property="og:description" content="{desc}">
<script type="application/ld+json">{json.dumps(ld, ensure_ascii=False).replace("</", "<\\/")}</script>
<style>body{{max-width:760px;margin:auto;padding:16px;font-family:'Malgun Gothic',sans-serif;line-height:1.8;color:#222}}img{{max-width:100%;height:auto;border-radius:8px}}h1{{font-size:26px}}</style></head>
<body><article><h1>{e(post['title'])}</h1>{body}
<p style="color:#888">{' '.join('#' + e(t.replace(' ', '')) for t in post.get('tags', []))}</p></article>
<p><a href="./index.html">← 이야기 목록</a> · <a href="{e(shop['url'])}">홈으로</a></p></body></html>"""


def update_index(out_dir, cfg):
    items = sorted([f for f in os.listdir(out_dir) if f.endswith(".html") and f != "index.html"], reverse=True)
    li = []
    for f in items[:300]:
        with open(os.path.join(out_dir, f), encoding="utf-8") as fp:
            m = re.search(r"<h1>(.*?)</h1>", fp.read())
        li.append(f'<li><a href="./{H.escape(f)}">{m.group(1) if m else H.escape(f)}</a> <small>{f[:10]}</small></li>')
    name = H.escape(cfg["shop"]["name"])
    with open(os.path.join(out_dir, "index.html"), "w", encoding="utf-8") as fp:
        fp.write(f'<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                 f'<title>{name} 이야기</title><style>body{{max-width:760px;margin:auto;padding:16px;font-family:sans-serif;line-height:1.9}}</style></head>'
                 f'<body><h1>{name} 이야기</h1><ul>{"".join(li)}</ul></body></html>')


def ftp_test():
    with imgmod.ftp_connect(15) as ftp:
        return ftp.nlst()[:20]


def publish(post, dry, cfg, account=None, channel=None):
    site = cfg.get("wonjuSite", {})
    sub = "dry" if dry else "live"
    out_dir = os.path.join(g.ROOT, "out", sub, "site", "blog")
    os.makedirs(out_dir, exist_ok=True)
    name = slugify(post) + ".html"
    f = os.path.join(out_dir, name)
    with open(f, "w", encoding="utf-8") as fp:
        fp.write(render_html(post, cfg))
    update_index(out_dir, cfg)
    pdir = os.path.join(os.path.dirname(out_dir), "photos")
    os.makedirs(pdir, exist_ok=True)
    for im in post.get("images") or []:
        shutil.copy(im["path"], os.path.join(pdir, im["name"]))
    if dry:
        return {"ok": True, "dry": True, "file": f, "preview": {"file": name, "images": len(post.get("images") or [])}}
    blog_dir = site.get("remoteDir", "/html/blog")
    with imgmod.ftp_connect() as ftp:
        if post.get("images"):
            imgmod.ftp_cd(ftp, (cfg.get("images") or {}).get("remoteDir", "/html/photos"))
            for im in post["images"]:
                with open(im["path"], "rb") as fp:
                    ftp.storbinary("STOR " + im["name"], fp)
        imgmod.ftp_cd(ftp, blog_dir)
        for p in (f, os.path.join(out_dir, "index.html")):
            with open(p, "rb") as fp:
                ftp.storbinary("STOR " + os.path.basename(p), fp)
    url = cfg["shop"]["url"].rstrip("/") + "/" + blog_dir.replace("/html", "", 1).strip("/") + "/" + name
    return {"ok": True, "url": url, "file": f}
