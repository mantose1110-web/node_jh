# -*- coding: utf-8 -*-
"""네이버 블로그: 공식 글쓰기 API 종료(2020) → 스마트에디터 ONE 화면 자동 조작

- 로그인한 계정 프로필 + 저장된 세션 쿠키로 같은 세션을 이어 씀 (connect.py 참고)
- 단계별로 진행 상황을 로그에 남기고, 실패하면 '어느 단계에서 왜' + 스크린샷 경로를 남김
- 화면 구조가 바뀌면 SEL 만 고치면 됩니다
호출하는 쪽(engine)에서 BROWSER_LOCK 과 계정 profile_lock 을 잡고 부름 (동시 실행 방지)
"""
import re
from ..browser import launch_profile, safe_goto, shot, restore_cookies, save_cookies, work_page
from ..util import log
from .tistory import _tags
import os
PUBLISH_WAIT_MS = int(os.environ.get("AUTOPOST_PUBLISH_WAIT_MS") or 60000)

SEL = {
    "popup_cancel": ".se-popup-button-cancel",                  # '작성 중인 글이 있습니다' → 취소(새 글)
    "help_close": ".se-help-panel-close-button, .se-help-close-button",
    "tooltip_close": ".se-tooltip-close-button, button[class*='tooltip'][class*='close']",
    "title": ".se-documentTitle .se-text-paragraph, .se-title-text .se-text-paragraph, .se-title-text",
    "body_para": ".se-component.se-text .se-text-paragraph",
    "image_btn": "button.se-image-toolbar-button, button[data-name='image']",
    "image_comp": ".se-component.se-image",
    "map_btn": "button.se-map-toolbar-button, button[data-name='map']",
    # 주의: 화면 아래 '글감을 검색해 보세요.' 입력칸도 placeholder 에 '검색'이 있음 → 장소 팝업 안의 입력칸만 써야 함
    "map_search": ".se-place-search-input, input[placeholder*='장소']",
    "map_popup": ".se-popup-placesMap, [class*='placesMap'], [class*='popup'][class*='place'], [class*='place'][class*='layer']",
    "map_result": ".se-place-map-search-result-item, li[class*='place_item'], li[class*='search_result']",
    "map_item_add": "button[class*='add'], .se-place-add-button-inner",
    "map_add": ".se-place-add-button, button[class*='add_button']",
    "map_confirm": ".se-popup-button-confirm, button[class*='confirm']",
    "map_close": ".se-popup-close-button, .se-place-close-button, button[class*='close']",
    "map_empty": ".se-place-no-result, [class*='no_result'], [class*='empty']",
    "map_done": ".se-component.se-placesMap, .se-component.se-place",
    "publish": "button[class*='publish_btn']",
    "category_btn": "button[class*='selectbox_button']",
    "category_item": "[class*='option_list'] [class*='item'], [class*='option_list'] li",
    "tag": "input#tag-input, input[class*='tag_input'], input[placeholder*='태그']",
    "confirm": "button[class*='confirm_btn']",
    "vis_public": "input#open_public",
    "vis_private": "input#open_private",
}


class PublishError(RuntimeError):
    pass


def to_plain(post):
    """본문 HTML → 줄 목록. 소제목은 '##' 표시, 사진 자리는 [[IMG:n]] 단독 줄"""
    h = re.sub(r"<!--.*?-->", "", post["body_html"], flags=re.S)
    h = re.sub(r"\[\[IMG:(\d+)\]\]", r"\n[[IMG:\1]]\n", h)
    h = re.sub(r"<h[23][^>]*>", "\n## ", h)
    h = re.sub(r"</(p|h2|h3|li|div|ul|ol)>|<br\s*/?>", "\n", h).replace("<li>", "• ")
    t = re.sub(r"<[^>]+>", "", h).replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&#x27;", "'").replace("&nbsp;", " ")
    lines = [ln.strip() for ln in t.split("\n")]
    out = []
    for ln in lines:
        if ln or (out and out[-1]):
            out.append(ln)
    return "\n".join(out).strip()


def preview(post, acc):
    return {"account": acc.get("label", "ID 1"), "blogId": acc.get("handle") or "(미설정)", "title": post["title"],
            "text": to_plain(post)[:400] + "…", "images": len(post.get("images") or []), "tags": post.get("tags"),
            "category": post.get("category"), "visibility": "비공개" if post.get("private") else "전체공개"}


def _click_if_visible(fr, sel):
    try:
        loc = fr.locator(sel)
        if loc.count() and loc.first.is_visible():
            loc.first.click(timeout=3000)
            return True
    except Exception:  # noqa: BLE001
        pass
    return False


def _click(fr, loc, timeout=15000):
    """클릭이 안내창에 가려 실패하면 안내창을 닫고 한 번 더 누름"""
    try:
        loc.click(timeout=min(timeout, 6000))
    except Exception:  # noqa: BLE001
        _dismiss_popups(fr)
        loc.click(timeout=timeout)


def _dismiss_popups(fr):
    """나타났다 사라지는 안내창(작성 중인 글·도움말·말풍선)을 닫음. 여러 번 불러도 안전"""
    n = 0
    for k in ("popup_cancel", "help_close", "tooltip_close"):
        if _click_if_visible(fr, SEL[k]):
            n += 1
    return n


def _body_text(fr):
    try:
        return " ".join(fr.locator(SEL["body_para"]).all_inner_texts())
    except Exception:  # noqa: BLE001
        return ""


def place_queries(cfg):
    """지도 검색어 후보 (네이버에 등록된 이름은 '아산 원주통닭 본점'이 아닐 수 있어 여러 개를 차례로 시도)"""
    pc = cfg.get("place") or {}
    shop = cfg["shop"]
    qs = [q for q in (pc.get("mapQueries") or []) if q.strip()]
    brand = shop.get("brand") or "원주통닭"
    qs += [f"{brand} 아산 온천동", f"{brand} 온천동", f"{brand} 아산", brand, re.sub(r"\(.*?\)", "", shop.get("address", "")).strip()]
    return list(dict.fromkeys(q for q in qs if q))


def place_match(text, cfg):
    """검색 결과 한 줄이 '우리 가게'인지: 상호가 있고 주소 확인 문구(기본: 시민로 386)가 들어 있어야 함"""
    pc = cfg.get("place") or {}
    brand = cfg["shop"].get("brand") or "원주통닭"
    must = [m for m in (pc.get("mapMatch") or ["시민로 386", "시민로386"]) if m.strip()]
    t = re.sub(r"\s+", " ", text or "")
    return brand in t and any(m in t or m.replace(" ", "") in t.replace(" ", "") for m in must)


def _place_popup(fr, box):
    """장소 검색창이 들어 있는 팝업 (닫기·확인 버튼을 이 안에서만 찾음 → 옆 '라이브러리' 닫기 버튼을 잘못 누르지 않음)"""
    pop = box.locator("xpath=ancestor::*[contains(@class,'popup') or contains(@class,'layer') or @role='dialog'][1]")
    return pop if pop.count() else fr.locator("body")


def _visible(loc):
    try:
        return loc.count() > 0 and loc.first.is_visible()
    except Exception:  # noqa: BLE001
        return False


def _find_place_box(fr, timeout=10):
    """장소 팝업 안의 검색 입력칸만 찾음 ('글감 검색'·본문 다른 입력칸은 제외). 못 찾으면 None"""
    import time as _t
    end = _t.time() + timeout
    while _t.time() < end:
        cands = [fr.locator(SEL["map_search"])]
        pops = fr.locator(SEL["map_popup"])
        for i in range(pops.count()):
            if _visible(pops.nth(i)):
                cands.append(pops.nth(i).locator("input[type='text'], input:not([type]), input[type='search']"))
        for c in cands:
            for i in range(c.count()):
                el = c.nth(i)
                try:
                    ph = (el.get_attribute("placeholder") or "") + " " + (el.get_attribute("class") or "")
                    if el.is_visible() and "글감" not in ph and "material" not in ph.lower():
                        return el
                except Exception:  # noqa: BLE001
                    pass
        _t.sleep(0.3)
    return None


def _place_popup_open(fr, box):
    """장소 팝업이 아직 떠 있는지 (입력칸이 화면에서 사라졌으면 닫힌 것)"""
    try:
        if box is not None and box.count() and box.is_visible():
            return True
    except Exception:  # noqa: BLE001
        pass
    pops = fr.locator(SEL["map_popup"])
    return any(_visible(pops.nth(i)) for i in range(pops.count()))


def _close_place_popup(fr, page, box):
    pop = _place_popup(fr, box) if box is not None else fr.locator(SEL["map_popup"])
    for sel in (".se-popup-close-button", "button[class*='close']", "button[aria-label*='닫기']"):
        try:
            b = pop.locator(sel)
            if b.count() and b.first.is_visible():
                b.first.click(timeout=3000)
                break
        except Exception:  # noqa: BLE001
            pass
    page.wait_for_timeout(400)
    for _ in range(2):
        if not _place_popup_open(fr, box):
            break
        page.keyboard.press("Escape")
        page.wait_for_timeout(500)
    return not _place_popup_open(fr, box)


def _confirm_enabled(btn):
    try:
        return btn.count() > 0 and btn.first.is_visible() and btn.first.is_enabled() and \
            "disabled" not in (btn.first.get_attribute("class") or "") and btn.first.get_attribute("aria-disabled") != "true"
    except Exception:  # noqa: BLE001
        return False


def _select_place_item(fr, page, pop, item):
    """검색 결과 고르기: 줄에 마우스를 올리면 나오는 '추가' 버튼을 누르고 → '확인'이 눌릴 수 있게 되면 확인"""
    confirm = pop.locator(SEL["map_confirm"] + ", button:has-text('확인')")
    item.scroll_into_view_if_needed(timeout=3000)
    for how in ("hover-add", "click", "click-add", "dblclick"):
        if how in ("hover-add", "click-add"):
            if how == "click-add":
                item.click(timeout=3000)
            item.hover(timeout=3000)
            page.wait_for_timeout(400)
            add = item.locator("button").filter(has_text=re.compile(r"추가|선택"))
            if not add.count():
                add = item.locator(SEL["map_item_add"] + ", " + SEL["map_add"])
            if add.count():
                add.first.click(timeout=3000, force=True)
        elif how == "click":
            item.click(timeout=3000)
        else:
            item.dblclick(timeout=3000)
        for _ in range(8):
            page.wait_for_timeout(300)
            if fr.locator(SEL["map_done"]).count():
                return True
            if _confirm_enabled(confirm):
                confirm.first.click(timeout=5000)
                return True
    return False


def _attach_place(fr, page, cfg, prof):
    """장소(지도) 첨부: 검색어를 차례로 넣어 보고 주소가 맞는 결과만 고름 → 추가 → 확인.
    못 찾거나 확인이 안 눌리면 팝업을 닫고 지도 없이 진행(엉뚱한 가게 방지, 팝업이 화면을 막지 않게)"""
    tried = []
    before = fr.locator(SEL["map_done"]).count()
    _click(fr, fr.locator(SEL["map_btn"]).first, 8000)
    box = _find_place_box(fr, 10)
    if box is None:
        closed = _close_place_popup(fr, page, None)
        log("WARN", f"[네이버 {prof}] '장소' 버튼을 눌렀지만 장소 검색칸을 찾지 못해 지도 없이 발행해요 (SEL['map_search'] 확인 필요)")
        if not closed:
            raise PublishError("장소 창이 닫히지 않아 발행을 멈췄어요")
        return False
    pop = _place_popup(fr, box)
    for q in place_queries(cfg):
        box.click()
        box.fill("")
        box.type(q, delay=30)
        box.press("Enter")
        items = pop.locator(SEL["map_result"])
        for _ in range(16):            # 결과(또는 '결과 없음')를 최대 8초 기다림
            page.wait_for_timeout(500)
            if items.count() or (pop.locator(SEL["map_empty"]).count() and pop.locator(SEL["map_empty"]).first.is_visible()):
                break
        page.wait_for_timeout(400)
        seen = [re.sub(r"\s+", " ", t)[:60] for t in items.all_inner_texts()[:6]]
        tried.append(f"'{q}' → {len(seen)}건")
        hit = next((i for i, t in enumerate(seen) if place_match(t, cfg)), None)
        log("INFO", f"[네이버 {prof}] 지도 검색 '{q}': {len(seen)}건 {seen[:3]}" + (f" → {hit + 1}번째 선택" if hit is not None else ""))
        if hit is None:
            continue
        if not _select_place_item(fr, page, pop, items.nth(hit)):
            tried.append("우리 가게는 찾았지만 '추가/확인'이 눌리지 않음")
            break
        try:
            fr.locator(SEL["map_done"]).nth(before).wait_for(timeout=15000)
        except Exception:  # noqa: BLE001
            tried.append("확인 후 지도가 본문에 안 들어옴")
            break
        txt = fr.locator(SEL["map_done"]).last.inner_text(timeout=5000)
        if (cfg["shop"].get("brand") or "원주통닭") not in txt:
            raise PublishError(f"지도에 다른 장소가 들어갔어요: {txt[:40]}")
        log("INFO", f"[네이버 {prof}] 지도 첨부 완료: {re.sub(chr(10), ' ', txt)[:60]}")
        return True
    closed = _close_place_popup(fr, page, box)
    log("WARN", f"[네이버 {prof}] 지도 첨부는 건너뛰고 발행해요 (시도: {', '.join(tried)}; 팝업 {'닫음' if closed else '안 닫힘'}). "
                "본문 아래 가게 안내·지도 링크는 그대로 있어요")
    if not closed:
        raise PublishError("장소 검색 창이 닫히지 않아 발행을 멈췄어요")
    return False


def type_body(fr, page, lines, imgs, prof, label="네이버"):
    """스마트에디터 본문 입력: 줄마다 타이핑, [[IMG:n]] 자리에서 사진 업로드 (블로그·카페 공용)"""
    uploaded = 0
    for line in lines:
        m = re.fullmatch(r"\[\[IMG:(\d+)\]\]", line.strip())
        if m:
            n = int(m.group(1))
            if n >= len(imgs):
                continue
            before = fr.locator(SEL["image_comp"]).count()
            _dismiss_popups(fr)
            try:
                with page.expect_file_chooser(timeout=20000) as fc:
                    _click(fr, fr.locator(SEL["image_btn"]).first)
                fc.value.set_files(imgs[n]["path"])
                fr.locator(SEL["image_comp"]).nth(before).wait_for(timeout=60000)
            except Exception as e:  # noqa: BLE001
                raise PublishError(f"사진 업로드 {uploaded + 1}/{len(imgs)} 실패: {str(e).splitlines()[0][:150]}") from None
            uploaded += 1
            page.wait_for_timeout(800)
            _caret_to_end(fr, page)
            continue
        if line.startswith("## "):
            page.keyboard.press("Control+b")
            page.keyboard.type(line[3:], delay=4)
            page.keyboard.press("Control+b")
        elif line:
            page.keyboard.type(line, delay=4)
        page.keyboard.press("Enter")
    return uploaded


def _caret_to_end(fr, page):
    para = fr.locator(SEL["body_para"])
    _click(fr, para.last, 10000)
    page.keyboard.press("End")


VIS_JS = """(want) => {
  const norm = t => (t || '').replace(/\\s+/g, '');
  const radios = [...document.querySelectorAll('input[type=radio]')];
  const info = radios.map(r => {
    const lab = (r.labels && r.labels[0]) || r.closest('label') || (r.id && document.querySelector('label[for="' + r.id + '"]')) || r.parentElement;
    return {r, lab, text: norm(lab ? lab.innerText : '') || norm(r.value) || norm(r.id)};
  });
  const pick = info.find(x => want === 'private' ? /비공개|private/i.test(x.text) : /^(전체공개|전체|공개|public|open_public)$/i.test(x.text) || /전체공개/.test(x.text));
  const found = info.map(x => x.text).filter(Boolean);
  if (!pick) return {ok: false, found};
  (pick.lab || pick.r).click();
  if (!pick.r.checked) pick.r.click();
  return {ok: pick.r.checked, found, chosen: pick.text};
}"""


def _choose_visibility(fr, private, prof=""):
    """공개 범위 고르기: 라벨 글자가 '전체공개'·'전체 공개'·'공개' 등 조금 달라도 찾음.
    비공개는 반드시 확인돼야 발행(실수로 공개되는 것 방지), 전체공개는 못 찾으면 네이버 기본값(전체공개)으로 진행"""
    want = "private" if private else "public"
    r = {"ok": False, "found": []}
    for _ in range(3):
        try:
            r = fr.evaluate(VIS_JS, want)
        except Exception as e:  # noqa: BLE001
            r = {"ok": False, "found": [], "error": str(e)[:80]}
        if r.get("ok"):
            log("INFO", f"[네이버 {prof}] 공개 설정: {r.get('chosen')}")
            return True
        fr.page.wait_for_timeout(700)
    found = ", ".join(r.get("found") or []) or "없음"
    if private:
        raise PublishError(f"발행 창에서 '비공개'를 찾지 못해 발행을 멈췄어요 (보이는 항목: {found})")
    log("WARN", f"[네이버 {prof}] 발행 창에서 '전체공개' 버튼을 못 찾아 블로그 기본 공개 설정으로 발행해요 (보이는 항목: {found})")
    return False


def _cat_items(fr):
    items = fr.locator(SEL["category_item"])
    return items, [re.sub(r"\s+", " ", t).strip() for t in items.all_inner_texts()]


def _choose_category(fr, page, name, prof):
    """카테고리 고르기 (선택 사항). 못 찾으면 목록만 닫고 블로그 기본 카테고리로 계속 - 절대 발행을 멈추지 않음.
    Esc 는 발행 창까지 닫아 버려서 쓰지 않고, 카테고리 버튼을 다시 눌러 목록만 닫음"""
    btn = fr.locator(SEL["category_btn"]).first
    try:
        if not btn.count() or not btn.is_visible():
            log("INFO", f"[네이버 {prof}] 이 블로그는 카테고리 선택 칸이 없어 기본 카테고리로 발행")
            return False
        btn.click(timeout=3000)
        page.wait_for_timeout(400)
        items, texts = _cat_items(fr)
        want = re.sub(r"\s+", " ", name).strip()
        idx = next((i for i, t in enumerate(texts) if t == want), None)
        if idx is None:
            idx = next((i for i, t in enumerate(texts) if want in t), None)
        if idx is not None:
            items.nth(idx).scroll_into_view_if_needed(timeout=2000)
            items.nth(idx).click(timeout=3000)
            log("INFO", f"[네이버 {prof}] 카테고리: {texts[idx]}")
            return True
        log("WARN", f"[네이버 {prof}] 카테고리 '{name}' 이(가) 블로그에 없어 기본 카테고리로 발행 (있는 카테고리: {', '.join(texts[:10]) or '없음'})")
    except Exception as e:  # noqa: BLE001
        log("WARN", f"[네이버 {prof}] 카테고리 선택 건너뜀: {str(e).splitlines()[0][:100]}")
    try:   # 열린 목록만 닫기
        if fr.locator(SEL["category_item"]).first.is_visible():
            btn.click(timeout=2000)
    except Exception:  # noqa: BLE001
        pass
    if not fr.locator(SEL["confirm"]).first.is_visible():   # 발행 창이 닫혔으면 다시 엶
        _click(fr, fr.locator(SEL["publish"]).first)
        fr.locator(SEL["confirm"]).first.wait_for(timeout=10000)
    return False


def fetch_categories(cfg, acc, prof, channel="naver"):
    """대시보드 '카테고리 불러오기': 글쓰기 화면 → 발행 창 → 카테고리 목록 읽기 (호출하는 쪽에서 잠금)"""
    from playwright.sync_api import sync_playwright
    from ..connect import editor_frame, write_url, LoginRequired
    if not acc.get("handle"):
        raise LoginRequired("블로그 아이디가 없어요 - 먼저 '연결하기'를 해 주세요")
    with sync_playwright() as pw:
        ctx = launch_profile(pw, prof, cfg)
        try:
            restore_cookies(ctx, prof)
            page = work_page(ctx)
            page.on("dialog", lambda d: d.dismiss())
            safe_goto(page, write_url("naver", acc["handle"]))
            fr = editor_frame(page, "naver", 60)
            if not fr:
                raise PublishError("글쓰기 화면이 열리지 않았어요")
            page.wait_for_timeout(1500)
            _dismiss_popups(fr)
            _click(fr, fr.locator(SEL["publish"]).first)
            fr.locator(SEL["confirm"]).first.wait_for(timeout=15000)
            btn = fr.locator(SEL["category_btn"]).first
            if not btn.count() or not btn.is_visible():
                return []
            btn.click(timeout=5000)
            page.wait_for_timeout(500)
            return [t for t in dict.fromkeys(_cat_items(fr)[1]) if t][:50]
        finally:
            try:
                ctx.close()
            except Exception:  # noqa: BLE001
                pass


def publish(post, dry, cfg, account=None, channel="naver"):
    from playwright.sync_api import sync_playwright
    from ..accounts import profile_name
    from ..connect import editor_frame, write_url, LoginRequired, spec
    acc = account or {"id": "main", "handle": ""}
    if dry:
        return {"ok": True, "dry": True, "preview": preview(post, acc)}
    blog_id = acc.get("handle")
    if not blog_id:
        raise LoginRequired("네이버 블로그 아이디가 아직 없어요 - '연결하기'로 로그인하면 자동으로 채워져요")
    prof = profile_name(channel, acc["id"])
    step = "브라우저 열기"
    with sync_playwright() as pw:
        ctx = launch_profile(pw, prof, cfg)
        page = None
        try:
            restore_cookies(ctx, prof)
            page = work_page(ctx)
            page.on("dialog", lambda d: d.accept())
            step = "글쓰기 화면 열기"
            log("INFO", f"[네이버 {prof}] {step}")
            safe_goto(page, write_url("naver", blog_id))
            fr = editor_frame(page, "naver", 60)     # 로그인 페이지로 가면 LoginRequired
            if not fr:
                raise PublishError("글쓰기 화면(스마트에디터)이 60초 안에 열리지 않았어요")
            page.wait_for_timeout(1500)
            _dismiss_popups(fr)
            page.wait_for_timeout(700)
            _dismiss_popups(fr)            # 늦게 뜨는 안내창까지
            step = "제목 입력"
            _click(fr, fr.locator(SEL["title"]).first)
            page.keyboard.type(post["title"], delay=15)
            got = fr.locator(SEL["title"]).first.inner_text(timeout=5000).strip()
            if post["title"][:10] not in got:
                raise PublishError("제목이 입력되지 않았어요")
            step = "본문 입력"
            _click(fr, fr.locator(SEL["body_para"]).first)
            imgs = post.get("images") or []
            uploaded = 0
            tags = list(dict.fromkeys(re.sub(r"\s+", "", t)[:20] for t in _tags(post)))   # 네이버 태그는 띄어쓰기 없음
            lines = to_plain(post).split("\n")
            if tags and cfg.get("naverBodyHashtags", True):   # 본문 끝 #태그 (네이버가 태그로도 인식) - 태그 칸을 못 찾아도 태그가 남음
                lines += ["", " ".join("#" + re.sub(r"\s+", "", t) for t in tags)]
            uploaded = type_body(fr, page, lines, imgs, prof)
            if uploaded < len(imgs):
                log("WARN", f"[네이버 {prof}] 사진 {len(imgs)}장 중 {uploaded}장만 본문 자리에 들어갔어요")
            step = "본문 확인"
            want = re.sub(r"\s+", "", re.sub(r"\[\[IMG:\d+\]\]|## ", "", "\n".join(lines)))
            got = re.sub(r"\s+", "", _body_text(fr))
            if len(got) < len(want) * 0.7:
                raise PublishError(f"본문이 다 들어가지 않았어요({len(got)}/{len(want)}자) - 안내창이 입력을 가렸을 수 있어요")
            if post.get("place") and cfg["shop"].get("name"):
                step = "장소(지도) 첨부"
                try:
                    _dismiss_popups(fr)
                    _attach_place(fr, page, cfg, prof)
                except PublishError:
                    raise
                except Exception as e:  # noqa: BLE001 (장소 첨부는 선택 기능 → 글 발행은 계속)
                    log("WARN", f"[네이버 {prof}] 장소 첨부 건너뜀: {str(e).splitlines()[0][:150]}")
                    if _place_popup_open(fr, None) and not _close_place_popup(fr, page, None):
                        raise PublishError("장소 검색 창이 닫히지 않아 발행을 멈췄어요") from None
            step = "발행 설정 열기"
            _dismiss_popups(fr)
            _click(fr, fr.locator(SEL["publish"]).first)
            fr.locator(SEL["confirm"]).first.wait_for(timeout=15000)
            if post.get("category"):
                step = "카테고리 선택"
                _choose_category(fr, page, post["category"], prof)
            step = "태그 입력"
            tag = fr.locator(SEL["tag"]).first
            if tags and tag.count() and tag.is_visible():
                for t in tags:
                    tag.fill(re.sub(r"[#\s]", "", t)[:20])
                    tag.press("Enter")
                    page.wait_for_timeout(150)
                log("INFO", f"[네이버 {prof}] 태그 {len(tags)}개 입력: {', '.join(tags)}")
            elif tags:
                log("WARN", f"[네이버 {prof}] 발행 창에서 태그 칸을 찾지 못함 → 본문 끝 #태그로 대신함 (SEL['tag'] 확인 필요)")
            step = "공개 설정"
            _choose_visibility(fr, bool(post.get("private")), prof)
            step = "발행 버튼"
            msgs = []
            page.on("dialog", lambda d: msgs.append(d.message))
            _click(fr, fr.locator(SEL["confirm"]).first, 10000)
            try:
                page.wait_for_url(re.compile(r"PostView|logNo=|/\d{9,}"), timeout=PUBLISH_WAIT_MS)
            except Exception:  # noqa: BLE001
                raise PublishError("발행 버튼을 눌렀지만 글 주소로 넘어가지 않았어요" + (f" (네이버 안내: {msgs[-1][:80]})" if msgs else "")) from None
            save_cookies(prof, ctx.cookies(), spec("naver")["domains"])
            log("INFO", f"[네이버 {prof}] 발행 완료 (사진 {uploaded}장): {page.url}")
            return {"ok": True, "url": page.url, "images": uploaded, "tags": len(tags)}
        except LoginRequired:
            if page:
                shot(page, f"{prof}-login")
            raise
        except Exception as e:  # noqa: BLE001
            path = shot(page, f"{prof}-error") if page else ""
            reason = str(e).split("\n")[0][:250]
            log("ERROR", f"[네이버 {prof}] '{step}' 단계 실패: {reason} / 스크린샷: {path or '없음'}")
            raise PublishError(f"'{step}' 단계에서 실패: {reason}" + (f" (스크린샷: {path})" if path else "")) from None
        finally:
            try:
                ctx.close()
            except Exception:  # noqa: BLE001
                pass
