# -*- coding: utf-8 -*-
"""인스타그램: 공식 Instagram Graph API (비즈니스/크리에이터 계정)
키워드 → AI 캡션·해시태그 → 자료함 사진 1장을 원주.kr 에 올려 공개 주소로 게시
1) POST /{ig-user-id}/media (image_url, caption) 2) status_code=FINISHED 대기 3) POST /{ig-user-id}/media_publish"""
import time
import requests
from .. import secure


def build_caption(post):
    tags = " ".join((post.get("hashtags") or [])[:30])
    return (post.get("caption", "").strip() + ("\n\n" + tags if tags else ""))[:2200]


def publish(post, dry, cfg, account=None, channel=None, session=None):
    from ..accounts import env_key
    from ..connect import graph_base, _gv, LoginRequired
    from .. import images as imgmod
    aid = (account or {}).get("id", "main")
    s = session or requests
    caption = build_caption(post)
    if dry:
        return {"ok": True, "dry": True, "preview": {"account": (account or {}).get("label", "ID 1"), "caption": caption,
                                                     "image": (post.get("images") or [{}])[0].get("name", "(사진 없음)")}}
    uid, tok = secure.get(env_key("IG_USER_ID", aid)), secure.get(env_key("IG_ACCESS_TOKEN", aid))
    if not uid or not tok:
        raise LoginRequired("인스타그램이 연결되지 않았어요 (토큰 연결 필요)")
    imgs = post.get("images") or []
    if not imgs:
        raise RuntimeError("인스타그램은 사진이 꼭 필요해요. 자료함에 가게 사진을 올려 주세요")
    if not imgmod.upload_public(imgs[:1], cfg) or not imgs[0].get("public_url"):
        raise RuntimeError("인스타 사진을 올릴 공개 주소가 없어요. 원주.kr FTP 연결과 '사진 공개 주소'를 확인해 주세요")
    image_url = imgs[0]["public_url"]
    base = f"{graph_base()}/{_gv()}/{uid}"

    def call(url, data):
        r = s.post(url, data={**data, "access_token": tok}, timeout=60)
        try:
            j = r.json()
        except ValueError:
            j = {}
        if r.status_code >= 400 or "error" in j:
            e = j.get("error", {})
            if e.get("code") == 190:
                raise LoginRequired("인스타 토큰이 만료됐어요. 다시 연결해 주세요")
            raise RuntimeError("인스타그램 오류: " + str(e.get("message", r.status_code)))
        return j

    cid = call(f"{base}/media", {"image_url": image_url, "caption": caption})["id"]
    for _ in range(40):
        j = s.get(f"{graph_base()}/{_gv()}/{cid}", params={"fields": "status_code", "access_token": tok}, timeout=30).json()
        if j.get("status_code") == "FINISHED":
            break
        if j.get("status_code") == "ERROR":
            raise RuntimeError("인스타그램이 사진을 처리하지 못했어요(사진 주소가 공개되어 있는지 확인)")
        time.sleep(3)
    else:
        raise RuntimeError("인스타그램 사진 처리가 2분 안에 끝나지 않았어요")
    mid = call(f"{base}/media_publish", {"creation_id": cid})["id"]
    return {"ok": True, "id": mid, "url": f"instagram:{mid}"}
