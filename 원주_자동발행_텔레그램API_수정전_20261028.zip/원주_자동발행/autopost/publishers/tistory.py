# -*- coding: utf-8 -*-
"""티스토리: Open API 종료(2024) → 관리자 글쓰기 화면 자동 조작 (계정마다 프로필 따로)
호출하는 쪽(engine)에서 BROWSER_LOCK 과 계정 profile_lock 을 잡고 부름"""
import re, time
from ..browser import launch_profile, safe_goto, shot, restore_cookies, save_cookies, work_page
from ..util import log
import os
PUBLISH_WAIT_MS = int(os.environ.get("AUTOPOST_PUBLISH_WAIT_MS") or 60000)
from .. import images as imgmod

SEL = {"title": "#post-title-inp, textarea[placeholder*='제목'], input[placeholder*='제목']",
       "tag": "#tagText, input[placeholder*='태그'], input[name='tag']",
       "complete": "#publish-layer-btn, button:has-text('완료'), button:has-text('발행하기')",
       "open_public": "#open20", "open_private": "#open0", "publish": "#publish-btn",
       "category_btn": "#category-btn", "category_item": "#category-list [role=option], #category-list li, #category-list .mce-menu-item",
       "file": "#attach-image, input[type=file][accept*='image'], input[type=file][id*='image'], input[type=file][name*='image']",
       # 실제 티스토리: 툴바 '첨부' → '사진' 을 누르면 그때 파일 선택 칸이 생김 (미리 있는 칸이 없을 수 있음)
       "attach_btn": "#mceu_0-open, #mceu_0 button, button:has-text('첨부'), [aria-label*='첨부']",
       "photo_item": ".mce-menu-item:has-text('사진'), [role=menuitem]:has-text('사진'), .mce-menu li:has-text('사진'), li:has-text('사진')",
       "photo_btn": "button[aria-label*='사진'], button[title*='사진'], [role=button][aria-label*='이미지'], button[title*='이미지']"}

DROP_JS = """async ([b64, name]) => {
  const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  const f = new File([u], name, {type: 'image/jpeg'}); const dt = new DataTransfer(); dt.items.add(f);
  const b = tinymce.activeEditor.getBody();
  for (const t of ['dragenter', 'dragover', 'drop']) b.dispatchEvent(new DragEvent(t, {dataTransfer: dt, bubbles: true, cancelable: true}));
  return true }"""

FIND_ED = "() => { try { return !!(window.tinymce && window.tinymce.activeEditor && window.tinymce.activeEditor.getBody()); } catch (e) { return false } }"


class PublishError(RuntimeError):
    pass


def _editor_frame(page, timeout=40):
    """tinymce 편집기가 있는 프레임을 찾음 (페이지가 새로 고쳐져도 다시 찾음)"""
    end = time.time() + timeout
    while time.time() < end:
        for fr in [page.main_frame] + [f for f in page.frames if f != page.main_frame]:
            try:
                if fr.evaluate(FIND_ED):
                    return fr
            except Exception:  # noqa: BLE001 (프레임 이동 중)
                pass
        page.wait_for_timeout(500)
    raise PublishError("티스토리 편집기(본문 칸)가 40초 안에 준비되지 않았어요")


class Ed:
    """편집기 명령: 'tinymce is not defined'·페이지 새로고침이 나면 편집기를 다시 찾아 한 번 더 실행"""
    def __init__(self, page):
        self.page = page
        self.fr = _editor_frame(page)
        self.reloaded = 0

    def __call__(self, js, arg=None):
        for attempt in range(3):
            try:
                return self.fr.evaluate(js, arg) if arg is not None else self.fr.evaluate(js)
            except Exception as e:  # noqa: BLE001
                m = str(e)
                if attempt < 2 and any(x in m for x in ("not defined", "destroyed", "detached", "Cannot read prop", "null")):
                    self.reloaded += 1
                    self.page.wait_for_timeout(1000)
                    self.fr = _editor_frame(self.page)
                    continue
                raise

    def text_len(self):
        return len(re.sub(r"\s+", "", self("() => tinymce.activeEditor.getBody().innerText || ''") or ""))

    def img_count(self):
        return self("() => tinymce.activeEditor.getBody().querySelectorAll('img').length")


def _find(page, sel):
    for fr in [page.main_frame] + [f for f in page.frames if f != page.main_frame]:
        try:
            loc = fr.locator(sel)
            if loc.count():
                return loc.first
        except Exception:  # noqa: BLE001
            pass
    return None


def _fill_body(page, ed, post, imgs, public, prof):
    """본문 넣기. 사진은 [[IMG:n]] 자리마다 (공개 주소가 있으면 주소로, 없으면 티스토리 첨부 업로드)"""
    if public or not imgs:
        html = imgmod.render_markers(post["body_html"], imgs, "public") if imgs else re.sub(r"\[\[IMG:\d+\]\]", "", post["body_html"])
        ed("h => { tinymce.activeEditor.setContent(h); tinymce.activeEditor.fire('change'); }", html)
        return len(imgs) if public else 0
    chunks = re.split(r"\[\[IMG:(\d+)\]\]", post["body_html"])
    ed("() => tinymce.activeEditor.setContent('')")
    uploaded, state = 0, {}
    for k, ch in enumerate(chunks):
        if k % 2 == 0:
            if ch.strip():
                ed("h => { const e = tinymce.activeEditor; e.focus(); e.selection.select(e.getBody(), true); e.selection.collapse(false); e.insertContent(h); }", ch)
            continue
        n = int(ch)
        if n >= len(imgs):
            continue
        if state.get("broken"):
            continue
        ed("() => { const e = tinymce.activeEditor; e.focus(); e.selection.select(e.getBody(), true); e.selection.collapse(false); }")
        how = _upload_image(page, ed, imgs[n]["path"], prof, state)
        if how:
            uploaded += 1
        else:
            state["broken"] = True
            log("WARN", f"[티스토리 {prof}] 사진 올리기 방법을 모두 시도했지만 안 돼서 사진 없이 글을 올려요 "
                        "(원주.kr FTP를 연결하면 사진 주소로 넣어 이 단계가 필요 없어요)")
    ed("() => tinymce.activeEditor.fire('change')")
    return uploaded


def _wait_img(page, ed, before, seconds):
    end = time.time() + seconds
    while time.time() < end:
        if ed.img_count() > before:
            return True
        page.wait_for_timeout(500)
    return False


def _upload_image(page, ed, path, prof, state):
    """사진 1장 올리기. 잘 된 방법을 기억해서 다음 사진부터 그 방법을 먼저 씀.
    ① 이미 있는 사진 파일 칸 ② 툴바 '첨부' → '사진' (파일 선택 창) ③ '사진' 버튼 ④ 편집기에 끌어다 놓기"""
    import base64
    before = ed.img_count()
    order = ["input", "menu", "button", "drop"]
    if state.get("how") in order:
        order.remove(state["how"])
        order.insert(0, state["how"])
    for how in order:
        try:
            if how == "input":
                inp = _find(page, SEL["file"])
                if not inp:
                    continue
                inp.set_input_files(path)
            elif how in ("menu", "button"):
                opener = _find(page, SEL["attach_btn"] if how == "menu" else SEL["photo_btn"])
                if not opener or not opener.is_visible():
                    continue
                with page.expect_file_chooser(timeout=8000) as fc:
                    opener.click(timeout=5000)
                    if how == "menu":
                        page.wait_for_timeout(400)
                        item = _find(page, SEL["photo_item"])
                        if not item:
                            raise RuntimeError("'첨부' 메뉴에 '사진'이 없음")
                        item.click(timeout=5000)
                fc.value.set_files(path)
            else:
                b64 = base64.b64encode(open(path, "rb").read()).decode()
                ed(DROP_JS, [b64, os.path.basename(path)])
            if _wait_img(page, ed, before, 60 if how != "drop" else 20):
                if state.get("how") != how:
                    log("INFO", f"[티스토리 {prof}] 사진 올리기 방법: {how}")
                state["how"] = how
                return how
        except Exception as e:  # noqa: BLE001
            log("INFO", f"[티스토리 {prof}] 사진 올리기 '{how}' 방법 실패: {str(e).splitlines()[0][:100]}")
            try:
                page.keyboard.press("Escape")
            except Exception:  # noqa: BLE001
                pass
    return None


VIS_TEXT_JS = """(want) => {
  const norm = s => (s || '').replace(/\\s+/g, '');
  const cands = [...document.querySelectorAll('label, button, [role=radio], [role=button], li, span')]
    .filter(e => e.offsetParent !== null && norm(e.innerText) === want);
  const e = cands[0]; if (!e) return false; e.click();
  const inp = e.querySelector('input') || (e.htmlFor && document.getElementById(e.htmlFor)); if (inp && !inp.checked) inp.click();
  return true }"""
VIS_STATE_JS = """(want) => {
  const norm = s => (s || '').replace(/\\s+/g, '');
  for (const e of document.querySelectorAll('input[type=radio]:checked')) {
    const l = e.closest('label') || document.querySelector('label[for="' + e.id + '"]'); if (l && norm(l.innerText) === want) return true }
  return [...document.querySelectorAll('[role=radio][aria-checked=true], [aria-pressed=true], .on, .selected, .active')]
    .some(e => e.offsetParent !== null && norm(e.innerText) === want) }"""


def _set_visibility(page, private, prof):
    """공개/비공개 고르기: id → 라벨 → 직접 선택 → (화면 구조가 달라도) 글자 '공개'/'비공개' 로 찾아 누르고, 선택됐는지 확인"""
    sel = SEL["open_private"] if private else SEL["open_public"]
    want = "비공개" if private else "공개"
    radio = page.locator(sel).first
    try:
        radio.wait_for(state="attached", timeout=8000)
    except Exception:  # noqa: BLE001 (id 가 다른 새 화면)
        radio = None
    if radio is None:
        for _ in range(2):
            if page.evaluate(VIS_TEXT_JS, want):
                page.wait_for_timeout(300)
                if page.evaluate(VIS_STATE_JS, want) or not private:
                    log("INFO", f"[티스토리 {prof}] 발행 창에서 '{want}' 선택(글자로 찾음)")
                    return
        if private:
            raise PublishError("발행 창에서 '비공개'를 고르지 못해 발행을 멈췄어요")
        log("WARN", f"[티스토리 {prof}] '공개' 버튼을 찾지 못해 블로그 기본 공개 설정으로 발행해요")
        return
    for how in ("check", "label", "js"):
        try:
            if how == "check":
                radio.check(timeout=3000)
            elif how == "label":
                rid = radio.get_attribute("id")
                lab = page.locator(f"label[for='{rid}']") if rid else page.locator(f"label:has({sel})")
                lab.first.click(timeout=3000)
            else:
                radio.evaluate("e => { e.checked = true; e.dispatchEvent(new Event('change', {bubbles: true})); e.click(); }")
            if radio.is_checked():
                return
        except Exception:  # noqa: BLE001
            continue
    if private:
        raise PublishError("발행 창에서 '비공개'를 고르지 못해 발행을 멈췄어요")
    log("WARN", f"[티스토리 {prof}] '{want}' 선택을 확인하지 못해 블로그 기본 공개 설정으로 발행해요")


def _find_visible(page, sel, seconds=10):
    end = time.time() + seconds
    while time.time() < end:
        for fr in [page.main_frame] + [f for f in page.frames if f != page.main_frame]:
            try:
                loc = fr.locator(sel)
                for i in range(loc.count()):
                    if loc.nth(i).is_visible():
                        return loc.nth(i)
            except Exception:  # noqa: BLE001
                pass
        page.wait_for_timeout(400)
    raise PublishError(f"화면에서 버튼을 찾지 못했어요: {sel[:60]}")


def _click_publish(page, private, prof):
    """마지막 발행 버튼: id(#publish-btn) → 글자('공개 발행'·'발행'·'비공개 저장'·'저장')"""
    sels = [SEL["publish"], "button:has-text('공개 발행')", "button:has-text('비공개 저장')" if private else "button:has-text('발행')",
            "button:has-text('발행')", "button:has-text('저장')"]
    for sel in sels:
        try:
            btn = _find_visible(page, sel, 4)
        except PublishError:
            continue
        if re.search(r"임시|예약|취소", btn.inner_text(timeout=2000) or ""):
            continue
        btn.click(timeout=8000)
        return
    names = page.evaluate("() => [...document.querySelectorAll('button')].filter(b => b.offsetParent !== null).map(b => b.innerText.trim()).filter(Boolean).slice(0, 15)")
    raise PublishError(f"발행 버튼을 찾지 못했어요 (보이는 버튼: {', '.join(names)})")


def _cat_texts(page):
    items = page.locator(SEL["category_item"])
    return items, [re.sub(r"\s+", " ", t).strip() for t in items.all_inner_texts()]


def _choose_category(page, name, prof):
    """카테고리 고르기 (선택 사항). 없거나 못 찾으면 목록을 닫고 기본 카테고리로 계속 - 발행을 멈추지 않음"""
    btn = page.locator(SEL["category_btn"]).first
    try:
        if not btn.count() or not btn.is_visible():
            log("INFO", f"[티스토리 {prof}] 카테고리 선택 칸이 없어 기본 카테고리로 발행")
            return False
        btn.click(timeout=3000)
        page.wait_for_timeout(400)
        items, texts = _cat_texts(page)
        want = re.sub(r"\s+", " ", name).strip()
        idx = next((i for i, t in enumerate(texts) if t.lstrip("- ").strip() == want), None)
        if idx is None:
            idx = next((i for i, t in enumerate(texts) if want and want in t), None)
        if idx is not None:
            items.nth(idx).scroll_into_view_if_needed(timeout=2000)
            items.nth(idx).click(timeout=3000)
            log("INFO", f"[티스토리 {prof}] 카테고리: {texts[idx]}")
            return True
        log("WARN", f"[티스토리 {prof}] 카테고리 '{name}' 이(가) 블로그에 없어 기본 카테고리로 발행 (있는 카테고리: {', '.join(texts[:10]) or '없음'})")
    except Exception as e:  # noqa: BLE001
        log("WARN", f"[티스토리 {prof}] 카테고리 선택 건너뜀: {str(e).splitlines()[0][:100]}")
    try:   # 열린 목록 닫기 (안 닫으면 '완료' 버튼을 가림)
        if page.locator(SEL["category_item"]).first.is_visible():
            btn.click(timeout=2000)
            page.wait_for_timeout(300)
        if page.locator(SEL["category_item"]).first.is_visible():
            page.keyboard.press("Escape")
            page.mouse.click(5, 5)
    except Exception:  # noqa: BLE001
        pass
    return False


def fetch_categories(cfg, acc, prof):
    """대시보드 '카테고리 불러오기' (호출하는 쪽에서 잠금)"""
    from playwright.sync_api import sync_playwright
    from ..connect import editor_frame, write_url, LoginRequired
    if not acc.get("handle"):
        raise LoginRequired("블로그 주소가 없어요")
    with sync_playwright() as pw:
        ctx = launch_profile(pw, prof, cfg)
        try:
            restore_cookies(ctx, prof)
            page = work_page(ctx)
            page.on("dialog", lambda d: d.dismiss())
            safe_goto(page, write_url("tistory", acc["handle"]))
            if not editor_frame(page, "tistory", 60):
                raise PublishError("글쓰기 화면이 열리지 않았어요")
            page.wait_for_timeout(int(os.environ.get("AUTOPOST_TISTORY_SETTLE_MS") or 3000))
            btn = page.locator(SEL["category_btn"]).first
            if not btn.count() or not btn.is_visible():
                return []
            btn.click(timeout=5000)
            page.wait_for_timeout(500)
            return [t.lstrip("- ").strip() for t in dict.fromkeys(_cat_texts(page)[1]) if t.strip() and "카테고리 없음" not in t and t.strip() != "카테고리"][:50]
        finally:
            try:
                ctx.close()
            except Exception:  # noqa: BLE001
                pass


def _tags(post):
    """블로그 태그: AI 태그 + 해시태그 + 핵심 키워드 (최대 10개)"""
    out = []
    for t in list(post.get("tags") or []) + [h.lstrip("#") for h in post.get("hashtags") or []] + [post.get("keyword") or ""]:
        t = re.sub(r"[#,]", "", str(t)).strip()[:25]
        if t and t not in out:
            out.append(t)
    return out[:10]


def publish(post, dry, cfg, account=None, channel=None):
    from playwright.sync_api import sync_playwright
    from ..accounts import profile_name
    from ..connect import editor_frame, write_url, LoginRequired, spec
    acc = account or {"id": "main", "handle": ""}
    blog = acc.get("handle")
    if dry:
        return {"ok": True, "dry": True, "preview": {"account": acc.get("label", "ID 1"), "blog": blog or "(미설정)", "title": post["title"],
                                                     "images": len(post.get("images") or []), "tags": post.get("tags"), "category": post.get("category")}}
    if not blog:
        raise LoginRequired("티스토리 블로그 주소를 입력하고 '연결하기'를 해 주세요")
    prof = profile_name("tistory", acc["id"])
    step = "브라우저 열기"
    with sync_playwright() as pw:
        ctx = launch_profile(pw, prof, cfg)
        page = None
        try:
            restore_cookies(ctx, prof)
            page = work_page(ctx)
            page.on("dialog", lambda d: d.dismiss())   # '저장된 글 이어서 쓸까요?' → 아니오
            step = "글쓰기 화면 열기"
            safe_goto(page, write_url("tistory", blog))
            fr = editor_frame(page, "tistory", 60)
            if not fr:
                raise PublishError("티스토리 글쓰기 화면이 60초 안에 열리지 않았어요")
            step = "편집기 준비"
            ed = Ed(page)
            page.wait_for_timeout(int(os.environ.get("AUTOPOST_TISTORY_SETTLE_MS") or 3000))   # '이어서 쓸까요?' 창·새로고침이 끝날 때까지
            ed = Ed(page)
            imgs = post.get("images") or []
            public = bool(imgs) and imgmod.upload_public(imgs, cfg) and all(i.get("public_url") for i in imgs)
            want = len(re.sub(r"\s+", "", re.sub(r"<[^>]+>", "", imgmod.render_markers(post["body_html"], [], "strip"))))
            for attempt in range(2):
                step = "제목 입력"
                page.locator(SEL["title"]).first.fill(post["title"])
                step = "본문 입력"
                uploaded = _fill_body(page, ed, post, imgs, public, prof)
                page.wait_for_timeout(800)
                got_title = page.locator(SEL["title"]).first.input_value()
                if ed.text_len() >= want * 0.7 and got_title.strip() == post["title"].strip() and ed.img_count() >= uploaded:
                    break
                log("WARN", f"[티스토리 {prof}] 본문이 사라졌어요(편집기 새로고침) → 다시 넣어요")
                ed = Ed(page)
            else:
                raise PublishError(f"본문·사진이 편집기에 남지 않았어요 (글자 {ed.text_len()}/{want}, 사진 {ed.img_count()}/{uploaded})")
            if uploaded < len(imgs):
                log("WARN", f"[티스토리 {prof}] 사진 {len(imgs)}장 중 {uploaded}장만 넣었어요")
            step = "태그 입력"
            tags = _tags(post)
            tag = _find(page, SEL["tag"])
            if tag and tags:
                for t in tags:
                    tag.fill(t)
                    tag.press("Enter")
                    page.wait_for_timeout(150)
                log("INFO", f"[티스토리 {prof}] 태그 {len(tags)}개 입력: {', '.join(tags)}")
            elif tags:
                log("WARN", f"[티스토리 {prof}] 태그 칸을 찾지 못해 태그 없이 진행 (SEL['tag'] 확인 필요)")
            if post.get("category"):
                step = "카테고리 선택"
                _choose_category(page, post["category"], prof)
            step = "발행 설정"
            _find_visible(page, SEL["complete"], 15).click(timeout=10000)
            page.wait_for_timeout(800)
            _set_visibility(page, bool(post.get("private")), prof)
            step = "발행 버튼"
            _click_publish(page, bool(post.get("private")), prof)
            page.wait_for_url(re.compile(r"manage/posts|/\d+$"), timeout=PUBLISH_WAIT_MS)
            save_cookies(prof, ctx.cookies(), spec("tistory")["domains"])
            log("INFO", f"[티스토리 {prof}] 발행 완료: {page.url}")
            return {"ok": True, "url": page.url, "images": uploaded, "tags": len(tags)}
        except LoginRequired:
            if page:
                shot(page, f"{prof}-login")
            raise
        except Exception as e:  # noqa: BLE001
            path = shot(page, f"{prof}-error") if page else ""
            reason = str(e).split("\n")[0][:250]
            log("ERROR", f"[티스토리 {prof}] '{step}' 단계 실패: {reason} / 스크린샷: {path or '없음'}")
            raise PublishError(f"'{step}' 단계에서 실패: {reason}" + (f" (스크린샷: {path})" if path else "")) from None
        finally:
            try:
                ctx.close()
            except Exception:  # noqa: BLE001
                pass
