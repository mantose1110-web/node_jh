# -*- coding: utf-8 -*-
"""X(트위터): 공식 X API v2 (OAuth 1.0a 사용자 토큰)
1) 사진이 있으면 POST /2/media/upload (multipart: media, media_category=tweet_image) → data.id
2) POST /2/tweets {"text": ..., "media": {"media_ids": [...]}}
- 글자 수는 X 규칙(한글 2칸, 링크 23칸, 최대 280칸)에 맞춰 자동으로 줄임
- 키·토큰은 암호화 저장소에서만 읽음
"""
import base64, hashlib, hmac, json, os, re, secrets, time, urllib.parse
import requests
from .. import secure

MAX_WEIGHT = 280
URL_RE = re.compile(r"https?://\S+")


def base():
    return (os.environ.get("AUTOPOST_X_BASE") or "https://api.x.com").rstrip("/")


def _w(ch):
    c = ord(ch)
    return 1 if (c <= 4351 or 8192 <= c <= 8205 or 8208 <= c <= 8223 or 8242 <= c <= 8247) else 2


def weighted_len(text):
    """X 글자 수 계산 (한글·이모지 2, 링크는 길이와 관계없이 23)"""
    n, last = 0, 0
    for m in URL_RE.finditer(text):
        n += sum(_w(c) for c in text[last:m.start()]) + 23
        last = m.end()
    return n + sum(_w(c) for c in text[last:])


def build_text(post, cfg):
    """본문 + 해시태그(최대 4개) + 홈페이지 링크를 280칸 안에 맞춤"""
    url = cfg["shop"]["url"]
    body = re.sub(r"https?://\S+", "", (post.get("caption") or post.get("title") or "")).strip()
    body = re.sub(r"\n{3,}", "\n\n", body)
    tags = [t if t.startswith("#") else "#" + t for t in (post.get("hashtags") or [])][:4]
    while True:
        tail = ("\n" + " ".join(tags) if tags else "") + "\n" + url
        if weighted_len(body + tail) <= MAX_WEIGHT:
            return body + tail
        if len(tags) > 2:
            tags.pop()
            continue
        while body and weighted_len(body + "…" + tail) > MAX_WEIGHT:
            body = body[:-1]
        return body.rstrip() + "…" + tail


def _pct(s):
    return urllib.parse.quote(str(s), safe="~")


def oauth_header(method, url, keys, params=None):
    """OAuth 1.0a 서명 (본문 JSON·multipart 는 서명에 넣지 않음)"""
    oauth = {"oauth_consumer_key": keys["api_key"], "oauth_nonce": secrets.token_hex(16), "oauth_signature_method": "HMAC-SHA1",
             "oauth_timestamp": str(int(time.time())), "oauth_token": keys["token"], "oauth_version": "1.0"}
    allp = {**(params or {}), **oauth}
    pstr = "&".join(f"{_pct(k)}={_pct(v)}" for k, v in sorted(allp.items()))
    base_str = "&".join([method.upper(), _pct(url.split("?")[0]), _pct(pstr)])
    key = f"{_pct(keys['api_secret'])}&{_pct(keys['token_secret'])}"
    oauth["oauth_signature"] = base64.b64encode(hmac.new(key.encode(), base_str.encode(), hashlib.sha1).digest()).decode()
    return "OAuth " + ", ".join(f'{k}="{_pct(v)}"' for k, v in sorted(oauth.items()))


def keys_for(aid):
    from ..accounts import env_key
    e = secure.all_values()
    k = {"api_key": e.get("X_API_KEY"), "api_secret": e.get("X_API_SECRET"),
         "token": e.get(env_key("X_ACCESS_TOKEN", aid)), "token_secret": e.get(env_key("X_ACCESS_SECRET", aid))}
    return k if all(k.values()) else None


def _err(r):
    try:
        j = r.json()
    except ValueError:
        j = {}
    msg = j.get("detail") or j.get("title") or (j.get("errors") or [{}])[0].get("message") or r.text[:150]
    return r.status_code, msg


def check(aid="main", session=None):
    """연결 확인: GET /2/users/me"""
    s = session or requests
    k = keys_for(aid)
    if not k:
        return {"ok": False, "error": "앱 키(API Key/Secret)와 이 계정의 Access Token/Secret 을 모두 넣어 주세요"}
    url = base() + "/2/users/me"
    r = s.get(url, headers={"Authorization": oauth_header("GET", url, k)}, timeout=30)
    if r.status_code != 200:
        code, msg = _err(r)
        return {"ok": False, "error": f"X 연결 실패({code}): {msg}"}
    d = r.json().get("data") or {}
    return {"ok": True, "username": d.get("username", ""), "id": d.get("id", "")}


def publish(post, dry, cfg, account=None, channel="x", session=None):
    from ..connect import LoginRequired
    aid = (account or {}).get("id", "main")
    text = build_text(post, cfg)
    imgs = (post.get("images") or [])[:1]
    if dry:
        return {"ok": True, "dry": True, "preview": {"account": (account or {}).get("label", "ID 1"), "text": text,
                                                     "length": weighted_len(text), "image": imgs[0]["name"] if imgs else "(사진 없음)"}}
    k = keys_for(aid)
    if not k:
        raise LoginRequired("X 키·토큰이 없어요")
    s = session or requests
    media_ids = []
    for im in imgs:
        url = base() + "/2/media/upload"
        with open(im["path"], "rb") as f:
            r = s.post(url, headers={"Authorization": oauth_header("POST", url, k)},
                       files={"media": (im["name"], f, "image/jpeg")}, data={"media_category": "tweet_image"}, timeout=120)
        if r.status_code in (401, 403):
            code, msg = _err(r)
            raise LoginRequired(f"X 인증 실패({code}): {msg}")
        if r.status_code >= 300:
            code, msg = _err(r)
            raise RuntimeError(f"X 사진 올리기 실패({code}): {msg}")
        mid = (r.json().get("data") or {}).get("id") or r.json().get("media_id_string")
        if not mid:
            raise RuntimeError("X 사진 올리기 응답에 id 가 없어요")
        media_ids.append(str(mid))
    url = base() + "/2/tweets"
    body = {"text": text, **({"media": {"media_ids": media_ids}} if media_ids else {})}
    r = s.post(url, headers={"Authorization": oauth_header("POST", url, k), "Content-Type": "application/json"},
               data=json.dumps(body, ensure_ascii=False).encode("utf-8"), timeout=60)
    if r.status_code in (401, 403):
        code, msg = _err(r)
        if code == 403 and "duplicate" in str(msg).lower():
            raise RuntimeError("X: 같은 내용의 글이 이미 올라가 있어요")
        raise LoginRequired(f"X 인증/권한 실패({code}): {msg}")
    if r.status_code >= 300:
        code, msg = _err(r)
        raise RuntimeError(f"X 글 올리기 실패({code}): {msg}")
    tid = (r.json().get("data") or {}).get("id")
    return {"ok": True, "id": tid, "url": f"https://x.com/i/web/status/{tid}"}
