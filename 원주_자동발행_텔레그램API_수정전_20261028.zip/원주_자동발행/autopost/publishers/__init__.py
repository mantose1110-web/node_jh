# -*- coding: utf-8 -*-
from . import naver, cafe, tistory, wonju, instagram, x, social

PUBLISHERS = {"naver": naver, "guide": naver, "cafe": cafe, "tistory": tistory, "wonju": wonju, "instagram": instagram, "x": x, "threads": social, "facebook": social, "band": social, "manual": social}
