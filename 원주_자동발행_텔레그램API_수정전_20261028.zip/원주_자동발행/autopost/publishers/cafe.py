# -*- coding: utf-8 -*-
"""네이버 카페: 사장님이 가입한 카페 게시판에 '사장님 본인 계정'으로 소통 글 등록 (스마트에디터 ONE)

- 계정 주소(handle) = 카페 주소(https://cafe.naver.com/카페이름) 만 넣으면 됨 → 카페 번호를 찾아 글쓰기 화면을 알아서 엶
- 게시판: '게시판 불러오기'로 글쓰기 화면의 게시판 목록을 읽어 사장님이 고름 → 발행 때 그 게시판을 골라서 올림
- 광고·링크·지도 없이 사장님 일상/동네 이야기만. 카페 규칙(홍보 금지 등)은 사장님이 확인
- 기본값은 '확인 후 등록'(글을 만든 뒤 사장님이 '등록 시작'을 눌러야 올라감)
호출하는 쪽(engine)에서 BROWSER_LOCK 과 계정 profile_lock 을 잡고 부름
"""
import os
import re
from urllib.parse import urlparse, parse_qs
from ..browser import launch_profile, safe_goto, shot, restore_cookies, save_cookies, work_page
from ..util import log
from .naver import PublishError, to_plain, type_body, _dismiss_popups, _click, _body_text, preview  # noqa: F401
PUBLISH_WAIT_MS = int(os.environ.get("AUTOPOST_PUBLISH_WAIT_MS") or 60000)

SEL = {
    "title": "textarea.textarea_input, textarea[placeholder*='제목'], .se-documentTitle .se-text-paragraph",
    "body_para": ".se-component.se-text .se-text-paragraph",
    "tag": ".tag_input_box input, input[placeholder*='태그']",
    "submit": "a.BaseButton--skinGreen, button.BaseButton--skinGreen, button:has-text('등록'), a:has-text('등록')",
    "done": r"/articles/\d+(?:[?#].*)?$|ArticleRead|articleid=\d+",
    "board_btn": ".FormSelectBox button, [class*='FormSelectBox'] button, button[class*='select'][class*='board'], button:has-text('게시판을 선택')",
    # 차례로 시도해서 처음 찾은 목록만 씀 (목록 전체를 한 줄로 읽는 일 방지)
    "board_opt": [".FormSelectBox .option_list li", "[class*='FormSelectBox'] li", "ul[role='listbox'] [role='option']", "ul[role='listbox'] li",
                  "[class*='option_list'] li"],
}
CLUB_RE = [r"/cafes/(\d+)", r"[?&]clubid=(\d+)", r"g_sClubId\s*=\s*[\"'](\d+)", r"[\"']?cafeId[\"']?\s*[:=]\s*[\"']?(\d+)", r"clubid=(\d+)"]


def cafe_base():
    return (os.environ.get("AUTOPOST_CAFE_BASE") or "https://cafe.naver.com").rstrip("/")


def cafe_api():
    return (os.environ.get("AUTOPOST_CAFE_API") or "https://apis.naver.com").rstrip("/")


def parse_handle(url):
    """(카페 번호 또는 '', 카페 이름 또는 '', 주소에 들어 있던 게시판 번호 또는 '')"""
    u = urlparse(url or "")
    cid = next((m.group(1) for r in CLUB_RE[:2] for m in [re.search(r, url or "", re.I)] if m), "")
    q = {k.lower(): v for k, v in parse_qs(u.query).items()}
    menu = (q.get("menuid") or [""])[0]
    m = re.search(r"/menus/(\d+)", u.path)
    menu = menu or (m.group(1) if m else "")
    base_path = urlparse(cafe_base()).path.rstrip("/")
    path = u.path[len(base_path):] if base_path and u.path.startswith(base_path) else u.path
    seg = [x for x in path.split("/") if x]
    name = seg[0] if seg and seg[0] not in ("ca-fe", "f-e", "cafes", "ArticleList.nhn", "ArticleRead.nhn") and not cid else ""
    return cid, name, menu


def write_page_url(cid, menu_id=""):
    return f"{cafe_base()}/ca-fe/cafes/{cid}/articles/write?boardType=L" + (f"&menuId={menu_id}" if menu_id else "")


def resolve_club(page, url):
    """카페 주소 → 카페 번호 (주소 → 카페 정보 API → 카페 첫 화면 순서로 찾음)"""
    cid, name, _ = parse_handle(url)
    if cid:
        return cid
    if name:
        try:
            r = page.request.get(f"{cafe_api()}/cafe-web/cafe2/CafeGateInfo.json?cluburl={name}", timeout=15000)
            if r.ok:
                j = r.json()
                v = (((j.get("message") or {}).get("result") or {}).get("cafeInfoView") or {}).get("cafeId")
                if v:
                    return str(v)
        except Exception:  # noqa: BLE001
            pass
    safe_goto(page, url)
    page.wait_for_timeout(1500)
    for src in (page.url, page.content()):
        for r in CLUB_RE:
            m = re.search(r, src, re.I)
            if m:
                return m.group(1)
    raise PublishError("카페 번호를 찾지 못했어요. 카페 주소(https://cafe.naver.com/카페이름)가 맞는지, 가입한 카페인지 확인해 주세요")


def _api_boards(page, cid):
    try:
        r = page.request.get(f"{cafe_api()}/cafe-web/cafe2/SideMenuList?cafeId={cid}", timeout=15000)
        if not r.ok:
            return []
        j = r.json()
        menus = ((j.get("message") or {}).get("result") or {}).get("menus") or []
        return [{"id": str(x.get("menuId")), "name": str(x.get("menuName") or "").strip()} for x in menus
                if x.get("menuId") and str(x.get("menuName") or "").strip() and x.get("menuType") not in ("S", "F", "L")]
    except Exception:  # noqa: BLE001
        return []


def _open_board_list(fr, page):
    btn = fr.locator(SEL["board_btn"]).first
    if not btn.count():
        return None
    btn.click(timeout=5000)
    page.wait_for_timeout(500)
    for sel in SEL["board_opt"]:
        loc = fr.locator(sel)
        try:
            if loc.count() and loc.first.is_visible():
                return loc
        except Exception:  # noqa: BLE001
            pass
    return fr.locator(SEL["board_opt"][0])


def _clean(t):
    return re.sub(r"\s+", " ", t or "").strip()


def list_boards(page, cid, editor_frame):
    """글을 쓸 수 있는 게시판 목록 [{id, name}]. 글쓰기 화면의 게시판 선택 목록이 기준(쓸 수 있는 곳만 나옴), 번호는 카페 API에서"""
    api = _api_boards(page, cid)
    safe_goto(page, write_page_url(cid))
    fr = editor_frame(page, "cafe", 40)
    names = []
    if fr:
        opts = _open_board_list(fr, page)
        if opts is not None:
            names = [n for n in (_clean(t) for t in opts.all_inner_texts()) if n and "선택" not in n]
            page.keyboard.press("Escape")
    if names:
        ids = {b["name"]: b["id"] for b in api}
        return [{"id": ids.get(n, ""), "name": n} for n in dict.fromkeys(names)]
    if api:
        return api
    raise PublishError("게시판 목록을 읽지 못했어요 (카페 가입·글쓰기 권한 확인)")


def choose_board(fr, page, board, prof):
    """글쓰기 화면에서 게시판이 골라졌는지 확인하고, 아니면 이름으로 고름"""
    name = (board or {}).get("name", "")
    btn = fr.locator(SEL["board_btn"]).first
    cur = _clean(btn.inner_text(timeout=3000)) if btn.count() else ""
    if name and name == cur:
        return cur
    if not name:
        if cur and "선택" not in cur:
            return cur
        raise PublishError("올릴 게시판을 먼저 골라 주세요 ('네이버 카페' 화면 → '게시판 불러오기')")
    opts = _open_board_list(fr, page)
    if opts is None:
        raise PublishError("게시판 선택 칸을 찾지 못했어요")
    texts = [_clean(t) for t in opts.all_inner_texts()]
    if name not in texts:
        page.keyboard.press("Escape")
        raise PublishError(f"게시판 '{name}'이(가) 글쓰기 목록에 없어요 (보이는 게시판: {', '.join(texts[:8])}) - '게시판 불러오기'로 다시 골라 주세요")
    opts.nth(texts.index(name)).click(timeout=5000)
    page.wait_for_timeout(400)
    cur = _clean(btn.inner_text(timeout=3000))
    if name not in cur:
        raise PublishError(f"게시판 '{name}'을(를) 고르지 못했어요")
    log("INFO", f"[카페 {prof}] 게시판 선택: {name}")
    return cur


def _strip_marketing(post):
    """카페 글에는 홈페이지 링크·주문 유도를 넣지 않음"""
    h = re.sub(r"<p>(?:(?!</p>).)*?<a [^>]*>(?:(?!</p>).)*?</p>", "", post["body_html"], flags=re.S)
    return {**post, "body_html": re.sub(r"<a [^>]*>(.*?)</a>", r"\1", h, flags=re.S)}


def publish(post, dry, cfg, account=None, channel="cafe"):
    import hashlib
    from playwright.sync_api import sync_playwright
    from ..accounts import profile_name
    from ..connect import editor_frame, LoginRequired, spec, cafe_url_ok
    acc = account or {"id": "main", "handle": ""}
    post = _strip_marketing(post)
    if dry:
        return {"ok": True, "dry": True, "preview": preview(post, acc)}
    url = acc.get("handle") or ""
    if not cafe_url_ok(url):
        raise LoginRequired("카페 주소가 아직 없어요 - '네이버 카페' 화면에서 카페 주소를 넣고 '연결하기'를 눌러 주세요")
    boards = [x for x in (acc.get("boardsSelected") or []) if x.get("id") and x.get("name")]
    board = (boards[int(hashlib.sha256((post.get("title") or "").encode("utf-8")).hexdigest(), 16) % len(boards)]
             if boards else (acc.get("board") or {}))
    prof = profile_name(channel, acc["id"])
    step = "브라우저 열기"
    with sync_playwright() as pw:
        ctx = launch_profile(pw, prof, cfg)
        page = None
        try:
            restore_cookies(ctx, prof)
            page = work_page(ctx)
            page.on("dialog", lambda d: d.accept())
            step = "카페 글쓰기 화면 열기"
            log("INFO", f"[카페 {prof}] {step}")
            cid = acc.get("clubId") or resolve_club(page, url)
            menu = board.get("id") or parse_handle(url)[2]
            safe_goto(page, write_page_url(cid, menu))
            fr = editor_frame(page, "cafe", 60)
            if not fr:
                raise PublishError("카페 글쓰기 화면이 60초 안에 열리지 않았어요 (카페 가입·글쓰기 권한 확인)")
            page.wait_for_timeout(1200)
            _dismiss_popups(fr)
            step = "게시판 선택"
            chosen = choose_board(fr, page, board, prof)
            step = "제목 입력"
            title = fr.locator(SEL["title"]).first
            if title.evaluate("e => e.tagName") == "TEXTAREA":
                title.fill(post["title"][:100])
                got = title.input_value()
            else:
                _click(fr, title)
                page.keyboard.type(post["title"], delay=15)
                got = title.inner_text(timeout=5000)
            if post["title"][:10] not in got:
                raise PublishError("제목이 입력되지 않았어요")
            step = "본문 입력"
            _click(fr, fr.locator(SEL["body_para"]).first)
            imgs = post.get("images") or []
            lines = to_plain(post).split("\n")
            uploaded = type_body(fr, page, lines, imgs, prof, "카페")
            step = "본문 확인"
            want = re.sub(r"\s+", "", re.sub(r"\[\[IMG:\d+\]\]|## ", "", "\n".join(lines)))
            got = re.sub(r"\s+", "", _body_text(fr))
            if len(got) < len(want) * 0.7:
                raise PublishError(f"본문이 다 들어가지 않았어요({len(got)}/{len(want)}자)")
            tags = [re.sub(r"[#\s]", "", t)[:20] for t in (post.get("tags") or [])][:10]
            tag = fr.locator(SEL["tag"]).first
            if tags and tag.count() and tag.is_visible():
                step = "태그 입력"
                for t in dict.fromkeys(tags):
                    tag.fill(t)
                    tag.press("Enter")
                    page.wait_for_timeout(120)
            step = "등록 버튼"
            msgs = []
            page.on("dialog", lambda d: msgs.append(d.message))
            _click(fr, fr.locator(SEL["submit"]).first, 10000)
            try:
                page.wait_for_url(re.compile(SEL["done"]), timeout=PUBLISH_WAIT_MS)
            except Exception:  # noqa: BLE001
                raise PublishError("등록 버튼을 눌렀지만 글 화면으로 넘어가지 않았어요" + (f" (카페 안내: {msgs[-1][:80]})" if msgs else "")) from None
            save_cookies(prof, ctx.cookies(), spec("naver")["domains"])
            log("INFO", f"[카페 {prof}] 등록 완료 (사진 {uploaded}장): {page.url}")
            return {"ok": True, "url": page.url, "images": uploaded, "tags": len(tags), "board": chosen}
        except LoginRequired:
            if page:
                shot(page, f"{prof}-login")
            raise
        except Exception as e:  # noqa: BLE001
            path = shot(page, f"{prof}-error") if page else ""
            reason = str(e).split("\n")[0][:250]
            log("ERROR", f"[카페 {prof}] '{step}' 단계 실패: {reason} / 스크린샷: {path or '없음'}")
            raise PublishError(f"'{step}' 단계에서 실패: {reason}" + (f" (스크린샷: {path})" if path else "")) from None
        finally:
            try:
                ctx.close()
            except Exception:  # noqa: BLE001
                pass


def fetch_boards(cfg, acc, prof):
    """대시보드 '게시판 불러오기': 로그인한 프로필로 카페 번호·게시판 목록 읽기 (호출하는 쪽에서 잠금)"""
    from playwright.sync_api import sync_playwright
    from ..connect import editor_frame, LoginRequired
    url = acc.get("handle") or ""
    with sync_playwright() as pw:
        ctx = launch_profile(pw, prof, cfg)
        try:
            restore_cookies(ctx, prof)
            page = work_page(ctx)
            page.on("dialog", lambda d: d.dismiss())
            cid = resolve_club(page, url)
            try:
                boards = list_boards(page, cid, editor_frame)
            except LoginRequired:
                raise PublishError("로그인이 풀렸어요 - '연결하기'를 다시 눌러 주세요") from None
            log("INFO", f"[카페 {prof}] 카페 번호 {cid}, 글쓰기 게시판 {len(boards)}개: {', '.join(b['name'] for b in boards[:10])}")
            return cid, boards
        finally:
            try:
                ctx.close()
            except Exception:  # noqa: BLE001
                pass
