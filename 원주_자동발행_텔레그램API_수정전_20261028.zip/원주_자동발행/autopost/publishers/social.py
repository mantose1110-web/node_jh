# -*- coding: utf-8 -*-
"""공식 API로 올리는 채널 (브라우저 없이)
- band     : 네이버 밴드 Open API (사장님이 가입한 밴드에 글) → 커뮤니티라 항상 '확인 후 등록'
- threads  : Threads API (컨테이너 만들기 → 공개)
- facebook : 페이스북 페이지 Graph API (사진 있으면 /photos, 없으면 /feed)
- manual   : API가 없는 곳(당근 비즈프로필 소식·카카오톡 채널 소식·스마트플레이스 소식) → 올릴 원고만 만들어 두고, 사장님이 복사해서 올림

토큰은 암호화 저장소에서만 읽음 (화면·기록에는 가림)
"""
import os
import re
import time

import requests

from .. import secure, images as imgmod
from ..util import log

TOKEN_KEY = {"band": "BAND_TOKEN", "threads": "THREADS_TOKEN", "facebook": "FB_PAGE_TOKEN"}
MANUAL_TARGETS = {
    "daangn": ("당근 비즈프로필 소식", "동네 이웃에게 알리는 짧은 가게 소식 300~500자. 친근한 말투, 이모지 1~3개, 마지막 줄에 위치·영업시간."),
    "kakao": ("카카오톡 채널 소식", "채널 친구에게 보내는 짧은 소식 200~400자. 첫 줄에 핵심, 줄바꿈 많이, 과장·광고성 단어 남발 금지."),
    "smartplace": ("네이버 스마트플레이스 소식", "플레이스 '소식' 글 200~500자. 오늘의 가게 소식·메뉴·영업 안내 위주, 정보 중심."),
}


class ApiError(RuntimeError):
    pass


def base(ch):
    env = {"band": "AUTOPOST_BAND_BASE", "threads": "AUTOPOST_THREADS_BASE", "facebook": "AUTOPOST_GRAPH_BASE"}[ch]
    dflt = {"band": "https://openapi.band.us", "threads": "https://graph.threads.com", "facebook": "https://graph.facebook.com"}[ch]
    return (os.environ.get(env) or dflt).rstrip("/")


def token(ch, aid):
    from .. import accounts as A
    return secure.get(A.env_key(TOKEN_KEY[ch], aid))


def plain(post, limit):
    """본문 HTML → 줄글 (사진 자리 표시·태그 제거)"""
    h = re.sub(r"\[\[IMG:\d+\]\]", "", post.get("body_html") or "")
    h = re.sub(r"<h[23][^>]*>", "\n■ ", h)
    h = re.sub(r"</(p|h2|h3|li|div)>|<br\s*/?>", "\n", h).replace("<li>", "• ")
    t = re.sub(r"<[^>]+>", "", h)
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&#x27;", "'"), ("&nbsp;", " ")):
        t = t.replace(a, b)
    t = re.sub(r"\n{3,}", "\n\n", "\n".join(x.strip() for x in t.split("\n"))).strip()
    if len(t) > limit:
        cut = t[:limit]
        t = cut[:max(cut.rfind("\n"), cut.rfind(". "), limit - 40)].rstrip() + " …"
    return t


def _json(r):
    try:
        return r.json()
    except ValueError:
        return {}


def _graph_err(r):
    j = _json(r)
    e = j.get("error") or {}
    return f"{r.status_code} {e.get('message') or r.text[:120]}"


# ---------------- 연결 확인 ----------------
def check(ch, aid="main", handle="", session=None):
    s = session or requests
    tok = token(ch, aid)
    if not tok:
        return {"ok": False, "error": "토큰을 먼저 넣고 저장해 주세요"}
    try:
        if ch == "band":
            r = s.get(f"{base(ch)}/v2.1/bands", params={"access_token": tok}, timeout=30)
            j = _json(r)
            if r.status_code != 200 or j.get("result_code") != 1:
                return {"ok": False, "error": f"밴드 연결 실패: {(j.get('result_data') or {}).get('message') or r.status_code}"}
            bands = [{"key": b.get("band_key"), "name": b.get("name")} for b in (j.get("result_data") or {}).get("bands") or []]
            if handle and handle not in {b["key"] for b in bands}:
                return {"ok": False, "error": "고른 밴드에 이 계정이 없어요 - '밴드 불러오기'로 다시 골라 주세요", "bands": bands}
            return {"ok": True, "username": next((b["name"] for b in bands if b["key"] == handle), ""), "bands": bands}
        if ch == "threads":
            r = s.get(f"{base(ch)}/v1.0/me", params={"fields": "id,username", "access_token": tok}, timeout=30)
            if r.status_code != 200:
                return {"ok": False, "error": f"Threads 연결 실패: {_graph_err(r)}"}
            j = _json(r)
            return {"ok": True, "username": j.get("username", ""), "id": str(j.get("id", ""))}
        if ch == "facebook":
            from ..connect import _gv
            r = s.get(f"{base(ch)}/{_gv()}/me", params={"fields": "id,name", "access_token": tok}, timeout=30)
            if r.status_code != 200:
                return {"ok": False, "error": f"페이스북 페이지 연결 실패: {_graph_err(r)}"}
            j = _json(r)
            return {"ok": True, "username": j.get("name", ""), "id": str(j.get("id", ""))}
    except requests.RequestException as e:
        return {"ok": False, "error": f"인터넷 연결 확인 필요: {str(e)[:120]}"}
    return {"ok": False, "error": "알 수 없는 채널"}


# ---------------- 발행 ----------------
def _public_image(post, cfg):
    imgs = (post.get("images") or [])[:1]
    if not imgs:
        return ""
    try:
        if imgmod.upload_public(imgs, cfg) and imgs[0].get("public_url"):
            return imgs[0]["public_url"]
    except Exception as e:  # noqa: BLE001
        log("WARN", f"사진 공개 주소 만들기 실패 → 글만 올려요: {str(e)[:100]}")
    return ""


def text_for(ch, post, cfg):
    url = cfg["shop"].get("url", "")
    tags = " ".join(h if h.startswith("#") else "#" + h for h in (post.get("hashtags") or [])[:5])
    if ch == "threads":   # 500자 제한, 주제 태그는 1개만 인식
        body = (post.get("caption") or plain(post, 380)).strip()
        tag = (post.get("hashtags") or [""])[0]
        tag = (" " + (tag if tag.startswith("#") else "#" + tag)) if tag else ""
        room = 480 - len(url) - len(tag) - 2
        body = body[:room].rstrip()
        return f"{body}\n{url}{tag}".strip()
    if ch == "facebook":
        body = post.get("caption") or plain(post, 1500)
        return f"{post['title']}\n\n{body}\n\n{url}\n{tags}".strip()
    if ch == "band":       # 동네 밴드: 링크·해시태그 없이 소통글
        return f"{post['title']}\n\n{plain(post, 3500)}".strip()
    return f"{post['title']}\n\n{plain(post, 1500)}".strip()


def publish(post, dry, cfg, account=None, channel="band", session=None):
    from ..connect import LoginRequired
    acc = account or {"id": "main", "label": "ID 1"}
    aid, ch = acc.get("id", "main"), channel
    text = text_for(ch, post, cfg)
    if ch == "manual":
        tgt = MANUAL_TARGETS.get(acc.get("handle") or "daangn", MANUAL_TARGETS["daangn"])[0]
        if dry:
            return {"ok": True, "dry": True, "preview": {"account": acc.get("label"), "target": tgt, "text": text}}
        log("INFO", f"[{tgt}] 올릴 원고 완성 - 미리보기에서 복사해 {tgt}에 올려 주세요")
        return {"ok": True, "url": "", "manual": True, "text": text}
    if dry:
        return {"ok": True, "dry": True, "preview": {"account": acc.get("label"), "channel": ch, "text": text[:600],
                                                     "image": (post.get("images") or [{}])[0].get("name", "(사진 없음)")}}
    s = session or requests
    tok = token(ch, aid)
    if not tok:
        raise LoginRequired("토큰이 없어요 - 채널 화면에서 토큰을 넣고 '연결 확인'을 눌러 주세요")
    if ch == "band":
        band = acc.get("handle") or ""
        if not band:
            raise LoginRequired("올릴 밴드를 먼저 골라 주세요 ('밴드 불러오기')")
        r = s.post(f"{base(ch)}/v2.2/band/post/create", params={"access_token": tok},
                   data={"band_key": band, "content": text, "do_push": "false"}, timeout=60)
        j = _json(r)
        if r.status_code in (401, 403) or j.get("result_code") in (211, 212, 401):
            raise LoginRequired(f"밴드 인증이 풀렸어요: {(j.get('result_data') or {}).get('message') or r.status_code}")
        if r.status_code != 200 or j.get("result_code") != 1:
            raise ApiError(f"밴드 글쓰기 실패: {(j.get('result_data') or {}).get('message') or r.status_code}")
        key = (j.get("result_data") or {}).get("post_key", "")
        log("INFO", f"[밴드 {acc.get('label')}] 등록 완료 (글 {key})")
        return {"ok": True, "url": f"https://band.us/band/{band}/post/{key}" if key else "", "post_key": key}
    if ch == "threads":
        me = check("threads", aid, session=s)
        if not me.get("ok"):
            raise LoginRequired(me.get("error", "Threads 연결 확인 실패"))
        uid, img = me["id"], _public_image(post, cfg)
        params = {"media_type": "IMAGE" if img else "TEXT", "text": text, "access_token": tok, **({"image_url": img} if img else {})}
        r = s.post(f"{base(ch)}/v1.0/{uid}/threads", params=params, timeout=60)
        if r.status_code != 200 or not _json(r).get("id"):
            raise ApiError(f"Threads 글 만들기 실패: {_graph_err(r)}")
        cid = _json(r)["id"]
        wait = float(os.environ.get("AUTOPOST_THREADS_WAIT") or 30)
        end = time.time() + max(wait, 3)
        while time.time() < end:   # 공식 안내: 컨테이너 처리 완료 후 공개 (보통 30초 안)
            st = _json(s.get(f"{base(ch)}/v1.0/{cid}", params={"fields": "status,error_message", "access_token": tok}, timeout=30))
            if st.get("status") in ("FINISHED", "PUBLISHED") or not st.get("status"):
                break
            if st.get("status") in ("ERROR", "EXPIRED"):
                raise ApiError(f"Threads 사진 처리 실패: {st.get('error_message') or st.get('status')}")
            time.sleep(2)
        r = s.post(f"{base(ch)}/v1.0/{uid}/threads_publish", params={"creation_id": cid, "access_token": tok}, timeout=60)
        if r.status_code != 200 or not _json(r).get("id"):
            raise ApiError(f"Threads 공개 실패: {_graph_err(r)}")
        pid = _json(r)["id"]
        log("INFO", f"[Threads @{me.get('username')}] 발행 완료 ({'사진' if img else '글'})")
        return {"ok": True, "url": f"https://www.threads.net/@{me.get('username')}/post/{pid}", "id": pid}
    if ch == "facebook":
        from ..connect import _gv
        me = check("facebook", aid, session=s)
        if not me.get("ok"):
            raise LoginRequired(me.get("error", "페이스북 연결 확인 실패"))
        img = _public_image(post, cfg)
        if img:
            r = s.post(f"{base(ch)}/{_gv()}/{me['id']}/photos", data={"url": img, "caption": text, "access_token": tok}, timeout=90)
        else:
            r = s.post(f"{base(ch)}/{_gv()}/{me['id']}/feed", data={"message": text, "link": cfg["shop"].get("url", ""), "access_token": tok}, timeout=60)
        j = _json(r)
        if r.status_code != 200 or not (j.get("post_id") or j.get("id")):
            raise ApiError(f"페이스북 페이지 글 올리기 실패: {_graph_err(r)}")
        pid = j.get("post_id") or j.get("id")
        log("INFO", f"[페이스북 {me.get('username')}] 발행 완료")
        return {"ok": True, "url": f"https://www.facebook.com/{pid}", "id": pid}
    raise ApiError("알 수 없는 채널")
