# -*- coding: utf-8 -*-
"""경로 관리
- resource_dir(): 프로그램에 포함된 읽기 전용 파일 (PyInstaller 실행 시 sys._MEIPASS)
- data_dir(): 쓰기 가능한 사용자 데이터 폴더 (설정·DB·로그·브라우저 프로필·암호화된 키)
    Windows: %APPDATA%\\원주통닭자동발행   /  Linux·mac: ~/.local/share/wonju-autopost
    환경변수 AUTOPOST_HOME 으로 변경 가능 (테스트용)
- browsers_dir(): Playwright 브라우저 설치 위치 (설치 프로그램과 같은 경로, 영문 경로)
"""
import os, shutil, sys

APP_NAME = "원주통닭자동발행"
INSTALL_NAME = "WonjuAutopost"   # 설치 폴더(영문): %LOCALAPPDATA%\WonjuAutopost


def resource_dir():
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def data_dir():
    if os.environ.get("AUTOPOST_HOME"):
        d = os.environ["AUTOPOST_HOME"]
    elif os.name == "nt":
        d = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), APP_NAME)
    else:
        d = os.path.join(os.path.expanduser("~"), ".local", "share", "wonju-autopost")
    os.makedirs(d, exist_ok=True)
    return d


def install_dir():
    if os.name == "nt":
        return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), INSTALL_NAME)
    return os.path.join(os.path.expanduser("~"), ".local", "share", INSTALL_NAME)


def browsers_dir():
    """Playwright 크로미움 위치. 설치.bat 이 같은 경로에 설치함"""
    if os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
        return os.environ["PLAYWRIGHT_BROWSERS_PATH"]
    return os.path.join(install_dir(), "ms-playwright")


def init_data(d=None):
    """첫 실행: 기본 설정·키워드를 데이터 폴더로 복사 (이미 있으면 그대로 둠)"""
    d = d or data_dir()
    r = resource_dir()
    for sub in ("data", "logs", "out", "profiles"):
        os.makedirs(os.path.join(d, sub), exist_ok=True)
    for f in ("config.json", "keywords.csv"):
        src, dst = os.path.join(r, f), os.path.join(d, f)
        if os.path.exists(src) and not os.path.exists(dst):
            shutil.copy(src, dst)
    merge_keywords(os.path.join(r, "keywords.csv"), os.path.join(d, "keywords.csv"), os.path.join(d, "data", "kw_merged.txt"))
    return d


def merge_keywords(src, dst, marker, group="확장 키워드"):
    """업데이트로 새로 생긴 '확장 키워드'를 사장님 키워드 파일에 한 번만 추가 (지운 키워드는 다시 넣지 않음)"""
    import csv
    if not (os.path.exists(src) and os.path.exists(dst)) or os.path.abspath(src) == os.path.abspath(dst):
        return 0
    try:
        done = set(open(marker, encoding="utf-8").read().split("\n")) if os.path.exists(marker) else set()
        with open(src, encoding="utf-8-sig", newline="") as f:
            new = [r for r in csv.reader(f) if r and r[0].startswith(group.split()[0]) and len(r) > 1 and r[1] not in done]
        if not new:
            return 0
        with open(dst, encoding="utf-8-sig", newline="") as f:
            have = {r[1] for r in csv.reader(f) if len(r) > 1}
        add = [r for r in new if r[1] not in have]
        if add:
            with open(dst, "rb") as f:
                data = f.read()
            nl = bool(data) and data[-1:] not in (b"\n", b"\r")
            with open(dst, "a", encoding="utf-8", newline="") as f:
                if nl:
                    f.write("\r\n")
                csv.writer(f).writerows(add)
        with open(marker, "a", encoding="utf-8") as f:
            f.write("\n".join(r[1] for r in new) + "\n")
        return len(add)
    except (OSError, ValueError, csv.Error):
        return 0
