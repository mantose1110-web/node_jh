# -*- coding: utf-8 -*-
"""공통: 설정 읽기/쓰기, 로그(비밀값 자동 가림)"""
import json, os, re, threading
from datetime import datetime
from . import generator as g

_lock = threading.RLock()
CHANNELS = ("naver", "guide", "cafe", "tistory", "wonju", "instagram", "x", "threads", "facebook", "band", "manual")
CH_NAME = {"wonju": "원주.kr 홈페이지", "naver": "네이버 블로그", "guide": "손님용 블로그", "cafe": "네이버 카페", "instagram": "인스타그램", "tistory": "티스토리",
           "x": "X(트위터)", "threads": "스레드(Threads)", "facebook": "페이스북 페이지", "band": "네이버 밴드", "manual": "원고(당근·카톡채널·플레이스)"}
SOCIAL = ("instagram", "x", "threads", "facebook")          # 짧은 SNS 글 (사진 1장)
NON_BLOG = SOCIAL + ("band", "manual")                        # 마케팅 블록·지도 카드를 붙이지 않는 채널
API_CHANNELS = ("threads", "facebook", "band")                # 토큰으로 올리는 채널
REVIEW_CHANNELS = ("cafe", "band", "manual")                  # 커뮤니티·수동 채널: 항상 사장님이 확인 후 등록
BROWSER_CHANNELS = ("naver", "guide", "cafe", "tistory")


def platform(ch):
    """손님용 블로그(guide)·네이버 카페(cafe)도 네이버 로그인을 씀"""
    return "naver" if ch in ("guide", "cafe") else ch


def load_config():
    return g.load_config()


def save_config(cfg):
    with _lock:
        p = os.path.join(g.ROOT, "config.json")
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        try:   # 마지막 정상 설정 (파일이 깨졌을 때 되살리는 용도)
            import shutil
            shutil.copy(p, p + ".lastgood")
        except OSError:
            pass


def is_dry(cfg, force_dry=False):
    return force_dry or cfg.get("live") is not True


_SECRET_RE = re.compile(r"(sk-ant-[A-Za-z0-9_\-]{6,}|sk-[A-Za-z0-9_\-]{16,}|[Bb]earer\s+[A-Za-z0-9._\-]{8,}|EAA[A-Za-z0-9]{10,}|"
                        r"access_token=[^&\s]+|client_secret=[^&\s]+|password=[^&\s]+|NID_(AUT|SES)=[^;\s]+)")


def redact(s):
    s = _SECRET_RE.sub("[가림]", str(s))
    try:
        from . import secure
        for v in secure.secret_values():
            s = s.replace(v, "[가림]")
    except Exception:  # noqa: BLE001
        pass
    return s


def log(level, msg):
    line = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] [{level}] {redact(msg)}"
    try:
        print(line, flush=True)
    except Exception:  # noqa: BLE001
        pass
    try:
        os.makedirs(os.path.join(g.ROOT, "logs"), exist_ok=True)
        with _lock, open(os.path.join(g.ROOT, "logs", f"{datetime.now():%Y-%m-%d}.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def tail_log(n=80):
    p = os.path.join(g.ROOT, "logs", f"{datetime.now():%Y-%m-%d}.log")
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8", errors="replace") as f:
        return f.read().splitlines()[-n:]
