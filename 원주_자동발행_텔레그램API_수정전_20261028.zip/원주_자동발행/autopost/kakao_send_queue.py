# -*- coding: utf-8 -*-
"""Persistent KakaoTalk send queue. Message bodies are encrypted for this Windows user."""
import base64
import json
import os
import tempfile
import time

from . import paths, secure


def _file():
    return os.path.join(paths.data_dir(), "kakao_send_queue.json")


def load():
    filename = _file()
    if not os.path.isfile(filename):
        return None
    with open(filename, encoding="utf-8") as source:
        queue = json.load(source)
    if not isinstance(queue, dict) or not isinstance(queue.get("items"), list):
        raise ValueError("카카오톡 예약 대기열 파일이 손상됐어요")
    # A process may have exited after pressing Enter. Never repeat that item.
    changed = False
    for item in queue["items"]:
        if item.get("status") == "sending":
            item["status"] = "review"
            item["error"] = "프로그램 종료 전 발송 여부를 확인할 수 없어요. 직접 확인해 주세요"
            changed = True
    if queue.get("state") in ("running", "waiting"):
        queue["state"] = "paused"
        queue["error"] = "프로그램이 다시 시작됐어요. 목록을 확인하고 재개해 주세요"
        changed = True
    if changed:
        save(queue)
    return queue


def save(queue):
    filename = _file()
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=".kakao-send-", suffix=".tmp", dir=os.path.dirname(filename))
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as target:
            json.dump(queue, target, ensure_ascii=False, indent=2)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, filename)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def encrypt_text(value):
    return base64.b64encode(secure.encrypt(value.encode("utf-8"))).decode("ascii")


def decrypt_text(value):
    return secure.decrypt(base64.b64decode(value)).decode("utf-8")


def public(queue):
    if not queue:
        return {"running": False, "state": "empty", "text": "대기열 없음", "sent": 0,
                "total": 0, "items": [], "error": ""}
    items = []
    for item in queue["items"]:
        visible = {key: item.get(key) for key in ("name", "dueAt", "status", "error", "sentAt", "closeAfter")}
        try:
            visible["message"] = decrypt_text(item["message"])
        except Exception:
            visible["message"] = "문구를 해독할 수 없어요"
        items.append(visible)
    sent = sum(item["status"] == "sent" for item in items)
    labels = {"running": "발송 중", "waiting": "예약 대기 중", "paused": "일시 중지됨",
              "complete": "발송 완료", "cancelled": "취소됨", "error": "확인 후 재개 필요"}
    state = queue.get("state", "paused")
    return {"running": state in ("running", "waiting"), "state": state,
            "text": labels.get(state, "대기 중"), "sent": sent, "total": len(items),
            "items": items, "accountId": queue.get("accountId"), "error": queue.get("error", ""),
            "createdAt": queue.get("createdAt", time.time())}
