# -*- coding: utf-8 -*-
"""Opt-in local KakaoTalk group reply helper.

This uses OCR and desktop input because ordinary KakaoTalk group chats do not
expose a public bot API. It never starts sending until the user presses Start.
"""
import ctypes
import ctypes.wintypes
from datetime import datetime
import hashlib
import os
import re
import statistics
import threading
import time
import unicodedata

from . import paths
from . import kakao_window
from . import kakao_profiles
from . import kakao_send_queue
from .util import load_config, save_config, log


def _windows():
    return kakao_window.windows()


def _main_window():
    return kakao_window.main_window()


def _focus_window(window, region, hold=False, cancel=None):
    import pyautogui
    if cancel and cancel.is_set():
        return False
    user32 = ctypes.windll.user32
    user32.BringWindowToTop.argtypes = [ctypes.wintypes.HWND]
    user32.SetForegroundWindow.argtypes = [ctypes.wintypes.HWND]
    user32.ShowWindow(window["hwnd"], 9)
    kakao_window.set_topmost(window, True)
    try:
        # Topmost only changes the Z-order. Explicitly request keyboard focus
        # before the click, then verify it belongs to the same Kakao window.
        user32.BringWindowToTop(window["hwnd"])
        user32.SetForegroundWindow(window["hwnd"])
        if region == "chats":
            x, y = window["left"] + 32, window["top"] + min(116, window["height"] // 8)
        elif region == "input":
            # KakaoTalk keeps its send/attachment toolbar in the bottom 60px.
            # The editable composer is above that toolbar.
            x, y = window["left"] + int(window["width"] * .50), window["top"] + window["height"] - 95
        else:
            user32.SetForegroundWindow(window["hwnd"])
            return user32.GetForegroundWindow() == window["hwnd"]
        for _ in range(8):
            if cancel and cancel.is_set():
                return False
            if kakao_window.point_belongs(window, x, y):
                break
            time.sleep(0.2)
        else:
            return False
        if cancel and cancel.is_set():
            return False
        pyautogui.click(x, y)
        time.sleep(0.15)
    finally:
        if not hold:
            kakao_window.set_topmost(window, False)
    return (kakao_window.point_belongs(window, x, y) and
            user32.GetForegroundWindow() == window["hwnd"])


def _chat_list_visible(lines, window):
    """Reject the friends tab before any mouse scrolling or room selection."""
    heading = [x["text"].strip() for x in lines
               if x["y"] < window["height"] * .11 and x["x"] < window["width"] * .35]
    return "친구" not in heading and ("채팅" in heading or "전체" in heading)


def _timestamp(text):
    return bool(re.match(r"^(?:\d{4}[.-]\d{1,2}[.-]\d{1,2}|(?:오전|오후)\s*\d{1,2}:\d{2}|어제|[월화수목금토일]요일)",
                         text.strip()))


def _name_band(image, anchor):
    """Find the dark, bold name line near a chat row's right-hand timestamp."""
    import numpy as np
    width, height = image.size
    top, bottom = max(0, int(anchor) - 17), min(height, int(anchor) + 16)
    area = np.asarray(image.crop((int(width * .26), top, int(width * .73), bottom)).convert("RGB"))
    counts = (area.min(axis=2) < 180).sum(axis=1)
    active = counts >= 4
    spans, start = [], None
    for offset, marked in enumerate(list(active) + [False]):
        if marked and start is None:
            start = offset
        elif not marked and start is not None:
            if offset - start >= 6:
                spans.append((top + start, top + offset))
            start = None
    return min(spans, key=lambda pair: abs((pair[0] + pair[1]) / 2 - anchor), default=None)


def _incoming_bubble(image, item):
    """Accept text surrounded by the light incoming bubble, not UI labels."""
    x, y = int(item["x"]), int(item["y"])
    right, bottom = int(item["x"] + item["w"]), int(item["y"] + item["h"])
    if x < image.width * .12 or right > image.width * .62:
        return False
    corners = ((x - 3, y - 3), (right + 3, y - 3),
               (x - 3, bottom + 3), (right + 3, bottom + 3))
    light = 0
    for px, py in corners:
        color = image.getpixel((max(0, min(image.width - 1, px)),
                                max(0, min(image.height - 1, py))))[:3]
        if min(color) >= 245 and max(color) - min(color) <= 12:
            light += 1
    return light >= 3


def _scroll_list(window, amount):
    import pyautogui
    x = window["left"] + min(150, int(window["width"] * .28))
    y = window["top"] + int(window["height"] * .70)
    if not kakao_window.point_belongs(window, x, y):
        kakao_window.set_topmost(window, True)
        user32 = ctypes.windll.user32
        user32.BringWindowToTop.argtypes = [ctypes.wintypes.HWND]
        user32.SetForegroundWindow.argtypes = [ctypes.wintypes.HWND]
        user32.BringWindowToTop(window["hwnd"])
        user32.SetForegroundWindow(window["hwnd"])
        time.sleep(.2)
        if not kakao_window.point_belongs(window, x, y):
            raise RuntimeError("카카오톡 채팅 목록이 다른 창에 가려져 스크롤을 중단했어요")
    pyautogui.moveTo(x, y)
    pyautogui.scroll(amount)


class KakaoAutoReplyManager:
    def __init__(self):
        self._lock = threading.RLock()
        self._thread = None
        self._stop = threading.Event()
        self._scan_cancel = threading.Event()
        self._status = {"running": False, "text": "중지됨", "lastScan": ""}
        self._rooms = []
        self._ambiguous_names = set()
        self._ocr = None
        self._observed = {}
        self._observed_frames = {}
        self._last_ocr_at = {}
        self._ui_lock = threading.Lock()
        self._active_account = None
        self._active_pid = None
        self._send_thread = None
        self._send_stop = threading.Event()
        self._queue = None
        self._queue_loaded = False
        self._list_step = None

    def accounts(self):
        return {"accounts": kakao_profiles.list_accounts(),
                "activeAccountId": self._active_account}

    def delete_account(self, account_id):
        if account_id == self._active_account:
            self.stop_all()
            self._active_account = None
            self._active_pid = None
            self._rooms = []
            self._ambiguous_names = set()
        kakao_profiles.delete_account(account_id)
        return self.accounts()

    def bind_account(self, account_id):
        kakao_profiles.get_account(account_id)
        self.stop()
        self.stop_send()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)
        if self._send_thread and self._send_thread.is_alive():
            self._send_thread.join(timeout=5)
        if ((self._thread and self._thread.is_alive()) or
                (self._send_thread and self._send_thread.is_alive())):
            raise RuntimeError("기존 카카오톡 작업이 끝나는 중이에요. 잠시 후 계정을 연결해 주세요")
        main = self.prepare_window()
        self._active_account = account_id
        self._active_pid = main["pid"]
        self._rooms = []
        self._ambiguous_names = set()
        self._list_step = None
        self._observed = {}
        self._observed_frames = {}
        self._last_ocr_at = {}
        self._status.update(text="현재 PC 카카오톡에 계정 설정을 연결했어요", error="")
        return self.accounts()

    def _require_account(self, account_id):
        if not account_id or self._active_account != account_id:
            raise RuntimeError("PC 카카오톡에 이 계정 설정을 먼저 연결해 주세요")
        main = _main_window()
        if not main or main["pid"] != self._active_pid:
            self.stop()
            self.stop_send()
            raise RuntimeError("카카오톡 로그인 창이 바뀌었어요. 계정을 다시 연결해 주세요")
        return main

    def _get_ocr(self):
        if self._ocr is None:
            from rapidocr import RapidOCR
            from rapidocr.utils.typings import OCRVersion, ModelType
            import onnxruntime as ort
            self._ocr = RapidOCR(params={
                "Rec.lang_type": "korean",
                "Rec.ocr_version": OCRVersion.PPOCRV5,
                "Rec.model_type": ModelType.MOBILE,
                "Global.model_root_dir": (os.path.join(paths.resource_dir(), "assets", "ocr_models")
                                          if os.path.isfile(os.path.join(paths.resource_dir(), "assets", "ocr_models",
                                                                         "korean_PP-OCRv5_rec_mobile.onnx"))
                                          else os.path.join(paths.data_dir(), "ocr_models")),
            })
            # Fail early with a human-readable install diagnosis rather than
            # silently running without a text-recognition engine.
            ort.get_available_providers()
        return self._ocr

    @staticmethod
    def _capture(window):
        return kakao_window.capture(window)

    def _read(self, window, raw=None, scale=1.0):
        import numpy as np
        raw = raw if raw is not None else self._capture(window)
        if scale != 1.0:
            raw = raw.resize((round(raw.width * scale), round(raw.height * scale)))
        image = np.asarray(raw)
        # RapidOCR remembers the previous call's flags. A title-only
        # recognition pass must not leave detection disabled for the next page.
        result = self._get_ocr()(image, use_det=True, use_cls=False)
        if result is None:
            return []
        if hasattr(result, "txts"):
            boxes, texts, scores = result.boxes, result.txts, result.scores
        else:
            boxes, texts, scores = result
        out = []
        if boxes is None or texts is None or scores is None:
            return []
        for box, txt, score in zip(boxes, texts, scores):
            text = re.sub(r"\s+", " ", str(txt)).strip()
            if text and float(score) >= 0.65:
                pts = list(box)
                xs = [float(p[0]) for p in pts]
                ys = [float(p[1]) for p in pts]
                out.append({"text": text, "x": min(xs) / scale, "y": min(ys) / scale,
                            "w": (max(xs) - min(xs)) / scale, "h": (max(ys) - min(ys)) / scale,
                            "score": float(score)})
        return sorted(out, key=lambda x: (x["y"], x["x"]))

    def _list_rows(self, window):
        """Read room names from their own line; never promote previews to names."""
        import numpy as np
        image = self._capture(window)
        lines = self._read(window, image)
        if not _chat_list_visible(lines, window):
            raise RuntimeError("카카오톡 채팅 탭이 아니에요. 왼쪽 말풍선 모양 채팅 탭을 열어 주세요")
        stamps = sorted(x["y"] for x in lines if x["x"] > window["width"] * .77 and
                        window["height"] * .11 < x["y"] < window["height"] * .91 and
                        _timestamp(x["text"]))
        gaps = [b - a for a, b in zip(stamps, stamps[1:]) if 48 <= b - a <= 105]
        if not stamps:
            raise RuntimeError("채팅 목록의 날짜·시간 줄을 읽지 못했어요. 채팅 탭을 열고 창 크기를 확인해 주세요")
        step = statistics.median(gaps) if gaps else (self._list_step or max(60, min(90, window["height"] * .067)))
        self._list_step = step
        first = stamps[0]
        while first - step >= window["height"] * .11:
            first -= step
        rows = []
        for index in range(20):
            anchor = first + index * step
            if anchor > window["height"] * .91:
                break
            # The timestamp and bold room title share one row. The lighter
            # message preview is below it and must never become a room name.
            options = [(x["text"].strip(), x["score"], x["x"], x["y"], x["w"], x["h"])
                       for x in lines if anchor - 10 <= x["y"] <= anchor + 18 and
                       window["width"] * .24 <= x["x"] <= window["width"] * .76 and
                       x["y"] + x["h"] <= anchor + 25 and
                       not _timestamp(x["text"])]
            options.sort(key=lambda item: item[1], reverse=True)
            chosen = next((item for item in options if item[1] >= .90 and
                           re.search(r"[가-힣A-Za-z0-9]", item[0]) and len(item[0]) >= 2), None)
            if chosen:
                name, score, x, y, text_width, text_height = chosen
            else:
                # One narrow recognition pass only when the full-window OCR
                # missed the title. Remove gray icons and preview text first.
                top, bottom = max(0, int(anchor) - 8), min(image.height, int(anchor) + 24)
                left = int(window["width"] * .26)
                right = int(window["width"] * .75)
                gray = np.asarray(image.crop((left, top, right, bottom)).convert("L"))
                if gray.size == 0 or int((gray < 110).sum()) < 12:
                    continue
                mono = np.where(gray < 110, 0, 255).astype(np.uint8)
                strip = np.repeat(np.repeat(mono, 3, axis=0), 3, axis=1)
                result = self._get_ocr()(np.stack((strip, strip, strip), axis=2),
                                         use_det=False, use_cls=False)
                if not result.txts or not result.scores or result.scores[0] < .78:
                    continue
                name, score, x, y, text_width, text_height = (str(result.txts[0]).strip(),
                                                               float(result.scores[0]), left, top,
                                                               right - left, bottom - top)
            name = re.sub(r"^[①-⑳]\s*(?=[가-힣])", "", name.strip(" +"))
            if _timestamp(name) or name in ("전체", "채팅", "친구"):
                continue
            rows.append({"name": name, "x": int(x), "y": int(y), "w": int(text_width),
                         "h": int(text_height), "score": round(float(score), 3)})
        return rows

    def prepare_window(self):
        if os.name != "nt":
            raise RuntimeError("카카오톡 PC 기능은 Windows에서만 사용할 수 있어요")
        main = _main_window()
        if not main:
            raise RuntimeError("카카오톡 채팅 목록 창을 찾지 못했어요. PC 카카오톡에 로그인하고 메인 창을 열어 주세요")
        ctypes.windll.user32.ShowWindow(main["hwnd"], 9)
        main = kakao_window.dock_right(main)
        self._status.update(text="카카오톡 창을 오른쪽에 배치했어요")
        return main

    def dock(self):
        if not self._ui_lock.acquire(blocking=False):
            raise RuntimeError("카카오톡 화면을 사용하는 작업이 진행 중이에요")
        try:
            return self.prepare_window()
        finally:
            self._ui_lock.release()

    def scan_rooms(self, account_id=None):
        """Read the visible chat-list pane and scroll through it to find room labels."""
        if os.name != "nt":
            raise RuntimeError("카카오톡 PC 자동응답은 Windows에서만 사용할 수 있어요")
        account_id = account_id or self._active_account
        self._require_account(account_id)
        if not self._ui_lock.acquire(blocking=False):
            raise RuntimeError("카카오톡 화면을 사용하는 작업이 진행 중이에요")
        try:
            self._scan_cancel.clear()
            self._rooms = []
            self._ambiguous_names = set()
            self._list_step = None
            self._status.update(text="채팅 목록 읽는 중", error="")
            return self._scan_rooms_locked(account_id)
        finally:
            main = _main_window()
            if main:
                try:
                    kakao_window.set_topmost(main, False)
                except RuntimeError:
                    pass
            self._ui_lock.release()

    def _scan_rooms_locked(self, account_id):
        main = self.prepare_window()
        import pyautogui
        if not _focus_window(main, "chats", hold=True):
            raise RuntimeError("카카오톡 창을 활성화하지 못했어요. 창을 직접 클릭한 뒤 다시 시도해 주세요")
        time.sleep(0.3)
        first = self._list_rows(main)
        if self._scan_cancel.is_set():
            raise RuntimeError("채팅방 읽기가 중지됐어요")
        left_rows, seen_pages, known, ambiguous = [], set(), {}, set()
        # The standalone Kakao main window uses almost its full width for the
        # chat list. Keep one title per row rather than storing message previews.
        unchanged_pages = 0
        for page_index in range(20):
            if self._scan_cancel.is_set():
                raise RuntimeError("채팅방 읽기가 중지됐어요")
            candidates = first if page_index == 0 else self._list_rows(main)
            if self._scan_cancel.is_set():
                raise RuntimeError("채팅방 읽기가 중지됐어요")
            page = tuple(x["name"] for x in candidates)
            if not page or page in seen_pages:
                break
            seen_pages.add(page)
            added = 0
            page_keys = [unicodedata.normalize("NFKC", x["name"].strip()).casefold() for x in candidates]
            ambiguous.update(key for key in page_keys if page_keys.count(key) > 1)
            for item in candidates:
                text = item["name"].strip()
                key = unicodedata.normalize("NFKC", text).casefold()
                if key not in known:
                    known[key] = dict(item)
                    added += 1
            unchanged_pages = 0 if added else unchanged_pages + 1
            if unchanged_pages >= 2:
                break
            if self._scan_cancel.is_set():
                raise RuntimeError("채팅방 읽기가 중지됐어요")
            _scroll_list(main, -5)
            time.sleep(0.25)
        # Return the visible list to its first page. Polling locates selected
        # rooms by OCR on each pass, so off-screen rooms are still supported.
        if self._scan_cancel.is_set():
            raise RuntimeError("채팅방 읽기가 중지됐어요")
        _scroll_list(main, 500)
        time.sleep(0.25)
        if self._scan_cancel.is_set():
            raise RuntimeError("채팅방 읽기가 중지됐어요")
        for item in known.values():
            if not any(x["name"] == item["name"] for x in left_rows):
                left_rows.append(item)
        left_rows = left_rows[:300]
        if not left_rows:
            raise RuntimeError("채팅방 이름을 읽지 못했어요. 채팅 탭을 선택하고 한글 OCR 모델 설치 상태를 확인해 주세요")
        self._rooms = left_rows
        self._ambiguous_names = ambiguous
        self._status.update(text=f"채팅방 {len(left_rows)}개를 읽었어요", error="",
                            lastScan=time.strftime("%H:%M:%S"))
        kinds = {r["name"].casefold(): r.get("kind", "normal")
                 for r in kakao_profiles.get_account(account_id).get("rooms", [])}
        return [{"name": r["name"], "kind": kinds.get(r["name"].casefold(), "normal"),
                 "confidence": r.get("score", 0),
                 "ambiguous": unicodedata.normalize("NFKC", r["name"]).casefold() in ambiguous}
                for r in left_rows]

    def settings(self, account_id=None):
        account_id = account_id or self._active_account or kakao_profiles.list_accounts()[0]["id"]
        return kakao_profiles.get_account(account_id)

    def save_settings(self, value, account_id=None):
        account_id = account_id or self._active_account or kakao_profiles.list_accounts()[0]["id"]
        return kakao_profiles.save_account(account_id, value)

    def start(self, account_id=None):
        with self._lock:
            if self._thread and self._thread.is_alive():
                return self.status()
            if self._send_thread and self._send_thread.is_alive():
                raise RuntimeError("직접 메시지 발송이 끝난 뒤 자동응답을 시작해 주세요")
            account_id = account_id or self._active_account
            self._require_account(account_id)
            if not load_config().get("auto"):
                raise ValueError("상단 자동 모드가 꺼져 있어요. 켠 뒤 카카오톡 자동응답을 시작해 주세요")
            config = self.settings(account_id)
            enabled_rooms = [r for r in config.get("rooms", []) if r.get("enabled") and r.get("reply")]
            if not enabled_rooms:
                raise ValueError("응답할 채팅방과 답변을 저장해 주세요")
            self._validate_scanned_rooms([r["name"] for r in enabled_rooms])
            self._stop.clear()
            self._scan_cancel.clear()
            self._thread = threading.Thread(target=self._run, args=(account_id,), daemon=True,
                                            name="kakao-auto-reply")
            self._status.update(running=True, text="시작 중", error="")
            self._thread.start()
            return self.status()

    def stop(self):
        self._stop.set()
        self._scan_cancel.set()
        self._status.update(running=False, text="중지됨", error="")
        return self.status()

    def stop_all(self):
        self.stop()
        self.stop_send()
        return {"reply": self.status(), "send": self.send_status()}

    def send_status(self):
        with self._lock:
            self._load_queue()
            return kakao_send_queue.public(self._queue)

    def _load_queue(self):
        if not self._queue_loaded:
            self._queue = kakao_send_queue.load()
            self._queue_loaded = True

    def _save_queue(self):
        kakao_send_queue.save(self._queue)

    def stop_send(self):
        self._send_stop.set()
        with self._lock:
            self._load_queue()
            if self._queue and self._queue["state"] in ("running", "waiting"):
                self._queue["state"] = "paused"
                self._save_queue()
        return self.send_status()

    def cancel_send(self):
        self.stop_send()
        with self._lock:
            if self._queue and self._queue["state"] != "complete":
                self._queue["state"] = "cancelled"
                for item in self._queue["items"]:
                    if item["status"] == "pending":
                        item["status"] = "cancelled"
                self._save_queue()
        return self.send_status()

    def resolve_send_item(self, index, outcome):
        with self._lock:
            self._load_queue()
            if not self._queue or self._queue["state"] not in ("error", "paused"):
                raise ValueError("확인할 대기열이 없어요")
            index = int(index)
            if index < 0 or index >= len(self._queue["items"]):
                raise ValueError("대상을 찾지 못했어요")
            item = self._queue["items"][index]
            if item["status"] != "review" or outcome not in ("sent", "skipped"):
                raise ValueError("확인 필요 항목은 발송 확인 또는 건너뛰기만 선택할 수 있어요")
            item.update(status=outcome, error="")
            self._save_queue()
        return self.send_status()

    def _validate_scanned_rooms(self, names):
        scanned = {r["name"] for r in self._rooms}
        if any(name not in scanned for name in names):
            raise ValueError("현재 계정에서 채팅방 목록을 새로 읽고 대상 방을 확인해 주세요")
        if any(unicodedata.normalize("NFKC", name).casefold() in self._ambiguous_names
               for name in names):
            raise ValueError("같은 이름의 채팅방이 여러 개 있어 안전하게 구분할 수 없어요")

    def start_send(self, account_id, room_names, message, options=None):
        options = options or {}
        account = self.settings(account_id)
        self._require_account(account_id)
        if self._thread and self._thread.is_alive():
            raise RuntimeError("자동응답을 중지한 뒤 직접 발송해 주세요")
        if self._send_thread and self._send_thread.is_alive():
            raise RuntimeError("이미 메시지를 보내는 중이에요")
        names = [str(x).strip() for x in (room_names or [])]
        if not 1 <= len(names) <= 20 or len(set(names)) != len(names):
            raise ValueError("보낼 방을 1~20개 선택해 주세요")
        allowed = {r["name"] for r in account.get("rooms", [])}
        if any(name not in allowed for name in names):
            raise ValueError("이 계정에 저장되지 않은 방이 포함됐어요. 목록을 읽고 저장해 주세요")
        self._validate_scanned_rooms(names)
        message = str(message or "").strip()
        if not 1 <= len(message) <= 1000:
            raise ValueError("보낼 메시지를 1~1000자로 입력해 주세요")
        raw_interval = options.get("intervalMinutes", 3)
        try:
            interval = float(raw_interval)
        except (TypeError, ValueError):
            raise ValueError("발송 간격을 숫자로 입력해 주세요")
        if not 0.1 <= interval <= 1440:
            raise ValueError("발송 간격은 0.1~1440분으로 입력해 주세요")
        start_value = str(options.get("startAt") or "").strip()
        try:
            start = datetime.fromisoformat(start_value).timestamp() if start_value else time.time()
        except ValueError:
            raise ValueError("시작 시각을 다시 입력해 주세요")
        if start > time.time() + 30 * 86400 or start < time.time() - 60:
            raise ValueError("시작 시각은 현재부터 30일 이내로 설정해 주세요")
        overrides = options.get("messages") or {}
        if not isinstance(overrides, dict) or any(key not in names for key in overrides):
            raise ValueError("대상별 문구 설정을 확인해 주세요")
        close_after = options.get("closeAfter", True) is not False
        items = []
        for index, name in enumerate(names):
            body = str(overrides.get(name) or message).strip()
            if not 1 <= len(body) <= 1000:
                raise ValueError(f"{name} 방 문구는 1~1000자로 입력해 주세요")
            items.append({"name": name, "message": kakao_send_queue.encrypt_text(body),
                          "dueAt": start + index * interval * 60, "status": "pending",
                          "sentAt": None, "error": "", "closeAfter": close_after})
        with self._lock:
            self._load_queue()
            if self._queue and self._queue["state"] not in ("complete", "cancelled"):
                raise RuntimeError("기존 대기열을 완료하거나 취소한 뒤 새로 등록해 주세요")
            self._queue = {"accountId": account_id, "createdAt": time.time(),
                           "intervalSeconds": interval * 60,
                           "state": "waiting", "error": "", "items": items}
            self._save_queue()
        self._start_queue_thread()
        return self.send_status()

    def _start_queue_thread(self):
        self._send_stop.clear()
        self._send_thread = threading.Thread(target=self._run_queue, daemon=True,
                                             name="kakao-scheduled-send")
        self._send_thread.start()

    def resume_send(self, account_id):
        with self._lock:
            self._load_queue()
            if not self._queue or self._queue["state"] not in ("paused", "error"):
                raise ValueError("재개할 대기열이 없어요")
            if self._send_thread and self._send_thread.is_alive():
                raise RuntimeError("기존 발송 작업이 멈추는 중이에요. 잠시 후 다시 시도해 주세요")
            if account_id != self._queue["accountId"]:
                raise ValueError("예약한 계정 설정을 선택해 주세요")
            self._require_account(account_id)
            pending = [item["name"] for item in self._queue["items"] if item["status"] == "pending"]
            if any(item["status"] == "review" for item in self._queue["items"]):
                raise ValueError("확인 필요 항목을 먼저 직접 확인해 주세요")
            if not pending:
                raise ValueError("남은 발송 대상이 없어요")
            self._validate_scanned_rooms(pending)
            self._queue.update(state="waiting", error="")
            self._save_queue()
            self._start_queue_thread()
        return self.send_status()

    def _run_queue(self):
        try:
            last_sent = max((entry.get("sentAt") or 0 for entry in self._queue["items"]
                             if entry["status"] == "sent"), default=0)
            for index, item in enumerate(self._queue["items"]):
                if item["status"] != "pending":
                    continue
                with self._lock:
                    if self._queue["state"] not in ("running", "waiting"):
                        return
                    self._queue["state"] = "waiting"
                    self._save_queue()
                due_at = max(item["dueAt"], last_sent + self._queue.get("intervalSeconds", 180))
                if self._send_stop.wait(max(0, due_at - time.time())):
                    return
                with self._lock:
                    if self._send_stop.is_set() or self._queue["state"] not in ("running", "waiting"):
                        return
                    self._queue["state"] = "running"
                    item["status"] = "sending"
                    self._save_queue()
                try:
                    self._require_account(self._queue["accountId"])
                    message = kakao_send_queue.decrypt_text(item["message"])
                    with self._ui_lock:
                        chat = self._send_one(self._queue["accountId"], item["name"], message)
                    if chat is None:
                        with self._lock:
                            item["status"] = "cancelled" if self._queue["state"] == "cancelled" else "pending"
                            self._save_queue()
                        return
                    with self._lock:
                        item.update(status="sent", sentAt=time.time())
                        self._save_queue()
                        last_sent = item["sentAt"]
                    log("INFO", f"카카오톡 예약 메시지 발송: {item['name']}")
                    if item["closeAfter"]:
                        kakao_window.close_room(chat, item["name"])
                except Exception as exc:
                    with self._lock:
                        if item["status"] == "sending":
                            item["status"] = "review"
                            item["error"] = "발송 여부 확인 필요: " + str(exc)[:180]
                        self._queue.update(state="error", error=str(exc)[:240])
                        self._save_queue()
                    log("WARN", f"카카오톡 예약 발송 중단: {type(exc).__name__}")
                    return
            with self._lock:
                if self._queue["state"] in ("running", "waiting"):
                    self._queue["state"] = "complete"
                    self._save_queue()
        finally:
            with self._lock:
                if self._queue and self._queue["state"] in ("running", "waiting"):
                    self._queue["state"] = "paused"
                    self._save_queue()

    def _send_one(self, account_id, name, message):
        main = None
        try:
            main = self.prepare_window()
            if self._send_stop.is_set():
                return None
            if not _focus_window(main, "chats", hold=True, cancel=self._send_stop):
                if self._send_stop.is_set():
                    return None
                raise RuntimeError("카카오톡 채팅 목록을 활성화하지 못했어요")
            if not self._locate_room(main, name, self._send_stop):
                if self._send_stop.is_set():
                    return None
                raise RuntimeError(f"{name} 채팅방을 찾지 못해 발송을 중단했어요")
            kakao_window.set_topmost(main, False)
            chat = self._wait_room_window(main, name, self._send_stop)
            if not chat:
                if self._send_stop.is_set():
                    return None
                raise RuntimeError(f"{name} 채팅창을 확인하지 못해 발송을 중단했어요")
            chat = kakao_window.dock_right(chat)
            if self._send_stop.is_set():
                return None
            confirmed = kakao_window.room_window(name, exclude=(main["hwnd"],))
            if not confirmed or confirmed["hwnd"] != chat["hwnd"] or confirmed["pid"] != main["pid"]:
                raise RuntimeError(f"{name} 채팅창이 바뀌어 발송을 중단했어요")
            if not self._send_reply(chat, message, self._send_stop):
                return None
            return chat
        finally:
            if main:
                try:
                    kakao_window.set_topmost(main, False)
                except RuntimeError:
                    pass

    def fail(self, message):
        self._stop.set()
        self._scan_cancel.set()
        self._status.update(running=False, text="오류로 중단됨", error=str(message)[:240])
        return self.status()

    def status(self):
        return {**self._status}

    def _send_reply(self, window, text, cancel=None):
        import pyautogui
        import pyperclip
        cancel = cancel or self._stop
        # Focus the detected KakaoTalk chat window and use clipboard paste so
        # Korean text is not lost through simulated key presses.
        try:
            if (not _focus_window(window, "input", hold=True, cancel=cancel) or
                    ctypes.windll.user32.GetForegroundWindow() != window["hwnd"] or
                    window["hwnd"] not in {w["hwnd"] for w in _windows()}):
                raise RuntimeError("선택한 카카오톡 채팅창을 활성화하지 못해 전송을 중단했어요")
            if cancel.is_set():
                return False
            pyperclip.copy(text)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(0.25)
            if cancel.is_set():
                return False
            if ctypes.windll.user32.GetForegroundWindow() != window["hwnd"]:
                raise RuntimeError("전송 직전 카카오톡 채팅창 포커스가 바뀌어 중단했어요")
            pyautogui.press("enter")
            return True
        finally:
            try:
                kakao_window.set_topmost(window, False)
            except RuntimeError:
                pass

    def _locate_room(self, window, name, cancel=None):
        import pyautogui
        cancel = cancel or self._stop
        _scroll_list(window, 500)
        time.sleep(0.15)
        target = unicodedata.normalize("NFKC", name).casefold()
        for _ in range(20):
            if cancel.is_set():
                return False
            candidates = self._list_rows(window)
            if cancel.is_set():
                return False
            if sum(unicodedata.normalize("NFKC", item["name"]).casefold() == target
                   for item in candidates) > 1:
                return False
            for item in candidates:
                text = unicodedata.normalize("NFKC", item["name"]).casefold()
                if text == target:
                    x = window["left"] + item["x"] + max(10, item["w"] // 2)
                    y = window["top"] + item["y"] + max(10, item["h"] // 2)
                    if not kakao_window.point_belongs(window, x, y):
                        # A notification or another window can briefly cover
                        # the row. Refocus the same Kakao window once, then
                        # reject the click if its ownership is still unclear.
                        if not _focus_window(window, "chats", hold=True, cancel=cancel):
                            return False
                        if not kakao_window.point_belongs(window, x, y):
                            return False
                    if cancel.is_set():
                        return False
                    pyautogui.doubleClick(x, y, interval=0.12)
                    return True
            if cancel.is_set():
                return False
            _scroll_list(window, -5)
            time.sleep(0.15)
        if cancel.is_set():
            return False
        _scroll_list(window, 500)
        return False

    @staticmethod
    def _wait_room_window(main, name, cancel=None):
        """KakaoTalk opens a separate chat window asynchronously."""
        for _ in range(25):
            if cancel is not None and cancel.is_set():
                return None
            chat = kakao_window.room_window(name, exclude=(main["hwnd"],))
            if chat and chat["pid"] == main["pid"]:
                return chat
            time.sleep(0.2)
        return None

    @staticmethod
    def _cooldown_ok(name, msg_hash, seconds):
        import sqlite3
        db = os.path.join(paths.data_dir(), "kakao_reply_dedupe.sqlite3")
        now = time.time()
        os.makedirs(os.path.dirname(db), exist_ok=True)
        with sqlite3.connect(db, timeout=10) as con:
            con.execute("CREATE TABLE IF NOT EXISTS replies(room TEXT PRIMARY KEY, hash TEXT NOT NULL, sent REAL NOT NULL)")
            row = con.execute("SELECT hash,sent FROM replies WHERE room=?", (name,)).fetchone()
            return not (row and (row[0] == msg_hash or now - float(row[1]) < seconds))

    @staticmethod
    def _mark_sent(name, msg_hash):
        import sqlite3
        db = os.path.join(paths.data_dir(), "kakao_reply_dedupe.sqlite3")
        with sqlite3.connect(db, timeout=10) as con:
            con.execute("INSERT INTO replies VALUES(?,?,?) ON CONFLICT(room) DO UPDATE SET hash=excluded.hash,sent=excluded.sent",
                        (name, msg_hash, time.time()))

    def _run(self, account_id):
        try:
            cfg = self.settings(account_id)
            rooms = [r for r in cfg.get("rooms", []) if r.get("enabled") and r.get("reply")]
            interval = int(cfg.get("intervalValue", 1)) * (3600 if cfg.get("intervalUnit") == "hours" else 60)
            self._status.update(text="카카오톡 채팅방 확인 중")
            # Capture a baseline first; never reply to an old message merely
            # because the feature was enabled for the first time.
            baseline = True
            while not self._stop.is_set():
                bound_main = self._require_account(account_id)
                if not load_config().get("auto"):
                    self.stop()
                    break
                for room in rooms:
                    if self._stop.is_set():
                        break
                    with self._ui_lock:
                        main = None
                        try:
                            main = bound_main
                            if not main:
                                raise RuntimeError("카카오톡 메인 창을 찾지 못했어요")
                            chat = kakao_window.room_window(room["name"], exclude=(main["hwnd"],))
                            opened = not chat
                            if not chat:
                                main = self.prepare_window()
                                if not _focus_window(main, "chats", hold=True):
                                    raise RuntimeError("카카오톡 창을 활성화하지 못했어요")
                                if not self._locate_room(main, room["name"]):
                                    if self._stop.is_set():
                                        break
                                    raise RuntimeError(f"{room['name']} 채팅방을 찾지 못했어요")
                                kakao_window.set_topmost(main, False)
                                chat = self._wait_room_window(main, room["name"], self._stop)
                            if not chat:
                                if self._stop.is_set():
                                    break
                                raise RuntimeError(f"{room['name']} 채팅창을 확인하지 못해 중단했어요")
                            if opened:
                                chat = kakao_window.dock_right(chat)
                            if chat["pid"] != main["pid"]:
                                raise RuntimeError(f"{room['name']} 채팅창이 다른 프로세스라 중단했어요")
                            confirmed = kakao_window.room_window(room["name"], exclude=(main["hwnd"],))
                            if not confirmed or confirmed["hwnd"] != chat["hwnd"]:
                                raise RuntimeError(f"{room['name']} 채팅창이 바뀌어 자동응답을 중단했어요")
                            image = self._capture(chat)
                            frame = image.crop((0, int(image.height * .18), image.width,
                                                max(int(image.height * .18) + 1, image.height - 110)))
                            fingerprint = hashlib.blake2b(frame.resize((80, 80)).tobytes(), digest_size=8).digest()
                            changed = (baseline or self._observed_frames.get(room["name"]) != fingerprint or
                                       time.time() - self._last_ocr_at.get(room["name"], 0) > 300)
                            if changed:
                                lines = self._read(chat, image, scale=1.5)
                                self._observed_frames[room["name"]] = fingerprint
                                self._last_ocr_at[room["name"]] = time.time()
                            else:
                                lines = []
                        finally:
                            if main:
                                try:
                                    kakao_window.set_topmost(main, False)
                                except RuntimeError:
                                    pass
                    # Only incoming bubbles in the left part of this selected
                    # Kakao-owned chat window are eligible. Header and composer
                    # are excluded; uncertain text is never sent.
                    inbound = [x for x in lines if x["score"] >= .75 and
                               x["y"] > chat["height"] * .18 and
                               x["y"] < chat["height"] - 110 and
                               x["text"].strip() != room["name"] and
                               not _timestamp(x["text"]) and
                               _incoming_bubble(image, x)]
                    if not inbound:
                        continue
                    msg = max(inbound, key=lambda x: x["y"])["text"].strip()
                    if not re.search(r"[가-힣A-Za-z0-9]", msg):
                        continue
                    digest = hashlib.sha256(msg.encode("utf-8")).hexdigest()
                    previous = self._observed.get(room["name"])
                    self._observed[room["name"]] = digest
                    if baseline or previous is None or previous == digest:
                        continue
                    if room.get("mode") == "keywords" and not any(k.casefold() in msg.casefold() for k in room.get("keywords", [])):
                        continue
                    dedupe_key = f"{account_id}:{room['name']}"
                    if not self._cooldown_ok(dedupe_key, digest, interval):
                        continue
                    if self._stop.is_set():
                        break
                    with self._ui_lock:
                        sent = self._send_reply(chat, room["reply"])
                    if not sent:
                        break
                    self._mark_sent(dedupe_key, digest)
                    self._status.update(text=f"{room['name']} 답변 전송", lastScan=time.strftime("%H:%M:%S"))
                    log("INFO", f"카카오톡 자동응답 전송: {room['name']}")
                if self._stop.is_set():
                    break
                baseline = False
                self._status.update(text="실행 중 · 다음 확인 대기")
                self._stop.wait(10)
        except Exception as exc:
            self.fail(f"{type(exc).__name__}: {str(exc)}")
            log("WARN", f"카카오톡 자동응답 중지: {type(exc).__name__}")
        finally:
            self._status["running"] = False


manager = KakaoAutoReplyManager()
