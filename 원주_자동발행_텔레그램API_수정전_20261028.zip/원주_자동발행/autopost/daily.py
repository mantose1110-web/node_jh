# -*- coding: utf-8 -*-
"""오늘의 일상 글 (카페용 탭): 오늘 찍은 사진 → AI가 사진을 보고 '글 지시문(프롬프트)'을 짜 줌 → 사장님이 확인·수정 → 글 생성

1) 사진 올리기: 자료함에 'daily' 사진으로 저장 (위치정보 EXIF 제거)
2) AI 계획: Claude 비전이 사진마다 보이는 것만 설명하고, 오늘 글의 핵심 키워드·제목 후보·글쓰기 지시문을 만듦
3) 글 만들기: 고른 채널·계정마다 작업을 만들어 사진 순서대로 글 속에 넣음 (테스트 모드면 미리보기만)
"""
import base64, io
from . import library as lib
from .util import log

PLAN_TOOL = {"name": "submit_plan", "description": "오늘의 일상 글 계획 제출",
             "input_schema": {"type": "object", "properties": {
                 "photos": {"type": "array", "items": {"type": "object", "properties": {
                     "index": {"type": "integer"}, "description": {"type": "string", "description": "사진에 보이는 것만 한 문장"},
                     "labels": {"type": "array", "items": {"type": "string"}}}, "required": ["index", "description"]}},
                 "summary": {"type": "string", "description": "오늘 하루 요약 2문장 (사진과 메모에 있는 것만)"},
                 "keyword": {"type": "string", "description": "검색용 핵심 키워드 (예: 아산 통닭, 온양 치킨)"},
                 "title_ideas": {"type": "array", "items": {"type": "string"}, "description": "제목 후보 3개"},
                 "prompt": {"type": "string", "description": "이 사진들로 블로그 글을 쓸 때 따를 지시문(사진 순서, 강조점, 분위기, 쓰지 말아야 할 것)"}},
                 "required": ["photos", "summary", "keyword", "title_ideas", "prompt"]}}


def _thumb(path, side=640):
    from PIL import Image
    with Image.open(path) as im:
        im = im.convert("RGB")
        im.thumbnail((side, side))
        b = io.BytesIO()
        im.save(b, "JPEG", quality=78)
    return base64.b64encode(b.getvalue()).decode()


def plan(cfg, photo_ids, memo="", kind="daily"):
    """사진(최대 10장) + 메모 → 글 계획. 키가 없으면 라벨로 간단한 계획"""
    from . import llm
    photos = [p for p in (lib.get_photo(int(i)) for i in photo_ids) if p][:10]
    if not photos:
        raise ValueError("사진을 먼저 올려 주세요")
    shop = cfg["shop"]
    if not llm.api_key():
        labs = [", ".join(p["labels"]) for p in photos]
        return {"photos": [{"index": i, "description": f"{l} 사진", "labels": p["labels"]} for i, (p, l) in enumerate(zip(photos, labs))],
                "summary": f"오늘 {shop['name']}의 하루를 사진 {len(photos)}장으로 남겨요.", "keyword": "아산 원주통닭",
                "title_ideas": [f"오늘의 {shop['name']}", "통닭집 사장의 하루", "아산 온천동 통닭집 일상"],
                "prompt": ("사진 순서대로 사장님의 가게 밖 하루를 일기처럼 써 주세요. 사진·메모에 있는 것만, 가게 홍보 없이." if kind == "life" else
                           "사장님이 쉬는 날 다녀온 곳을 메모에 있는 사실만으로 담백하게 소개하세요. 별점·평가·우리 가게 홍보는 쓰지 마세요."
                           if kind == "visit" else "사진 순서대로 오늘 가게 하루를 소개하고, 사진마다 보이는 것만 설명하세요. 마지막에 영업시간과 포장 안내를 넣으세요.")
                          + (f" 메모: {memo}" if memo else ""), "photoIds": [p["id"] for p in photos], "ai": False, "kind": kind}
    content = []
    for i, p in enumerate(photos):
        content += [{"type": "text", "text": f"사진 {i}"},
                    {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": _thumb(p["path"])}}]
    if kind == "life":
        content.append({"type": "text", "text": (
            f"충남 아산 온천동 통닭집 '{shop['name']}' 사장님의 가게 밖 개인 일상(여행·나들이·산책·집청소·운동·가족 시간 등) 사진들입니다. 사장님 메모: {memo or '(없음)'}\n"
            "사진마다 실제로 보이는 것만 설명하고(추측 금지), 사장님 1인칭 개인 일상 블로그 글 계획을 세워 주세요. keyword 는 이 일상에 맞는 검색어(예: 장소+활동). "
            "prompt 에는 지시문 6~10줄: 사진 순서대로 그날의 흐름, 사진·메모에 있는 것만 사실로, 장소 이름은 메모에 있을 때만, 감정·소소한 생각을 담백하게, "
            "가게 홍보·메뉴·가격은 쓰지 않기, 이모지 적당히. submit_plan 도구로 제출.")})
    elif kind == "visit":
        content.append({"type": "text", "text": (
            f"충남 아산 온천동 통닭집 '{shop['name']}' 사장님이 쉬는 날 직접 다녀온 다른 식당에서 찍은 사진들입니다. 사장님 메모: {memo or '(없음)'}\n"
            "사진마다 실제로 보이는 것만 설명하고(추측 금지), 사장님 본인의 방문 경험 글(카페·블로그) 계획을 세워 주세요. "
            "prompt 에는 지시문 6~10줄: 메모에 있는 가게 이름·메뉴·느낌만 사실로 쓰기, 사진 순서, 담백한 말투. "
            "별점·점수·순위·'최고' 평가, 메모에 없는 맛·가격, 우리 가게 홍보, 다른 치킨집 언급은 쓰지 말라는 내용도 넣으세요. submit_plan 도구로 제출.")})
    else:
        content.append({"type": "text", "text": (
        f"충남 아산 온천동 통닭집 '{shop['name']}' 사장님이 오늘 찍은 사진들입니다. 사장님 메모: {memo or '(없음)'}\n"
        "사진마다 실제로 보이는 것만 설명하고(추측 금지), 이 사진들로 사장님 1인칭 블로그 일상 글을 쓸 계획을 세워 주세요. "
        "prompt 에는 글쓴이가 따를 구체적인 지시문(사진 순서·각 사진에서 이야기할 점·분위기·말투)을 한국어로 6~10줄 쓰세요. "
        "손님 후기·별점·손님 말 인용, 가게 정보에 없는 가격·이벤트는 쓰지 말라는 내용도 넣으세요. submit_plan 도구로 제출.")})  # noqa: E128
    out, model = llm.call_tool(cfg, "", content, PLAN_TOOL, 2000, "text", {"channel": "daily", "keyword": "일상 계획"})
    notes = {int(x.get("index", -1)): x for x in out.get("photos") or [] if isinstance(x, dict)}
    for i, p in enumerate(photos):   # 사진 설명은 자료함에도 저장 → 글 속 사진 자리 맞추기에 사용
        n = notes.get(i)
        if n and n.get("description"):
            lib.set_labels(p["id"], n.get("labels") or p["labels"], n["description"][:60], "vision")
    log("INFO", f"[일상 글] 사진 {len(photos)}장으로 글 계획 생성 ({model})")
    return {**out, "photoIds": [p["id"] for p in photos], "ai": True, "kind": kind}
