# -*- coding: utf-8 -*-
"""Kakao i Open Builder skill webhook helpers (response schema v2.0)."""
import hashlib, os, re, secrets, sqlite3, time
from datetime import datetime

from . import generator as g, secure
from .util import load_config, save_config

TOKEN_HEADER = "X-JHNode-Kakao-Token"
MAX_RESPONSE_BYTES = 30_720
_hits = {}


def new_channel(label="새 카카오 채널"):
    return {
        "id": secrets.token_hex(6), "label": str(label)[:50], "enabled": False,
        "fallback": "문의 감사합니다. 담당자가 확인 후 안내드리겠습니다.",
        "closedMessage": "현재 상담시간이 아닙니다. 남겨주신 문의는 운영시간에 확인하겠습니다.",
        "businessHours": {"enabled": False, "start": "09:00", "end": "18:00"},
        "rules": [{"keywords": ["가격", "비용"], "response": "원하시는 서비스와 수량을 알려주시면 견적을 안내드리겠습니다."}],
        "handoffKeywords": ["상담원", "담당자", "전화"],
        "handoffMessage": "상담원 연결 요청을 접수했습니다. 담당자가 확인 후 안내드리겠습니다.",
        "quickReplies": ["서비스 안내", "견적 문의", "상담원 연결"],
        "maxPerMinute": 12, "logMessageText": False,
    }


def channels(cfg=None):
    return list(((cfg or load_config()).get("kakaoChannel") or {}).get("channels") or [])


def public_base(cfg=None):
    cfg = cfg or load_config()
    return str((cfg.get("kakaoChannel") or {}).get("publicBaseUrl") or "").rstrip("/")


def token_key(channel_id):
    return f"KAKAO_SKILL_TOKEN__{channel_id}"


def ensure_token(channel_id):
    key = token_key(channel_id)
    token = secure.get(key)
    if not token:
        token = secrets.token_urlsafe(32)
        secure.set_many({key: token})
    return token


def _db():
    path = os.path.join(g.ROOT, "data", "kakao_channel.sqlite3")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    db = sqlite3.connect(path, timeout=5)
    db.execute("CREATE TABLE IF NOT EXISTS events(ts INTEGER, channel_id TEXT, user_hash TEXT, matched TEXT, message TEXT)")
    return db


def _log(channel, user_id, utterance, matched):
    salt = secure.get("KAKAO_LOG_SALT")
    if not salt:
        salt = secrets.token_hex(24)
        secure.set_many({"KAKAO_LOG_SALT": salt})
    user_hash = hashlib.sha256((salt + str(user_id)).encode()).hexdigest()[:20]
    message = str(utterance)[:500] if channel.get("logMessageText") else ""
    db = _db()
    try:
        db.execute("INSERT INTO events VALUES(?,?,?,?,?)", (int(time.time()), channel["id"], user_hash, matched, message))
        db.execute("DELETE FROM events WHERE ts < ?", (int(time.time()) - 90 * 86400,))
        db.commit()
    finally:
        db.close()


def stats(channel_id):
    try:
        db = _db()
        try:
            total = db.execute("SELECT COUNT(*) FROM events WHERE channel_id=?", (channel_id,)).fetchone()[0]
            day = db.execute("SELECT COUNT(*) FROM events WHERE channel_id=? AND ts>=?", (channel_id, int(time.time()) - 86400)).fetchone()[0]
        finally:
            db.close()
        return {"total": total, "last24h": day}
    except sqlite3.Error:
        return {"total": 0, "last24h": 0}


def _rate_ok(channel_id, user_id, maximum):
    now = time.monotonic(); key = (channel_id, str(user_id)); q = [x for x in _hits.get(key, []) if now - x < 60]
    if len(q) >= maximum:
        _hits[key] = q
        return False
    q.append(now); _hits[key] = q
    return True


def _is_open(hours, now=None):
    if not hours.get("enabled"):
        return True
    now = now or datetime.now()
    try:
        start = tuple(map(int, str(hours.get("start", "09:00")).split(":")))
        end = tuple(map(int, str(hours.get("end", "18:00")).split(":")))
        current = (now.hour, now.minute)
        return start <= current < end
    except (ValueError, TypeError):
        return True


def skill_response(text, quick_replies=None):
    text = str(text or "문의 내용을 확인했습니다.")[:1000]
    result = {"version": "2.0", "template": {"outputs": [{"simpleText": {"text": text}}]}}
    quick = [str(x).strip()[:30] for x in (quick_replies or []) if str(x).strip()][:10]
    if quick:
        result["template"]["quickReplies"] = [{"label": x, "action": "message", "messageText": x} for x in quick]
    return result


def handle(channel, payload):
    request = payload.get("userRequest") if isinstance(payload, dict) else None
    if not isinstance(request, dict):
        raise ValueError("Kakao userRequest가 없습니다")
    utterance = str(request.get("utterance") or "").strip()[:1000]
    user = request.get("user") if isinstance(request.get("user"), dict) else {}
    props = user.get("properties") if isinstance(user.get("properties"), dict) else {}
    user_id = user.get("id") or props.get("botUserKey") or props.get("plusfriendUserKey") or "anonymous"
    if not _rate_ok(channel["id"], user_id, max(1, min(60, int(channel.get("maxPerMinute", 12))))):
        return skill_response("요청이 많습니다. 잠시 후 다시 문의해 주세요.")
    normalized = re.sub(r"\s+", "", utterance).lower()
    if any(re.sub(r"\s+", "", str(k)).lower() in normalized for k in channel.get("handoffKeywords") or [] if str(k).strip()):
        text, matched = channel.get("handoffMessage"), "handoff"
    elif not _is_open(channel.get("businessHours") or {}):
        text, matched = channel.get("closedMessage"), "closed"
    else:
        text, matched = channel.get("fallback"), "fallback"
        for i, rule in enumerate(channel.get("rules") or []):
            keys = rule.get("keywords") if isinstance(rule, dict) else []
            if any(re.sub(r"\s+", "", str(k)).lower() in normalized for k in keys or [] if str(k).strip()):
                text, matched = rule.get("response"), f"rule:{i}"
                break
    _log(channel, user_id, utterance, matched)
    return skill_response(text, channel.get("quickReplies"))


def sanitize_channel(raw, old=None):
    old = old or new_channel()
    cid = str(raw.get("id") or old.get("id") or "")
    if not re.fullmatch(r"[a-f0-9]{12}", cid):
        raise ValueError("잘못된 채널 ID")
    def lines(value, limit=20):
        seq = value if isinstance(value, list) else str(value or "").splitlines()
        return [str(x).strip()[:60] for x in seq if str(x).strip()][:limit]
    rules = []
    for x in raw.get("rules") or []:
        if not isinstance(x, dict): continue
        keywords = lines(x.get("keywords"), 20); response = str(x.get("response") or "").strip()[:1000]
        if keywords and response: rules.append({"keywords": keywords, "response": response})
    hours = raw.get("businessHours") if isinstance(raw.get("businessHours"), dict) else {}
    for field in ("start", "end"):
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", str(hours.get(field) or "")):
            hours[field] = (old.get("businessHours") or {}).get(field, "09:00" if field == "start" else "18:00")
    return {**old, "id": cid, "label": str(raw.get("label") or old.get("label") or "카카오 채널")[:50],
            "enabled": bool(raw.get("enabled")), "fallback": str(raw.get("fallback") or "")[:1000],
            "closedMessage": str(raw.get("closedMessage") or "")[:1000],
            "businessHours": {"enabled": bool(hours.get("enabled")), "start": hours["start"], "end": hours["end"]},
            "rules": rules[:30], "handoffKeywords": lines(raw.get("handoffKeywords")),
            "handoffMessage": str(raw.get("handoffMessage") or "")[:1000], "quickReplies": lines(raw.get("quickReplies"), 10),
            "maxPerMinute": max(1, min(60, int(raw.get("maxPerMinute", 12)))), "logMessageText": bool(raw.get("logMessageText"))}
