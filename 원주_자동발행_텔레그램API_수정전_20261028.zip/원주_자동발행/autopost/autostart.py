# -*- coding: utf-8 -*-
"""PC 켜면 자동 실행 (Windows: HKCU\\...\\Run 레지스트리 / Linux: ~/.config/autostart)"""
import os, sys

NAME = "WonjuTongdakAutopost"


def _cmd():
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}" --minimized'
    return f'"{sys.executable}" -m autopost --minimized'


def is_enabled():
    if os.name == "nt":
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") as k:
                winreg.QueryValueEx(k, NAME)
                return True
        except OSError:
            return False
    return os.path.exists(os.path.expanduser(f"~/.config/autostart/{NAME}.desktop"))


def set_enabled(on):
    if os.name == "nt":
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE) as k:
            if on:
                winreg.SetValueEx(k, NAME, 0, winreg.REG_SZ, _cmd())
            else:
                try:
                    winreg.DeleteValue(k, NAME)
                except OSError:
                    pass
    else:
        p = os.path.expanduser(f"~/.config/autostart/{NAME}.desktop")
        if on:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(f"[Desktop Entry]\nType=Application\nName=원주통닭 자동발행\nExec={_cmd()}\n")
        elif os.path.exists(p):
            os.remove(p)
    return is_enabled()
