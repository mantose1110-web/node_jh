# -*- coding: utf-8 -*-
"""네이버 플레이스에서 가게 정보·사장님 등록 사진 불러오기 (playwright, m.place.naver.com)

- 가져오는 것: 상호, 주소, 전화, 영업시간, 메뉴·가격, '업체 사진'(사장님 등록) + 메뉴 사진
- 가져오지 않는 것: 방문자 리뷰·리뷰 사진(손님 저작물) — 리뷰 탭은 열지도 않음
- 결과: data/place_cache.json (매주 자동 갱신), 사진은 photos/place/ (해시 중복 제거) → 이미지 1순위
"""
import hashlib, json, os, re
from datetime import datetime
import requests
from . import generator as g
from .util import log
from .browser import launch_profile, safe_goto, BROWSER_LOCK, work_page

MOBILE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"


def _wait_apollo(page):
    try:
        page.wait_for_function("() => !!window.__APOLLO_STATE__", timeout=30000)
    except Exception:  # noqa: BLE001 (없으면 아래에서 안내 오류)
        pass


def parse_place_id(text):
    """URL/ID/공유링크 어떤 형태든 숫자 ID 추출 (naver.me 단축링크는 따라가서 확인)"""
    text = (text or "").strip()
    if re.fullmatch(r"\d{5,}", text):
        return text
    m = re.search(r"(?:place|restaurant|entry/place|placeId=)[/=]?(\d{5,})", text)
    if m:
        return m.group(1)
    if "naver.me" in text:
        try:
            r = requests.get(text, allow_redirects=True, timeout=15, headers={"User-Agent": MOBILE_UA})
            return parse_place_id(r.url)
        except requests.RequestException:
            return None
    return None


def _walk(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from _walk(v)
    elif isinstance(o, list):
        for v in o:
            yield from _walk(v)


def parse_apollo(state):
    """__APOLLO_STATE__ 에서 필요한 사실만 추출 (구조 변경에 견디도록 typename/키 이름 기반 탐색)"""
    info = {"name": "", "address": "", "phone": "", "hours": "", "menu": [], "menu_images": []}
    for o in _walk(state):
        t = o.get("__typename", "")
        if t == "PlaceDetailBase" or ("roadAddress" in o and "name" in o and not info["name"]):
            info["name"] = info["name"] or o.get("name", "")
            info["address"] = info["address"] or o.get("roadAddress") or o.get("address", "")
            info["phone"] = info["phone"] or o.get("phone") or o.get("virtualPhone") or ""
        if t == "Menu" and o.get("name"):
            price = str(o.get("price") or "").strip()
            if price.isdigit():
                price = f"{int(price):,}원"
            info["menu"].append({"name": o["name"], "price": price})
            for im in o.get("images") or []:
                if isinstance(im, str) and im.startswith("http"):
                    info["menu_images"].append(im)
        if "BusinessHours" in t or t == "NewBusinessHour":
            for bh in o.get("businessHours") or o.get("newBusinessHours") or []:
                if isinstance(bh, dict):
                    day = bh.get("day") or bh.get("businessHoursName") or ""
                    st, en = (bh.get("businessHours") or {}).get("start") or bh.get("startTime"), (bh.get("businessHours") or {}).get("end") or bh.get("endTime")
                    if st and en and len(info["hours"]) < 300:
                        info["hours"] += f"{day} {st}~{en}, "
    info["hours"] = info["hours"].rstrip(", ")
    seen, menu = set(), []
    for m in info["menu"]:
        if m["name"] not in seen:
            seen.add(m["name"]); menu.append(m)
    info["menu"] = menu[:40]
    return info


def _imgs_from_page(page):
    """'업체' 사진 탭에 보이는 이미지 원본 주소 (리뷰 사진 탭은 사용 안 함)"""
    urls = page.eval_on_selector_all("img", "els => els.map(e => e.currentSrc || e.src)")
    out = []
    for u in urls:
        if "pstatic.net" in u and ("ldb-phinf" in u or "myplace-phinf" in u or "naverbooking-phinf" in u or "search.pstatic" in u):
            m = re.search(r"src=([^&]+)", u)
            out.append(requests.utils.unquote(m.group(1)) if m else u.split("?")[0])
    return list(dict.fromkeys(out))


def fetch_place(place_id, cfg, max_photos=30):
    from playwright.sync_api import sync_playwright
    base = f"https://m.place.naver.com/restaurant/{place_id}"
    with BROWSER_LOCK, sync_playwright() as pw:
        ctx = launch_profile(pw, "place", cfg, headless=True)
        try:
            page = work_page(ctx)
            page.set_extra_http_headers({"User-Agent": MOBILE_UA})
            safe_goto(page, f"{base}/home")
            _wait_apollo(page)
            if page.title().strip() in ("", "네이버") and "429" in page.content()[:2000]:
                raise RuntimeError("네이버가 잠시 접속을 제한했습니다(429). 잠시 후 다시 시도하세요.")
            state = page.evaluate("() => window.__APOLLO_STATE__ || null")
            if not state:
                raise RuntimeError("플레이스 정보를 읽지 못했습니다 (ID 확인 또는 잠시 후 재시도)")
            info = parse_apollo(state)
            safe_goto(page, f"{base}/menu/list")
            _wait_apollo(page)
            m_state = page.evaluate("() => window.__APOLLO_STATE__ || null")
            if m_state:
                mi = parse_apollo(m_state)
                info["menu"] = info["menu"] or mi["menu"]
                info["menu_images"] += mi["menu_images"]
            photos = []
            safe_goto(page, f"{base}/photo?filterType=" + requests.utils.quote("업체"))
            try:
                page.wait_for_selector("img", timeout=20000)
            except Exception:  # noqa: BLE001
                pass
            for _ in range(4):
                page.mouse.wheel(0, 3000); page.wait_for_timeout(800)
            photos = _imgs_from_page(page)[:max_photos]
        finally:
            ctx.close()
    info.update({"place_id": place_id, "owner_photos": photos, "fetched": datetime.now().isoformat(timespec="seconds")})
    return info


def download_photos(info, limit=40):
    d = os.path.join(g.ROOT, "photos", "place")
    os.makedirs(d, exist_ok=True)
    have = {hashlib.sha256(open(os.path.join(d, f), "rb").read()).hexdigest() for f in os.listdir(d)}
    saved = 0
    for i, u in enumerate((info.get("menu_images") or []) + (info.get("owner_photos") or [])):
        if saved >= limit:
            break
        try:
            raw = requests.get(u, timeout=30, headers={"User-Agent": MOBILE_UA, "Referer": "https://m.place.naver.com/"}).content
        except requests.RequestException:
            continue
        h = hashlib.sha256(raw).hexdigest()
        if len(raw) < 5000 or h in have:
            continue
        have.add(h)
        kind = "menu" if i < len(info.get("menu_images") or []) else "store"
        with open(os.path.join(d, f"place-{kind}-{h[:12]}.jpg"), "wb") as f:
            f.write(raw)
        saved += 1
    return saved


def cache_path():
    return os.path.join(g.ROOT, "data", "place_cache.json")


def load_cache():
    try:
        with open(cache_path(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def import_place(place_ref, cfg, apply=False, download=True):
    """미리보기(apply=False) 또는 config 반영(apply=True)"""
    pid = parse_place_id(place_ref)
    if not pid:
        raise RuntimeError("플레이스 주소/ID를 확인해 주세요 (예: https://m.place.naver.com/restaurant/12345678)")
    info = fetch_place(pid, cfg)
    os.makedirs(os.path.dirname(cache_path()), exist_ok=True)
    with open(cache_path(), "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
    if download:
        info["downloaded"] = download_photos(info)
    if apply:
        apply_to_config(info, cfg)
    log("INFO", f"[플레이스] {info.get('name')} 정보 {'반영' if apply else '미리보기'} (메뉴 {len(info['menu'])}개, 사진 {info.get('downloaded', 0)}장 저장)")
    return info


def apply_to_config(info, cfg):
    from .util import save_config
    s = cfg["shop"]
    for k in ("address", "phone", "hours"):
        if info.get(k):
            s[k] = info[k]
    if info.get("menu"):
        s["menu"] = info["menu"]
    s["naverPlaceId"] = info["place_id"]
    s["placeSyncedAt"] = info["fetched"]
    save_config(cfg)
