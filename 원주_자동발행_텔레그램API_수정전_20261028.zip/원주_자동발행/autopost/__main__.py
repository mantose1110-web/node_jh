import sys
from autopost.main import main
sys.exit(main())
