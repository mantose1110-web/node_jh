# -*- coding: utf-8 -*-
"""Persistent user-controlled Telegram join queues, owned by the Telegram loop."""
import asyncio
import copy
import re
import time
import uuid
from urllib.parse import parse_qs, urlparse

from . import secure

TERMINAL = {"joined", "already", "requested", "error", "invalid"}
PUBLIC_NAME = re.compile(r"[A-Za-z][A-Za-z0-9_]{4,31}\Z")
INVITE_HASH = re.compile(r"[A-Za-z0-9_-]{8,128}\Z")
RESERVED = {"addlist", "addstickers", "addemoji", "setlanguage", "share", "proxy",
            "socks", "login", "invoice", "giftcode", "contact", "boost", "joinchat"}


def parse_links(text):
    if not isinstance(text, str) or len(text) > 12000:
        raise ValueError("주소 목록은 12,000자 이하로 입력해 주세요")
    items, seen, duplicates = [], set(), 0
    for raw in re.split(r"[\s,;]+", text.strip()):
        source = raw.strip("<>\"'")
        if not source:
            continue
        kind = value = ""
        error = "채널·그룹의 공개 주소 또는 초대 링크를 입력해 주세요"
        if source.startswith("@"):
            if PUBLIC_NAME.fullmatch(source[1:]):
                kind, value = "public", source[1:].lower()
        else:
            try:
                url = urlparse(source if "://" in source else "https://" + source)
                if url.scheme == "tg" and url.netloc == "join" and url.path in ("", "/"):
                    kind, value = "invite", (parse_qs(url.query).get("invite") or [""])[0]
                elif (url.scheme in ("https", "http") and not url.username and not url.password
                      and url.port is None and (url.hostname or "").lower() in
                      ("t.me", "www.t.me", "telegram.me", "www.telegram.me")):
                    parts = [p for p in url.path.split("/") if p]
                    if len(parts) == 1 and parts[0].startswith("+"):
                        kind, value = "invite", parts[0][1:]
                    elif len(parts) == 2 and parts[0] == "joinchat":
                        kind, value = "invite", parts[1]
                    else:
                        if len(parts) == 2 and parts[0] == "s":
                            parts = parts[1:]
                        if parts and (len(parts) == 1 or len(parts) == 2 and parts[1].isdigit()):
                            if PUBLIC_NAME.fullmatch(parts[0]) and parts[0].lower() not in RESERVED:
                                kind, value = "public", parts[0].lower()
            except ValueError:
                pass
        if kind == "invite" and not INVITE_HASH.fullmatch(value):
            kind = ""
            error = "초대 링크 형식이 올바르지 않아요"
        key = (kind, value) if kind else ("invalid", source)
        if key in seen:
            duplicates += 1
            continue
        seen.add(key)
        index = len(items) + 1
        address = "@" + value if kind == "public" else f"비공개 초대 링크 {index}" if kind else f"입력 {index}"
        canonical = "@" + value if kind == "public" else "https://t.me/+" + value if kind else source
        items.append({"index": index, "kind": kind, "value": value, "source": canonical,
                      "address": address, "title": address, "status": "pending" if kind else "invalid",
                      "message": "대기 중" if kind else error})
        if len(items) > 50:
            raise ValueError("중복을 제외하고 한 번에 최대 50개 주소까지 저장할 수 있어요")
    if not items:
        raise ValueError("입장할 주소를 한 개 이상 입력해 주세요")
    return items, duplicates


class TelegramJoinQueue:
    def __init__(self, get_client):
        self.get_client = get_client
        self._states = {}
        self._tasks = {}
        self._events = {}

    @staticmethod
    def _name(account_id):
        if not re.fullmatch(r"[a-z0-9]{1,12}", account_id):
            raise ValueError("계정 번호가 올바르지 않아요")
        return "telegram-joins-" + account_id

    def _load(self, account_id):
        if account_id not in self._states:
            state = secure.load_json(self._name(account_id), None)
            if not isinstance(state, dict) or state.get("version") != 1:
                state = {"version": 1, "batchId": "", "items": [], "phase": "empty",
                         "message": "주소 목록을 입력해 주세요", "intervalSeconds": 30,
                         "duplicates": 0, "retryAt": 0, "nextAt": 0}
            else:
                for item in state["items"]:
                    if item["status"] == "joining":
                        item.update(status="pending", message="재개하면 참여 여부부터 확인합니다")
                if state.get("phase") in ("running", "waiting", "pausing"):
                    state.update(phase="paused", message="이전 작업을 복구했어요. 이어서 시작을 눌러 주세요")
            self._states[account_id] = state
        return self._states[account_id]

    def _persist(self, account_id):
        secure.save_json(self._name(account_id), self._states[account_id])

    def _active(self, account_id):
        task = self._tasks.get(account_id)
        return bool(task and not task.done())

    def _snapshot(self, account_id, include_links=False):
        state = self._load(account_id)
        items = state["items"]
        counts = {key: sum(x["status"] == key for x in items)
                  for key in ("joined", "already", "requested", "error", "invalid")}
        done = sum(counts.values())
        running = self._active(account_id) and state["phase"] in ("running", "waiting", "pausing")
        out = {"ok": True, **{k: state.get(k) for k in
               ("batchId", "phase", "message", "intervalSeconds", "duplicates", "retryAt", "nextAt")},
               "total": len(items), "done": done, "pending": len(items) - done,
               "joined": counts["joined"], "already": counts["already"], "requested": counts["requested"],
               "errors": counts["error"] + counts["invalid"], "running": running,
               "canResume": not running and len(items) > done,
               "results": [{k: x[k] for k in ("index", "address", "title", "status", "message")} for x in items]}
        if include_links:
            out["links"] = "\n".join(x["source"] for x in items)
        return copy.deepcopy(out)

    async def status(self, account_id, include_links=False):
        return self._snapshot(account_id, include_links)

    async def save(self, account_id, text, interval_seconds=30):
        if self._active(account_id):
            raise ValueError("진행 중인 작업을 일시정지한 뒤 새 목록을 저장해 주세요")
        try:
            interval = int(interval_seconds)
        except (TypeError, ValueError):
            raise ValueError("입장 간격을 초 단위 숫자로 입력해 주세요") from None
        if not 10 <= interval <= 3600:
            raise ValueError("입장 간격은 10~3,600초로 설정해 주세요")
        items, duplicates = parse_links(text)
        old = self._load(account_id)
        state = {"version": 1, "batchId": uuid.uuid4().hex, "phase": "ready", "items": items,
                 "duplicates": duplicates, "intervalSeconds": interval, "retryAt": old.get("retryAt", 0),
                 "nextAt": old.get("nextAt", 0), "message": "목록을 저장했어요. 이어서 시작을 누르면 입장합니다"}
        self._states[account_id] = state
        try:
            self._persist(account_id)
        except Exception:
            self._states[account_id] = old
            raise ValueError("목록을 저장하지 못했어요. 데이터 폴더의 쓰기 권한을 확인해 주세요") from None
        return self._snapshot(account_id, include_links=True)

    async def start(self, account_id, text, interval_seconds=30):
        await self.save(account_id, text, interval_seconds)
        return await self.resume(account_id)

    async def resume(self, account_id):
        state = self._load(account_id)
        if self._active(account_id):
            return self._snapshot(account_id)
        if not any(x["status"] not in TERMINAL for x in state["items"]):
            raise ValueError("처리할 주소가 없어요. 새 목록을 저장해 주세요")
        if self.get_client(account_id) is None:
            raise ValueError("개인 계정 연결을 확인한 뒤 이어서 시작해 주세요")
        self._events[account_id] = asyncio.Event()
        state.update(phase="running", message="저장된 목록에서 남은 주소를 처리합니다")
        self._persist(account_id)
        self._tasks[account_id] = asyncio.create_task(self._run(account_id))
        return self._snapshot(account_id)

    async def pause(self, account_id):
        state = self._load(account_id)
        if self._active(account_id):
            state.update(phase="pausing", message="현재 요청을 마친 뒤 일시정지합니다")
            self._events[account_id].set()
            self._persist(account_id)
        return self._snapshot(account_id)

    async def _wait(self, account_id, seconds):
        if seconds <= 0:
            return
        try:
            await asyncio.wait_for(self._events[account_id].wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def _run(self, account_id):
        state = self._states[account_id]
        event = self._events[account_id]
        current = None
        try:
            for item in state["items"]:
                if item["status"] in TERMINAL:
                    continue
                current = item
                while item["status"] not in TERMINAL and not event.is_set():
                    due = max(float(state.get("retryAt") or 0), float(state.get("nextAt") or 0))
                    if due > time.time():
                        reason = "텔레그램이 지정한 대기시간" if state.get("retryAt", 0) > time.time() else "다음 입장까지 설정한 간격"
                        state.update(phase="waiting", message=reason + "이 끝나면 자동으로 이어갑니다")
                        self._persist(account_id)
                        await self._wait(account_id, due - time.time())
                        continue
                    client = self.get_client(account_id)
                    if client is None:
                        state.update(phase="paused", message="계정 연결이 끊겼어요. 연결 후 이어서 시작해 주세요")
                        event.set()
                        break
                    state.update(phase="running", retryAt=0, message=f"{item['index']}/{len(state['items'])}번 주소 처리 중")
                    item.update(status="joining", message="참여 여부 확인 및 입장 처리 중")
                    self._persist(account_id)
                    try:
                        result = await asyncio.wait_for(self._join_one(client, item), timeout=60)
                        item.update(result)
                    except Exception as exc:
                        name = type(exc).__name__
                        if name in ("FloodWaitError", "FloodPremiumWaitError"):
                            wait = max(1, int(getattr(exc, "seconds", 60)))
                            state["retryAt"] = time.time() + wait + 1
                            item.update(status="pending", message="텔레그램 대기시간 종료 후 재시도 예정")
                            self._persist(account_id)
                            continue
                        if name in ("UserAlreadyParticipantError", "InviteRequestSentError"):
                            item.update(status="already" if name == "UserAlreadyParticipantError" else "requested",
                                        message="이미 가입됨" if name == "UserAlreadyParticipantError" else "관리자 승인 대기")
                        elif isinstance(exc, (OSError, asyncio.TimeoutError)) or name in (
                                "AuthKeyUnregisteredError", "SessionRevokedError", "UserDeactivatedError",
                                "UserDeactivatedBanError", "PeerFloodError", "ChannelsTooMuchError",
                                "UserChannelsTooMuchError", "FrozenMethodInvalidError"):
                            item.update(status="pending", message="계정 또는 연결 상태를 확인한 뒤 다시 처리해 주세요")
                            state.update(phase="paused", message="연결 또는 계정 제한으로 일시정지했어요. 상태 확인 후 이어서 시작해 주세요")
                            event.set()
                        else:
                            label = {"InviteHashExpiredError": "초대 링크가 만료됐어요",
                                     "InviteHashInvalidError": "초대 링크가 올바르지 않아요",
                                     "ChannelPrivateError": "비공개 채널은 유효한 초대 링크가 필요해요",
                                     "UsernameNotOccupiedError": "해당 공개 주소를 찾지 못했어요",
                                     "UsernameInvalidError": "사용자명 형식이 올바르지 않아요",
                                     "UserBannedInChannelError": "이 계정은 해당 대화에 입장할 수 없어요",
                                     "StarsPaymentRequiredError": "유료 초대는 텔레그램 앱에서 확인해 주세요"}.get(name, "주소 또는 입장 권한을 확인해 주세요")
                            item.update(status="error", message=label)
                    state["nextAt"] = time.time() + state["intervalSeconds"]
                    self._persist(account_id)
                if event.is_set():
                    break
            if all(x["status"] in TERMINAL for x in state["items"]):
                state.update(phase="complete", message="목록 처리를 마쳤어요. 아래 결과를 확인해 주세요")
            elif state["phase"] != "paused":
                state.update(phase="paused", message="일시정지했어요. 이어서 시작하면 남은 주소만 처리합니다")
        except asyncio.CancelledError:
            if current and current["status"] == "joining":
                current.update(status="pending", message="재개하면 참여 여부부터 확인합니다")
            state.update(phase="paused", message="작업을 저장했어요. 이어서 시작할 수 있습니다")
            raise
        except Exception:
            if current and current["status"] == "joining":
                current.update(status="pending", message="처리 기록을 확인한 뒤 재개해 주세요")
            state.update(phase="error", message="작업이 중단됐어요. 데이터 폴더와 계정 연결을 확인해 주세요")
        finally:
            try:
                self._persist(account_id)
            except Exception:
                state.update(phase="error", message="기록 저장에 실패했어요. 프로그램을 닫기 전에 결과를 내려받아 주세요")

    async def _join_one(self, client, item):
        from telethon.tl.functions.channels import JoinChannelRequest
        from telethon.tl.functions.messages import CheckChatInviteRequest, ImportChatInviteRequest
        from telethon.tl.types import Channel, ChatInviteAlready
        if item["kind"] == "invite":
            info = await client(CheckChatInviteRequest(item["value"]), flood_sleep_threshold=0)
            if isinstance(info, ChatInviteAlready):
                return {"title": str(info.chat.title), "status": "already", "message": "이미 가입됨"}
            if getattr(info, "subscription_pricing", None):
                return {"status": "error", "message": "유료 초대는 텔레그램 앱에서 확인해 주세요"}
            title = str(getattr(info, "title", item["address"]))
            item["title"] = title
            await client(ImportChatInviteRequest(item["value"]), flood_sleep_threshold=0)
        else:
            entity = await client.get_entity(item["value"])
            if not isinstance(entity, Channel):
                return {"status": "error", "message": "그룹·채널 주소가 아닙니다"}
            title = str(entity.title)
            item["title"] = title
            if not entity.left:
                return {"title": title, "status": "already", "message": "이미 가입됨"}
            await client(JoinChannelRequest(entity), flood_sleep_threshold=0)
        return {"title": title, "status": "joined", "message": "입장 완료"}

    async def close(self, account_id=None, forget=False):
        ids = [account_id] if account_id is not None else list(self._states)
        for aid in ids:
            task = self._tasks.pop(aid, None)
            if task and not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            if forget:
                self._states.pop(aid, None)
                self._events.pop(aid, None)
                secure.delete_json(self._name(aid))
