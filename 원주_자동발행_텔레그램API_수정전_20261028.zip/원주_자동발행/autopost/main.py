# -*- coding: utf-8 -*-
"""JH-NODE 광고·SNS 운영 솔루션 - 실행 진입점

  WonjuAutopost.exe              대시보드(127.0.0.1) + 자동 발행 엔진 (브라우저 자동 열림, 트레이 아이콘)
  WonjuAutopost.exe --minimized  창 없이 트레이로 시작 (PC 자동 시작용)
  WonjuAutopost.exe --smoke      설치 점검: 임시 폴더로 서버·API·테스트 발행·종료까지 자동 확인 (결과 파일 남김)
"""
import argparse, json, os, socket, sys, threading, time, urllib.request, urllib.error, webbrowser


def _bootstrap():
    from . import paths, generator as g
    d = paths.init_data()
    g.ROOT = d
    from .browser import browsers_path
    browsers_path()
    return d


def _port_in_use(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def _existing_instance(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=2) as r:
            return json.loads(r.read()).get("app") == "wonju-autopost"
    except Exception:  # noqa: BLE001
        return False


def _single_instance_lock(d):
    f = open(os.path.join(d, "app.lock"), "a+")
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return f
    except OSError:
        f.close()
        return None


def run_tray(url, on_quit):
    """시스템 트레이 아이콘 (없거나 오류여도 프로그램은 계속 실행)"""
    from .util import log
    try:
        import pystray
        from PIL import Image, ImageDraw
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        dr = ImageDraw.Draw(img)
        dr.ellipse((4, 4, 60, 60), fill=(232, 89, 12))
        dr.text((24, 22), "W", fill="white")
        win = os.name == "nt"
        icon = pystray.Icon("jh-node", img, "JH-NODE 광고 운영 솔루션", menu=pystray.Menu(
            pystray.MenuItem("대시보드 열기" if win else "Open", lambda: _safe_open(url), default=True),
            pystray.MenuItem("종료" if win else "Quit", lambda: (icon.stop(), on_quit()))))
    except BaseException as e:  # noqa: BLE001
        log("INFO", f"트레이 아이콘 없이 실행: {type(e).__name__}")
        return None

    def _run():
        try:
            icon.run()
        except BaseException as e:  # noqa: BLE001
            log("WARN", f"트레이 아이콘 중단(프로그램은 계속 실행): {e}")
    threading.Thread(target=_run, daemon=True, name="tray").start()
    return icon


def _safe_open(url):
    try:
        webbrowser.open(url)
    except Exception:  # noqa: BLE001
        pass


def serve(args):
    d = _bootstrap()
    from .util import load_config, log
    from .engine import Engine
    from .dashboard import create_app
    from .telegram_reply import manager as telegram_manager
    from .kakao_auto_reply import manager as kakao_auto_manager
    cfg = load_config()
    port = int(os.environ.get("AUTOPOST_PORT") or cfg.get("dashboard", {}).get("port", 5858))
    bind = os.environ.get("AUTOPOST_BIND", "127.0.0.1").strip() or "127.0.0.1"
    url = f"http://127.0.0.1:{port}/"
    lock = _single_instance_lock(d)
    if not lock or _port_in_use(port):
        if _existing_instance(port):
            if not args.no_browser:
                _safe_open(url)
            return 0
        if not lock:
            return 0
        log("ERROR", f"포트 {port} 를 다른 프로그램이 쓰고 있어요. 데이터 폴더의 config.json 에서 dashboard.port 를 바꿔 주세요")
        return 2
    stop = threading.Event()
    engine = Engine()
    engine.start()
    telegram_manager.start()
    app = create_app(engine, on_quit=stop.set, port=port)
    from werkzeug.serving import make_server
    srv = make_server(bind, port, app, threaded=True)   # 기본은 로컬 전용, 운영 서버에서만 AUTOPOST_BIND 지정
    threading.Thread(target=srv.serve_forever, daemon=True, name="http").start()
    log("INFO", f"대시보드 실행: {url} (데이터 폴더 {d})")
    if not args.minimized and not args.no_browser and cfg.get("dashboard", {}).get("openBrowser", True):
        threading.Timer(1.0, lambda: _safe_open(url)).start()
    tray = None if args.no_tray else run_tray(url, stop.set)
    try:
        while not stop.wait(0.5):
            pass
    except KeyboardInterrupt:
        pass
    log("INFO", "종료합니다")
    try:
        from .connect import shutdown_logins
        shutdown_logins()
    except Exception:  # noqa: BLE001
        pass
    try:
        telegram_manager.shutdown()
    except Exception as e:  # noqa: BLE001
        log("WARN", f"텔레그램 수신기 종료 중 오류: {type(e).__name__}")
    try:
        kakao_auto_manager.stop_all()
    except Exception as e:  # noqa: BLE001
        log("WARN", f"카카오톡 자동응답 종료 중 오류: {type(e).__name__}")
    srv.shutdown()
    engine.shutdown()
    if tray:
        try:
            tray.stop()
        except Exception:  # noqa: BLE001
            pass
    return 0


def smoke(args):
    """설치 점검 (임시 데이터 폴더, 실제 계정·키 사용 안 함). 결과는 --report 파일에 기록"""
    import tempfile, re
    os.environ["AUTOPOST_HOME"] = tempfile.mkdtemp(prefix="autopost-smoke-")
    os.environ.setdefault("AUTOPOST_TICK", "1")
    port = int(os.environ.get("AUTOPOST_PORT") or 5899)
    os.environ["AUTOPOST_PORT"] = str(port)
    args.no_browser = args.no_tray = args.minimized = True
    lines = []

    def out(s):
        lines.append(s)
        try:
            print(s, flush=True)
        except Exception:  # noqa: BLE001
            pass
    t = threading.Thread(target=serve, args=(args,), daemon=True)
    t.start()
    base = f"http://127.0.0.1:{port}"
    for _ in range(120):
        try:
            urllib.request.urlopen(base + "/api/ping", timeout=2)
            break
        except Exception:  # noqa: BLE001
            time.sleep(0.5)
    html = urllib.request.urlopen(base + "/", timeout=10).read().decode()
    m = re.search(r'name="csrf" content="([^"]+)"', html)
    tok = m.group(1) if m else ""

    def call(path, body=None):
        req = urllib.request.Request(base + path, data=None if body is None else json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json", "X-CSRF-Token": tok})
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read())

    def flow():
        jid = call("/api/run/naver", {"aid": "main"})["id"]
        for _ in range(120):
            j = next(x for x in call("/api/jobs")["jobs"] if x["id"] == jid)
            if j["status"] in ("테스트 완료", "생성 실패", "발행 실패", "검토 필요"):
                return j["status"] == "테스트 완료"
            time.sleep(0.5)
        return False

    def forbidden():
        try:
            urllib.request.urlopen(urllib.request.Request(base + "/api/settings", data=b"{}", headers={"Content-Type": "application/json"}), timeout=5)
            return False
        except urllib.error.HTTPError as e:
            return e.code == 403
    checks = [("대시보드 화면", lambda: "JH-NODE" in html and bool(tok)),
              ("상태 API", lambda: call("/api/state")["shop"]["naverPlaceId"] == "17232917"),
              ("키워드 목록", lambda: len(call("/api/keywords")["items"]) > 50),
              ("테스트 글 생성→테스트 발행", flow),
              ("보안 토큰 없는 요청 차단", forbidden),
              ("발행용 브라우저 실행", _browser_check),
              ("카카오톡 한글 OCR 모델", _kakao_ocr_check),
              ("종료", lambda: call("/api/quit", {})["ok"])]
    ok_all = True
    for name, fn in checks:
        try:
            ok = bool(fn())
        except Exception as e:  # noqa: BLE001
            ok, name = False, f"{name} ({e})"
        ok_all &= ok
        out(("[OK] " if ok else "[FAIL] ") + name)
    t.join(30)
    out("[OK] 정상 종료" if not t.is_alive() else "[FAIL] 종료되지 않음")
    ok_all &= not t.is_alive()
    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n" + ("RESULT=OK" if ok_all else "RESULT=FAIL") + "\n")
    return 0 if ok_all else 1


def _kakao_ocr_check():
    """Verify the bundled Korean model using generated text, without reading chats."""
    from PIL import Image, ImageDraw, ImageFont
    from .kakao_auto_reply import manager
    font_file = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", "malgun.ttf")
    if not os.path.isfile(font_file):
        return False
    image = Image.new("RGB", (440, 100), "white")
    ImageDraw.Draw(image).text((18, 20), "오늘 회사 공지입니다", fill="black",
                               font=ImageFont.truetype(font_file, 28))
    result = manager._get_ocr()(image)
    return any("오늘" in text for text in (result.txts or ()))


def _browser_check():
    """Playwright 드라이버로 크롬/엣지/크로미움을 실제로 띄워 페이지를 열어 봄"""
    from playwright.sync_api import sync_playwright
    from .browser import system_browser, browsers_path
    from .util import load_config
    browsers_path()
    kind, exe = system_browser(load_config())
    with sync_playwright() as pw:
        b = pw.chromium.launch(executable_path=exe, headless=True)
        try:
            p = b.new_page()
            p.set_content("<title>ok</title><h1>원주통닭</h1>")
            return p.title() == "ok"
        finally:
            b.close()


def _console_to_file():
    """창 없는 exe(콘솔 없음)에서는 sys.stdout/stderr 가 None → 라이브러리 오류 방지를 위해 파일로 연결"""
    if sys.stdout is not None and sys.stderr is not None:
        return
    try:
        from . import paths
        d = os.path.join(paths.data_dir(), "logs")
        os.makedirs(d, exist_ok=True)
        f = open(os.path.join(d, "console.log"), "a", encoding="utf-8", buffering=1)
    except OSError:
        f = open(os.devnull, "w", encoding="utf-8")
    if sys.stdout is None:
        sys.stdout = f
    if sys.stderr is None:
        sys.stderr = f


def main(argv=None):
    _console_to_file()
    if sys.stdout and hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
    ap = argparse.ArgumentParser(prog="JH-NODE")
    ap.add_argument("--minimized", action="store_true")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--no-tray", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--report", default="")
    a = ap.parse_args(argv)
    if a.smoke:
        return smoke(a)
    return serve(a)
