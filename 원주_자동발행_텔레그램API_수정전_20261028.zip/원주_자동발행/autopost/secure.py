# -*- coding: utf-8 -*-
"""비밀값(API 키·비밀번호·토큰·로그인 쿠키) 암호화 저장소

- Windows: DPAPI(CryptProtectData, 현재 Windows 사용자 계정에 묶임) → 다른 PC/다른 사용자는 풀 수 없음
- 그 외(개발·테스트용 리눅스/맥): cryptography Fernet + 소유자 전용(0600) 키 파일
- 값은 config.json 이나 로그, 대시보드 응답에 절대 원문으로 나가지 않음 (가린 값만 표시)
- 예전 버전의 평문 .env 가 있으면 첫 실행 때 암호화 저장소로 옮기고 평문 파일은 지움
"""
import json, os, re, threading

MAGIC = b"WAP1"
ENTROPY = b"wonju-autopost-v3"
_lock = threading.RLock()
_cache = {"mtime": None, "data": None}

# 저장을 허용하는 키 (대시보드에서 입력)
KEYS = ["ANTHROPIC_API_KEY", "META_APP_ID", "META_APP_SECRET", "IG_USER_ID", "IG_ACCESS_TOKEN", "IG_TOKEN_EXPIRES",
        "FTP_HOST", "FTP_USER", "FTP_PASSWORD", "X_API_KEY", "X_API_SECRET", "X_ACCESS_TOKEN", "X_ACCESS_SECRET",
        "BAND_TOKEN", "THREADS_TOKEN", "FB_PAGE_TOKEN", "TG_API_ID", "TG_API_HASH"]
SECRET_KEYS = {"ANTHROPIC_API_KEY", "META_APP_SECRET", "IG_ACCESS_TOKEN", "FTP_PASSWORD", "X_API_SECRET", "X_ACCESS_TOKEN", "X_ACCESS_SECRET",
               "BAND_TOKEN", "THREADS_TOKEN", "FB_PAGE_TOKEN", "TG_API_HASH"}
_ACCT_RE = re.compile(r"^(IG_USER_ID|IG_ACCESS_TOKEN|IG_TOKEN_EXPIRES|X_ACCESS_TOKEN|X_ACCESS_SECRET|BAND_TOKEN|THREADS_TOKEN|FB_PAGE_TOKEN|TG_SESSION|TG_BOT_TOKEN|NAVER_TALK_TOKEN|CHAT_WEBHOOK_SECRET|KAKAO_SKILL_TOKEN)__[a-z0-9]{1,12}$")  # 추가 계정


def allowed(k):
    return k in KEYS or k == "KAKAO_LOG_SALT" or bool(_ACCT_RE.match(k))


def is_secret(k):
    return k in SECRET_KEYS or k == "KAKAO_LOG_SALT" or k.startswith(("IG_ACCESS_TOKEN__", "X_ACCESS_TOKEN__", "X_ACCESS_SECRET__", "BAND_TOKEN__", "THREADS_TOKEN__", "FB_PAGE_TOKEN__", "TG_SESSION__", "TG_BOT_TOKEN__", "NAVER_TALK_TOKEN__", "CHAT_WEBHOOK_SECRET__", "KAKAO_SKILL_TOKEN__"))


def _root():
    from . import generator as g
    return g.ROOT


def _dir():
    d = os.path.join(_root(), "data", "secure")
    os.makedirs(d, exist_ok=True)
    return d


# ---------------- 암호화 ----------------
def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def mk(b):
        buf = ctypes.create_string_buffer(b, len(b))
        return BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    fn.argtypes = [ctypes.POINTER(BLOB), ctypes.c_void_p, ctypes.POINTER(BLOB), ctypes.c_void_p, ctypes.c_void_p,
                   wintypes.DWORD, ctypes.POINTER(BLOB)]
    fn.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    src, _k1 = mk(data)
    ent, _k2 = mk(ENTROPY)
    out = BLOB()
    CRYPTPROTECT_UI_FORBIDDEN = 0x1
    if not fn(ctypes.byref(src), None, ctypes.byref(ent), None, None, CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out)):
        raise OSError("Windows 암호화(DPAPI) 실패: 다른 Windows 사용자 계정에서 만든 파일일 수 있어요")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))


def _fernet():
    from cryptography.fernet import Fernet
    kf = os.path.join(_dir(), ".key")
    if not os.path.exists(kf):
        fd = os.open(kf, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(Fernet.generate_key())
    with open(kf, "rb") as f:
        return Fernet(f.read().strip())


def encrypt(data: bytes) -> bytes:
    if os.name == "nt":
        return MAGIC + _dpapi(data, True)
    return MAGIC + _fernet().encrypt(data)


def decrypt(blob: bytes) -> bytes:
    if not blob.startswith(MAGIC):
        raise ValueError("알 수 없는 암호화 파일 형식")
    body = blob[len(MAGIC):]
    if os.name == "nt":
        return _dpapi(body, False)
    return _fernet().decrypt(body)


def _write_atomic(path, data: bytes):
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    os.replace(tmp, path)


# ---------------- 키 저장소 ----------------
def _store_path():
    return os.path.join(_dir(), "secrets.bin")


def _migrate_plain_env():
    """예전 평문 .env → 암호화 저장소로 이동 후 평문 삭제"""
    p = os.path.join(_root(), ".env")
    if not os.path.exists(p):
        return {}
    out = {}
    try:
        with open(p, encoding="utf-8") as f:
            for line in f:
                if "=" in line and not line.lstrip().startswith("#"):
                    k, v = line.split("=", 1)
                    k, v = k.strip(), v.strip().strip('"').strip("'")
                    if allowed(k) and v:
                        out[k] = v
    finally:
        try:
            os.remove(p)
        except OSError:
            pass
    return out


def _load():
    with _lock:
        p = _store_path()
        mt = os.path.getmtime(p) if os.path.exists(p) else None
        if _cache["data"] is not None and _cache["mtime"] == mt and _cache.get("path") == p:
            return dict(_cache["data"])
        data = {}
        if mt is not None:
            with open(p, "rb") as f:
                data = json.loads(decrypt(f.read()).decode("utf-8"))
        legacy = _migrate_plain_env()
        if legacy:
            data.update(legacy)
            _save(data)
            mt = os.path.getmtime(p)
        _cache.update(mtime=mt, data=data, path=p)
        return dict(data)


def _save(data):
    with _lock:
        p = _store_path()
        _write_atomic(p, encrypt(json.dumps(data, ensure_ascii=False).encode("utf-8")))
        _cache.update(mtime=os.path.getmtime(p), data=dict(data), path=p)


def get(k, default=""):
    return _load().get(k, default)


def all_values():
    return _load()


def set_many(updates):
    """허용 키만 저장. 빈 문자열 = 변경 없음, None = 삭제"""
    with _lock:
        cur = _load()
        for k, v in updates.items():
            if not allowed(k):
                continue
            if v is None:
                cur.pop(k, None)
            elif isinstance(v, str) and v.strip():
                cur[k] = "".join(ch for ch in v.strip() if ch >= " ")[:4000]
        _save(cur)
        return masked()


def masked():
    e, out = _load(), {}
    for k in KEYS + sorted(k for k in e if _ACCT_RE.match(k)):
        v = e.get(k, "")
        out[k] = "" if not v else "••••••••" if is_secret(k) else v
    return out


def secret_values():
    """로그 가림용: 저장된 비밀값 목록"""
    try:
        return [v for k, v in _load().items() if is_secret(k) and v and len(v) >= 6]
    except Exception:  # noqa: BLE001
        return []


# ---------------- 로그인 쿠키(세션) 저장 ----------------
def _blob_path(name):
    if not re.fullmatch(r"[a-z0-9\-]{1,40}", name):
        raise ValueError("잘못된 이름")
    return os.path.join(_dir(), f"session-{name}.bin")


def save_json(name, obj):
    _write_atomic(_blob_path(name), encrypt(json.dumps(obj, ensure_ascii=False).encode("utf-8")))


def load_json(name, default=None):
    p = _blob_path(name)
    if not os.path.exists(p):
        return default
    try:
        with open(p, "rb") as f:
            return json.loads(decrypt(f.read()).decode("utf-8"))
    except Exception:  # noqa: BLE001 (손상·다른 PC 파일 → 없는 것으로)
        return default


def delete_json(name):
    try:
        os.remove(_blob_path(name))
    except OSError:
        pass
