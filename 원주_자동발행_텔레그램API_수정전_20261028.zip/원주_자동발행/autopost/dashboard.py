# -*- coding: utf-8 -*-
"""로컬 대시보드 (Flask, 127.0.0.1 전용)

보안
- 127.0.0.1 에만 열림 (다른 PC·휴대폰에서 접속 불가), Host 헤더 확인(DNS 리바인딩 방지)
- 요청 위조(CSRF) 방지: 실행할 때마다 새 비밀 토큰을 화면에만 넣고, 모든 변경 요청(POST)에 X-CSRF-Token 헤더 필수
  + Origin/Referer/Sec-Fetch-Site 가 다른 사이트면 거부
- 비밀값은 암호화 저장소에만 저장, 응답·로그에는 가린 값만
"""
import hmac, os, re, secrets as pysecrets, threading, queue
from datetime import datetime
from urllib.parse import urlparse
from flask import Flask, jsonify, request, send_from_directory, abort, Response
from . import generator as g, paths, secure, accounts as A, tasks as T
from .util import CHANNELS, CH_NAME, BROWSER_CHANNELS, load_config, save_config, log, tail_log, redact, is_dry

VERSION = "3.12.0"
POSITIONS = ("top", "bottom") + tuple(f"img{n}" for n in range(1, 8))


def _int(v, lo, hi, name):
    try:
        return max(lo, min(int(v), hi))
    except (TypeError, ValueError):
        abort(400, description=f"{name}는 숫자로 입력해 주세요")


CARD_RE = re.compile(r'<div class="shop-card".*?</div></div>', re.S)


def create_app(engine=None, on_quit=None, port=None):
    from . import connect, browser, autostart, library as lib, llm
    from .readiness import channel_status, live_check
    app = Flask(__name__, static_folder=None)
    app.config["MAX_CONTENT_LENGTH"] = 400 * 1024 * 1024
    ui = os.path.join(paths.resource_dir(), "autopost", "ui")
    csrf = pysecrets.token_urlsafe(32)
    app.config["CSRF"] = csrf
    try:   # 처음 실행: 원주통닭 기업 CI(로고)를 자료함에 등록
        lib.ensure_default_ci(load_config())
    except Exception as e:  # noqa: BLE001
        log("WARN", f"기업 CI 등록 실패: {e}")
    label_q = queue.Queue()
    label_state = {"pending": 0}

    def poke():
        if engine:
            engine.poke()

    # ---------- 보안 ----------
    @app.before_request
    def guard():
        host = (request.host or "").rsplit(":", 1)[0].strip("[]")
        public_hosts = {x.strip().lower() for x in os.environ.get("AUTOPOST_PUBLIC_HOSTS", "").split(",") if x.strip()}
        is_kakao_hook = request.path.startswith("/api/kakao/skill/") and request.method == "POST"
        if host.lower() not in ({"127.0.0.1", "localhost"} | (public_hosts if is_kakao_hook else set())):
            abort(403)
        if is_kakao_hook:
            return
        if request.method in ("GET", "HEAD", "OPTIONS"):
            return
        tok = request.headers.get("X-CSRF-Token", "")
        if not tok or not hmac.compare_digest(tok, csrf):
            abort(403, description="보안 확인 실패: 화면을 새로고침해 주세요")
        sfs = request.headers.get("Sec-Fetch-Site")
        if sfs and sfs not in ("same-origin", "none"):
            abort(403)
        origin = request.headers.get("Origin") or request.headers.get("Referer")
        if origin:
            o = urlparse(origin)
            if o.hostname not in ("127.0.0.1", "localhost") or (port and o.port != port):
                abort(403)

    @app.after_request
    def headers(resp):
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                                                   "script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; form-action 'self'")
        if request.path.startswith("/api/") or request.path == "/":
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.errorhandler(Exception)
    def err(e):
        code = getattr(e, "code", 500)
        if not isinstance(code, int):
            code = 500
        if code >= 500:
            log("ERROR", f"대시보드 오류: {e}")
        msg = getattr(e, "description", None) if code < 500 else str(e)
        return jsonify({"ok": False, "error": redact(msg or "오류")[:300]}), code

    @app.get("/")
    def index():
        with open(os.path.join(ui, "index.html"), encoding="utf-8") as f:
            html = f.read().replace("__CSRF__", csrf)
        return Response(html, mimetype="text/html")

    @app.get("/api/ping")
    def ping():
        return jsonify({"app": "wonju-autopost", "version": VERSION})

    # ---------- 상태 ----------
    @app.get("/api/state")
    def state():
        cfg = load_config()
        st = channel_status(cfg)
        accs = {}
        for ch in CHANNELS:
            accs[ch] = [{**a, "status": st[ch]["accounts"].get(a["id"], {})} for a in A.list_accounts(cfg, ch)]
        return jsonify({
            "version": VERSION, "live": cfg.get("live") is True, "auto": bool(cfg.get("auto")), "shop": cfg["shop"], "accounts": accs,
            "channels": {ch: {"name": CH_NAME[ch], "ok": st[ch]["ok"], "text": st[ch]["text"]} for ch in CHANNELS},
            "schedule": cfg.get("schedule", {}), "secrets": secure.masked(), "llm": {**llm.status(cfg), "maxTokens": g.max_tokens(cfg)},
            "images": {"publicBaseUrl": cfg.get("images", {}).get("publicBaseUrl", "")},
            "browser": browser.browser_available(cfg), "install": browser.INSTALL, "autostart": autostart.is_enabled(),
            "dataDir": g.ROOT, "engine": engine.status() if engine else {}, "labeling": label_state["pending"],
            "instagram": cfg.get("instagram", {}), "voices": g.VOICES, "config": _config_view(cfg)})

    def _config_view(cfg):
        from . import blocks
        ps = list(cfg.get("prompts") or g.DEFAULT_PROMPTS)
        if "cafe" not in {x.get("id") for x in ps} and "cafe" not in (cfg.get("promptsRemoved") or []):   # 업데이트로 생긴 기본 프롬프트
            ps += [x for x in g.DEFAULT_PROMPTS if x["id"] == "cafe"]
        return {"prompts": ps, "defaultPrompt": cfg.get("defaultPrompt") or "owner",
                "promptByChannel": {**g.DEFAULT_PROMPT_BY_CHANNEL, **(cfg.get("promptByChannel") or {})}, "promptExtra": cfg.get("promptExtra", ""),
                "blocks": blocks.all_blocks(cfg), "topicBlocks": blocks.topic_blocks(cfg),
                "modes": {k: {"name": m["name"], "promo": m["promo"], "w": float((cfg.get("modeWeights") or {}).get(k, m["w"]))} for k, m in g.CONTENT_MODES.items()},
                "autoModes": cfg.get("autoModes") is not False,
                "ci": {**lib.ci_settings(cfg), "photos": [_pub(p) for p in lib.ci_photos()]},
                "campaigns": g.campaigns(cfg), "activeCampaigns": [c["name"] for c in g.active_campaigns(cfg)],
                "place": {"mapQueries": [], "mapMatch": ["시민로 386"], "autoRefresh": True, **(cfg.get("place") or {})},
                "library": {"minPhotos": 3, "maxPhotos": 6, "noRepeatDays": 14, **(cfg.get("library") or {})},
                "keywords": {"noRepeatDays": cfg["keywords"].get("noRepeatDays", 14)},
                "quality": {"maxKeywordRepeats": 5, "maxSimilarity": 0.5, **(cfg.get("quality") or {})},
                "browser": {"headless": False, "slowMo": 30, **(cfg.get("browser") or {})},
                "channelNames": CH_NAME, "topics": g.all_topics(), "styleAutoLearn": cfg.get("styleAutoLearn", True)}

    # ---------- 스위치·일정 ----------
    @app.post("/api/settings")
    def settings():
        cfg, b = load_config(), request.get_json(force=True) or {}
        warn = []
        if "live" in b:
            if b["live"] and not cfg.get("live"):
                ok, missing = live_check(cfg)
                if not ok:
                    return jsonify({"ok": False, "live": False, "error": "실제 발행을 켤 수 없어요. 연결된 계정이 하나도 없어요. 먼저 '계정 연결'에서 연결해 주세요"
                                    + (": " + ", ".join(f"{n}({t})" for n, t in missing[:6]) if missing else "")})
                if not llm.api_key():
                    return jsonify({"ok": False, "live": False, "error": "실제 발행에는 Claude API 키가 필요해요. 'AI 설정'에서 키를 넣어 주세요"})
                warn = [f"{n}: {t}" for n, t in missing]
            cfg["live"] = bool(b["live"])
            log("INFO", f"실제 발행 {'켜짐' if cfg['live'] else '꺼짐(테스트 모드)'}")
        if "auto" in b:
            cfg["auto"] = bool(b["auto"])
            log("INFO", f"자동 모드 {'켜짐' if cfg['auto'] else '꺼짐'}")
        sc = cfg.setdefault("schedule", {})
        s = b.get("schedule") or {}
        if "activeHours" in s:
            h = s["activeHours"]
            if not (isinstance(h, list) and len(h) == 2):
                abort(400, description="활동 시간을 확인해 주세요")
            h0, h1 = _int(h[0], 0, 23, "시작 시각"), _int(h[1], 1, 24, "끝 시각")
            if h1 <= h0:
                abort(400, description="끝 시각이 시작 시각보다 늦어야 해요")
            sc["activeHours"] = [h0, h1]
        if "accountGapMinutes" in s:
            sc["accountGapMinutes"] = _int(s["accountGapMinutes"], 10, 360, "같은 채널 글 사이 간격")
        if "sameAccountGapMinutes" in s:
            sc["sameAccountGapMinutes"] = _int(s["sameAccountGapMinutes"], 3, 180, "같은 계정 발행 간격")
        if "autostart" in b:
            try:
                autostart.set_enabled(bool(b["autostart"]))
            except OSError as e:
                warn.append(f"자동 실행 설정 실패: {e}")
        save_config(cfg)
        if "auto" in b and not cfg["auto"]:
            from .kakao_auto_reply import manager as kakao_manager
            kakao_manager.stop_all()
        poke()
        return jsonify({"ok": True, "live": cfg.get("live") is True, "auto": bool(cfg.get("auto")), "warnings": warn})

    # ---------- 계정 ----------
    @app.post("/api/accounts/<ch>")
    def accounts_save(ch):
        if ch not in CHANNELS:
            abort(404)
        cfg, b = load_config(), request.get_json(force=True) or {}
        lst = A.list_accounts(cfg, ch)
        act = b.get("action")
        if act == "add":
            if len(lst) >= A.MAX_ACCOUNTS[ch]:
                abort(400, description=f"계정은 {A.MAX_ACCOUNTS[ch]}개까지예요")
            aid = A.new_id(cfg, ch)
            lst.append(A.new_account(aid, f"ID {len(lst) + 1}"))
            log("INFO", f"[{CH_NAME[ch]}] 계정 추가: {aid}")
        elif act == "remove":
            aid = str(b.get("id") or "")
            if aid == "main":
                abort(400, description="ID 1 은 지울 수 없어요 (하루 발행 수를 0으로 하면 쉬어요)")
            if not any(x["id"] == aid for x in lst):
                abort(404, description="계정을 찾을 수 없어요")
            cfg["accounts"][ch]["list"] = [x for x in lst if x["id"] != aid]
            if ch == "instagram":
                secure.set_many({A.env_key(k, aid): None for k in A.IG_ENV})
            if ch == "x":
                secure.set_many({A.env_key(k, aid): None for k in A.X_ENV})
            if ch in ("threads", "facebook", "band"):
                from .publishers.social import TOKEN_KEY
                secure.set_many({A.env_key(TOKEN_KEY[ch], aid): None})
            prof = A.profile_name(ch, aid)
            if A.valid_id(aid):
                import shutil
                shutil.rmtree(browser.profile_dir(prof), ignore_errors=True)
                secure.delete_json(browser.session_name(prof))
            log("INFO", f"[{CH_NAME[ch]}] 계정 삭제: {aid}")
        elif act == "save":
            for v in b.get("accounts") or []:
                a = next((x for x in lst if x["id"] == v.get("id")), None)
                if not a:
                    continue
                if "label" in v:
                    a["label"] = str(v["label"]).strip()[:30] or a["label"]
                if "handle" in v and ch == "cafe":
                    h = str(v["handle"]).strip()
                    if h and not h.startswith("http"):
                        h = "https://cafe.naver.com/" + h.strip("/")
                    if h and not connect.cafe_url_ok(h):
                        abort(400, description=f"{a['label']}: 카페 주소(https://cafe.naver.com/카페이름)를 넣어 주세요")
                    if h != a.get("handle"):
                        a["clubId"], a["board"], a["boardsSelected"] = "", {}, []
                    a["handle"] = h
                if "handle" in v and ch == "band":
                    h = str(v["handle"] or "").strip()
                    if h and not re.fullmatch(r"[A-Za-z0-9_\-]{4,80}", h):
                        abort(400, description=f"{a['label']}: 밴드를 '밴드 불러오기'로 골라 주세요")
                    a["handle"] = h
                if "handle" in v and ch == "manual":
                    from .publishers.social import MANUAL_TARGETS
                    a["handle"] = v["handle"] if v["handle"] in MANUAL_TARGETS else "daangn"
                if "board" in v and ch == "cafe":
                    bid, _, bname = str(v["board"] or "").partition("|")
                    a["board"] = {"id": re.sub(r"\D", "", bid)[:12], "name": bname.strip()[:60]} if bname.strip() else {}
                if "boardsSelected" in v and ch == "cafe":
                    selected = v["boardsSelected"] if isinstance(v["boardsSelected"], list) else [v["boardsSelected"]]
                    known = {str(x.get("id")): str(x.get("name") or "") for x in (a.get("boards") or [])}
                    clean = []
                    for raw in selected[:30]:
                        bid, _, bname = str(raw or "").partition("|")
                        bid = re.sub(r"\D", "", bid)[:12]
                        name = (known.get(bid) or bname.strip())[:60]
                        if bid and name and not any(x["id"] == bid for x in clean):
                            clean.append({"id": bid, "name": name})
                    a["boardsSelected"] = clean
                    if clean:
                        a["board"] = clean[0]
                elif "handle" in v and ch in BROWSER_CHANNELS:
                    h = re.sub(r"^https?://", "", str(v["handle"]).strip())
                    h = h.replace("m.blog.naver.com/", "").replace("blog.naver.com/", "").replace(".tistory.com", "").split("/")[0].strip()
                    if h and not re.fullmatch(r"[A-Za-z0-9_\-]{1,50}", h):
                        abort(400, description=f"{a['label']}: 블로그 아이디/이름은 영문·숫자·-·_ 만 쓸 수 있어요")
                    if h and h in {x.get("handle") for x in lst if x is not a}:
                        abort(400, description=f"{a['label']}: 다른 계정과 같은 블로그예요")
                    a["handle"] = h
                if "postsPerDay" in v:
                    a["postsPerDay"] = _int(v["postsPerDay"], 0, 10, "하루 발행 수")
                if "enabled" in v:
                    a["enabled"] = bool(v["enabled"])
                if "categories" in v:
                    raw = v["categories"] if isinstance(v["categories"], list) else str(v["categories"]).split(",")
                    a["categories"] = [str(x).strip()[:40] for x in raw if str(x).strip()][:30]
                    a["catConfirmed"] = True
                if "keywords" in v:
                    raw = v["keywords"] if isinstance(v["keywords"], list) else re.split(r"[,\n]", str(v["keywords"]))
                    a["keywords"] = [str(x).strip()[:60] for x in raw if str(x).strip()][:100]
                if "voice" in v:
                    a["voice"] = str(v["voice"]).strip()[:300]
                if "mode" in v:
                    a["mode"] = v["mode"] if v["mode"] in g.CONTENT_MODES else ""
                if "prompt" in v:
                    pids = {x["id"] for x in (load_config().get("prompts") or g.DEFAULT_PROMPTS)}
                    a["prompt"] = v["prompt"] if v["prompt"] in pids else ""
                for k in ("private", "place", "hold", "summary"):
                    if k in v:
                        a[k] = bool(v[k])
                if "topics" in v:
                    ok_t = set(g.topics_for(ch))
                    a["topics"] = [t for t in (v["topics"] or []) if t in ok_t][:20]
                if "block" in v:
                    a["block"] = re.sub(r"[^A-Za-z0-9_\-]", "", str(v["block"]))[:30]
                if "position" in v:
                    a["position"] = v["position"] if v["position"] in POSITIONS else "bottom"
        else:
            abort(400)
        A.sync_legacy(cfg)
        save_config(cfg)
        poke()
        return jsonify({"ok": True})

    def _acc_or_404(ch, cfg=None):
        aid = str((request.get_json(silent=True) or {}).get("aid") or "main")
        cfg = cfg or load_config()
        if ch not in CHANNELS or not A.get(cfg, ch, aid):
            abort(404, description="계정을 찾을 수 없어요")
        return cfg, aid

    @app.post("/api/connect/<ch>")
    def connect_login(ch):
        if ch not in BROWSER_CHANNELS:
            abort(404)
        cfg, aid = _acc_or_404(ch)
        if ch == "cafe" and not (A.get(cfg, ch, aid) or {}).get("handle"):
            abort(400, description="카페 게시판 글쓰기 주소를 먼저 넣고 저장해 주세요")
        if ch == "tistory" and not (A.get(cfg, ch, aid) or {}).get("handle"):
            abort(400, description="티스토리 블로그 주소(예: wonju 또는 wonju.tistory.com)를 먼저 넣고 저장해 주세요")
        try:
            return jsonify(connect.connect_login(ch, cfg, aid))
        except RuntimeError as e:
            abort(400, description=str(e))

    @app.post("/api/connect/<ch>/done")
    def connect_done(ch):
        if ch not in BROWSER_CHANNELS:
            abort(404)
        _, aid = _acc_or_404(ch)
        return jsonify(connect.login_done(ch, aid))

    verify_state = {}

    @app.post("/api/verify/<ch>")
    def verify(ch):
        if ch not in BROWSER_CHANNELS:
            abort(404)
        cfg, aid = _acc_or_404(ch)
        key = f"{ch}-{aid}"
        if verify_state.get(key) == "running":
            return jsonify({"ok": True, "started": False})
        verify_state[key] = "running"

        def work():
            try:
                connect.verify_session(ch, cfg, aid)
            except Exception as e:  # noqa: BLE001
                log("ERROR", f"연결 확인 실패: {e}")
            finally:
                verify_state[key] = "done"
                poke()
        threading.Thread(target=work, daemon=True).start()
        return jsonify({"ok": True, "started": True})

    @app.post("/api/run/<ch>")
    def run_now(ch):
        """지금 1건: 이 계정으로 AI 글 1개를 만들어 (테스트 모드면 미리보기만, 실제 발행이면 올림)"""
        cfg, aid = _acc_or_404(ch)
        acc = A.get(cfg, ch, aid)
        b = request.get_json(silent=True) or {}
        st = T.job_defaults(acc)
        if "private" in b:
            st["private"] = bool(b["private"])
        jid = T.add(ch, aid, A.label(cfg, ch, aid), auto=False, settings=st)
        poke()
        return jsonify({"ok": True, "id": jid, "dry": is_dry(cfg)})

    # ---------- 키 (암호화 저장) ----------
    @app.post("/api/secrets")
    def secrets_save():
        b = request.get_json(force=True)
        if not isinstance(b, dict):
            abort(400)
        upd = {k: v for k, v in b.items() if secure.allowed(k) and (isinstance(v, str) or v is None)}
        res = secure.set_many(upd)
        if upd.get("ANTHROPIC_API_KEY"):
            def chk():
                try:
                    llm.list_models(force=True)
                except Exception as e:  # noqa: BLE001
                    log("WARN", f"Claude 모델 확인 실패: {e}")
            threading.Thread(target=chk, daemon=True).start()
        if any(k.startswith("FTP_") for k in upd):
            connect.set_state("wonju", ok=False, state="none")
        log("INFO", f"키 저장(암호화): {', '.join(k for k, v in upd.items() if v) or '-'}")
        return jsonify({"ok": True, "secrets": res})

    @app.post("/api/ftp/test")
    def ftp_test():
        from .publishers.wonju import ftp_test as t
        try:
            entries = t()
            connect.set_state("wonju", ok=True, state="connected")
            T.on_connected("wonju", "main")
            poke()
            return jsonify({"ok": True, "entries": entries})
        except Exception as e:  # noqa: BLE001
            connect.set_state("wonju", ok=False, state="failed")
            return jsonify({"ok": False, "error": redact(str(e))[:200]})

    @app.post("/api/images")
    def images_save():
        cfg, b = load_config(), request.get_json(force=True) or {}
        u = str(b.get("publicBaseUrl") or "").strip()
        if u and not re.match(r"^https?://[^\s\"'<>]+$", u):
            abort(400, description="사진 공개 주소는 http:// 또는 https:// 로 시작해야 해요")
        cfg.setdefault("images", {})["publicBaseUrl"] = u.rstrip("/")
        save_config(cfg)
        return jsonify({"ok": True})

    @app.post("/api/instagram/token")
    def ig_token():
        b = request.get_json(force=True) or {}
        tok, aid = (b.get("token") or "").strip(), str(b.get("aid") or "main")
        if not tok:
            abort(400, description="토큰을 붙여넣어 주세요")
        if not A.get(load_config(), "instagram", aid):
            abort(404, description="계정을 찾을 수 없어요")
        try:
            r = connect.exchange_instagram_token(tok, aid=aid)
            poke()
            return jsonify(r)
        except Exception as e:  # noqa: BLE001
            return jsonify({"ok": False, "error": "인스타 연결 실패: " + redact(str(e))[:200]})

    @app.post("/api/instagram/check")
    def ig_check():
        return jsonify(connect.check_instagram(aid=str((request.get_json(silent=True) or {}).get("aid") or "main")))

    @app.post("/api/instagram/settings")
    def ig_settings():
        cfg, b = load_config(), request.get_json(force=True) or {}
        if "hashtagSet" in b:
            cfg.setdefault("instagram", {})["hashtagSet"] = ["#" + t.strip().lstrip("#") for t in re.split(r"[\s,]+", str(b["hashtagSet"])) if t.strip("# ")][:30]
        save_config(cfg)
        return jsonify({"ok": True})

    # ---------- AI ----------
    @app.post("/api/llm")
    def llm_save():
        cfg, b = load_config(), request.get_json(force=True) or {}
        l = cfg.setdefault("llm", {})
        if "model" in b:
            m = str(b["model"]).strip()
            if m not in ("", "auto") and not re.fullmatch(r"[A-Za-z0-9._:\-]{3,80}", m):
                abort(400, description="모델 ID 형식이 올바르지 않아요")
            l["model"] = m or "auto"
        if "maxTokens" in b:
            l["maxTokens"] = _int(b["maxTokens"], 1000, 16000, "최대 토큰")
        l.pop("anthropicModel", None)
        save_config(cfg)
        return jsonify({"ok": True})

    @app.post("/api/llm/refresh")
    def llm_refresh():
        try:
            ms = llm.list_models(force=True)
        except llm.ClaudeError as e:
            abort(400, description=str(e))
        return jsonify({"ok": True, "count": len(ms), "chosen": llm.chosen_model(load_config())})

    @app.get("/api/usage")
    def usage():
        return jsonify(g.usage_summary(load_config()))

    # ---------- 작업 ----------
    @app.get("/api/jobs")
    def jobs():
        out = []
        for t in T.list_jobs(int(request.args.get("limit", 150))):
            out.append({k: t[k] for k in ("id", "created", "channel", "account_id", "account_label", "auto", "status", "keyword", "title",
                                          "scheduled_at", "url", "error", "published_at", "dry", "attempts", "provider", "pub_after")}
                       | {"kind": "daily" if (t["settings"] or {}).get("daily") else ("hold" if (t["settings"] or {}).get("hold") else ""),
                          "prompt": (t["settings"] or {}).get("promptUsed") or (t["settings"] or {}).get("prompt") or ""}
                       | {"images": len(t["images"] or []), "hasShot": bool(t["shot"]), "channelName": CH_NAME.get(t["channel"], t["channel"])})
        return jsonify({"jobs": out})

    @app.post("/api/jobs/<int:jid>/<act>")
    def job_action(jid, act):
        if act == "retry":
            ok = T.retry_publish(jid)
        elif act == "regenerate":
            ok = T.regenerate(jid)
        elif act == "generate":
            ok = T.start_generation(jid)
        elif act == "release":
            ok = T.release(jid)
        elif act == "delete":
            T.delete(jid)
            ok = True
        else:
            abort(404)
        poke()
        if not ok:
            abort(400, description="지금 상태에서는 할 수 없어요")
        return jsonify({"ok": True})


    # ---------- 작업 설정 (예전 메인 화면): 작업 추가 → 글 생성 시작 → 등록 시작 ----------
    def _job_settings(b, cfg, acc):
        pids = {x["id"] for x in (cfg.get("prompts") or g.DEFAULT_PROMPTS)}
        from . import blocks as _bl
        bids = {x["id"] for x in _bl.all_blocks(cfg)} | {"basic", "takeout", "auto", ""}
        st = T.job_defaults(acc)
        if b.get("prompt") in pids:
            st["prompt"] = b["prompt"]
        if b.get("block") in bids:
            st["block"] = b["block"]
        if b.get("position") in POSITIONS:
            st["position"] = b["position"]
        for k in ("place", "private", "hold"):
            if k in b:
                st[k] = bool(b[k])
        if b.get("category"):
            st["category"] = str(b["category"])[:40]
        return st

    @app.post("/api/jobs/add")
    def jobs_add():
        cfg, b = load_config(), request.get_json(force=True) or {}
        ch = b.get("channel")
        if ch not in CHANNELS:
            abort(400, description="채널을 골라 주세요")
        aids = [a for a in (b.get("accounts") or [b.get("accountId") or "main"]) if A.get(cfg, ch, a)]
        if not aids:
            abort(400, description="계정을 골라 주세요")
        sat = str(b.get("scheduled_at") or "").strip()
        if sat:
            from datetime import datetime as _dt
            try:
                sat = _dt.fromisoformat(sat).isoformat(timespec="seconds")
            except ValueError:
                abort(400, description="예약 시간 형식이 올바르지 않아요")
        kws = [k.strip()[:60] for k in re.split(r"[,\n]", str(b.get("keywords") or "")) if k.strip()] or [""]
        count = _int(b.get("count") or 1, 1, 20, "작업 개수") if kws == [""] else 1
        ids = []
        for aid in aids:
            acc = A.get(cfg, ch, aid)
            st = _job_settings(b, cfg, acc)
            for k in kws[:30]:
                for _ in range(count):
                    when = sat or ("9999-12-31T00:00:00" if st.get("hold") else "")   # 확인 후 등록: '글 생성 시작'을 누를 때까지 기다림
                    ids.append(T.add(ch, aid, A.label(cfg, ch, aid), auto=False, scheduled_at=when, keyword=k, settings=st))
        poke()
        return jsonify({"ok": True, "ids": ids})

    @app.post("/api/jobs/bulk/<act>")
    def jobs_bulk(act):
        ids = [int(i) for i in ((request.get_json(force=True) or {}).get("ids") or []) if str(i).isdigit()][:200]
        fn = {"generate": T.start_generation, "release": T.release, "retry": T.retry_publish, "regenerate": T.regenerate,
              "delete": lambda i: (T.delete(i), True)[1]}.get(act)
        if not fn:
            abort(404)
        n = sum(1 for i in ids if fn(i))
        poke()
        return jsonify({"ok": True, "done": n})

    # ---------- X(트위터) ----------
    @app.post("/api/x/check")
    def x_check():
        from .publishers import x as X
        aid = str((request.get_json(silent=True) or {}).get("aid") or "main")
        if not A.get(load_config(), "x", aid):
            abort(404, description="계정을 찾을 수 없어요")
        try:
            r = X.check(aid)
        except Exception as e:  # noqa: BLE001
            r = {"ok": False, "error": redact(str(e))[:200]}
        prof = A.profile_name("x", aid)
        connect.set_state(prof, ok=bool(r.get("ok")), state="connected" if r.get("ok") else "failed",
                          **({"username": r.get("username", "")} if r.get("ok") else {"error": r.get("error", "")}))
        if r.get("ok"):
            T.on_connected("x", aid)
            poke()
        return jsonify(r)

    @app.post("/api/x/token")
    def x_token():
        b = request.get_json(force=True) or {}
        aid = str(b.get("aid") or "main")
        if not A.get(load_config(), "x", aid):
            abort(404, description="계정을 찾을 수 없어요")
        upd = {A.env_key("X_ACCESS_TOKEN", aid): str(b.get("token") or ""), A.env_key("X_ACCESS_SECRET", aid): str(b.get("secret") or "")}
        secure.set_many(upd)
        connect.set_state(A.profile_name("x", aid), ok=False, state="none")
        return jsonify({"ok": True})

    # ---------- 토큰 채널: 스레드·페이스북 페이지·네이버 밴드 ----------
    @app.post("/api/social/<ch>/token")
    def social_token(ch):
        from .publishers.social import TOKEN_KEY
        if ch not in TOKEN_KEY:
            abort(404)
        cfg, aid = _acc_or_404(ch)
        tok = str((request.get_json(silent=True) or {}).get("token") or "").strip()
        if not tok or len(tok) < 10 or re.search(r"\s", tok):
            abort(400, description="토큰을 정확히 붙여넣어 주세요 (공백 없이)")
        secure.set_many({A.env_key(TOKEN_KEY[ch], aid): tok})
        connect.set_state(A.profile_name(ch, aid), ok=False, state="none")
        return jsonify({"ok": True})

    @app.post("/api/social/<ch>/check")
    def social_check(ch):
        from .publishers import social
        if ch not in social.TOKEN_KEY:
            abort(404)
        cfg, aid = _acc_or_404(ch)
        acc = A.get(cfg, ch, aid)
        try:
            r = social.check(ch, aid, acc.get("handle", "") if ch == "band" else "")
        except Exception as e:  # noqa: BLE001
            r = {"ok": False, "error": redact(str(e))[:200]}
        if ch == "band" and r.get("bands") is not None:
            cfg = load_config()
            A.get(cfg, ch, aid)["bands"] = r["bands"][:100]
            save_config(cfg)
            if not acc.get("handle"):   # 토큰은 맞음 → 밴드만 고르면 됨
                r = {**r, "ok": True, "needBand": True}
        prof = A.profile_name(ch, aid)
        connect.set_state(prof, ok=bool(r.get("ok")), state="connected" if r.get("ok") else "failed",
                          **({"username": r.get("username", "")} if r.get("ok") else {"error": r.get("error", "")}))
        if r.get("ok") and not r.get("needBand"):
            T.on_connected(ch, aid)
            poke()
        return jsonify({k: v for k, v in r.items() if k != "id"})

    # ---------- 오늘의 일상 글 (카페용) ----------
    @app.post("/api/daily/upload")
    def daily_upload():
        files = request.files.getlist("files")
        if not files:
            abort(400, description="사진을 골라 주세요")
        cfg, out, errs = load_config(), [], []
        for f in files[:20]:
            try:
                p, _ = lib.add_photo(f.read(), f.filename, cfg, source="daily", label=False)
                out.append(_pub(p))
            except Exception as e:  # noqa: BLE001 (한 장이 이상해도 나머지는 계속)
                errs.append(str(e)[:160])
        if not out and errs:
            abort(400, description=errs[0])
        return jsonify({"ok": True, "photos": out, "errors": errs})

    @app.post("/api/daily/plan")
    def daily_plan():
        from . import daily
        b = request.get_json(force=True) or {}
        try:
            return jsonify({"ok": True, "plan": daily.plan(load_config(), b.get("photoIds") or [], str(b.get("memo") or "")[:500],
                                                           b.get("kind") if b.get("kind") in ("visit", "life") else "daily")})
        except (ValueError, llm.ClaudeError) as e:
            abort(400, description=str(e))

    @app.post("/api/daily/create")
    def daily_create():
        cfg, b = load_config(), request.get_json(force=True) or {}
        pids = [int(i) for i in (b.get("photoIds") or []) if str(i).isdigit() and lib.get_photo(int(i))][:10]
        if not pids:
            abort(400, description="사진을 먼저 올려 주세요")
        prompt_text = str(b.get("prompt") or "").strip()[:3000]
        if not prompt_text:
            abort(400, description="'AI가 글 계획 짜기'를 먼저 눌러 주세요 (지시문이 비어 있어요)")
        kind = b.get("kind") if b.get("kind") in ("visit", "life") else "daily"
        sat = str(b.get("scheduled_at") or "").strip()
        if sat:   # 올릴 시간 (예약)
            try:
                sat = datetime.fromisoformat(sat.replace(" ", "T")).isoformat(timespec="seconds")
            except ValueError:
                abort(400, description="올릴 시간 형식이 잘못됐어요")
        memo = str(b.get("memo") or "").strip()[:500]
        if kind == "visit" and len(memo) < 10:
            abort(400, description="'다른 가게 방문기'는 실제로 다녀온 곳·먹은 것·느낀 점을 메모에 10자 이상 적어 주세요 (메모에 있는 것만 글에 씁니다)")
        ids = []
        for tgt in b.get("targets") or []:
            ch, aid = tgt.get("channel"), str(tgt.get("aid") or "main")
            acc = A.get(cfg, ch, aid) if ch in CHANNELS else None
            if not acc or (kind == "visit" and ch not in ("naver", "cafe", "tistory")) or \
                    (kind == "life" and ch not in ("naver", "tistory", "cafe", "band", "instagram", "x", "threads", "facebook")):
                continue
            st = _job_settings(b, cfg, acc)
            st["daily"] = {"photo_ids": pids, "plan": prompt_text, "memo": memo, "keyword": str(b.get("keyword") or "")[:60], "kind": kind,
                           "sign": bool(b.get("sign"))}
            ids.append(T.add(ch, aid, A.label(cfg, ch, aid), auto=False, keyword=st["daily"]["keyword"], settings=st, scheduled_at=sat))
        if not ids:
            abort(400, description="올릴 채널·계정을 하나 이상 골라 주세요")
        poke()
        return jsonify({"ok": True, "ids": ids})

    # ---------- 블로그 카테고리 불러오기 (네이버·손님용·티스토리) ----------
    @app.post("/api/categories/<ch>")
    def categories_fetch(ch):
        from .browser import BROWSER_LOCK, profile_lock
        from .publishers import naver as NV, tistory as TS
        if ch not in ("naver", "guide", "tistory"):
            abort(404)
        cfg, aid = _acc_or_404(ch)
        acc = A.get(cfg, ch, aid)
        prof = A.profile_name(ch, aid)
        plock = profile_lock(prof)
        if not plock.acquire(timeout=120):
            abort(409, description="지금 이 계정으로 발행·로그인 중이에요. 잠시 뒤 다시 눌러 주세요")
        try:
            with BROWSER_LOCK:
                cats = TS.fetch_categories(cfg, acc, prof) if ch == "tistory" else NV.fetch_categories(cfg, acc, prof, ch)
        except Exception as e:  # noqa: BLE001
            abort(400, description=f"카테고리를 불러오지 못했어요: {str(e)[:200]}")
        finally:
            plock.release()
        cfg = load_config()
        A.get(cfg, ch, aid)["catList"] = cats
        save_config(cfg)
        log("INFO", f"[{CH_NAME[ch]} {acc['label']}] 카테고리 {len(cats)}개 불러옴: {', '.join(cats[:10])}")
        return jsonify({"ok": True, "categories": cats})

    # ---------- 네이버 카페: 게시판 불러오기 ----------
    @app.post("/api/cafe/boards")
    def cafe_boards():
        from .publishers import cafe as C
        from .browser import BROWSER_LOCK, profile_lock
        cfg, aid = _acc_or_404("cafe")
        acc = A.get(cfg, "cafe", aid)
        if not connect.cafe_url_ok(acc.get("handle") or ""):
            abort(400, description="카페 주소를 먼저 넣고 저장해 주세요")
        prof = A.profile_name("cafe", aid)
        plock = profile_lock(prof)
        if not plock.acquire(timeout=90):
            abort(409, description="지금 이 계정으로 발행·로그인 중이에요. 잠시 뒤 다시 눌러 주세요")
        try:
            with BROWSER_LOCK:
                cid, boards = C.fetch_boards(cfg, acc, prof)
        except Exception as e:  # noqa: BLE001
            abort(400, description=f"게시판을 불러오지 못했어요: {str(e)[:200]}")
        finally:
            plock.release()
        cfg = load_config()
        a = A.get(cfg, "cafe", aid)
        a["clubId"], a["boards"] = cid, boards[:60]
        save_config(cfg)
        return jsonify({"ok": True, "clubId": cid, "boards": boards})

    # ---------- 기존 글 스타일 학습 ----------
    @app.post("/api/style/<ch>")
    def style_learn(ch):
        from . import style
        cfg, aid = _acc_or_404(ch)
        b = request.get_json(silent=True) or {}
        acc = A.get(cfg, ch, aid)
        if b.get("clear"):
            acc["style"] = {}
            save_config(cfg)
            return jsonify({"ok": True, "style": {}})
        raw = str(b.get("texts") or "").strip()
        texts = [t for t in re.split(r"\n\s*-{3,}\s*\n|\n{4,}", raw) if t.strip()][:6] if raw else None
        try:
            st = style.learn(cfg, ch, acc, texts)
        except Exception as e:  # noqa: BLE001
            abort(400, description=f"스타일 학습 실패: {str(e)[:200]}")
        save_config(cfg)
        return jsonify({"ok": True, "style": st})

    # ---------- 설정 묶음: 프롬프트 / 마케팅 / 장소 / 세부 설정 ----------
    @app.get("/api/config")
    def config_get():
        return jsonify(_config_view(load_config()))

    # ---------- Unified chat channel credentials ----------
    @app.get("/api/chat/connections")
    def chat_connections_get():
        from . import chat_integrations as ci
        cfg = load_config(); root = cfg.get("chatIntegrations") or {}
        base = str(root.get("publicBaseUrl") or "").rstrip("/")
        return jsonify({"ok": True, "publicBaseUrl": base,
                        "connections": [ci.masked_connection(x, base) for x in root.get("connections") or []]})

    @app.post("/api/chat/connections")
    def chat_connections_save():
        from . import chat_integrations as ci
        cfg, b = load_config(), request.get_json(force=True) or {}
        root = cfg.setdefault("chatIntegrations", {}); items = root.setdefault("connections", [])
        action = str(b.get("action") or "")
        if action == "add":
            try: items.append(ci.new_connection(str(b.get("provider") or ""), str(b.get("label") or "")))
            except ValueError as e: abort(400, description=str(e))
        elif action == "delete":
            cid = str(b.get("id") or ""); item = next((x for x in items if x.get("id") == cid), None)
            if not item: abort(404, description="상담 채널을 찾을 수 없어요")
            secure.set_many({ci.telegram_key(cid): None, ci.naver_key(cid): None, ci.webhook_key(cid): None})
            root["connections"] = [x for x in items if x.get("id") != cid]
        elif action == "base":
            base = str(b.get("publicBaseUrl") or "").strip().rstrip("/")
            if base and not re.fullmatch(r"https://[A-Za-z0-9.-]+(?::\d+)?(?:/[A-Za-z0-9._~!$&'()*+,;=:@%-]*)*", base):
                abort(400, description="공개 주소는 HTTPS 도메인으로 입력해 주세요")
            root["publicBaseUrl"] = base
        else: abort(400, description="잘못된 요청입니다")
        save_config(cfg); return chat_connections_get()

    @app.post("/api/chat/connections/<cid>/token")
    def chat_connection_token(cid):
        from . import chat_integrations as ci
        cfg, b = load_config(), request.get_json(force=True) or {}
        item = next((x for x in (cfg.get("chatIntegrations") or {}).get("connections") or [] if x.get("id") == cid), None)
        if not item: abort(404, description="상담 채널을 찾을 수 없어요")
        token = str(b.get("token") or "").strip()
        try:
            if item["provider"] == "telegram_bot":
                account = ci.verify_telegram(token); secure.set_many({ci.telegram_key(cid): token})
            else:
                account = ci.validate_naver_token(token); secure.set_many({ci.naver_key(cid): token})
        except ValueError as e: abort(400, description=str(e))
        item["account"], item["enabled"], item["lastError"] = account, True, ""
        save_config(cfg)
        return jsonify({"ok": True, "account": account, "message": "연결 정보를 암호화해서 저장했습니다"})

    @app.post("/api/chat/connections/<cid>/webhook-secret")
    def chat_connection_webhook_secret(cid):
        from . import chat_integrations as ci
        cfg = load_config()
        if not any(x.get("id") == cid for x in (cfg.get("chatIntegrations") or {}).get("connections") or []):
            abort(404, description="상담 채널을 찾을 수 없어요")
        value = pysecrets.token_urlsafe(32); secure.set_many({ci.webhook_key(cid): value})
        return jsonify({"ok": True, "secret": value})

    # ---------- Kakao Channel: official Open Builder skill webhook ----------
    @app.get("/api/kakao/channels")
    def kakao_channels_get():
        from . import kakao_channel as kc
        cfg = load_config(); base = kc.public_base(cfg)
        items = []
        for ch in kc.channels(cfg):
            cid = ch.get("id", "")
            items.append({**ch, "hasToken": bool(secure.get(kc.token_key(cid))), "stats": kc.stats(cid),
                          "webhookUrl": (base + f"/api/kakao/skill/{cid}") if base else f"/api/kakao/skill/{cid}"})
        return jsonify({"ok": True, "publicBaseUrl": base, "tokenHeader": kc.TOKEN_HEADER, "channels": items})

    @app.post("/api/kakao/channels")
    def kakao_channels_save():
        from . import kakao_channel as kc
        cfg, b = load_config(), request.get_json(force=True) or {}
        root = cfg.setdefault("kakaoChannel", {})
        action = str(b.get("action") or "save")
        current = root.setdefault("channels", [])
        if action == "add":
            ch = kc.new_channel(str(b.get("label") or "새 카카오 채널"))
            current.append(ch); kc.ensure_token(ch["id"])
        elif action == "delete":
            cid = str(b.get("id") or "")
            if not any(x.get("id") == cid for x in current): abort(404, description="카카오 채널을 찾을 수 없어요")
            root["channels"] = [x for x in current if x.get("id") != cid]
            secure.set_many({kc.token_key(cid): None})
        elif action == "token":
            cid = str(b.get("id") or "")
            if not any(x.get("id") == cid for x in current): abort(404, description="카카오 채널을 찾을 수 없어요")
            secure.set_many({kc.token_key(cid): pysecrets.token_urlsafe(32)})
        else:
            raw_items = b.get("channels") or []
            old = {x.get("id"): x for x in current}; clean = []
            try:
                for x in raw_items:
                    if x.get("id") in old: clean.append(kc.sanitize_channel(x, old[x.get("id")]))
            except (ValueError, TypeError) as e:
                abort(400, description=str(e))
            root["channels"] = clean
            base = str(b.get("publicBaseUrl") or "").strip().rstrip("/")
            if base and not re.fullmatch(r"https://[A-Za-z0-9.-]+(?::\d+)?(?:/[A-Za-z0-9._~!$&'()*+,;=:@%-]*)*", base):
                abort(400, description="공개 주소는 HTTPS 도메인으로 입력해 주세요")
            root["publicBaseUrl"] = base
        save_config(cfg)
        return kakao_channels_get()

    @app.post("/api/kakao/test/<cid>")
    def kakao_test(cid):
        from . import kakao_channel as kc
        ch = next((x for x in kc.channels() if x.get("id") == cid), None)
        if not ch: abort(404, description="카카오 채널을 찾을 수 없어요")
        utterance = str((request.get_json(silent=True) or {}).get("utterance") or "테스트 문의")[:1000]
        return jsonify({"ok": True, "response": kc.handle(ch, {"userRequest": {"utterance": utterance, "user": {"id": "dashboard-test"}}})})

    @app.post("/api/kakao/token/<cid>")
    def kakao_token(cid):
        from . import kakao_channel as kc
        if not any(x.get("id") == cid for x in kc.channels()): abort(404, description="카카오 채널을 찾을 수 없어요")
        token = pysecrets.token_urlsafe(32)
        secure.set_many({kc.token_key(cid): token})
        return jsonify({"ok": True, "token": token, "header": kc.TOKEN_HEADER})

    @app.post("/api/kakao/skill/<cid>")
    def kakao_skill(cid):
        from . import kakao_channel as kc
        ch = next((x for x in kc.channels() if x.get("id") == cid), None)
        if not ch or not ch.get("enabled"): abort(404)
        expected = secure.get(kc.token_key(cid))
        supplied = request.headers.get(kc.TOKEN_HEADER, "")
        if not expected or not supplied or not hmac.compare_digest(expected, supplied): abort(403)
        if not request.is_json: abort(415, description="JSON 요청만 지원합니다")
        try:
            return jsonify(kc.handle(ch, request.get_json(force=True)))
        except ValueError as e:
            abort(400, description=str(e))

    # ---------- KakaoTalk PC group auto-replies (local OCR/UI automation) ----------
    @app.get("/api/kakao-auto/status")
    def kakao_auto_status():
        from .kakao_auto_reply import manager as km
        account_id = request.args.get("accountId") or None
        try:
            return jsonify({"ok": True, "settings": km.settings(account_id), "status": km.status(),
                            "sendStatus": km.send_status(), **km.accounts()})
        except ValueError as e:
            abort(400, description=str(e))

    @app.post("/api/kakao-auto/accounts")
    def kakao_auto_accounts_save():
        from . import kakao_profiles
        from .kakao_auto_reply import manager as km
        body = request.get_json(force=True) or {}
        try:
            if body.get("action") == "add":
                account = kakao_profiles.create_account(body.get("label"))
                return jsonify({"ok": True, "account": account, **km.accounts()})
            if body.get("action") == "delete":
                return jsonify({"ok": True, **km.delete_account(body.get("accountId"))})
            abort(400, description="계정 추가 또는 삭제 작업을 선택해 주세요")
        except ValueError as e:
            abort(400, description=str(e))

    @app.post("/api/kakao-auto/accounts/bind")
    def kakao_auto_accounts_bind():
        from .kakao_auto_reply import manager as km
        try:
            return jsonify({"ok": True, **km.bind_account((request.get_json(force=True) or {}).get("accountId"))})
        except (ValueError, RuntimeError) as e:
            abort(400, description=str(e))

    @app.post("/api/kakao-auto/dock")
    def kakao_auto_dock():
        from .kakao_auto_reply import manager as km
        try:
            window = km.dock()
            return jsonify({"ok": True, "window": {"title": window["title"],
                         "width": window["width"], "height": window["height"]}, "status": km.status()})
        except RuntimeError as e:
            abort(400, description=str(e))

    @app.post("/api/kakao-auto/scan")
    def kakao_auto_scan():
        from .kakao_auto_reply import manager as km
        account_id = (request.get_json(force=True) or {}).get("accountId")
        try:
            rooms = km.scan_rooms(account_id)
            return jsonify({"ok": True, "rooms": rooms, "settings": km.settings(account_id), "status": km.status()})
        except Exception as e:
            if str(e) != "채팅방 읽기가 중지됐어요":
                km.fail(str(e))
            abort(400, description=f"카카오톡 채팅방을 읽지 못했어요: {type(e).__name__}: {str(e)[:180]}")

    @app.post("/api/kakao-auto/settings")
    def kakao_auto_settings():
        from .kakao_auto_reply import manager as km
        try:
            body = request.get_json(force=True) or {}
            saved = km.save_settings(body, body.get("accountId"))
            return jsonify({"ok": True, "settings": saved})
        except ValueError as e:
            abort(400, description=str(e))

    @app.post("/api/kakao-auto/start")
    def kakao_auto_start():
        from .kakao_auto_reply import manager as km
        try:
            return jsonify({"ok": True, "status": km.start((request.get_json(force=True) or {}).get("accountId"))})
        except (ValueError, ImportError, RuntimeError) as e:
            abort(400, description=f"자동응답을 시작하지 못했어요: {str(e)[:180]}")

    @app.post("/api/kakao-auto/stop")
    def kakao_auto_stop():
        from .kakao_auto_reply import manager as km
        result = km.stop_all()
        return jsonify({"ok": True, "status": result["reply"], "sendStatus": result["send"]})

    @app.post("/api/kakao-auto/send")
    def kakao_auto_send():
        from .kakao_auto_reply import manager as km
        body = request.get_json(force=True) or {}
        try:
            return jsonify({"ok": True, "sendStatus": km.start_send(body.get("accountId"),
                            body.get("roomNames"), body.get("message"), body.get("options"))})
        except (ValueError, RuntimeError) as e:
            abort(400, description=str(e))

    @app.get("/api/kakao-auto/send/status")
    def kakao_auto_send_status():
        from .kakao_auto_reply import manager as km
        return jsonify({"ok": True, "sendStatus": km.send_status()})

    @app.post("/api/kakao-auto/send/stop")
    def kakao_auto_send_stop():
        from .kakao_auto_reply import manager as km
        return jsonify({"ok": True, "sendStatus": km.stop_send()})

    @app.post("/api/kakao-auto/send/resume")
    def kakao_auto_send_resume():
        from .kakao_auto_reply import manager as km
        try:
            return jsonify({"ok": True, "sendStatus": km.resume_send((request.get_json(force=True) or {}).get("accountId"))})
        except (ValueError, RuntimeError) as e:
            abort(400, description=str(e))

    @app.post("/api/kakao-auto/send/cancel")
    def kakao_auto_send_cancel():
        from .kakao_auto_reply import manager as km
        return jsonify({"ok": True, "sendStatus": km.cancel_send()})

    @app.post("/api/kakao-auto/send/resolve")
    def kakao_auto_send_resolve():
        from .kakao_auto_reply import manager as km
        body = request.get_json(force=True) or {}
        try:
            return jsonify({"ok": True, "sendStatus": km.resolve_send_item(body.get("index"), body.get("outcome"))})
        except (ValueError, TypeError) as e:
            abort(400, description=str(e))

    # ---------- Telegram: opt-in group event replies ----------
    @app.get("/api/telegram/api-wizard/status")
    def telegram_api_wizard_status():
        from .telegram_api_wizard import wizard
        return jsonify({"ok": True, **wizard.status()})

    @app.post("/api/telegram/api-wizard/start")
    def telegram_api_wizard_start():
        from .telegram_api_wizard import wizard
        return jsonify({"ok": True, **wizard.start()})

    @app.post("/api/telegram/api-wizard/capture")
    def telegram_api_wizard_capture():
        from .telegram_api_wizard import wizard
        result = wizard.capture()
        if not result.get("ok"): abort(400, description=result.get("message"))
        return jsonify(result)

    @app.post("/api/telegram/api-wizard/cancel")
    def telegram_api_wizard_cancel():
        from .telegram_api_wizard import wizard
        return jsonify(wizard.cancel())

    @app.get("/api/telegram/status")
    def telegram_status():
        from .telegram_reply import manager as tm, _accounts
        secrets = secure.all_values()
        out = []
        for a in _accounts():
            status = tm.status().get(a["id"], {"connected": False, "text": "연결 안 됨"})
            hint = str(a.get("phoneHint") or str(a.get("phone") or "")[-4:])
            out.append({**a, "phone": ("••••" + hint) if hint else "", "status": status})
        return jsonify({"ok": True, "hasCredentials": bool(secrets.get("TG_API_ID") and secrets.get("TG_API_HASH")),
                        "apiId": secrets.get("TG_API_ID", ""), "accounts": out})

    @app.post("/api/telegram/login/start")
    def telegram_login_start():
        from .telegram_reply import manager as tm
        b = request.get_json(force=True) or {}
        api_id = str(b.get("apiId") or secure.get("TG_API_ID") or "").strip()
        api_hash = str(b.get("apiHash") or secure.get("TG_API_HASH") or "").strip()
        phone = str(b.get("phone") or "").strip()
        label = str(b.get("label") or "텔레그램 계정").strip()[:60]
        if not api_id.isdigit() or not re.fullmatch(r"[a-fA-F0-9]{32}", api_hash):
            abort(400, description="Telegram API ID와 32자리 API Hash를 입력해 주세요")
        if not re.fullmatch(r"\+[1-9][0-9]{7,14}", phone):
            abort(400, description="전화번호를 국가번호 포함 형식으로 입력해 주세요 (예: +821012345678)")
        secure.set_many({"TG_API_ID": api_id, "TG_API_HASH": api_hash})
        try:
            return jsonify(tm.begin_login(label, phone, int(api_id), api_hash))
        except ImportError:
            abort(400, description="Telethon이 설치되지 않았어요. 프로그램 업데이트 후 다시 시도해 주세요")
        except Exception as e:
            abort(400, description=f"인증 코드 요청 실패: {type(e).__name__}: {str(e)[:120]}")

    @app.post("/api/telegram/login/finish")
    def telegram_login_finish():
        from .telegram_reply import manager as tm
        b = request.get_json(force=True) or {}
        aid = str(b.get("accountId") or "")
        if not re.fullmatch(r"[a-f0-9]{12}", aid):
            abort(400, description="계정 로그인 요청이 유효하지 않아요")
        try:
            return jsonify(tm.finish_login(aid, str(b.get("code") or "").strip(),
                                           str(b.get("password") or "")))
        except Exception as e:
            abort(400, description=f"로그인 확인 실패: {type(e).__name__}: {str(e)[:120]}")

    @app.post("/api/telegram/accounts/<aid>/groups")
    def telegram_groups(aid):
        from .telegram_reply import manager as tm, _accounts
        if aid not in {a.get("id") for a in _accounts()}:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        try:
            groups = tm.list_groups(aid)
            return jsonify({"ok": True, "groups": groups})
        except Exception as e:
            abort(400, description=f"그룹 목록을 불러오지 못했어요: {type(e).__name__}: {str(e)[:120]}")

    @app.post("/api/telegram/accounts/<aid>/addresses")
    def telegram_addresses(aid):
        from .telegram_reply import manager as tm, _accounts
        if aid not in {a.get("id") for a in _accounts()}:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        try:
            return jsonify(tm.list_chat_addresses(aid))
        except ValueError as exc:
            abort(400, description=str(exc))
        except Exception as exc:
            abort(503, description=f"채널·그룹 주소를 읽지 못했어요: {type(exc).__name__}")

    @app.post("/api/telegram/accounts/<aid>/scan")
    def telegram_scan(aid):
        from .telegram_reply import manager as tm, _accounts
        if aid not in {a.get("id") for a in _accounts()}:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        b = request.get_json(force=True) or {}
        try:
            return jsonify(tm.scan_chat_references(aid, b.get("messagesPerChat", 50), b.get("maxChats", 200)))
        except (ValueError, TypeError) as exc:
            abort(400, description=str(exc))
        except Exception as exc:
            abort(503, description=f"대화 기록을 읽지 못했어요: {type(exc).__name__}")

    @app.post("/api/telegram/accounts/<aid>/recurring/targets")
    def telegram_recurring_targets(aid):
        from .telegram_reply import manager as tm, _accounts
        if aid not in {a.get("id") for a in _accounts()}:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        try:
            return jsonify(tm.recurring_targets(aid))
        except ValueError as exc:
            abort(400, description=str(exc))
        except Exception as exc:
            abort(503, description=f"대화방 목록을 읽지 못했어요: {type(exc).__name__}")

    @app.get("/api/telegram/accounts/<aid>/recurring/status")
    def telegram_recurring_status(aid):
        from .telegram_reply import manager as tm, _accounts
        acc = next((a for a in _accounts() if a.get("id") == aid), None)
        if not acc:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        result = tm.recurring_status(aid)
        result["settings"] = acc.get("recurring") or {}
        return jsonify(result)

    @app.post("/api/telegram/accounts/<aid>/recurring/start")
    def telegram_recurring_start(aid):
        from .telegram_reply import manager as tm
        cfg = load_config()
        acc = next((a for a in (cfg.get("telegram") or {}).get("accounts") or [] if a.get("id") == aid), None)
        if not acc:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        b = request.get_json(force=True) or {}
        if not isinstance(b, dict):
            abort(400, description="입력 형식이 올바르지 않아요")
        targets, body = b.get("targetIds"), b.get("text")
        mode = str(b.get("formatMode") or "plain")
        values = acc.get("templateValues") or {}
        try:
            result = tm.recurring_start(aid, targets, body, b.get("hours", 0),
                                        b.get("minutes", 0), b.get("seconds", 0), mode, values)
        except ValueError as exc:
            abort(400, description=str(exc))
        except Exception as exc:
            abort(503, description=f"주기 발송을 시작하지 못했어요: {type(exc).__name__}")
        acc["recurring"] = {"targetIds": [str(x) for x in targets], "text": body,
                            "hours": int(b.get("hours", 0)), "minutes": int(b.get("minutes", 0)),
                            "seconds": int(b.get("seconds", 0)), "formatMode": mode}
        save_config(cfg)
        return jsonify(result)

    @app.post("/api/telegram/accounts/<aid>/recurring/stop")
    def telegram_recurring_stop(aid):
        from .telegram_reply import manager as tm, _accounts
        if aid not in {a.get("id") for a in _accounts()}:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        return jsonify(tm.recurring_stop(aid))

    def telegram_join_manager(aid):
        from .telegram_reply import manager as tm, _accounts
        if aid not in {a.get("id") for a in _accounts()}:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        return tm

    def telegram_join_action(aid, action):
        tm = telegram_join_manager(aid)
        body = request.get_json(force=True) or {}
        if not isinstance(body, dict):
            abort(400, description="입력 형식이 올바르지 않아요")
        try:
            if action in ("start", "save"):
                links = body.get("links", "")
                fn = tm.join_chats if action == "start" else tm.save_join_list
                return jsonify(fn(aid, links, body.get("intervalSeconds", 30)))
            fn = tm.pause_join if action == "pause" else tm.resume_join
            return jsonify(fn(aid))
        except ValueError as e:
            abort(400, description=str(e))
        except Exception:
            abort(503, description="입장 작업에 연결하지 못했어요. 계정 연결과 데이터 폴더를 확인해 주세요")

    @app.post("/api/telegram/accounts/<aid>/join")
    def telegram_join_chats(aid):
        return telegram_join_action(aid, "start")

    @app.post("/api/telegram/accounts/<aid>/join/save")
    def telegram_join_save(aid):
        return telegram_join_action(aid, "save")

    @app.post("/api/telegram/accounts/<aid>/join/pause")
    def telegram_join_pause(aid):
        return telegram_join_action(aid, "pause")

    @app.post("/api/telegram/accounts/<aid>/join/resume")
    def telegram_join_resume(aid):
        return telegram_join_action(aid, "resume")

    @app.get("/api/telegram/accounts/<aid>/join/status")
    def telegram_join_status(aid):
        tm = telegram_join_manager(aid)
        try:
            return jsonify(tm.join_status(aid, include_links=request.args.get("includeLinks") == "1"))
        except Exception:
            abort(503, description="입장 기록을 불러오지 못했어요. 잠시 후 다시 확인해 주세요")

    @app.post("/api/telegram/accounts/<aid>/private/recipients")
    def telegram_private_recipients(aid):
        tm = telegram_join_manager(aid)
        try:
            return jsonify(tm.private_recipients(aid))
        except ValueError as e:
            abort(400, description=str(e))
        except Exception:
            abort(503, description="텔레그램 대화·연락처를 불러오지 못했어요. 계정 연결을 확인해 주세요")

    @app.post("/api/telegram/accounts/<aid>/private/send")
    def telegram_private_send(aid):
        tm = telegram_join_manager(aid)
        b = request.get_json(force=True) or {}
        if not isinstance(b, dict):
            abort(400, description="입력 형식이 올바르지 않아요")
        try:
            return jsonify(tm.private_send(aid, b.get("userIds"), b.get("text")))
        except ValueError as e:
            abort(400, description=str(e))
        except Exception:
            abort(503, description="메시지 보내기를 시작하지 못했어요. 계정 연결을 확인해 주세요")

    @app.get("/api/telegram/accounts/<aid>/private/send/status")
    def telegram_private_send_status(aid):
        tm = telegram_join_manager(aid)
        return jsonify(tm.private_send_status(aid))

    @app.post("/api/telegram/accounts/<aid>/private/send/stop")
    def telegram_private_send_stop(aid):
        tm = telegram_join_manager(aid)
        return jsonify(tm.private_send_stop(aid))

    @app.post("/api/telegram/accounts/<aid>/private/settings")
    def telegram_private_settings(aid):
        cfg = load_config()
        accounts = (cfg.get("telegram") or {}).get("accounts") or []
        acc = next((a for a in accounts if a.get("id") == aid), None)
        if not acc:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        b = request.get_json(force=True) or {}
        if not isinstance(b, dict):
            abort(400, description="입력 형식이 올바르지 않아요")
        raw_text = b.get("text")
        if not isinstance(raw_text, str) or len(raw_text) > 1000:
            abort(400, description="개인 자동응답 문구는 1,000자 이하로 입력해 주세요")
        enabled = bool(b.get("enabled"))
        if enabled and not raw_text.strip():
            abort(400, description="개인 자동응답을 켜려면 문구를 입력해 주세요")
        try:
            value = int(b.get("cooldownValue", 3))
            unit = str(b.get("cooldownUnit") or "minutes")
            limits = {"seconds": 86400, "minutes": 1440, "hours": 24}
            if not 0 <= value <= limits[unit]:
                raise ValueError()
        except (KeyError, TypeError, ValueError):
            abort(400, description="개인 자동응답 대기시간을 확인해 주세요")
        acc.update(replyPrivate=enabled, privateReplyText=raw_text.strip(),
                   privateCooldownValue=value, privateCooldownUnit=unit)
        format_mode = str(b.get("formatMode") or acc.get("privateFormatMode") or "plain")
        if format_mode not in ("plain", "html", "markdownv2"):
            abort(400, description="텔레그램 서식 선택이 올바르지 않아요")
        acc["privateFormatMode"] = format_mode
        values = b.get("templateValues", acc.get("templateValues") or {})
        if not isinstance(values, dict) or len(values) > 30 or any(
                not re.fullmatch(r"[A-Za-z0-9_가-힣]{1,32}", str(key)) or len(str(value)) > 300
                for key, value in values.items()):
            abort(400, description="키워드는 최대 30개, 값은 300자 이하로 입력해 주세요")
        acc["templateValues"] = {str(key): str(value) for key, value in values.items()}
        save_config(cfg)
        return jsonify({"ok": True})

    @app.post("/api/telegram/accounts/<aid>/settings")
    def telegram_account_settings(aid):
        from .telegram_reply import manager as tm
        cfg, b = load_config(), request.get_json(force=True) or {}
        accounts = (cfg.get("telegram") or {}).get("accounts") or []
        acc = next((a for a in accounts if a.get("id") == aid), None)
        if not acc:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        valid = {g["id"]: g for g in tm.list_groups(aid)}
        groups = []
        for x in b.get("groups") or []:
            gid = str(x.get("id") or "")
            if gid in valid:
                groups.append({"id": gid, "title": valid[gid]["title"], "enabled": bool(x.get("enabled"))})
        acc["groups"] = groups
        acc["replyText"] = str(b.get("replyText") or "")[:1000]
        acc["replyEmoji"] = str(b.get("replyEmoji") or "")[:80]
        format_mode = str(b.get("formatMode") or acc.get("formatMode") or "plain")
        if format_mode not in ("plain", "html", "markdownv2"):
            abort(400, description="텔레그램 서식 선택이 올바르지 않아요")
        acc["formatMode"] = format_mode
        values = b.get("templateValues", acc.get("templateValues") or {})
        if not isinstance(values, dict) or len(values) > 30 or any(
                not re.fullmatch(r"[A-Za-z0-9_가-힣]{1,32}", str(key)) or len(str(value)) > 300
                for key, value in values.items()):
            abort(400, description="키워드는 최대 30개, 값은 300자 이하로 입력해 주세요")
        acc["templateValues"] = {str(key): str(value) for key, value in values.items()}
        if "replyPrivate" in b:
            acc["replyPrivate"] = bool(b.get("replyPrivate"))
        acc["dedupeIncoming"] = bool(b.get("dedupeIncoming", True))
        mode = str(b.get("replyMode") or "new_message")
        acc["replyMode"] = mode if mode in ("new_message", "quote_reply") else "new_message"
        try:
            acc["maxRepliesPerMinute"] = max(1, min(20, int(b.get("maxRepliesPerMinute", 6))))
            acc["minReplyIntervalSeconds"] = max(1, min(60, int(b.get("minReplyIntervalSeconds", 3))))
            for kind in ("group", "private"):
                if kind == "private" and f"{kind}CooldownValue" not in b:
                    continue
                unit = str(b.get(f"{kind}CooldownUnit") or "minutes")
                if unit not in ("seconds", "minutes", "hours"):
                    raise ValueError("지원하지 않는 시간 단위")
                value = max(0, int(b.get(f"{kind}CooldownValue", 3)))
                limit = {"seconds": 86400, "minutes": 1440, "hours": 24}[unit]
                acc[f"{kind}CooldownValue"] = min(limit, value)
                acc[f"{kind}CooldownUnit"] = unit
            acc.pop("groupCooldownMinutes", None)
            acc.pop("privateCooldownMinutes", None)
            acc.pop("groupCooldownSeconds", None)
            acc.pop("privateCooldownSeconds", None)
        except (TypeError, ValueError):
            abort(400, description="대기시간 숫자와 초/분/시간 단위를 확인해 주세요")
        image = str(b.get("replyImage") or "")
        if image and not re.fullmatch(r"[a-f0-9]{32}\.(png|jpe?g|webp|gif)", image, re.I):
            abort(400, description="이미지 파일 선택을 다시 해 주세요")
        acc["replyImage"] = image
        if "enabled" in b:
            acc["enabled"] = bool(b["enabled"])
        if acc.get("enabled") and (not any(group["enabled"] for group in groups)
                                    or not (acc["replyText"].strip() or acc["replyEmoji"].strip() or image)):
            acc["enabled"] = False
        save_config(cfg)
        return jsonify({"ok": True, "enabled": bool(acc.get("enabled"))})

    @app.post("/api/telegram/accounts/<aid>/reply/start")
    def telegram_group_reply_start(aid):
        from .telegram_reply import manager as tm
        cfg = load_config()
        acc = next((a for a in (cfg.get("telegram") or {}).get("accounts") or [] if a.get("id") == aid), None)
        if not acc:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        if not any(group.get("enabled") for group in acc.get("groups") or []):
            abort(400, description="응답할 그룹을 선택하고 설정을 저장해 주세요")
        if not (str(acc.get("replyText") or "").strip() or str(acc.get("replyEmoji") or "").strip()
                or acc.get("replyImage")):
            abort(400, description="자동응답 문구 또는 이미지를 저장해 주세요")
        client = tm.clients.get(aid)
        if not client or not client.is_connected() or aid not in tm.handlers:
            abort(503, description="텔레그램 계정 연결을 확인해 주세요")
        acc["enabled"] = True
        save_config(cfg)
        return jsonify({"ok": True, "enabled": True})

    @app.post("/api/telegram/accounts/<aid>/reply/stop")
    def telegram_group_reply_stop(aid):
        cfg = load_config()
        acc = next((a for a in (cfg.get("telegram") or {}).get("accounts") or [] if a.get("id") == aid), None)
        if not acc:
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        acc["enabled"] = False
        save_config(cfg)
        return jsonify({"ok": True, "enabled": False})

    @app.post("/api/telegram/media")
    def telegram_media_upload():
        import secrets as rand
        from werkzeug.utils import secure_filename
        f = request.files.get("file")
        if not f or not f.filename:
            abort(400, description="이미지 파일을 골라 주세요")
        name = secure_filename(f.filename)
        ext = os.path.splitext(name)[1].lower()
        if ext not in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
            abort(400, description="PNG, JPG, WEBP, GIF 이미지 파일만 올릴 수 있어요")
        data = f.read(8 * 1024 * 1024 + 1)
        if len(data) > 8 * 1024 * 1024:
            abort(413, description="이미지는 8MB 이하로 올려 주세요")
        if not data:
            abort(400, description="빈 파일은 올릴 수 없어요")
        try:
            import io
            from PIL import Image
            with Image.open(io.BytesIO(data)) as image:
                if image.format not in ("PNG", "JPEG", "WEBP", "GIF"):
                    raise ValueError("지원하지 않는 이미지 형식")
                image.verify()
        except Exception:
            abort(400, description="파일 내용을 읽을 수 있는 PNG/JPG/WEBP/GIF 이미지인지 확인해 주세요")
        from . import telegram_reply as tr
        folder = os.path.join(tr._data_dir(), "telegram_media")
        os.makedirs(folder, exist_ok=True)
        filename = rand.token_hex(16) + ext
        with open(os.path.join(folder, filename), "wb") as dst:
            dst.write(data)
        return jsonify({"ok": True, "file": filename, "name": name})

    @app.post("/api/telegram/accounts/<aid>/delete")
    def telegram_account_delete(aid):
        from .telegram_reply import manager as tm
        cfg = load_config()
        tg = cfg.setdefault("telegram", {})
        accs = tg.get("accounts") or []
        if not any(a.get("id") == aid for a in accs):
            abort(404, description="텔레그램 계정을 찾을 수 없어요")
        tm.remove_account(aid)
        tg["accounts"] = [a for a in accs if a.get("id") != aid]
        save_config(cfg)
        secure.set_many({f"TG_SESSION__{aid}": None})
        return jsonify({"ok": True})

    @app.post("/api/config/<section>")
    def config_save(section):
        cfg, b = load_config(), request.get_json(force=True) or {}
        if section == "prompts":
            ps = []
            for i, x in enumerate(b.get("prompts") or []):
                pid = re.sub(r"[^a-z0-9_\-]", "", str(x.get("id") or f"p{i}").lower())[:30] or f"p{i}"
                if str(x.get("text") or "").strip():
                    ps.append({"id": pid, "name": str(x.get("name") or pid)[:60], "text": str(x["text"])[:4000]})
            if not ps:
                abort(400, description="프롬프트를 하나 이상 남겨 주세요")
            cfg["prompts"] = ps
            ids = {p["id"] for p in ps}
            cfg["defaultPrompt"] = b.get("defaultPrompt") if b.get("defaultPrompt") in ids else ps[0]["id"]
            cfg["promptByChannel"] = {k: v for k, v in (b.get("promptByChannel") or {}).items() if k in (*CHANNELS, "daily") and v in ids}
            cfg["promptExtra"] = str(b.get("promptExtra") or "")[:2000]
            cfg["promptsRemoved"] = [d["id"] for d in g.DEFAULT_PROMPTS if d["id"] not in ids]
        elif section == "marketing":
            blocks_ = []
            for i, x in enumerate(b.get("blocks") or []):
                btns = [{"label": str(y.get("label", ""))[:40], "url": str(y.get("url", "")).strip()[:300]} for y in (x.get("buttons") or [])
                        if re.match(r"^(https?://|tel:)", str(y.get("url", "")).strip(), re.I)][:5]
                blocks_.append({"id": re.sub(r"[^A-Za-z0-9_\-]", "", str(x.get("id") or f"b{i}"))[:30] or f"b{i}", "name": str(x.get("name", ""))[:60],
                                "text": str(x.get("text", ""))[:600], "buttons": btns})
            from . import blocks as _bl
            m = cfg.setdefault("marketing", {})
            if "blocks" in b:
                m["blocks"] = blocks_[:30]
                ids_ = {x["id"] for x in blocks_}
                m["blocksRemoved"] = [d["id"] for d in _bl.default_blocks(cfg["shop"]) if d["id"] not in ids_]
            if "topicBlocks" in b:
                valid = {x["id"] for x in _bl.all_blocks(cfg)} | {""}
                m["topicBlocks"] = {str(k)[:30]: v for k, v in (b.get("topicBlocks") or {}).items() if v in valid}
            if "campaigns" in b:
                cs = []
                for i, x in enumerate(b.get("campaigns") or []):
                    st_, en_ = str(x.get("start", "")).strip(), str(x.get("end", "")).strip()
                    if not (re.fullmatch(r"(\d{4}-)?\d{2}-\d{2}", st_) and re.fullmatch(r"(\d{4}-)?\d{2}-\d{2}", en_)):
                        abort(400, description=f"시즌 '{x.get('name', '')}': 날짜는 MM-DD 또는 YYYY-MM-DD 로 넣어 주세요")
                    cs.append({"id": re.sub(r"[^A-Za-z0-9_\-]", "", str(x.get("id") or f"c{i}"))[:30] or f"c{i}", "name": str(x.get("name", ""))[:40],
                               "start": st_, "end": en_, "theme": str(x.get("theme", ""))[:400], "enabled": bool(x.get("enabled", True)),
                               "keywords": [k.strip()[:40] for k in re.split(r"[,\n]", str(x.get("keywords", "") if not isinstance(x.get("keywords"), list) else ",".join(x["keywords"]))) if k.strip()][:15]})
                m["campaigns"] = cs[:30]
        elif section == "ci":
            c = cfg.setdefault("ci", {})
            if "enabled" in b:
                c["enabled"] = bool(b["enabled"])
            if b.get("position") in ("top", "bottom"):
                c["position"] = b["position"]
            if b.get("which") in ("wide", "icon", "random"):
                c["which"] = b["which"]
        elif section == "modes":
            if "autoModes" in b:
                cfg["autoModes"] = bool(b["autoModes"])
            if isinstance(b.get("weights"), dict):
                w = {k: float(_int(v, 0, 10, "비중")) for k, v in b["weights"].items() if k in g.CONTENT_MODES}
                if w and not any(w.values()):
                    abort(400, description="글 종류 비중이 모두 0이에요 - 하나 이상은 1 이상으로")
                cfg["modeWeights"] = w
        elif section == "place":
            pc = cfg.setdefault("place", {})
            if "mapQueries" in b:
                pc["mapQueries"] = [q.strip()[:60] for q in re.split(r"[\n,]", str(b["mapQueries"])) if q.strip()][:10]
            if "mapMatch" in b:
                pc["mapMatch"] = [q.strip()[:40] for q in re.split(r"[\n,]", str(b["mapMatch"])) if q.strip()][:5] or ["시민로 386"]
            if "autoRefresh" in b:
                pc["autoRefresh"] = bool(b["autoRefresh"])
        elif section == "advanced":
            lc = cfg.setdefault("library", {})
            if "minPhotos" in b:
                lc["minPhotos"] = _int(b["minPhotos"], 0, 10, "글당 최소 사진")
            if "maxPhotos" in b:
                lc["maxPhotos"] = max(lc.get("minPhotos", 3), _int(b["maxPhotos"], 1, 10, "글당 최대 사진"))
            if "photoNoRepeatDays" in b:
                lc["noRepeatDays"] = _int(b["photoNoRepeatDays"], 0, 90, "같은 사진 쉬는 기간")
            if "keywordNoRepeatDays" in b:
                cfg["keywords"]["noRepeatDays"] = _int(b["keywordNoRepeatDays"], 0, 90, "같은 키워드 쉬는 기간")
            q = cfg.setdefault("quality", {})
            if "maxKeywordRepeats" in b:
                q["maxKeywordRepeats"] = _int(b["maxKeywordRepeats"], 2, 15, "키워드 최대 반복")
            if "maxSimilarity" in b:
                try:
                    q["maxSimilarity"] = max(0.2, min(0.9, float(b["maxSimilarity"])))
                except (TypeError, ValueError):
                    abort(400, description="유사도는 0.2~0.9 사이 숫자예요")
            br = cfg.setdefault("browser", {})
            if "headless" in b:
                br["headless"] = bool(b["headless"])
            if "slowMo" in b:
                br["slowMo"] = _int(b["slowMo"], 0, 300, "입력 속도")
            sc = cfg.setdefault("schedule", {})
            if "autoRetries" in b:
                sc["autoRetries"] = _int(b["autoRetries"], 0, 5, "자동 재시도 횟수")
            if "retryMinutes" in b:
                sc["retryMinutes"] = _int(b["retryMinutes"], 1, 120, "재시도 간격")
        else:
            abort(404)
        save_config(cfg)
        log("INFO", f"설정 저장: {section}")
        return jsonify({"ok": True, "config": _config_view(cfg)})

    @app.get("/preview/<int:jid>")
    def preview(jid):
        import html as H
        from . import images as imgmod
        t = T.get(jid)
        if not t:
            abort(404)
        body = imgmod.render_markers(t["body_html"], [dict(i, name=i.get("name")) for i in t["images"] or []], "library")
        tags = " ".join(H.escape(x) for x in (t["hashtags"] or []))
        copy_box, edit_box = "", ""
        if t["title"] and t["status"] in (T.S_HOLD, T.S_READY, T.S_REVIEW, T.S_PUB_FAIL, T.S_NEED, T.S_TEST):
            from .publishers.naver import to_plain
            txt = to_plain({"body_html": CARD_RE.sub("", t["body_html"])})
            edit_box = (f'<hr><h3>✏️ 올리기 전에 직접 고치기</h3><p style="color:#666">문단 사이는 빈 줄, 소제목은 줄 앞에 <b>## </b>, 사진 자리 <b>[[IMG:번호]]</b>는 그대로 두세요.</p>'
                        f'<input id="et" value="{H.escape(t["title"])}" style="width:100%;font-size:18px;padding:8px;box-sizing:border-box">'
                        f'<textarea id="eb" style="width:100%;min-height:420px;font:inherit;margin-top:8px;box-sizing:border-box">{H.escape(txt)}</textarea>'
                        f'<p><button id="es" style="font-size:16px;padding:10px 18px">💾 고친 내용 저장</button> <span id="em"></span></p>'
                        f'<script>document.getElementById("es").onclick=async()=>{{const r=await fetch("/api/jobs/{jid}/edit",{{method:"POST",headers:{{"Content-Type":"application/json","X-CSRF-Token":"{csrf}"}},'
                        f'body:JSON.stringify({{title:document.getElementById("et").value,text:document.getElementById("eb").value}})}});const j=await r.json().catch(()=>({{}}));'
                        f'document.getElementById("em").textContent=r.ok?(j.warning||"저장했어요 ✓ (새로 고침하면 반영된 미리보기)"):(j.error||"저장 실패")}}</script>')
        if t["channel"] in ("threads", "facebook", "band", "manual") and t["title"]:
            from .publishers import social
            txt = social.text_for(t["channel"], {k: t[k] for k in ("title", "body_html", "caption", "hashtags")}, load_config())
            copy_box = (f'<h3>올라갈 글 그대로</h3><textarea id="cp" readonly style="width:100%;min-height:260px;font:inherit">{H.escape(txt)}</textarea>'
                        '<p><button onclick="const t=document.getElementById(\'cp\');t.select();navigator.clipboard.writeText(t.value).then(()=>this.textContent=\'복사했어요 ✓\')" '
                        'style="font-size:16px;padding:10px 18px">📋 글 복사하기</button>'
                        + (' <span style="color:#666">사진은 위 사진을 길게 눌러 저장해서 같이 올리세요</span>' if t["channel"] == "manual" else "") + "</p>")
        page = f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>미리보기 #{jid}</title><style>body{{max-width:760px;margin:auto;padding:16px;font-family:'Malgun Gothic',sans-serif;line-height:1.8;color:#222}}
img{{max-width:100%}}.meta{{color:#666;font-size:13px;background:#f6f6f6;padding:10px;border-radius:8px}}</style></head><body>
<div class="meta">{H.escape(CH_NAME.get(t['channel'], ''))} · {H.escape(t['account_label'] or '')} · 상태 {H.escape(t['status'])} · 키워드 {H.escape(t['keyword'] or '')}
{('<br>오류: ' + H.escape(t['error'])) if t['error'] else ''}</div><h1>{H.escape(t['title'] or '(아직 글 없음)')}</h1>{body}
{('<h3>' + ('X 글' if t['channel'] == 'x' else '인스타 캡션') + '</h3><p style="white-space:pre-wrap">' + H.escape(t['caption']) + '</p>') if t['channel'] in ('instagram', 'x') else ''}
<p style="color:#888">{tags}</p>{copy_box}{edit_box}</body></html>"""
        return Response(page, mimetype="text/html")

    @app.post("/api/jobs/<int:jid>/edit")
    def job_edit(jid):
        import html as H
        from .compliance import check_text
        t = T.get(jid)
        if not t or t["status"] not in (T.S_HOLD, T.S_READY, T.S_REVIEW, T.S_PUB_FAIL, T.S_NEED, T.S_TEST):
            abort(400, description="지금은 고칠 수 없는 작업이에요 (발행 중이거나 이미 올라감)")
        b = request.get_json(force=True) or {}
        title = re.sub(r"\s+", " ", str(b.get("title") or "")).strip()[:100]
        text = str(b.get("text") or "").replace("\r\n", "\n")[:20000]
        if len(title) < 2 or len(text.strip()) < 10:
            abort(400, description="제목과 본문을 채워 주세요")
        parts = []
        for block in re.split(r"\n\s*\n", text):
            for line in block.split("\n"):
                line = line.strip()
                if not line:
                    continue
                if re.fullmatch(r"\[\[IMG:\d+\]\]", line):
                    parts.append(line)
                elif line.startswith("## "):
                    parts.append(f"<h2>{H.escape(line[3:])}</h2>")
                else:
                    esc = H.escape(line, quote=False)
                    if t["channel"] in ("tistory", "wonju"):
                        esc = re.sub(r"(https?://[^\s<]+)", lambda m: f'<a href="{m.group(1)}">{m.group(1)}</a>', esc)
                    parts.append(f"<p>{esc}</p>")
        card = CARD_RE.search(t["body_html"] or "")
        body = (card.group(0) if card else "") + g.sanitize_html("".join(parts))
        visit = (((t["settings"] or {}).get("daily") or {}).get("kind") or "") in g.PERSONAL_KINDS
        issues = [i for i in check_text(title + " " + g.strip_html(body)) if i.startswith("[") and not (visit and i in g.VISIT_OK)]
        st = t["status"]
        if issues:
            st = T.S_REVIEW
        elif st == T.S_REVIEW:
            st = T.S_HOLD
        T.update(jid, title=title, body_html=body, status=st, error="; ".join(issues))
        log("INFO", f"[작업 {jid}] 사장님이 글을 직접 고침" + (f" (확인 필요: {'; '.join(issues)})" if issues else ""))
        return jsonify({"ok": True, "status": st, "warning": ("고친 글에 문제가 있어 '검토 필요'로 두었어요: " + "; ".join(issues)) if issues else ""})

    @app.get("/shot/<int:jid>")
    def job_shot(jid):
        t = T.get(jid)
        if not t or not t["shot"]:
            abort(404)
        d = os.path.join(g.ROOT, "logs", "screens")
        p = os.path.realpath(t["shot"])
        if not p.startswith(os.path.realpath(d)) or not os.path.exists(p):
            abort(404)
        return send_from_directory(d, os.path.basename(p))

    # ---------- 키워드 ----------
    @app.get("/api/keywords")
    def keywords():
        cfg = load_config()
        kws, src = g.keyword_pool(cfg)
        return jsonify({"items": [{"keyword": k["keyword"], "group": k["group"]} for k in kws],
                        "selected": cfg["keywords"].get("selected", []), "custom": cfg["keywords"].get("custom", [])})

    @app.post("/api/keywords/suggest")
    def keywords_suggest():
        try:
            return jsonify({"ok": True, "items": g.suggest_keywords(load_config())})
        except Exception as e:  # noqa: BLE001
            abort(400, description=f"키워드 아이디어를 만들지 못했어요: {str(e)[:150]}")

    @app.post("/api/keywords")
    def keywords_save():
        cfg, b = load_config(), request.get_json(force=True) or {}
        kc = cfg["keywords"]
        kc.setdefault("custom", [])
        if "selected" in b and isinstance(b["selected"], list):
            kc["selected"] = list(dict.fromkeys(str(x).strip()[:60] for x in b["selected"] if str(x).strip()))[:500]
        for k in re.split(r"[,\n]", str(b.get("add") or "")):
            k = k.strip()[:60]
            if k and k not in kc["custom"]:
                kc["custom"].append(k)
                kc["selected"] = list(dict.fromkeys(kc.get("selected", []) + [k]))
        if b.get("remove"):
            kc["custom"] = [c for c in kc["custom"] if c != b["remove"]]
            kc["selected"] = [c for c in kc.get("selected", []) if c != b["remove"]]
        save_config(cfg)
        return jsonify({"ok": True, "selected": len(kc.get("selected", []))})

    # ---------- 자료함 ----------
    def _pub(p):
        return {k: v for k, v in p.items() if k not in ("path", "sha")}

    def labeler():
        while True:
            pid = label_q.get()
            try:
                lib.relabel(pid, load_config())
            except Exception as e:  # noqa: BLE001
                log("WARN", f"[자료함] 라벨 실패 {pid}: {e}")
            finally:
                label_state["pending"] = max(0, label_state["pending"] - 1)
    threading.Thread(target=labeler, daemon=True, name="labeler").start()

    @app.post("/api/ci/upload")
    def ci_upload():
        files = request.files.getlist("files")
        if not files:
            abort(400, description="로고 파일을 골라 주세요")
        out = []
        for f in files[:4]:
            try:
                p, _ = lib.add_photo(f.read(), f.filename, load_config(), source="ci", label=False)
                kind = "icon" if re.search(r"icon|아이콘|정사각", f.filename or "", re.I) else "wide"
                out.append(_pub(lib.mark_ci(p["id"], kind)))
            except Exception as e:  # noqa: BLE001
                abort(400, description=f"{f.filename}: {str(e)[:120]}")
        return jsonify({"ok": True, "photos": out})

    @app.post("/api/library/pull")
    def library_pull():
        kw = str((request.get_json(silent=True) or {}).get("keyword") or "")
        try:
            r = lib.pull_by_keyword(load_config(), kw)
        except ValueError as e:
            abort(400, description=str(e))
        return jsonify({"ok": True, "found": [_pub(p) for p in r["found"]], "added": [_pub(p) for p in r["added"]]})

    @app.get("/api/library")
    def library_get():
        return jsonify({"photos": [_pub(p) for p in lib.list_photos() if p.get("source") != "ci"], "summary": lib.summary(), "labels": lib.LABELS,
                        "vision": bool(llm.api_key()), "labeling": label_state["pending"]})

    @app.post("/api/library/upload")
    def library_upload():
        files = request.files.getlist("files")
        if not files:
            abort(400, description="사진을 골라 주세요")
        if len(files) > 200:
            abort(400, description="한 번에 200장까지 올릴 수 있어요")
        cfg, out = load_config(), []
        for f in files:
            try:
                p, created = lib.add_photo(f.read(), f.filename, cfg, label=False)
                out.append({"name": f.filename, "ok": True, "created": created})
                if created and llm.api_key():
                    label_state["pending"] += 1
                    label_q.put(p["id"])
            except ValueError as e:
                out.append({"name": f.filename, "ok": False, "error": str(e)})
            except Exception as e:  # noqa: BLE001 (한 장이 이상해도 나머지는 계속)
                log("WARN", f"[자료함] 사진 올리기 실패 {f.filename}: {e}")
                out.append({"name": f.filename, "ok": False, "error": f"사진을 저장하지 못했어요: {str(e)[:80]}"})
        n = sum(1 for x in out if x.get("created"))
        log("INFO", f"[자료함] 사진 {n}장 추가 (요청 {len(files)}장, 위치정보 제거)")
        return jsonify({"ok": True, "results": out, "added": n, "dup": sum(1 for x in out if x.get("ok") and not x.get("created")),
                        "labeling": label_state["pending"]})

    @app.post("/api/library/<int:pid>")
    def library_edit(pid):
        b = request.get_json(force=True) or {}
        if not lib.get_photo(pid):
            abort(404, description="사진을 찾을 수 없어요")
        labels = b.get("labels")
        if isinstance(labels, str):
            labels = [x for x in re.split(r"[,\s]+", labels) if x]
        if not isinstance(labels, list):
            abort(400, description="라벨을 입력해 주세요")
        lib.set_labels(pid, labels)
        return jsonify({"ok": True, "photo": _pub(lib.get_photo(pid))})

    @app.post("/api/library/<int:pid>/relabel")
    def library_relabel(pid):
        if not lib.get_photo(pid):
            abort(404, description="사진을 찾을 수 없어요")
        if not llm.api_key():
            abort(400, description="자동 라벨에는 Claude API 키가 필요해요")
        label_state["pending"] += 1
        label_q.put(pid)
        return jsonify({"ok": True})

    @app.post("/api/library/<int:pid>/delete")
    def library_delete(pid):
        return jsonify({"ok": lib.delete_photo(pid)})

    place_state = {"running": False, "message": ""}

    @app.post("/api/library/import-place")
    def library_import_place():
        if place_state["running"]:
            return jsonify({"ok": True, "started": False})
        cfg = load_config()
        ref = str((request.get_json(silent=True) or {}).get("place") or cfg["shop"].get("naverPlaceId") or "").strip()
        if not ref:
            abort(400, description="네이버 플레이스 주소나 번호를 넣어 주세요")

        def work():
            from . import place
            place_state.update(running=True, message="네이버 플레이스에서 가져오는 중…")
            try:
                info = place.import_place(ref, load_config(), apply=True, download=True)
                n = lib.import_place_photos(load_config())
                for p in lib.list_photos():
                    if p["source"] == "place" and p["labelSrc"] == "filename" and llm.api_key():
                        label_state["pending"] += 1
                        label_q.put(p["id"])
                place_state["message"] = f"완료: {info.get('name') or ''} 정보 반영, 메뉴 {len(info.get('menu') or [])}개, 새 사진 {n}장"
            except Exception as e:  # noqa: BLE001
                m = str(e)
                place_state["message"] = "실패: " + ("네이버가 잠시 접속을 막았어요(429). 나중에 다시 시도해 주세요" if "429" in m else redact(m)[:150])
                log("WARN", f"플레이스 가져오기 실패: {redact(m)[:200]}")
            finally:
                place_state["running"] = False
        threading.Thread(target=work, daemon=True).start()
        return jsonify({"ok": True, "started": True})

    @app.get("/api/library/import-place")
    def library_import_status():
        return jsonify(place_state)

    @app.get("/library/<name>")
    def library_file(name):
        if not re.fullmatch(r"[a-z]+-[0-9a-f]{16}\.jpg", name):
            abort(404)
        return send_from_directory(lib.lib_dir(), name, max_age=3600)

    # ---------- 가게 정보 ----------
    @app.post("/api/shop")
    def shop():
        cfg, b = load_config(), request.get_json(force=True) or {}
        for k in ("name", "address", "hours", "phone", "url", "nearby", "since"):
            if k in b:
                cfg["shop"][k] = str(b[k]).strip()[:200]
        if "naverPlaceId" in b:
            pid = re.sub(r"\D", "", str(b["naverPlaceId"]))[:15]
            cfg["shop"]["naverPlaceId"] = pid
        for k in ("menu", "neighborhood", "features"):
            if k in b:
                items = [x.strip() for x in str(b[k]).splitlines() if x.strip()][:40]
                cfg["shop"][k] = [{"name": x.split("|")[0].strip(), "price": (x.split("|")[1].strip() if "|" in x else "")} for x in items] if k == "menu" else items
        if isinstance(b.get("services"), dict):
            cfg["shop"]["services"] = {str(k)[:10]: bool(v) for k, v in b["services"].items()}
        save_config(cfg)
        log("INFO", "가게 정보 저장")
        return jsonify({"ok": True})

    # ---------- 기타 ----------
    @app.get("/api/log")
    def get_log():
        return jsonify({"log": tail_log(200)})

    @app.post("/api/browser/install")
    def install():
        return jsonify(browser.install_chromium_async())

    @app.post("/api/quit")
    def quit_():
        if on_quit:
            threading.Timer(0.5, on_quit).start()
        return jsonify({"ok": True})

    return app
