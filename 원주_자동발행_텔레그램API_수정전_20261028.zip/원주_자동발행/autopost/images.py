# -*- coding: utf-8 -*-
"""글 사진: 자료함 사진만 사용 (사장님이 올린 사진 + 네이버 플레이스의 업체 등록 사진)
- 다른 블로그·남의 사진은 수집하지 않음
- 자료함 사진은 저장할 때 EXIF(위치정보 포함)를 모두 지움
- 공개 주소(인스타·티스토리용): 원주.kr FTP(/html/photos)로 올리고 https://원주.kr/photos/파일 주소 사용
"""
import ftplib, html as H, re, urllib.parse
from . import secure


def ftp_addr(host):
    host = (host or "").strip()
    for p in ("ftp://", "http://", "https://"):
        if host.startswith(p):
            host = host[len(p):]
    host = host.strip("/")
    if host.count(":") == 1:
        h, p = host.split(":")
        if p.isdigit():
            return h, int(p)
    return host, 21


def ftp_connect(timeout=30):
    e = secure.all_values()
    host, user, pw = e.get("FTP_HOST"), e.get("FTP_USER"), e.get("FTP_PASSWORD")
    if not (host and user and pw):
        raise RuntimeError("원주.kr FTP 정보(주소·아이디·비밀번호)가 없어요. '계정 연결 > 원주.kr'에서 넣어 주세요")
    ftp = ftplib.FTP(timeout=timeout, encoding="utf-8")
    try:
        ftp.connect(*ftp_addr(host))
        ftp.login(user, pw)
    except ftplib.error_perm as ex:
        ftp.close()
        raise RuntimeError(f"FTP 로그인 실패: 아이디·비밀번호를 확인해 주세요 ({str(ex)[:60]})") from None
    except OSError as ex:
        ftp.close()
        raise RuntimeError(f"FTP 서버에 접속하지 못했어요: 주소를 확인해 주세요 ({str(ex)[:60]})") from None
    return ftp


def ftp_cd(ftp, remote_dir):
    ftp.cwd("/")
    for part in [p for p in remote_dir.replace("\\", "/").split("/") if p and p != ".."]:
        try:
            ftp.cwd(part)
        except ftplib.error_perm:
            ftp.mkd(part)
            ftp.cwd(part)


def upload_public(images, cfg):
    """사진을 원주.kr 공개 폴더로 업로드하고 public_url 을 채움. FTP 가 없으면 False"""
    e = secure.all_values()
    if not (images and e.get("FTP_HOST") and e.get("FTP_USER") and e.get("FTP_PASSWORD")):
        return False
    base = (cfg.get("images") or {}).get("publicBaseUrl", "").rstrip("/")
    with ftp_connect() as ftp:
        ftp_cd(ftp, (cfg.get("images") or {}).get("remoteDir", "/html/photos"))
        for i in images:
            with open(i["path"], "rb") as f:
                ftp.storbinary("STOR " + i["name"], f)
            if base:
                i["public_url"] = f"{base}/{urllib.parse.quote(i['name'])}"
    return True


def render_markers(html, images, mode):
    """[[IMG:n]] → 실제 태그. mode: relative(홈페이지) | public(공개 URL) | library(대시보드 미리보기) | strip"""
    for n, i in enumerate(images):
        alt = H.escape(", ".join(i.get("labels") or []))
        if mode == "relative":
            tag = f'<p><img src="../photos/{urllib.parse.quote(i["name"])}" alt="{alt}" style="max-width:100%"></p>'
        elif mode == "public" and i.get("public_url"):
            tag = f'<p><img src="{i["public_url"]}" alt="{alt}" style="max-width:100%"></p>'
        elif mode == "library":
            tag = f'<p><img src="/library/{urllib.parse.quote(i["name"])}" alt="{alt}" style="max-width:100%;border-radius:8px"></p>'
        else:
            tag = ""
        html = html.replace(f"[[IMG:{n}]]", tag)
    return re.sub(r"\[\[IMG:\d+\]\]", "", html)
