# -*- coding: utf-8 -*-
"""Opt-in Telegram group auto-replies for explicitly selected account/chat pairs.

Telethon clients live on one dedicated asyncio thread. Session strings are held in
the application's encrypted secure store; they are never written to config/logs.
"""
import asyncio
import concurrent.futures
from collections import deque
import os
import re
import threading
import time
import uuid

from . import secure
from .telegram_join import TelegramJoinQueue
from .telegram_private import TelegramPrivateSender
from .telegram_recurring import TelegramRecurringSender
from .util import load_config, save_config, log


def _accounts(cfg=None):
    return ((cfg or load_config()).get("telegram") or {}).get("accounts") or []


def _secret_key(account_id):
    return f"TG_SESSION__{account_id}"


class TelegramReplyManager:
    def __init__(self):
        self.loop = None
        self.thread = None
        self.started = threading.Event()
        self.clients = {}
        self.handlers = {}
        self.pending = {}
        self.statuses = {}
        self.paused_until = {}
        self.send_times = {}
        self.last_sent_at = {}
        self.failures = {}
        self._lock = threading.RLock()
        self._stopping = False
        self.join_queue = TelegramJoinQueue(lambda aid: self.clients.get(aid))
        self.private_sender = TelegramPrivateSender(lambda aid: self.clients.get(aid))
        self.recurring_sender = TelegramRecurringSender(lambda aid: self.clients.get(aid))

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self._stopping = False
        self.thread = threading.Thread(target=self._thread_main, daemon=True, name="telegram-replies")
        self.thread.start()
        self.started.wait(10)
        if not self.started.is_set():
            log("ERROR", "텔레그램 수신기 시작 시간 초과")

    def _thread_main(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.started.set()
        self.loop.create_task(self._restore())
        self.loop.create_task(self._monitor_connections())
        try:
            self.loop.run_forever()
        finally:
            pending = asyncio.all_tasks(self.loop)
            for task in pending:
                task.cancel()
            if pending:
                self.loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            self.loop.close()

    def _call(self, coro, timeout=60):
        self.start()
        if not self.loop or not self.loop.is_running():
            raise RuntimeError("텔레그램 수신기가 실행되지 않았어요")
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout)

    async def _restore(self):
        try:
            from telethon import TelegramClient
            from telethon.sessions import StringSession
            creds = secure.all_values()
            api_id, api_hash = creds.get("TG_API_ID"), creds.get("TG_API_HASH")
            if not api_id or not api_hash:
                return
            cfg = load_config()
            accounts = _accounts(cfg)
            changed = False
            for acc in accounts:
                session = secure.get(_secret_key(acc["id"]))
                if not session:
                    continue
                try:
                    client = TelegramClient(StringSession(session), int(api_id), api_hash,
                                            sequential_updates=True, catch_up=False, flood_sleep_threshold=0)
                    if hasattr(client.session, "report_errors"):
                        client.session.report_errors = False
                    await client.connect()
                    if not await client.is_user_authorized():
                        self.statuses[acc["id"]] = {"connected": False, "text": "로그인 만료"}
                        await client.disconnect()
                        continue
                    me = await client.get_me()
                    self.clients[acc["id"]] = client
                    if acc.get("userId") != str(me.id):
                        acc["userId"] = str(me.id)
                        changed = True
                    self._add_handler(acc["id"], client)
                    self.statuses[acc["id"]] = {"connected": True, "text": "수신 중"}
                except Exception as exc:
                    self.statuses[acc["id"]] = {"connected": False, "text": str(exc)[:100]}
                    log("WARN", f"텔레그램 계정 {acc.get('label', acc['id'])} 연결 실패: {type(exc).__name__}")
            if changed:
                save_config(cfg)
        except ImportError:
            log("WARN", "Telethon이 설치되지 않아 텔레그램 수신기를 시작하지 않았어요")

    def _add_handler(self, account_id, client):
        from telethon import events

        previous = self.handlers.pop(account_id, None)
        if previous:
            try:
                client.remove_event_handler(previous)
            except Exception:
                pass

        async def on_message(event):
            if event.out or not event.chat_id or not (event.is_group or event.is_private):
                return
            if getattr(event.message, "action", None) is not None:
                return
            cfg = load_config()
            accounts = _accounts(cfg)
            acc = next((x for x in accounts if x.get("id") == account_id), None)
            if not acc:
                return
            now = time.time()
            paused = float(self.paused_until.get(account_id, 0))
            if paused > now:
                left = max(1, int(paused - now))
                self.statuses[account_id] = {"connected": True, "text": f"발송 제한 대기 {left}초"}
                return
            peer = str(event.chat_id)
            is_private = bool(event.is_private)
            if is_private:
                if not acc.get("replyPrivate", False):
                    return
                target = {"title": "개인 대화"}
                cooldown = _cooldown_seconds(acc, "private")
                text = str(acc.get("privateReplyText", (str(acc.get("replyText") or "") +
                                                         str(acc.get("replyEmoji") or ""))) or "").strip()
                media = ""
            else:
                if not acc.get("enabled", False):
                    return
                target = next((x for x in acc.get("groups", []) if str(x.get("id")) == peer and x.get("enabled", True)), None)
                if not target:
                    return
                cooldown = _cooldown_seconds(acc, "group")
                text = (str(acc.get("replyText") or "") + str(acc.get("replyEmoji") or "")).strip()
                media = acc.get("replyImage") or ""
            # Do not let linked accounts trigger each other's handlers and form a reply loop.
            linked_ids = {str(x.get("userId")) for x in accounts if x.get("userId")}
            sender = str(event.sender_id or "")
            if sender in linked_ids:
                return
            if not text and not media:
                return
            window = self.send_times.setdefault(account_id, deque())
            while window and now - window[0] >= 60:
                window.popleft()
            per_minute = max(1, min(20, int(acc.get("maxRepliesPerMinute", 6) or 6)))
            min_interval = max(1, min(60, int(acc.get("minReplyIntervalSeconds", 3) or 3)))
            if len(window) >= per_minute or now - float(self.last_sent_at.get(account_id, 0)) < min_interval:
                return
            if not self._allow_reply(account_id, peer, sender, event.id, cooldown,
                                     bool(acc.get("dedupeIncoming", True))):
                return
            try:
                from .telegram_format import format_message
                mode = acc.get("privateFormatMode", "plain") if is_private else acc.get("formatMode", "plain")
                text, parse_mode = format_message(text, mode, acc.get("templateValues") or {},
                                                  {"이름": str(getattr(getattr(event, "sender", None), "first_name", "") or ""),
                                                   "그룹": str(target.get("title") or "")})
                entity = await event.get_input_chat()
                reply_to = event.id if acc.get("replyMode") == "quote_reply" else None
                if media:
                    path = os.path.join(_data_dir(), "telegram_media", os.path.basename(media))
                    if os.path.isfile(path):
                        await client.send_file(entity, path, caption=text, parse_mode=parse_mode, reply_to=reply_to)
                    elif text:
                        await client.send_message(entity, text, parse_mode=parse_mode, reply_to=reply_to)
                elif text:
                    await client.send_message(entity, text, parse_mode=parse_mode, reply_to=reply_to)
                sent_at = time.time()
                window.append(sent_at)
                self.last_sent_at[account_id] = sent_at
                self.failures[account_id] = 0
                self.statuses[account_id] = {"connected": True, "text": "수신 중"}
                log("INFO", f"텔레그램 자동응답: {acc.get('label', account_id)} / {target.get('title', peer)}")
            except Exception as exc:
                name = type(exc).__name__
                if name == "FloodWaitError":
                    wait = max(60, min(86400, int(getattr(exc, "seconds", 300) or 300)))
                    self.paused_until[account_id] = time.time() + wait
                    self.statuses[account_id] = {"connected": True, "text": f"Telegram 제한으로 {wait}초 대기"}
                    log("WARN", f"텔레그램 발송 제한 ({acc.get('label', account_id)}): {wait}초 동안 자동 대기")
                else:
                    failures = int(self.failures.get(account_id, 0)) + 1
                    self.failures[account_id] = failures
                    if failures >= 3:
                        self.paused_until[account_id] = time.time() + 300
                        self.statuses[account_id] = {"connected": True, "text": "연속 오류로 5분 대기"}
                    log("WARN", f"텔레그램 자동응답 실패 ({acc.get('label', account_id)}): {name}")

        client.add_event_handler(on_message, events.NewMessage(incoming=True))
        self.handlers[account_id] = on_message

    def _allow_reply(self, account_id, peer, sender_id, message_id, cooldown_seconds=30,
                     dedupe_incoming=True):
        import sqlite3
        p = os.path.join(_data_dir(), "telegram_replies.sqlite3")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        con = sqlite3.connect(p, timeout=10)
        try:
            now = time.time()
            con.execute("CREATE TABLE IF NOT EXISTS incoming_events(account_id TEXT, peer TEXT, message_id INTEGER, created REAL NOT NULL, PRIMARY KEY(account_id,peer,message_id))")
            con.execute("CREATE TABLE IF NOT EXISTS reply_cooldowns_v2(account_id TEXT, peer TEXT, sender_id TEXT, replied REAL NOT NULL, PRIMARY KEY(account_id,peer,sender_id))")
            con.execute("BEGIN IMMEDIATE")
            if dedupe_incoming:
                con.execute("DELETE FROM incoming_events WHERE created < ?", (now - 60 * 60 * 24 * 14,))
                try:
                    con.execute("INSERT INTO incoming_events VALUES(?,?,?,?)", (account_id, peer, int(message_id), now))
                except sqlite3.IntegrityError:
                    con.rollback()
                    return False
            # Cooldown is per sender. Person B is not blocked because person A was
            # answered in the same group, and A can be answered again after expiry.
            sender_key = str(sender_id or peer)
            row = con.execute("SELECT replied FROM reply_cooldowns_v2 WHERE account_id=? AND peer=? AND sender_id=?", (account_id, peer, sender_key)).fetchone()
            if row and now - float(row[0]) < max(0, int(cooldown_seconds)):
                con.rollback()
                return False
            con.execute("INSERT INTO reply_cooldowns_v2(account_id,peer,sender_id,replied) VALUES(?,?,?,?) ON CONFLICT(account_id,peer,sender_id) DO UPDATE SET replied=excluded.replied", (account_id, peer, sender_key, now))
            con.commit()
            return True
        finally:
            con.close()

    async def _monitor_connections(self):
        while not self._stopping:
            await asyncio.sleep(15)
            for account_id, client in list(self.clients.items()):
                try:
                    if not client.is_connected():
                        self.statuses[account_id] = {"connected": False, "text": "재연결 중"}
                        await client.connect()
                    authorized = await client.is_user_authorized()
                    paused = float(self.paused_until.get(account_id, 0))
                    if authorized and paused > time.time():
                        self.statuses[account_id] = {"connected": True, "text": f"발송 제한 대기 {max(1, int(paused - time.time()))}초"}
                    else:
                        self.statuses[account_id] = {"connected": bool(authorized), "text": "수신 중" if authorized else "로그인 만료"}
                except Exception as exc:
                    self.statuses[account_id] = {"connected": False, "text": "재연결 대기"}
                    log("WARN", f"텔레그램 계정 {account_id} 연결 점검 실패: {type(exc).__name__}")

    def begin_login(self, label, phone, api_id, api_hash):
        return self._call(self._begin_login(label, phone, api_id, api_hash))

    async def _begin_login(self, label, phone, api_id, api_hash):
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        account_id = uuid.uuid4().hex[:12]
        client = TelegramClient(StringSession(), int(api_id), api_hash,
                                sequential_updates=True, catch_up=False, flood_sleep_threshold=0)
        if hasattr(client.session, "report_errors"):
            client.session.report_errors = False
        await client.connect()
        sent = await client.send_code_request(phone)
        self.pending[account_id] = {"client": client, "phone": phone, "phone_code_hash": sent.phone_code_hash,
                                    "label": label[:60], "api_id": int(api_id), "api_hash": api_hash}
        self.statuses[account_id] = {"connected": False, "text": "인증 코드 입력 대기"}
        return {"ok": True, "accountId": account_id, "message": "텔레그램 앱으로 받은 인증 코드를 입력해 주세요."}

    def finish_login(self, account_id, code, password=""):
        return self._call(self._finish_login(account_id, code, password))

    async def _finish_login(self, account_id, code, password):
        from telethon.errors import AuthKeyUnregisteredError, SessionPasswordNeededError
        p = self.pending.get(account_id)
        if not p:
            raise ValueError("로그인 요청이 만료됐어요. 인증을 다시 시작해 주세요")
        try:
            if password:
                me = await p["client"].sign_in(password=password)
            else:
                me = await p["client"].sign_in(phone=p["phone"], code=code,
                                               phone_code_hash=p["phone_code_hash"])
        except SessionPasswordNeededError:
            self.statuses[account_id] = {"connected": False, "text": "2단계 인증 비밀번호 필요"}
            return {"ok": True, "needsPassword": True, "accountId": account_id,
                    "message": "텔레그램 2단계 인증 비밀번호를 입력해 주세요."}
        except AuthKeyUnregisteredError as exc:
            # This login challenge is tied to a temporary authorization key Telegram
            # no longer recognizes. Do not reuse it on subsequent button presses.
            self.pending.pop(account_id, None)
            self.statuses[account_id] = {"connected": False, "text": "인증 세션 초기화 필요"}
            try:
                await p["client"].disconnect()
            except Exception:
                pass
            raise ValueError("텔레그램이 진행 중인 로그인 세션 키를 더 이상 인정하지 않습니다. 인증 코드를 다시 요청하고 새 코드로 처음부터 진행해 주세요.") from exc
        from telethon.sessions import StringSession
        session = p["client"].session.save()
        cfg = load_config()
        tg = cfg.setdefault("telegram", {})
        if any(str(x.get("userId")) == str(me.id) for x in tg.get("accounts") or []):
            await p["client"].disconnect()
            self.pending.pop(account_id, None)
            raise ValueError("이미 연결된 텔레그램 계정입니다. 다른 개인계정 전화번호로 추가해 주세요")
        secure.set_many({"TG_API_ID": str(p["api_id"]), "TG_API_HASH": p["api_hash"], _secret_key(account_id): session})
        acc = {"id": account_id, "label": p["label"] or getattr(me, "first_name", "Telegram"),
               "phoneHint": p["phone"][-4:], "userId": str(me.id), "enabled": False, "groups": [],
               "replyText": "", "replyEmoji": "", "replyImage": "", "replyPrivate": False,
               "privateReplyText": "",
               "groupCooldownValue": 3, "groupCooldownUnit": "minutes",
               "privateCooldownValue": 3, "privateCooldownUnit": "minutes",
               "maxRepliesPerMinute": 6, "minReplyIntervalSeconds": 3,
               "dedupeIncoming": True, "replyMode": "new_message"}
        tg.setdefault("accounts", []).append(acc)
        save_config(cfg)
        self.clients[account_id] = p["client"]
        self._add_handler(account_id, p["client"])
        self.pending.pop(account_id, None)
        self.statuses[account_id] = {"connected": True, "text": "연결됨"}
        log("INFO", f"텔레그램 계정 연결: {acc['label']}")
        return {"ok": True, "accountId": account_id, "message": "계정이 연결됐어요."}

    def list_groups(self, account_id):
        return self._call(self._list_groups(account_id))

    async def _list_groups(self, account_id):
        client = self.clients.get(account_id)
        if not client:
            raise ValueError("텔레그램 계정이 연결되지 않았어요")
        out = []
        async for d in client.iter_dialogs():
            if d.is_group:
                out.append({"id": str(await client.get_peer_id(d.entity)), "title": str(d.name or d.id)[:120],
                            "enabled": False})
        return out

    def list_chat_addresses(self, account_id):
        return self._call(self._list_chat_addresses(account_id), timeout=180)

    async def _list_chat_addresses(self, account_id):
        client = self.clients.get(account_id)
        if not client:
            raise ValueError("텔레그램 계정이 연결되지 않았어요")
        rows = []
        async for dialog in client.iter_dialogs():
            if not (dialog.is_group or dialog.is_channel):
                continue
            entity = dialog.entity
            username = getattr(entity, "username", None) or ""
            if not username:
                username = next((item.username for item in getattr(entity, "usernames", ())
                                 if getattr(item, "active", False) and getattr(item, "username", None)), "")
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{3,31}", username):
                username = ""
            rows.append({"id": str(await client.get_peer_id(entity)),
                         "title": str(dialog.name or dialog.id)[:120],
                         "kind": "group" if dialog.is_group else "channel",
                         "address": "https://t.me/" + username if username else ""})
        rows.sort(key=lambda row: (row["kind"], row["title"].casefold(), row["id"]))
        return {"ok": True, "items": rows, "total": len(rows),
                "public": sum(bool(row["address"]) for row in rows)}

    def scan_chat_references(self, account_id, messages_per_chat=50, max_chats=200):
        return self._call(self._scan_chat_references(account_id, messages_per_chat, max_chats), timeout=300)

    async def _scan_chat_references(self, account_id, messages_per_chat, max_chats):
        from .telegram_extract import scan_dialogs
        client = self.clients.get(account_id)
        if not client:
            raise ValueError("텔레그램 계정이 연결되지 않았어요")
        return await scan_dialogs(client, messages_per_chat, max_chats)

    def join_chats(self, account_id, text, interval_seconds=30):
        return self._call(self.join_queue.start(account_id, text, interval_seconds), timeout=15)

    def save_join_list(self, account_id, text, interval_seconds=30):
        return self._call(self.join_queue.save(account_id, text, interval_seconds), timeout=15)

    def pause_join(self, account_id):
        return self._call(self.join_queue.pause(account_id), timeout=15)

    def resume_join(self, account_id):
        return self._call(self.join_queue.resume(account_id), timeout=15)

    def join_status(self, account_id, include_links=False):
        return self._call(self.join_queue.status(account_id, include_links), timeout=15)

    def private_recipients(self, account_id):
        return self._call(self.private_sender.refresh(account_id), timeout=90)

    def private_send(self, account_id, user_ids, text):
        acc = next((a for a in _accounts() if a.get("id") == account_id), {})
        return self._call(self.private_sender.send(account_id, user_ids, text,
                                                  acc.get("privateFormatMode", "plain"),
                                                  acc.get("templateValues") or {}), timeout=15)

    def private_send_status(self, account_id):
        return self._call(self._private_send_status(account_id), timeout=15)

    async def _private_send_status(self, account_id):
        return self.private_sender.status(account_id)

    def private_send_stop(self, account_id):
        return self._call(self.private_sender.stop(account_id), timeout=15)

    def recurring_targets(self, account_id):
        return self._call(self.recurring_sender.refresh(account_id), timeout=90)

    def recurring_start(self, account_id, target_ids, text, hours, minutes, seconds,
                        format_mode="plain", template_values=None):
        return self._call(self.recurring_sender.start(account_id, target_ids, text, hours, minutes,
                                                      seconds, format_mode, template_values), timeout=15)

    def recurring_status(self, account_id):
        return self._call(self._recurring_status(account_id), timeout=15)

    async def _recurring_status(self, account_id):
        return self.recurring_sender.status(account_id)

    def recurring_stop(self, account_id):
        return self._call(self.recurring_sender.stop(account_id), timeout=15)

    def status(self):
        return {k: dict(v) for k, v in self.statuses.items()}

    def remove_account(self, account_id):
        self._call(self._disconnect_one(account_id), timeout=15)

    async def _disconnect_one(self, account_id):
        await self.join_queue.close(account_id, forget=True)
        await self.private_sender.close(account_id)
        await self.recurring_sender.close(account_id)
        client = self.clients.pop(account_id, None)
        if client:
            handler = self.handlers.pop(account_id, None)
            if handler:
                client.remove_event_handler(handler)
            await client.disconnect()
        self.statuses.pop(account_id, None)
        self.paused_until.pop(account_id, None)
        self.send_times.pop(account_id, None)
        self.last_sent_at.pop(account_id, None)
        self.failures.pop(account_id, None)

    def shutdown(self):
        if not self.loop or not self.loop.is_running():
            return
        self._stopping = True
        try:
            self._call(self._disconnect_all(), timeout=15)
        except Exception:
            pass
        self.loop.call_soon_threadsafe(self.loop.stop)
        if self.thread:
            self.thread.join(15)

    async def _disconnect_all(self):
        await self.join_queue.close()
        await self.private_sender.close()
        await self.recurring_sender.close()
        for client in list(self.clients.values()) + [x["client"] for x in self.pending.values()]:
            try:
                await client.disconnect()
            except Exception:
                pass
        self.clients.clear()
        self.handlers.clear()
        self.pending.clear()


def _data_dir():
    from . import generator as g
    return g.ROOT


def _cooldown_seconds(account, kind):
    value_key = f"{kind}CooldownValue"
    unit_key = f"{kind}CooldownUnit"
    if value_key in account:
        try:
            value = max(0, int(account.get(value_key) or 0))
            multiplier = {"seconds": 1, "minutes": 60, "hours": 3600}.get(str(account.get(unit_key)), 60)
            return min(86400, value * multiplier)
        except (TypeError, ValueError):
            return 180
    minute_key = f"{kind}CooldownMinutes"
    legacy_key = f"{kind}CooldownSeconds"
    if minute_key in account:
        try:
            return max(0, min(1440, int(account.get(minute_key) or 0))) * 60
        except (TypeError, ValueError):
            return 180
    try:
        return max(0, min(86400, int(account.get(legacy_key, 180) or 0)))
    except (TypeError, ValueError):
        return 180


manager = TelegramReplyManager()
