# -*- coding: utf-8 -*-
"""Small, predictable subset of Telegram HTML and MarkdownV2 formatting."""
from datetime import datetime
from html import escape
import re


PLACEHOLDER = re.compile(r"\{([A-Za-z0-9_가-힣]{1,32})\}")
MD_SPECIAL = "_*[]()~`>#+-=|{}.!\\"


def _markdown_to_html(source):
    """Convert supported MarkdownV2 bold, italic, code and links to Telethon HTML."""
    def render(start=0, closing=""):
        out = []
        index = start
        while index < len(source):
            ch = source[index]
            if closing and ch == closing:
                return "".join(out), index + 1, True
            if ch == "\\" and index + 1 < len(source):
                out.append(escape(source[index + 1]))
                index += 2
                continue
            if ch == "`":
                end = source.find("`", index + 1)
                if end != -1:
                    out.append("<code>" + escape(source[index + 1:end].replace("\\`", "`")) + "</code>")
                    index = end + 1
                    continue
            if ch == "[":
                match = re.match(r"\[([^]\n]+)\]\((https?://[^\s)]+)\)", source[index:])
                if match:
                    out.append('<a href="' + escape(match.group(2), quote=True) + '">' + escape(match.group(1)) + '</a>')
                    index += len(match.group())
                    continue
            if ch in "*_":
                inner, end, found = render(index + 1, ch)
                if found:
                    tag = "b" if ch == "*" else "i"
                    out.append(f"<{tag}>{inner}</{tag}>")
                    index = end
                    continue
            out.append(escape(ch))
            index += 1
        return "".join(out), index, False
    return render()[0]


def format_message(template, mode="plain", mapping=None, context=None):
    """Replace named placeholders and return (body, Telethon parse mode)."""
    if mode not in ("plain", "html", "markdownv2"):
        raise ValueError("서식은 일반 텍스트, HTML, MarkdownV2 중에서 선택해 주세요")
    values = {str(key): str(value) for key, value in (mapping or {}).items()}
    values.update({str(key): str(value) for key, value in (context or {}).items()})
    now = datetime.now().astimezone()
    values.setdefault("날짜", now.strftime("%Y-%m-%d"))
    values.setdefault("시간", now.strftime("%H:%M"))
    def replace(match):
        key = match.group(1)
        if key not in values:
            raise ValueError(f"{{{key}}}에 넣을 값이 없어요")
        value = values[key]
        if mode == "html":
            return escape(value)
        if mode == "markdownv2":
            return "".join("\\" + ch if ch in MD_SPECIAL else ch for ch in value)
        return value
    body = PLACEHOLDER.sub(replace, str(template or ""))
    if mode == "markdownv2":
        return _markdown_to_html(body), "html"
    return body, "html" if mode == "html" else None
