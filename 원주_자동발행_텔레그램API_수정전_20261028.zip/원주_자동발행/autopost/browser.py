# -*- coding: utf-8 -*-
"""브라우저 관리 (네이버·티스토리 발행, 플레이스 가져오기)

핵심 원칙 (로그인 만료·충돌 오류 해결)
1) 계정마다 프로필 폴더 1개: 데이터폴더/profiles/<채널>[-계정]
   로그인 창(자동화 표시 없는 일반 크롬)과 발행 브라우저가 '같은 프로필 폴더 + 같은 크롬 실행 파일'을 씀
2) 로그인 때 받은 쿠키(세션 쿠키 포함)를 암호화해 저장 → 발행 때 프로필에 없거나 사라진 쿠키만 다시 넣음
   (크롬은 창을 닫으면 '세션 쿠키'를 버리기 때문에, 로그인 상태 유지를 안 눌렀어도 같은 세션으로 이어짐)
3) 한 번에 브라우저 하나만(BROWSER_LOCK), 같은 프로필은 동시에 절대 두 번 열지 않음(profile_lock)
   + 다른 크롬 창이 그 프로필을 쓰고 있으면 열지 않고 알려 줌 → 'Target page, context or browser has been closed' 방지
"""
import glob, json, os, re, shutil, socket, threading, time
from . import generator as g, paths
from .util import log

INSTALL = {"running": False, "percent": 0, "message": "", "done": False, "error": ""}
BROWSER_LOCK = threading.RLock()        # 자동화 브라우저는 한 번에 하나
_profile_locks = {}
_pl_guard = threading.Lock()
NAV_TIMEOUT = int(os.environ.get("AUTOPOST_NAV_TIMEOUT_MS") or 60000)
IGNORE_DEFAULT_ARGS = ["--enable-automation"]   # 자동화 안내 줄 제거
STEALTH_JS = "Object.defineProperty(Navigator.prototype, 'webdriver', {get: () => undefined, configurable: true});"


def browsers_path():
    p = paths.browsers_dir()
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = p
    return p


def profile_dir(name):
    return os.path.join(g.ROOT, "profiles", name)


def profile_lock(name):
    with _pl_guard:
        return _profile_locks.setdefault(name, threading.Lock())


# ---------------- 크롬/엣지 찾기 ----------------
def _windows_candidates():
    c = []
    for env in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData"):
        base = os.environ.get(env)
        if base:
            c.append(("chrome", os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")))
    for env in ("ProgramFiles(x86)", "ProgramFiles"):
        base = os.environ.get(env)
        if base:
            c.append(("msedge", os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe")))
    return c


def _downloaded_chromium():
    pats = ["chromium-*/chrome-win*/chrome.exe", "chromium-*/chrome-linux*/chrome", "chromium-*/chrome-mac*/Chromium.app/Contents/MacOS/Chromium"]
    for base in (browsers_path(), "/opt/pw-browsers", os.path.expanduser("~/.cache/ms-playwright")):
        for pat in pats:
            hits = sorted(glob.glob(os.path.join(base, pat)))
            if hits:
                return hits[-1]
    return None


def system_browser(cfg):
    """(종류, 실행 파일). 일반 크롬 우선 → 엣지 → 내려받은 크로미움. 환경변수 AUTOPOST_BROWSER_EXE 로 지정 가능(테스트)"""
    if os.environ.get("AUTOPOST_BROWSER_EXE"):
        return "chromium", os.environ["AUTOPOST_BROWSER_EXE"]
    want = (cfg.get("browser") or {}).get("channel", "auto")
    cands = []
    if os.name == "nt":
        cands = _windows_candidates()
    elif hasattr(os, "uname") and os.uname().sysname == "Darwin":
        cands = [("chrome", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
                 ("msedge", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")]
    else:
        for k, names in (("chrome", ["google-chrome", "google-chrome-stable"]), ("msedge", ["microsoft-edge", "microsoft-edge-stable"])):
            for n in names:
                w = shutil.which(n)
                if w:
                    cands.append((k, w))
    found = [(k, p) for k, p in cands if os.path.exists(p)]
    if want in ("chrome", "msedge"):
        found = [x for x in found if x[0] == want] or found
    if found and want != "chromium":
        return found[0]
    ch = _downloaded_chromium()
    if ch:
        return "chromium", ch
    raise RuntimeError("크롬(Chrome)이나 엣지(Edge)를 찾지 못했어요. 크롬을 설치하거나 설치.bat 을 다시 실행해 주세요.")


def browser_available(cfg):
    try:
        k, p = system_browser(cfg)
        return {"ok": True, "kind": k}
    except RuntimeError:
        return {"ok": False, "kind": None}


def profile_browser(prof, cfg):
    """이 프로필에 로그인할 때 쓴 브라우저 실행 파일 (없으면 지금 찾은 것)"""
    try:
        with open(os.path.join(profile_dir(prof), ".autopost_browser"), encoding="utf-8") as f:
            kind, exe = (f.read().strip().split("|", 1) + [""])[:2]
        if exe and os.path.exists(exe):
            return kind, exe
    except OSError:
        pass
    return system_browser(cfg)


def remember_browser(prof, kind, exe):
    d = profile_dir(prof)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, ".autopost_browser"), "w", encoding="utf-8") as f:
        f.write(f"{kind}|{exe}")


# ---------------- 프로필 사용 중 확인 ----------------
def _pid_alive(pid):
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def profile_in_use(d):
    """다른 크롬 창이 이 프로필을 쓰고 있는지 (남은 잠금 파일은 정리)"""
    lock = os.path.join(d, "SingletonLock")
    if os.path.lexists(lock):  # 리눅스·맥: 심볼릭 링크 '호스트-pid'
        try:
            pid = int(os.readlink(lock).rsplit("-", 1)[-1])
        except (OSError, ValueError):
            pid = -1
        if _pid_alive(pid):
            return True
        for f in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
            try:
                os.remove(os.path.join(d, f))
            except OSError:
                pass
    lf = os.path.join(d, "lockfile")  # 윈도우: 크롬이 실행 중이면 지울 수 없음
    if os.name == "nt" and os.path.exists(lf):
        try:
            os.remove(lf)
        except PermissionError:
            return True
        except OSError:
            pass
    return False


LOGIN_ACTIVE = set()   # 사장님이 로그인 중인 프로필(이 창은 절대 강제로 닫지 않음) - connect.py 가 관리


def _norm(p):
    return os.path.normcase(os.path.abspath(p)).rstrip("\\/")


def profile_processes(d):
    """이 프로필 폴더(--user-data-dir)로 실행 중인 크롬/엣지 프로세스 (프로그램 전용 프로필만 대상)"""
    try:
        import psutil
    except ImportError:
        return []
    want, out = _norm(d), []
    for pr in psutil.process_iter(["pid", "cmdline"]):
        try:
            for a in pr.info.get("cmdline") or []:
                if a.startswith("--user-data-dir=") and _norm(a.split("=", 1)[1].strip('"')) == want:
                    out.append(pr)
                    break
        except Exception:  # noqa: BLE001 (권한 없음·이미 종료)
            continue
    return out


def kill_profile_processes(d, prof=""):
    """프로그램이 쓰는 프로필에 남아 있는 크롬(로그인 창을 닫았는데 덜 꺼진 것 등)을 정리. 정리한 개수"""
    if prof in LOGIN_ACTIVE:
        return 0
    procs = profile_processes(d)
    if not procs:
        return 0
    try:
        import psutil
        for pr in procs:
            try:
                pr.terminate()
            except Exception:  # noqa: BLE001
                pass
        _, alive = psutil.wait_procs(procs, timeout=6)
        for pr in alive:
            try:
                pr.kill()
            except Exception:  # noqa: BLE001
                pass
        psutil.wait_procs(alive, timeout=4)
    except Exception as e:  # noqa: BLE001
        log("WARN", f"[{prof}] 남은 크롬 정리 실패: {e}")
    log("WARN", f"[{prof}] 이 계정 전용 크롬이 덜 꺼진 채 남아 있어서 정리했어요({len(procs)}개)")
    return len(procs)


def ensure_profile_free(d, prof, seconds=8):
    """프로필이 쓰이고 있으면: 로그인 중이면 그대로 두고(False), 아니면 남은 크롬을 정리한 뒤 다시 확인"""
    if wait_profile_free(d, seconds):
        return True
    if prof in LOGIN_ACTIVE:
        return False
    kill_profile_processes(d, prof)
    return wait_profile_free(d, 10)


def wait_profile_free(d, seconds=20):
    end = time.time() + seconds
    while time.time() < end:
        if not profile_in_use(d):
            return True
        time.sleep(0.5)
    return not profile_in_use(d)


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# ---------------- 저장된 로그인 쿠키 ----------------
def session_name(prof):
    return re.sub(r"[^a-z0-9\-]", "", prof.lower())[:40] or "x"


def save_cookies(prof, cookies, domains):
    from . import secure
    keep = [c for c in cookies if any(c.get("domain", "").lstrip(".").endswith(d) for d in domains)]
    secure.save_json(session_name(prof), {"saved": time.time(), "cookies": keep})
    return len(keep)


def load_cookies(prof):
    from . import secure
    return (secure.load_json(session_name(prof)) or {}).get("cookies") or []


def restore_cookies(ctx, prof):
    """프로필에 없는 저장 쿠키만 넣음 (더 새로운 쿠키는 덮어쓰지 않음)"""
    saved = load_cookies(prof)
    if not saved:
        return 0
    have = {(c["name"], c.get("domain", "").lstrip("."), c.get("path", "/")) for c in ctx.cookies()}
    now = time.time()
    add = []
    for c in saved:
        if (c["name"], c.get("domain", "").lstrip("."), c.get("path", "/")) in have:
            continue
        if c.get("expires", -1) not in (-1, None) and 0 < c["expires"] < now:
            continue
        x = {k: c[k] for k in ("name", "value", "domain", "path", "httpOnly", "secure") if k in c}
        if c.get("expires", -1) not in (-1, None) and c["expires"] > 0:
            x["expires"] = c["expires"]
        if c.get("sameSite") in ("Strict", "Lax", "None"):
            x["sameSite"] = c["sameSite"]
        add.append(x)
    if add:
        ctx.add_cookies(add)
    return len(add)


# ---------------- 실행 ----------------
class ProfileBusy(RuntimeError):
    """프로필을 다른 크롬이 쓰는 중 (연결이 끊긴 게 아님)"""


def launch_profile(pw, prof, cfg, headless=None):
    """로그인 때와 같은 크롬 실행 파일 + 같은 프로필 폴더로 실행. 호출하는 쪽에서 BROWSER_LOCK·profile_lock 을 잡을 것"""
    browsers_path()
    d = profile_dir(prof)
    os.makedirs(d, exist_ok=True)
    if not ensure_profile_free(d, prof, 8):
        raise ProfileBusy("이 계정의 로그인 창이 열려 있어요. 로그인을 마치거나 그 창을 닫으면 자동으로 다시 시도해요"
                          if prof in LOGIN_ACTIVE else "이 계정의 크롬이 꺼지지 않아요. 작업 관리자에서 크롬을 모두 닫은 뒤 다시 시도해 주세요")
    b = cfg.get("browser") or {}
    kind, exe = profile_browser(prof, cfg)
    hl = b.get("headless", False) if headless is None else headless
    no_restore(d)
    args = ["--no-first-run", "--no-default-browser-check", "--disable-features=Translate", "--hide-crash-restore-bubble",
            "--disable-session-crashed-bubble"]
    if os.name != "nt":
        args.append("--password-store=basic")   # 로그인 창과 같은 쿠키 암호화 방식
    last = None
    for attempt in range(2):
        try:
            ctx = pw.chromium.launch_persistent_context(
                d, executable_path=exe, headless=hl, slow_mo=int(b.get("slowMo", 30)), locale="ko-KR", timezone_id="Asia/Seoul",
                viewport={"width": 1280, "height": 900}, ignore_default_args=IGNORE_DEFAULT_ARGS, args=args)
            ctx.add_init_script(STEALTH_JS)
            ctx._autopost_kind = kind
            return ctx
        except Exception as e:  # noqa: BLE001
            last = e
            detail = re.sub(r"[╔╗╚╝║═]+", " ", str(e))
            detail = re.sub(r"\s+", " ", detail.split("Call log:")[0])[:600]
            log("WARN", f"[{prof}] 브라우저 실행 실패({attempt + 1}/2): {detail}")
            time.sleep(3)
            ensure_profile_free(d, prof, 5)
    detail = re.sub(r"\s+", " ", re.sub(r"[╔╗╚╝║═]+", " ", str(last)).split("Call log:")[0])[:300]
    raise RuntimeError(f"브라우저를 열 수 없어요(크롬 창이 이미 열려 있거나 크롬이 막힘): {detail}")


def no_restore(d):
    """로그인 창을 강제로 닫으면 크롬이 '비정상 종료'로 기억해 다음 실행 때 지난 탭을 복원함 →
    복원하면서 처음 탭을 닫아 버려 'Target page, context or browser has been closed' 가 날 수 있음.
    실행 전에 '정상 종료'로 표시하고 시작 페이지를 새 탭으로, 지난 탭 기록 파일은 지움 (로그인 쿠키는 그대로)"""
    pref = os.path.join(d, "Default", "Preferences")
    try:
        if os.path.exists(pref):
            with open(pref, encoding="utf-8") as f:
                p = json.load(f)
            p.setdefault("profile", {}).update(exit_type="Normal", exited_cleanly=True)
            p.setdefault("session", {})["restore_on_startup"] = 5
            tmp = pref + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(p, f)
            os.replace(tmp, pref)
    except (OSError, ValueError) as e:
        log("WARN", f"크롬 프로필 설정 정리 실패(계속 진행): {e}")
    files = [os.path.join(d, "Default", n) for n in ("Current Session", "Current Tabs", "Last Session", "Last Tabs")]
    sess = os.path.join(d, "Default", "Sessions")
    if os.path.isdir(sess):
        files += [os.path.join(sess, f) for f in os.listdir(sess)]
    for f in files:
        try:
            os.remove(f)
        except OSError:
            pass


def work_page(ctx):
    """작업용 새 탭 (크롬이 시작할 때 연 탭은 복원·정리 중에 닫힐 수 있어 쓰지 않음). 닫힘·멈춤은 기록에 남김"""
    page = ctx.new_page()
    page.on("crash", lambda *_: log("WARN", "브라우저 탭이 멈췄어요(crash) - 메모리가 부족하거나 크롬 오류일 수 있어요"))
    for p in list(ctx.pages):
        if p is not page and p.url in ("about:blank", "chrome://newtab/", "chrome://new-tab-page/"):
            try:
                p.close()
            except Exception:  # noqa: BLE001
                pass
    return page


def fix_headless_ua(ctx, page):
    """헤드리스 확인용: 'HeadlessChrome' 표시를 일반 크롬으로"""
    try:
        ua = page.evaluate("navigator.userAgent")
        if "Headless" in ua:
            cdp = ctx.new_cdp_session(page)
            cdp.send("Network.setUserAgentOverride", {"userAgent": ua.replace("HeadlessChrome", "Chrome"), "acceptLanguage": "ko-KR,ko"})
    except Exception:  # noqa: BLE001
        pass


def safe_goto(page, url, timeout=None, wait_until="domcontentloaded"):
    """느린 페이지는 시간 초과를 오류로 보지 않음(이후 필요한 요소를 따로 기다림)"""
    try:
        page.goto(url, wait_until=wait_until, timeout=timeout or NAV_TIMEOUT)
        return True
    except Exception as e:  # noqa: BLE001
        if "Timeout" not in type(e).__name__ and "Timeout" not in str(e):
            raise
        log("INFO", f"페이지 로딩이 느려요(계속 진행): {url[:80]}")
        return False


def shot(page, name):
    d = os.path.join(g.ROOT, "logs", "screens")
    os.makedirs(d, exist_ok=True)
    f = os.path.join(d, f"{time.strftime('%Y%m%d-%H%M%S')}-{name}.png")
    try:
        page.screenshot(path=f, full_page=True, timeout=15000)
    except Exception:  # noqa: BLE001
        try:
            page.screenshot(path=f, timeout=10000)
        except Exception:  # noqa: BLE001
            return ""
    return f


def install_chromium_async():
    """크롬·엣지가 없을 때만: 크로미움 내려받기 (대시보드 진행률 표시)"""
    if INSTALL["running"]:
        return INSTALL
    import subprocess

    def work():
        INSTALL.update(running=True, percent=0, message="다운로드 준비 중…", done=False, error="")
        try:
            from playwright._impl._driver import compute_driver_executable, get_driver_env
            exe = compute_driver_executable()
            cmd = list(exe) if isinstance(exe, (tuple, list)) else [exe]
            env = {**get_driver_env(), "PLAYWRIGHT_BROWSERS_PATH": browsers_path()}
            flags = 0x08000000 if os.name == "nt" else 0
            p = subprocess.Popen(cmd + ["install", "chromium"], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, encoding="utf-8", errors="replace", creationflags=flags)
            for line in p.stdout:
                m = re.search(r"(\d{1,3})%", line)
                if m:
                    INSTALL["percent"] = int(m.group(1))
                INSTALL["message"] = line.strip()[:120]
            if p.wait() != 0:
                raise RuntimeError(INSTALL["message"] or "설치 실패")
            INSTALL.update(percent=100, message="설치 완료", done=True)
        except Exception as e:  # noqa: BLE001
            INSTALL.update(error=str(e)[:200], message="설치 실패")
            log("ERROR", f"Chromium 설치 실패: {e}")
        finally:
            INSTALL["running"] = False
    threading.Thread(target=work, daemon=True).start()
    return INSTALL
