# -*- coding: utf-8 -*-
"""Official messaging-channel credential helpers.

Secrets are stored through secure.py only. Provider pages are never scraped.
"""
import json, re, secrets, urllib.error, urllib.request

from . import secure


def telegram_key(cid):
    return f"TG_BOT_TOKEN__{cid}"


def naver_key(cid):
    return f"NAVER_TALK_TOKEN__{cid}"


def webhook_key(cid):
    return f"CHAT_WEBHOOK_SECRET__{cid}"


def valid_id(value):
    return bool(re.fullmatch(r"[a-f0-9]{12}", str(value or "")))


def new_connection(provider, label=""):
    if provider not in ("telegram_bot", "naver_talk"):
        raise ValueError("지원하지 않는 상담 채널")
    cid = secrets.token_hex(6)
    secret = secrets.token_urlsafe(32)
    secure.set_many({webhook_key(cid): secret})
    return {"id": cid, "provider": provider, "label": str(label or ("텔레그램 봇" if provider == "telegram_bot" else "네이버 톡톡"))[:50],
            "enabled": False, "account": {}, "lastError": ""}


def verify_telegram(token, timeout=8):
    token = str(token or "").strip()
    if not re.fullmatch(r"\d{5,15}:[A-Za-z0-9_-]{25,80}", token):
        raise ValueError("BotFather에서 받은 텔레그램 봇 토큰 형식이 아닙니다")
    req = urllib.request.Request(f"https://api.telegram.org/bot{token}/getMe", headers={"User-Agent": "JH-NODE/3.8"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as res:
            data = json.loads(res.read(512_000))
    except urllib.error.HTTPError as e:
        raise ValueError("텔레그램이 토큰을 거부했습니다") from e
    except (OSError, ValueError) as e:
        raise ValueError(f"텔레그램 연결 확인 실패: {type(e).__name__}") from e
    bot = data.get("result") if data.get("ok") else None
    if not isinstance(bot, dict) or not bot.get("id"):
        raise ValueError("텔레그램 봇 정보를 확인하지 못했습니다")
    return {"id": str(bot["id"]), "username": str(bot.get("username") or "")[:80], "name": str(bot.get("first_name") or "")[:80]}


def validate_naver_token(token):
    """TalkTalk has no harmless account-info endpoint; validate syntax only."""
    token = str(token or "").strip()
    if len(token) < 20 or len(token) > 300 or not re.fullmatch(r"[A-Za-z0-9._~-]+", token):
        raise ValueError("톡톡 파트너센터의 보내기 API Authorization 값을 확인해 주세요")
    return {"status": "형식 확인", "note": "실제 연결은 톡톡 웹훅 테스트 메시지로 확인됩니다"}


def masked_connection(item, public_base=""):
    cid, provider = item["id"], item["provider"]
    key = telegram_key(cid) if provider == "telegram_bot" else naver_key(cid)
    base = str(public_base or "").rstrip("/")
    return {**item, "hasToken": bool(secure.get(key)), "tokenMasked": "••••••••" if secure.get(key) else "",
            "webhookUrl": (base + f"/api/chat/webhook/{provider}/{cid}") if base else f"/api/chat/webhook/{provider}/{cid}",
            "hasWebhookSecret": bool(secure.get(webhook_key(cid)))}
