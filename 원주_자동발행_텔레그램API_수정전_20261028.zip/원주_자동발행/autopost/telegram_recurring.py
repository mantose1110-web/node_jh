# -*- coding: utf-8 -*-
"""Opt-in, per-account recurring Telegram sends. Jobs pause on application exit."""
import asyncio
import time

from .telegram_format import format_message


class TelegramRecurringSender:
    def __init__(self, get_client):
        self.get_client = get_client
        self.targets = {}
        self.jobs = {}
        self.tasks = {}
        self.stop_events = {}

    async def refresh(self, account_id):
        client = self.get_client(account_id)
        if not client:
            raise ValueError("텔레그램 계정을 먼저 연결해 주세요")
        directory = {}
        async for dialog in client.iter_dialogs():
            if not (dialog.is_user or dialog.is_group or dialog.is_channel):
                continue
            peer_id = str(await client.get_peer_id(dialog.entity))
            directory[peer_id] = {"id": peer_id, "name": str(dialog.name or peer_id)[:120],
                                  "kind": "person" if dialog.is_user else "group" if dialog.is_group else "channel",
                                  "entity": dialog.entity}
        self.targets[account_id] = directory
        items = [{key: item[key] for key in ("id", "name", "kind")} for item in directory.values()]
        items.sort(key=lambda item: (item["kind"], item["name"].casefold()))
        return {"ok": True, "items": items, "total": len(items)}

    def status(self, account_id):
        job = self.jobs.get(account_id)
        task = self.tasks.get(account_id)
        if not job:
            return {"ok": True, "running": False, "phase": "idle", "message": "시작 대기", "sent": 0}
        return {"ok": True, "running": bool(task and not task.done()), "phase": job["phase"],
                "message": job["message"], "sent": job["sent"], "lastSentAt": job.get("lastSentAt"),
                "lastTarget": job.get("lastTarget", ""), "nextAt": job.get("nextAt")}

    async def start(self, account_id, target_ids, text, hours, minutes, seconds,
                    format_mode="plain", template_values=None):
        if self.tasks.get(account_id) and not self.tasks[account_id].done():
            raise ValueError("이 계정의 주기 발송이 이미 실행 중이에요")
        client = self.get_client(account_id)
        if not client or not client.is_connected():
            raise ValueError("텔레그램 계정 연결을 확인해 주세요")
        directory = self.targets.get(account_id) or {}
        if not isinstance(target_ids, list) or not 1 <= len(target_ids) <= 30:
            raise ValueError("받는 대화방을 1~30개 선택해 주세요")
        ids = [str(value) for value in target_ids]
        if len(set(ids)) != len(ids) or any(value not in directory for value in ids):
            raise ValueError("대화방 목록을 새로고침하고 다시 선택해 주세요")
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 2000:
            raise ValueError("메시지는 1~2,000자로 입력해 주세요")
        try:
            h, m, s = int(hours), int(minutes), int(seconds)
        except (TypeError, ValueError):
            raise ValueError("시간·분·초를 숫자로 입력해 주세요") from None
        if not (0 <= h <= 24 and 0 <= m < 60 and 0 <= s < 60):
            raise ValueError("시간은 0~24, 분·초는 0~59로 입력해 주세요")
        interval = h * 3600 + m * 60 + s
        if not 10 <= interval <= 86400:
            raise ValueError("발송 간격은 10초~24시간으로 설정해 주세요")
        values = template_values or {}
        for target_id in ids:
            format_message(text, format_mode, values, {"이름": directory[target_id]["name"],
                                                       "그룹": directory[target_id]["name"]})
        self.stop_events[account_id] = asyncio.Event()
        self.jobs[account_id] = {"phase": "running", "message": "주기 발송 시작", "sent": 0}
        self.tasks[account_id] = asyncio.create_task(self._run(account_id, ids, text.strip(),
                                                               interval, format_mode, values))
        return self.status(account_id)

    async def stop(self, account_id):
        event = self.stop_events.get(account_id)
        if event:
            event.set()
            if account_id in self.jobs:
                self.jobs[account_id].update(phase="stopping", message="현재 요청을 마친 뒤 중지합니다")
        return self.status(account_id)

    async def _run(self, account_id, ids, template, interval, format_mode, values):
        job = self.jobs[account_id]
        stopped = self.stop_events[account_id]
        try:
            while not stopped.is_set():
                for target_id in ids:
                    if stopped.is_set():
                        break
                    target = self.targets[account_id][target_id]
                    body, parse_mode = format_message(template, format_mode, values,
                                                      {"이름": target["name"], "그룹": target["name"]})
                    job.update(phase="sending", message=f"{target['name']} 발송 중", lastTarget=target["name"])
                    try:
                        await asyncio.wait_for(self.get_client(account_id).send_message(
                            target["entity"], body, parse_mode=parse_mode), timeout=60)
                    except Exception as exc:
                        name = type(exc).__name__
                        if name in ("FloodWaitError", "FloodPremiumWaitError"):
                            delay = max(1, int(getattr(exc, "seconds", 60))) + 1
                            job.update(phase="waiting", message=f"텔레그램 제한으로 {delay}초 대기", nextAt=time.time() + delay)
                            try:
                                await asyncio.wait_for(stopped.wait(), timeout=delay)
                            except asyncio.TimeoutError:
                                pass
                            continue
                        if isinstance(exc, (OSError, asyncio.TimeoutError)):
                            job.update(phase="error", message="발송 여부를 확인할 수 없어 중단했어요. 텔레그램 앱을 확인해 주세요")
                        else:
                            job.update(phase="error", message=f"{target['name']} 발송 오류: {name}")
                        stopped.set()
                        break
                    job.update(sent=job["sent"] + 1, lastSentAt=time.time(), phase="waiting",
                               message=f"{target['name']} 발송 완료 · 다음 발송 대기", nextAt=time.time() + interval)
                    try:
                        await asyncio.wait_for(stopped.wait(), timeout=interval)
                    except asyncio.TimeoutError:
                        pass
            if job["phase"] != "error":
                job.update(phase="stopped", message="주기 발송 중지", nextAt=None)
        except asyncio.CancelledError:
            job.update(phase="stopped", message="프로그램 종료로 중지", nextAt=None)
            raise
        except Exception as exc:
            job.update(phase="error", message=f"주기 발송 중단: {type(exc).__name__}", nextAt=None)

    async def close(self, account_id=None):
        ids = [account_id] if account_id is not None else list(self.tasks)
        for aid in ids:
            task = self.tasks.pop(aid, None)
            if task and not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            self.stop_events.pop(aid, None)
            self.targets.pop(aid, None)
