# -*- coding: utf-8 -*-
"""자료함: 사장님이 한 번 올려 둔 키워드·사진(+네이버 플레이스 사진·가게 정보)
- 사진을 올리면 자동 라벨(Claude 비전 → 키가 없으면 파일 이름) / 라벨은 고쳐도 되고 안 고쳐도 됨
- 글마다 키워드·주제에 맞는 사진 3~6장 자동 선택, 같은 계정이 최근 쓴 사진은 피함
- 어떤 글에 어떤 키워드·사진이 쓰였는지 기록(material_usage)"""
import base64, hashlib, io, json, os, re, time
from datetime import datetime, timedelta
from . import generator as g
from .util import log

LABELS = ["후라이드", "양념", "간장", "반반", "순살", "통닭", "매장외관", "매장내부", "테이블", "포장", "메뉴판", "조리과정",
          "음료", "사이드", "사장님", "간판", "기타"]
# 파일 이름(영문/한글) → 라벨 (키가 없을 때)
NAME_HINTS = [
    (r"후라이드|프라이드|fried|crispy", "후라이드"), (r"양념|yangnyeom|spicy|sauce|red", "양념"), (r"간장|soy", "간장"),
    (r"반반|half", "반반"), (r"순살|boneless", "순살"), (r"통닭|whole", "통닭"),
    (r"외관|간판|front|outside|exterior|store-?front|sign", "매장외관"), (r"내부|홀|inside|interior|hall", "매장내부"),
    (r"테이블|table|상차림", "테이블"), (r"포장|takeout|take-?out|pack|box|배달|delivery", "포장"), (r"메뉴판|menu", "메뉴판"),
    (r"조리|튀기|주방|kitchen|cook|fry", "조리과정"), (r"맥주|음료|콜라|beer|drink|cola", "음료"),
    (r"사이드|감자|떡볶이|무|side|fries|potato", "사이드"), (r"사장|owner|boss", "사장님"),
]
# 키워드·주제 → 어울리는 사진 라벨
KW_HINTS = [
    (r"양념", ["양념", "반반"]), (r"후라이드|프라이드|바삭", ["후라이드", "통닭", "반반"]), (r"간장", ["간장"]), (r"반반", ["반반", "양념", "후라이드"]),
    (r"순살", ["순살"]), (r"옛날|통닭|전기구이|시장", ["통닭", "후라이드", "조리과정"]), (r"치킨|닭", ["후라이드", "양념", "통닭"]),
    (r"포장|테이크아웃|배달|야식|집에서", ["포장", "통닭"]),
    (r"맛집|가볼만|추천|분위기|데이트|모임|회식|단체|가족", ["매장내부", "테이블", "매장외관"]),
    (r"주차|위치|가는\s*길|근처|역|온천|동네|골목", ["매장외관", "간판"]), (r"메뉴|가격|세트", ["메뉴판", "후라이드", "양념"]),
    (r"맥주|치맥|술|호프|안주", ["음료", "테이블"]), (r"떡볶이|감자|사이드", ["사이드"]),
]
TOPIC_HINTS = {"매장일상": ["매장내부", "조리과정", "사장님", "매장외관"], "오늘튀긴닭": ["조리과정", "후라이드", "통닭"],
               "메뉴소개": ["후라이드", "양념", "반반", "메뉴판", "사이드"], "손님반응소개": ["포장", "테이블", "매장내부"],
               "동네정보": ["매장외관", "간판"]}
MAX_SIDE = 2000          # 원본은 긴 변 2000px 로 줄여 저장 (EXIF/GPS 제거)
MAX_UPLOAD = 50 * 1024 * 1024
try:   # 아이폰 HEIC/HEIF 사진 (설치돼 있을 때만)
    import pillow_heif
    pillow_heif.register_heif_opener()
    HEIC_OK = True
except Exception:  # noqa: BLE001
    HEIC_OK = False


def lib_dir():
    d = os.path.join(g.ROOT, "data", "library")
    os.makedirs(d, exist_ok=True)
    return d


def init(con):
    con.executescript("""
    CREATE TABLE IF NOT EXISTS library_photos(id INTEGER PRIMARY KEY, sha TEXT UNIQUE, file TEXT, orig_name TEXT, labels TEXT,
        caption TEXT, label_src TEXT, source TEXT, w INTEGER, h INTEGER, added TEXT);
    CREATE TABLE IF NOT EXISTS material_usage(id INTEGER PRIMARY KEY, ts TEXT, channel TEXT, account TEXT, keyword TEXT,
        photo_ids TEXT, title TEXT, topic TEXT, task_id INTEGER, dry INTEGER);""")


def _con():
    con = g.db()
    init(con)
    return con


def _row(r):
    return {"id": r[0], "sha": r[1], "file": r[2], "name": r[3], "labels": json.loads(r[4] or "[]"), "caption": r[5] or "",
            "labelSrc": r[6], "source": r[7], "w": r[8], "h": r[9], "added": r[10], "path": os.path.join(lib_dir(), r[2])}


def list_photos(con=None):
    own = con is None
    con = con or _con()
    try:
        return [_row(r) for r in con.execute("SELECT id,sha,file,orig_name,labels,caption,label_src,source,w,h,added FROM library_photos ORDER BY id DESC")]
    finally:
        if own:
            con.close()


def get_photo(pid, con=None):
    own = con is None
    con = con or _con()
    try:
        r = con.execute("SELECT id,sha,file,orig_name,labels,caption,label_src,source,w,h,added FROM library_photos WHERE id=?", (pid,)).fetchone()
        return _row(r) if r else None
    finally:
        if own:
            con.close()


def labels_from_name(name, extra=""):
    s = (name or "").lower() + " " + (extra or "")
    out = [lab for pat, lab in NAME_HINTS if re.search(pat, s, re.I)]
    return list(dict.fromkeys(out)) or ["기타"]


def clean_labels(labels):
    out = []
    for x in labels or []:
        x = re.sub(r"[\s#,]+", "", str(x))[:12]
        if x and x not in out:
            out.append(x)
    return out[:6] or ["기타"]


def _thumb_b64(path, side=768):
    from PIL import Image
    with Image.open(path) as im:
        im = im.convert("RGB")
        im.thumbnail((side, side))
        b = io.BytesIO()
        im.save(b, "JPEG", quality=80)
    return base64.b64encode(b.getvalue()).decode()


LABEL_TOOL = {"name": "submit_labels", "description": "사진 라벨 제출",
              "input_schema": {"type": "object", "properties": {
                  "labels": {"type": "array", "items": {"type": "string"}, "description": "사진에 보이는 것 라벨 1~4개"},
                  "caption": {"type": "string", "description": "사진에 보이는 것만 쓴 한국어 한 줄 설명(30자 이내)"}},
                  "required": ["labels", "caption"]}}


def vision_labels(path, cfg):
    """Claude 비전으로 라벨·한 줄 설명. 키가 없으면 None (모델은 /v1/models 에서 자동 선택)"""
    from . import llm
    if not llm.api_key():
        return None
    prompt = ("통닭집 사장님이 올린 가게 사진입니다. 사진에 보이는 것만 보고 라벨 1~4개와 한국어 한 줄 설명(30자 이내)을 주세요. "
              f"라벨은 가능하면 다음 중에서: {', '.join(LABELS)}. 보이지 않는 것은 추측하지 마세요. submit_labels 도구로 제출.")
    content = [{"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": _thumb_b64(path)}},
               {"type": "text", "text": prompt}]
    j, _model = llm.call_tool(cfg, "", content, LABEL_TOOL, 300, "vision", {"channel": "library", "keyword": "사진 라벨"})
    return clean_labels(j.get("labels")), str(j.get("caption") or "")[:60]


def add_photo(data, orig_name, cfg, source="upload", hint="", label=True):
    """사진 1장 추가 (중복이면 기존 것 반환). 반환: (photo, created)"""
    from PIL import Image, UnidentifiedImageError
    if not data:
        raise ValueError(f"빈 파일이에요: {orig_name}")
    if len(data) > MAX_UPLOAD:
        raise ValueError(f"사진이 너무 커요(최대 50MB): {orig_name}")
    heic = data[4:12] in (b"ftypheic", b"ftypheix", b"ftyphevc", b"ftypmif1", b"ftypmsf1", b"ftypheim", b"ftypheis") or \
        str(orig_name or "").lower().endswith((".heic", ".heif"))
    if heic and not HEIC_OK:
        raise ValueError(f"아이폰 HEIC 사진이에요: {orig_name} - '설치.bat'을 다시 실행하면 읽을 수 있어요 "
                         "(또는 아이폰 설정 › 카메라 › 포맷 › '높은 호환성'으로 찍거나, 사진을 JPG로 보내 주세요)")
    try:
        im = Image.open(io.BytesIO(data))
        im.verify()
        im = Image.open(io.BytesIO(data))
        from PIL import ImageOps
        im = ImageOps.exif_transpose(im)   # 회전 정보 반영 후
        im = im.convert("RGB")             # 새로 저장 → EXIF(GPS 위치 등) 전부 제거
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError, MemoryError) as e:
        raise ValueError(f"사진 파일이 아니거나 읽을 수 없어요: {orig_name}") from e
    im.thumbnail((MAX_SIDE, MAX_SIDE))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=88, exif=b"")  # EXIF·위치정보 없이 저장
    raw = buf.getvalue()
    h = hashlib.sha256(data).hexdigest()
    con = _con()
    try:
        r = con.execute("SELECT id FROM library_photos WHERE sha=?", (h,)).fetchone()
        if r:
            return get_photo(r[0], con), False
        fname = f"{source}-{h[:16]}.jpg"
        with open(os.path.join(lib_dir(), fname), "wb") as f:
            f.write(raw)
        safe_name = os.path.basename(str(orig_name or fname))[:120]
        labels, caption, src = labels_from_name(safe_name, hint), "", "filename"
        cur = con.execute("INSERT INTO library_photos(sha,file,orig_name,labels,caption,label_src,source,w,h,added) VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (h, fname, safe_name, json.dumps(labels, ensure_ascii=False), caption, src, source, im.width, im.height,
                           datetime.now().isoformat(timespec="seconds")))
        con.commit()
        pid = cur.lastrowid
    finally:
        con.close()
    if label:
        relabel(pid, cfg)
    return get_photo(pid), True


def relabel(pid, cfg):
    """자동 라벨 다시 붙이기(비전 → 실패/키 없음이면 파일 이름 라벨 유지)"""
    p = get_photo(pid)
    if not p:
        return None
    try:
        res = vision_labels(p["path"], cfg)
    except Exception as e:  # noqa: BLE001 (비전 실패해도 사진은 저장, 파일 이름 라벨 사용)
        log("WARN", f"[자료함] 사진 {pid} 자동 라벨 실패 → 파일 이름 라벨 사용: {str(e)[:120]}")
        res = None
    if res:
        set_labels(pid, res[0], res[1], "vision")
    return get_photo(pid)


def set_labels(pid, labels, caption=None, src="manual"):
    con = _con()
    try:
        if caption is None:
            con.execute("UPDATE library_photos SET labels=?, label_src=? WHERE id=?", (json.dumps(clean_labels(labels), ensure_ascii=False), src, pid))
        else:
            con.execute("UPDATE library_photos SET labels=?, caption=?, label_src=? WHERE id=?",
                        (json.dumps(clean_labels(labels), ensure_ascii=False), str(caption)[:60], src, pid))
        con.commit()
    finally:
        con.close()


def delete_photo(pid):
    p = get_photo(pid)
    if not p:
        return False
    con = _con()
    try:
        con.execute("DELETE FROM library_photos WHERE id=?", (pid,))
        con.commit()
    finally:
        con.close()
    try:
        from .tasks import files_in_use
        in_use = p["file"] in files_in_use()
    except Exception:  # noqa: BLE001
        in_use = False
    if in_use:   # 아직 올리지 않은 글에 들어간 사진은 파일을 남겨 둠 (발행 때 '파일 없음' 방지)
        log("INFO", f"[자료함] 사진 {pid}는 목록에서만 지우고, 올릴 글이 쓰고 있어 파일은 남겨 둠")
    else:
        try:
            os.remove(p["path"])
        except OSError:
            pass
    return True


def import_place_photos(cfg, folder=None):
    """플레이스에서 내려받은 사진(photos/place)을 자료함으로 (메뉴 사진은 메뉴 이름 힌트)"""
    folder = folder or os.path.join(g.ROOT, "photos", "place")
    if not os.path.isdir(folder):
        return 0
    n = 0
    for f in sorted(os.listdir(folder)):
        if not f.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
            continue
        with open(os.path.join(folder, f), "rb") as fh:
            data = fh.read()
        hint = "메뉴판 통닭" if "-menu-" in f else ("외관" if "-store-" in f else "")
        try:
            _, created = add_photo(data, f, cfg, source="place", hint=hint)
            n += int(created)
        except ValueError:
            continue
    return n


# ---------------- 글마다 사진 고르기 ----------------
TOPIC_ALIAS = {"비하인드": "오늘튀긴닭", "운영이야기": "오늘튀긴닭", "특장점안내": "메뉴소개", "특장점정리": "메뉴소개", "고민해결": "메뉴소개",
               "메뉴가격안내": "메뉴소개", "상황별추천": "메뉴소개", "사장일기": "매장일상", "휴무일상": "동네정보", "동네이야기": "동네정보",
               "사장의생각": "매장일상", "계절에세이": "동네정보", "동네풍경": "동네정보", "치킨보관데우기": "메뉴소개", "야식고르기": "메뉴소개",
               "주방상식": "오늘튀긴닭", "이번주날씨와한끼": "메뉴소개", "동네계절소식": "동네정보", "자주묻는질문": "메뉴소개"}


def wanted_labels(keyword, topic=None):
    """키워드·주제에서 어울리는 라벨 (가중치 dict). 구체적인 메뉴 이름이 있으면 일반 '치킨' 규칙은 쓰지 않음"""
    w = {}
    specific = False
    for pat, labs in KW_HINTS:
        if pat.startswith("치킨") and specific:
            continue
        if re.search(pat, keyword or ""):
            if pat in (r"양념", r"후라이드|프라이드|바삭", r"간장", r"반반", r"순살", r"옛날|통닭|전기구이|시장"):
                specific = True
            for i, lab in enumerate(labs):
                w[lab] = max(w.get(lab, 0), 3 - i * 0.7)
    for i, lab in enumerate(TOPIC_HINTS.get(topic or "") or TOPIC_HINTS.get(TOPIC_ALIAS.get(topic or "", ""), [])):
        w[lab] = max(w.get(lab, 0), 1.5 - i * 0.25)
    return w


def recent_photo_ids(con, account, channel, days):
    since = (datetime.now() - timedelta(days=days)).isoformat()
    acc, all_ = set(), {}
    for ch, ac, ids, ts in con.execute("SELECT channel, account, photo_ids, ts FROM material_usage WHERE ts>=?", (since,)):
        for i in json.loads(ids or "[]"):
            all_[i] = max(all_.get(i, ""), ts)
            if ac == account and ch == channel:
                acc.add(i)
    return acc, all_


def photo_usage(con, days=30):
    """(최근 N일 사진별 사용 횟수(모든 채널·계정), 가장 최근 글들에 쓴 사진 묶음 목록)"""
    since = (datetime.now() - timedelta(days=days)).isoformat()
    cnt, sets = {}, []
    for ids, in con.execute("SELECT photo_ids FROM material_usage WHERE ts>=? ORDER BY id DESC", (since,)):
        ids = json.loads(ids or "[]")
        if len(sets) < 6 and ids:
            sets.append(set(ids))
        for i in ids:
            cnt[i] = cnt.get(i, 0) + 1
    return cnt, sets


def _weighted_sample(cands, k, rng):
    """가중치 무작위 뽑기 (중복 없이) - 점수가 높을수록 잘 뽑히지만 매번 다른 조합"""
    pool, out = list(cands), []
    while pool and len(out) < k:
        tot = sum(w for w, _ in pool)
        r, acc = rng.random() * tot, 0.0
        for i, (w, item) in enumerate(pool):
            acc += w
            if acc >= r:
                out.append(item)
                pool.pop(i)
                break
        else:
            out.append(pool.pop()[1])
    return out


def pick_photos(cfg, keyword, topic, channel, account, rng, n=None, con=None):
    """키워드·주제에 맞는 사진 n장(기본 3~6, SNS 1)을 '가중치 무작위'로 고름.
    - 이 계정·채널이 최근(기본 14일) 쓴 사진은 빼고, 모든 채널에서 자주 쓴 사진·오늘 쓴 사진은 덜 뽑힘
    - 바로 앞 글들과 같은 사진 묶음이 되지 않게(겹치는 사진 최대 1장), 같은 라벨은 최대 3장
    - 사진이 모자라면 오래전에 쓴 사진으로 최소 장수만 채움"""
    own = con is None
    con = con or _con()
    init(con)
    try:
        photos = [p for p in list_photos(con) if p.get("source") != "ci"]   # 기업 CI 는 따로 (항상 넣음)
        if not photos:
            return []
        lc = cfg.get("library") or {}
        if n is None:
            lo, hi = int(lc.get("minPhotos", 3)), int(lc.get("maxPhotos", 6))
            n = 1 if channel == "instagram" else rng.randint(min(lo, hi), max(lo, hi))
        n = max(1, min(n, len(photos)))
        acc_recent, any_recent = recent_photo_ids(con, account, channel, int(lc.get("noRepeatDays", 14)))
        uses, last_sets = photo_usage(con, 30)
        today = datetime.now().strftime("%Y-%m-%d")
        gap_since = (datetime.now() - timedelta(days=int(lc.get("globalGapDays", 3)))).isoformat()
        want = wanted_labels(keyword, topic)
        lo = 1 if channel == "instagram" else min(int(lc.get("minPhotos", 3)), n)
        cands = []
        kw_tokens = [w for w in re.findall(r"[가-힣A-Za-z0-9]{2,}", keyword or "") if w not in ("아산", "충남")]
        for p in photos:
            match = sum(want.get(lab, 0) for lab in p["labels"])
            hay = " ".join(p["labels"]) + " " + (p.get("caption") or "") + " " + (p.get("name") or "")
            if kw_tokens and any(t in hay for t in kw_tokens):
                match += 2.0   # 키워드로 가져온 사진·키워드가 붙은 사진
            w = (1.0 + match) / (1.0 + uses.get(p["id"], 0)) ** 2.0               # 맞을수록 ↑, 자주 쓸수록 크게 ↓
            if any_recent.get(p["id"], "") >= gap_since:
                w *= 0.15      # 최근 며칠 안에 어느 채널이든 쓴 사진은 거의 안 뽑힘
            if any_recent.get(p["id"], "") >= today:
                w *= 0.25      # 오늘 다른 채널·계정이 쓴 사진
            cands.append((max(w, 0.001), match, p))
        out, labels = [], {}

        def ok(p, strict):
            key = p["labels"][0] if p["labels"] else ""
            if labels.get(key, 0) >= 3 and len(photos) > n * 2:
                return False
            if strict:
                ids = {o["id"] for o in out} | {p["id"]}
                if any(len(ids & s_) >= 2 and len(s_) >= 2 for s_ in last_sets) and len(photos) > n * 3:
                    return False    # 앞 글과 같은 사진 2장 이상 겹치는 묶음은 피함
            return True

        def take(pool, limit, strict):
            pool = [(w, (m, p)) for w, m, p in pool if all(o["id"] != p["id"] for o in out)]
            for m, p in _weighted_sample(pool, len(pool), rng):
                if len(out) >= limit:
                    break
                if not ok(p, strict):
                    continue
                out.append(dict(p, match=round(m, 2)))
                key = p["labels"][0] if p["labels"] else ""
                labels[key] = labels.get(key, 0) + 1
        fresh = [c for c in cands if c[2]["id"] not in acc_recent]
        matching = [c for c in fresh if c[1] > 0]
        if matching:   # 첫 장은 키워드와 가장 잘 맞는 사진 중에서 (그 안에서는 무작위·덜 쓴 것 우선)
            best = max(c[1] for c in matching)
            top = [c for c in matching if c[1] >= best * 0.8]
            take(top, 1, False)
        take(matching, max(1, round(n * 0.6)), True)    # 60%는 키워드·주제와 맞는 사진
        take(fresh, n, True)                              # 나머지는 다른 사진도 무작위로 섞음 (같은 사진만 계속 쓰지 않게)
        take(matching, n, True)       # 1) 맞는 사진 중 무작위 (최근 안 쓴 것)
        if len(out) < lo:
            take(fresh, lo, True)                           # 2) 최근 안 쓴 다른 사진
        if len(out) < lo:
            take(fresh, lo, False)
        if len(out) < lo:                                   # 3) 사진이 적을 때만: 오래전에 쓴 사진 (덜 쓴 것부터)
            take(sorted(cands, key=lambda c: any_recent.get(c[2]["id"], "")), lo, False)
        out.sort(key=lambda o: -o["match"] + rng.random() * 0.5)   # 잘 맞는 사진이 앞쪽, 순서도 조금씩 섞음
        return out
    finally:
        if own:
            con.close()


def variant_dir():
    d = os.path.join(lib_dir(), "v")
    os.makedirs(d, exist_ok=True)
    return d


def make_variant(path, rng=None):
    """글마다 다른 사진 파일: 아주 조금 자르기·크기·밝기·화질을 무작위로 바꿔 새로 저장 (눈으로는 같은 사진, 파일은 매번 다름 → 같은 사진 반복 감지 방지).
    위치정보 없이 저장. 실패하면 원본 경로"""
    import random as _r
    from PIL import Image, ImageEnhance
    rng = rng or _r.Random()
    try:
        with Image.open(path) as im:
            im = im.convert("RGB")
            w, h = im.size
            cx, cy = int(w * rng.uniform(0.01, 0.04)), int(h * rng.uniform(0.01, 0.04))
            ox, oy = rng.randint(0, cx), rng.randint(0, cy)
            im = im.crop((ox, oy, w - (cx - ox), h - (cy - oy)))
            sc = rng.uniform(0.94, 1.0)
            im = im.resize((max(1, int(im.width * sc)), max(1, int(im.height * sc))), Image.LANCZOS)
            im = ImageEnhance.Brightness(im).enhance(rng.uniform(0.97, 1.04))
            im = ImageEnhance.Contrast(im).enhance(rng.uniform(0.97, 1.04))
            stem = os.path.splitext(os.path.basename(path))[0][:40]
            name = f"{stem}-v{rng.randrange(16 ** 6):06x}.jpg"
            out = os.path.join(variant_dir(), name)
            im.save(out, "JPEG", quality=rng.randint(85, 92), exif=b"")
            return out, name
    except Exception:  # noqa: BLE001
        return path, os.path.basename(path)


def as_images(photos, cfg, variants=None):
    """발행용 이미지 목록. 기본은 글마다 살짝 다른 사본(variant)을 만들어 씀 (설정 library.uniqueCopies=false 면 원본)"""
    import urllib.parse
    base = (cfg.get("images") or {}).get("publicBaseUrl", "").rstrip("/")
    if variants is None:
        variants = (cfg.get("library") or {}).get("uniqueCopies", True)
    out = []
    for p in photos:
        path, name = make_variant(p["path"]) if variants else (p["path"], p["file"])
        out.append({"path": path, "hash": p["sha"], "source": "library", "credit": "", "name": name,
                    "public_url": f"{base}/{urllib.parse.quote(name)}" if base else "",
                    "photoId": p["id"], "labels": p["labels"], "caption": p.get("caption", ""), "orig": p["file"]})
    return out


def cleanup_variants(days=21):
    """올린 지 오래된 사진 사본 정리 (아직 올리지 않은 작업이 쓰는 것은 남김)"""
    from .tasks import files_in_use
    keep, cut, n = files_in_use(), time.time() - days * 86400, 0
    for f in os.listdir(variant_dir()):
        fp = os.path.join(variant_dir(), f)
        if f not in keep and os.path.getmtime(fp) < cut:
            try:
                os.remove(fp)
                n += 1
            except OSError:
                pass
    return n


# ---------------- 키워드로 사진 가져오기 (사장님 자료함 + 사장님 블로그 글 속 사진만) ----------------
def search_photos(keyword, con=None):
    toks = [w for w in re.findall(r"[가-힣A-Za-z0-9]{2,}", keyword or "")]
    if not toks:
        return []
    out = []
    for p in list_photos(con):
        if p.get("source") == "ci":
            continue
        hay = " ".join(p["labels"]) + " " + (p.get("caption") or "") + " " + (p.get("name") or "")
        if any(t in hay for t in toks):
            out.append(p)
    return out


def _own_blog_images(cfg, keyword, limit):
    """연결한 사장님 블로그(네이버·손님용·티스토리) 공개 글 중 키워드가 들어간 글의 사진 주소"""
    import html as H
    import requests
    from . import accounts as A
    toks = [w for w in re.findall(r"[가-힣A-Za-z0-9]{2,}", keyword or "")]
    urls = []
    for ch in ("naver", "guide", "tistory"):
        for a in A.list_accounts(cfg, ch):
            h = a.get("handle")
            if not h:
                continue
            rss = ((os.environ.get("AUTOPOST_TISTORY_RSS_URL") or "https://{id}.tistory.com/rss") if ch == "tistory"
                   else (os.environ.get("AUTOPOST_NAVER_RSS_URL") or "https://rss.blog.naver.com/{id}.xml")).replace("{id}", h)
            try:
                x = requests.get(rss, timeout=20, headers={"User-Agent": "Mozilla/5.0"}).text
            except Exception:  # noqa: BLE001
                continue
            for it in re.findall(r"<item>(.*?)</item>", x, flags=re.S)[:40]:
                text = H.unescape(re.sub(r"<!\[CDATA\[|\]\]>", "", it))
                if toks and not any(t in text for t in toks):
                    continue
                for u in re.findall(r"<img[^>]+src=[\"']([^\"']+)", text):
                    urls.append((u, "https://blog.naver.com/" if ch != "tistory" else f"https://{h}.tistory.com/"))
                m = re.search(r"/(\d{9,})", text)
                if ch != "tistory" and m:
                    post = (os.environ.get("AUTOPOST_NAVER_POST_URL") or "https://m.blog.naver.com/{id}/{no}").replace("{id}", h).replace("{no}", m.group(1))
                    try:
                        page = requests.get(post, timeout=20, headers={"User-Agent": "Mozilla/5.0"}).text
                        for u in re.findall(r'(?:data-lazy-src|src)="(https?://[^"]+?\.(?:jpe?g|png|webp|JPE?G|PNG)[^"]*)"', page):
                            if "postfiles" in u or "blogfiles" in u or "pstatic" in u or "/_uploads/" in u:
                                urls.append((u, "https://m.blog.naver.com/"))
                    except Exception:  # noqa: BLE001
                        pass
                if len(urls) >= limit * 3:
                    break
    return list(dict.fromkeys(urls))


def pull_by_keyword(cfg, keyword, limit=12):
    """키워드로 사진 모으기: ① 자료함에서 찾기 ② 사장님 블로그 글 속 사진 내려받기(위치정보 제거, 키워드 라벨)
    ※ 다른 사람 블로그·검색 결과 사진은 저작권 때문에 가져오지 않음"""
    import requests
    keyword = re.sub(r"\s+", " ", keyword or "").strip()[:40]
    if len(keyword) < 2:
        raise ValueError("키워드를 2글자 이상 넣어 주세요")
    found = search_photos(keyword)
    added = []
    for u, ref in _own_blog_images(cfg, keyword, limit):
        if len(added) >= limit:
            break
        try:
            r = requests.get(u.replace("?type=w80_blur", "?type=w966"), timeout=30, headers={"User-Agent": "Mozilla/5.0", "Referer": ref})
            if r.status_code != 200 or len(r.content) < 2000:
                continue
            p, created = add_photo(r.content, f"{keyword}-{os.path.basename(u.split('?')[0])[:40] or 'blog.jpg'}", cfg, source="myblog", hint=keyword, label=True)
        except (ValueError, requests.RequestException):
            continue
        tag = re.sub(r"\s+", "", keyword)[:12]
        if tag not in p["labels"]:
            set_labels(p["id"], p["labels"][:1] + [tag] + p["labels"][1:], p.get("caption", ""), p.get("label_src") or "keyword")
        if created:
            added.append(get_photo(p["id"]))
    for p in found:   # 자료함에 있던 사진도 키워드 라벨을 붙여 다음 글에서 잘 골라지게
        tag = re.sub(r"\s+", "", keyword)[:12]
        if tag not in p["labels"]:
            set_labels(p["id"], p["labels"][:1] + [tag] + p["labels"][1:], p.get("caption", ""), p.get("label_src") or "keyword")
    from .util import log
    log("INFO", f"[자료함] 키워드 '{keyword}' 사진: 자료함 {len(found)}장 + 내 블로그에서 새로 {len(added)}장")
    return {"found": [get_photo(p["id"]) for p in found], "added": added}


def record_usage(channel, account, keyword, images, title, topic, task_id=None, dry=False):
    con = _con()
    try:
        con.execute("INSERT INTO material_usage(ts,channel,account,keyword,photo_ids,title,topic,task_id,dry) VALUES(?,?,?,?,?,?,?,?,?)",
                    (datetime.now().isoformat(timespec="seconds"), channel, account or "", keyword,
                     json.dumps([i["photoId"] for i in images if i.get("photoId")]), title, topic, task_id, int(dry)))
        con.commit()
    finally:
        con.close()


def usage_list(limit=50):
    con = _con()
    try:
        rows = con.execute("SELECT ts,channel,account,keyword,photo_ids,title,topic,dry FROM material_usage ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    finally:
        con.close()
    return [{"ts": r[0], "channel": r[1], "account": r[2], "keyword": r[3], "photoIds": json.loads(r[4] or "[]"), "title": r[5], "topic": r[6], "dry": bool(r[7])}
            for r in rows]


def summary():
    ps = [p for p in list_photos() if p.get("source") != "ci"]
    counts = {}
    for p in ps:
        for lab in p["labels"]:
            counts[lab] = counts.get(lab, 0) + 1
    return {"photos": len(ps), "labels": dict(sorted(counts.items(), key=lambda x: -x[1])),
            "vision": sum(1 for p in ps if p["labelSrc"] == "vision"), "place": sum(1 for p in ps if p["source"] == "place")}


# ---------------- 기업 CI (로고) : 글마다 항상 넣는 이미지 ----------------
CI_CHANNELS = ("naver", "guide", "tistory", "wonju")   # 사진을 글 속에 넣는 블로그 채널 (카페·밴드·SNS 는 제외)


def ci_settings(cfg):
    return {"enabled": True, "position": "bottom", "which": "wide", **(cfg.get("ci") or {})}


def ci_photos(con=None):
    return [p for p in list_photos(con) if p.get("source") == "ci"]


def mark_ci(pid, kind):
    """사진을 CI 로 지정(kind: wide|icon). 같은 종류의 예전 CI 는 지움"""
    caption = "아이콘 로고" if kind == "icon" else "가로형 로고"
    for old in ci_photos():
        if old["id"] != pid and (old.get("caption") or "") == caption:
            delete_photo(old["id"])
    con = _con()
    try:
        con.execute("UPDATE library_photos SET source='ci' WHERE id=?", (pid,))
        con.commit()
    finally:
        con.close()
    set_labels(pid, ["CI"], caption, "manual")
    return get_photo(pid)


def ensure_default_ci(cfg):
    """처음 한 번: 프로그램에 들어 있는 원주통닭 CI(가로형·아이콘)를 자료함 CI 로 등록"""
    from . import paths
    if ci_photos() or (cfg.get("ci") or {}).get("defaultImported"):
        return 0
    d = os.path.join(paths.resource_dir(), "assets", "ci")
    n = 0
    if os.path.isdir(d):
        for f in sorted(os.listdir(d)):
            if f.lower().endswith((".jpg", ".jpeg", ".png")):
                with open(os.path.join(d, f), "rb") as fh:
                    p, created = add_photo(fh.read(), f, cfg, source="ci", label=False)
                mark_ci(p["id"], "wide" if "wide" in f else "icon")
                n += int(created)
    from .util import load_config, save_config
    c2 = load_config()
    c2.setdefault("ci", {})["defaultImported"] = True
    save_config(c2)
    return n


def pick_ci(cfg):
    """설정에 맞는 CI 사진 (가로형/아이콘/번갈아). 없거나 꺼져 있으면 None"""
    st = ci_settings(cfg)
    if not st.get("enabled", True):
        return None
    cis = ci_photos()
    if not cis:
        return None
    want = st.get("which", "wide")
    if want == "random":
        import random as _r
        return _r.choice(cis)
    key = "아이콘" if want == "icon" else "가로"
    return next((p for p in cis if key in (p.get("caption") or "") or ("icon" if want == "icon" else "wide") in (p.get("name") or "")), cis[0])
