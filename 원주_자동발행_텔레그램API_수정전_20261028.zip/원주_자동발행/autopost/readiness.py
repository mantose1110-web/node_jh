# -*- coding: utf-8 -*-
"""채널·계정별 '연결됨' 여부. 연결 안 된 계정은 글을 만들지 않고 '연결 필요'로 기다림"""
from datetime import datetime
from . import accounts as A, secure
from .util import BROWSER_CHANNELS

STATE_TEXT = {
    "waiting": "로그인 창에서 로그인해 주세요 (로그인하면 자동으로 확인돼요)",
    "verifying": "글쓰기 화면 확인 중…",
    "notfound": "로그인이 확인되지 않았어요 - '연결하기'를 다시 눌러 주세요",
    "expired": "로그인이 풀렸어요 - '연결하기'를 다시 눌러 주세요",
    "failed": "연결 실패 - '연결하기'를 다시 눌러 주세요",
    "timeout": "10분 동안 로그인이 없어 창을 닫았어요 - 다시 연결해 주세요",
    "cancelled": "로그인 창이 닫혔어요 - 다시 연결해 주세요",
}


def account_status(cfg, ch, acc, env=None, ss=None):
    aid = acc["id"]
    if ch in BROWSER_CHANNELS:
        from .connect import is_waiting, session_status
        from .browser import load_cookies
        ss = session_status() if ss is None else ss
        prof = A.profile_name(ch, aid)
        s = dict(ss.get(prof, {}))
        st = s.get("state")
        if is_waiting(prof):
            st = st if st in ("waiting", "verifying") else "waiting"
        elif st in ("waiting", "verifying"):   # 앱 재시작 등으로 남은 오래된 표시
            st = "connected" if s.get("ok") else "notfound"
        ok = bool(s.get("ok") and st == "connected" and acc.get("handle") and load_cookies(prof))
        if ok and ch == "cafe" and not (acc.get("boardsSelected") or [(acc.get("board") or {})])[0].get("name"):
            from .publishers.cafe import parse_handle
            if not parse_handle(acc.get("handle", ""))[2]:
                return {"ok": False, "waiting": False, "state": "board", "text": "로그인됨 - '게시판 불러오기'로 올릴 게시판을 골라 주세요"}
        if ok:
            text = "연결됨"
        elif st in STATE_TEXT:
            text = STATE_TEXT[st] + (f" ({s['error']})" if s.get("error") and st == "failed" else "")
        elif not acc.get("handle") and ch == "tistory":
            text = "블로그 주소 입력 후 '연결하기'"
        elif not acc.get("handle") and ch == "cafe":
            text = "카페 글쓰기 주소 입력 후 '연결하기'"
        else:
            text = "연결 안 됨 - '연결하기'를 눌러 로그인해 주세요"
        return {"ok": ok, "waiting": st in ("waiting", "verifying"), "state": st or "none", "text": text}
    if ch == "instagram":
        env = secure.all_values() if env is None else env
        uid, tok, exp = (env.get(A.env_key(k, aid)) for k in A.IG_ENV)
        try:
            left = (datetime.fromisoformat(exp) - datetime.now()).days if exp else None
        except ValueError:
            left = None
        ok = bool(uid and tok and (left is None or left >= 0))
        text = ((f"연결됨 (토큰 {left}일 남음, 자동 갱신)" if left is not None else "연결됨") if ok
                else "토큰 만료 - 다시 연결해 주세요" if (uid and tok) else "연결 안 됨 - 토큰을 붙여넣고 '연결'")
        return {"ok": ok, "waiting": False, "state": "connected" if ok else "none", "text": text}
    if ch == "x":
        env = secure.all_values() if env is None else env
        from .connect import session_status
        ss = session_status() if ss is None else ss
        has = bool(env.get("X_API_KEY") and env.get("X_API_SECRET") and all(env.get(A.env_key(k, aid)) for k in A.X_ENV))
        s = ss.get(A.profile_name("x", aid), {})
        ok = has and bool(s.get("ok"))
        text = (f"연결됨 (@{s.get('username', '')})" if ok else "앱 키·계정 토큰을 넣고 '연결 확인'을 눌러 주세요" if not has
                else ("연결 확인 실패: " + s.get("error", "") if s.get("error") else "'연결 확인'을 눌러 주세요"))
        return {"ok": ok, "waiting": False, "state": "connected" if ok else "none", "text": text}
    if ch == "manual":   # 원고만 만드는 채널: 연결이 필요 없음
        from .publishers.social import MANUAL_TARGETS
        return {"ok": True, "waiting": False, "state": "connected",
                "text": f"원고 만들기 ({MANUAL_TARGETS.get(acc.get('handle') or 'daangn', MANUAL_TARGETS['daangn'])[0]})"}
    if ch in ("threads", "facebook", "band"):
        env = secure.all_values() if env is None else env
        from .connect import session_status
        from .publishers.social import TOKEN_KEY
        ss = session_status() if ss is None else ss
        has = bool(env.get(A.env_key(TOKEN_KEY[ch], aid)))
        s = ss.get(A.profile_name(ch, aid), {})
        ok = has and bool(s.get("ok")) and (ch != "band" or bool(acc.get("handle")))
        text = (f"연결됨 ({s.get('username', '')})" if ok else "토큰을 넣고 '연결 확인'을 눌러 주세요" if not has
                else "'밴드 불러오기'로 올릴 밴드를 골라 주세요" if ch == "band" and s.get("ok") and not acc.get("handle")
                else ("연결 확인 실패: " + s.get("error", "") if s.get("error") else "'연결 확인'을 눌러 주세요"))
        return {"ok": ok, "waiting": False, "state": "connected" if ok else "none", "text": text}
    if ch == "wonju":
        env = secure.all_values() if env is None else env
        from .connect import session_status
        ss = session_status() if ss is None else ss
        has = bool(env.get("FTP_HOST") and env.get("FTP_USER") and env.get("FTP_PASSWORD"))
        ok = has and bool(ss.get("wonju", {}).get("ok"))
        text = "FTP 연결됨" if ok else ("FTP 정보를 넣고 '접속 테스트'를 눌러 주세요" if not has else "'접속 테스트'를 눌러 주세요")
        return {"ok": ok, "waiting": False, "state": "connected" if ok else "none", "text": text}
    raise ValueError(ch)


def channel_status(cfg):
    from .connect import session_status
    from .util import CHANNELS
    ss, env = session_status(), secure.all_values()
    st = {}
    for ch in CHANNELS:
        accs = {a["id"]: account_status(cfg, ch, a, env, ss) for a in A.list_accounts(cfg, ch)}
        n_ok = sum(1 for v in accs.values() if v["ok"])
        st[ch] = {"ok": n_ok > 0, "waiting": any(v["waiting"] for v in accs.values()), "accounts": accs,
                  "text": (f"{n_ok}/{len(accs)}개 계정 연결됨" if len(accs) > 1 else next(iter(accs.values()))["text"])}
    return st


def account_ready(cfg, ch, aid):
    acc = A.get(cfg, ch, aid)
    if not acc:
        return {"ok": False, "text": "계정 없음"}
    return account_status(cfg, ch, acc)


def live_check(cfg):
    """(켤 수 있음, 준비 안 된 계정[(이름, 이유)]) — 연결된 계정이 하나라도 있으면 켤 수 있음"""
    from .util import CH_NAME
    st = channel_status(cfg)
    any_ok, missing = False, []
    for ch, v in st.items():
        for aid, s in v["accounts"].items():
            acc = A.get(cfg, ch, aid)
            if not acc or not acc.get("enabled", True) or not int(acc.get("postsPerDay") or 0):
                continue
            if s["ok"]:
                any_ok = True
            else:
                missing.append((CH_NAME[ch] + " " + A.label(cfg, ch, aid), s["text"]))
    return any_ok, missing
