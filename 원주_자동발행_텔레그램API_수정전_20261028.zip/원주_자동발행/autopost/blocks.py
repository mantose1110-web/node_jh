# -*- coding: utf-8 -*-
"""마케팅 블록(전화·주문·길찾기·원주.kr 링크)과 장소(네이버 플레이스) 카드 삽입"""
import html as H
import re


def default_blocks(shop):
    tel = re.sub(r"[^0-9]", "", shop.get("phone", ""))
    pid = shop.get("naverPlaceId", "")
    return [
        {"id": "basic", "name": "기본 안내 (전화·길찾기·홈페이지)", "text": "포장·예약 문의는 전화 주세요. 홈페이지에서 메뉴와 위치를 확인하실 수 있어요.",
         "buttons": [{"label": f"📞 전화 {shop.get('phone', '')}", "url": f"tel:{tel}"},
                     {"label": "🗺 길찾기", "url": f"https://map.naver.com/p/entry/place/{pid}" if pid else ""},
                     {"label": "🍗 원주.kr 메뉴 보기", "url": shop.get("url", "https://원주.kr")}]},
        {"id": "takeout", "name": "포장 안내", "text": "전화로 미리 주문하시면 기다리지 않고 바로 가져가실 수 있어요.",
         "buttons": [{"label": "📞 포장 주문 전화", "url": f"tel:{tel}"}]},
        {"id": "group", "name": "모임·회식 예약 안내", "text": "모임·회식은 미리 전화로 예약해 주시면 자리를 준비해 둘게요.",
         "buttons": [{"label": "📞 예약 전화", "url": f"tel:{tel}"}]},
        {"id": "visit", "name": "찾아오는 길·주차", "text": " ".join(x for x in (shop.get("nearby", ""), "무료 주차 가능해요." if (shop.get("services") or {}).get("무료주차") else "") if x),
         "buttons": [{"label": "🗺 네이버 지도 길찾기", "url": f"https://map.naver.com/p/entry/place/{pid}" if pid else ""}]},
        {"id": "hours", "name": "영업시간 안내", "text": f"영업시간: {shop.get('hours', '')}",
         "buttons": [{"label": f"📞 {shop.get('phone', '')}", "url": f"tel:{tel}"}, {"label": "🗺 위치 보기", "url": f"https://map.naver.com/p/entry/place/{pid}" if pid else ""}]},
        {"id": "follow", "name": "가게 소식 받기 (홈페이지·플레이스)", "text": "새 메뉴·영업 소식은 홈페이지와 네이버 플레이스에서 먼저 알려 드려요.",
         "buttons": [{"label": "🍗 원주.kr", "url": shop.get("url", "https://원주.kr")}, {"label": "📍 네이버 플레이스", "url": f"https://map.naver.com/p/entry/place/{pid}" if pid else ""}]},
    ]


# 글 주제별로 어울리는 마케팅 블록 (블록을 '주제에 맞게 자동'으로 고르면 이 표를 씀 - 마케팅 관리에서 바꿀 수 있음)
DEFAULT_TOPIC_BLOCKS = {
    "이용안내": "visit", "찾아오는길주차": "visit", "동네정보": "visit", "동네와함께": "visit",
    "포장예약방법": "takeout", "고민해결": "takeout", "고민해결안내": "takeout", "오늘튀긴닭": "takeout",
    "영업시간이용팁": "hours", "상황별추천": "group", "손님모습": "group",
    "메뉴소개": "basic", "메뉴가격안내": "basic", "특장점안내": "basic", "특장점정리": "basic",
    "비하인드": "follow", "매장일상": "follow", "오늘의일상": "follow",
}


def all_blocks(cfg):
    """저장한 블록 + (업데이트로 새로 생긴 기본 블록 중 사장님이 지우지 않은 것)"""
    m = cfg.get("marketing") or {}
    saved = m.get("blocks") or []
    if not saved:
        return default_blocks(cfg["shop"])
    have, removed = {b.get("id") for b in saved}, set(m.get("blocksRemoved") or [])
    return saved + [b for b in default_blocks(cfg["shop"]) if b["id"] not in have and b["id"] not in removed]


def topic_blocks(cfg):
    return {**DEFAULT_TOPIC_BLOCKS, **((cfg.get("marketing") or {}).get("topicBlocks") or {})}


def resolve(cfg, bid, topic):
    """'auto' → 글 주제에 맞는 블록 id"""
    if bid != "auto":
        return bid
    return topic_blocks(cfg).get(topic or "", "basic")


def get(cfg, bid):
    """설정의 마케팅 블록 (없으면 기본 블록)"""
    if not bid:
        return None
    return next((b for b in all_blocks(cfg) if b.get("id") == bid), None)


def render_block(b, channel):
    """채널별 표현: html(홈페이지·티스토리) / 네이버·인스타는 텍스트+링크"""
    btns = [x for x in b.get("buttons", []) if x.get("url")]
    if channel in ("naver", "guide", "cafe", "instagram"):   # 네이버 계열은 HTML 버튼이 안 됨 → 글자 + 주소
        lines = [b.get("text", "")] + [f"{x['label']} {x['url'] if not x['url'].startswith('tel:') else ''}".strip() for x in btns]
        return "<p>" + "<br>".join(H.escape(l) for l in lines if l) + "</p>"
    btn_html = "".join(f'<a href="{H.escape(x["url"])}" style="display:inline-block;margin:4px;padding:10px 14px;border-radius:10px;background:#d9480f;color:#fff;text-decoration:none">{H.escape(x["label"])}</a>' for x in btns)
    return f'<div class="promo" style="border:1px solid #eee;border-radius:12px;padding:14px;margin:16px 0;background:#fffaf5"><p>{H.escape(b.get("text", ""))}</p>{btn_html}</div>'


def place_card(shop, channel, with_url=True):
    pid = shop.get("naverPlaceId")
    if not pid:
        return ""
    url = f"https://map.naver.com/p/entry/place/{pid}"
    lines = [f"📍 {shop.get('name', '')}", shop.get("address", ""), f"영업시간 {shop.get('hours', '')}", f"전화 {shop.get('phone', '')}", shop.get("nearby", "")]
    if channel in ("naver", "guide", "cafe", "instagram"):
        # 네이버는 주소를 넣으면 링크 카드가 생김 → 위 블록에 같은 지도 주소가 있으면 한 번만
        return "<p>" + "<br>".join(H.escape(x) for x in lines if x) + (f"<br>네이버 지도: {url}" if with_url else "") + "</p>"
    return ('<div class="place" style="border:1px solid #e5e5e5;border-radius:12px;padding:14px;margin:16px 0">'
            + "".join(f"<div>{H.escape(x)}</div>" for x in lines if x)
            + f'<a href="{url}" style="color:#03c75a;font-weight:700">네이버 지도에서 보기 →</a></div>')


def summary_lines(shop):
    """가게 한눈에 보기 (가게 정보에 있는 것만)"""
    menu = [m for m in shop.get("menu") or [] if isinstance(m, dict) and m.get("name")]
    main = [f"{m['name']} {m['price']}" if m.get("price") else m["name"] for m in menu if m.get("price")][:4] or [m["name"] for m in menu][:4]
    svc = [k for k, v in (shop.get("services") or {}).items() if v]
    since = re.sub(r"\s*영업$", "", shop.get("since", "")).strip()
    lines = [f"🍗 {shop.get('name', '')} 한눈에 보기" + (f" ({since})" if since else "")]
    if shop.get("address"):
        lines.append(f"📍 {shop['address']}" + (f" · {shop['nearby']}" if shop.get("nearby") else ""))
    if shop.get("hours"):
        lines.append(f"⏰ {shop['hours']}")
    if main:
        lines.append("🍗 대표 메뉴: " + " · ".join(main))
    if svc:
        lines.append("✅ " + " · ".join(("무료 주차" if k == "무료주차" else k) for k in svc))
    if shop.get("phone"):
        lines.append(f"📞 {shop['phone']}")
    return lines


def summary_card(shop, channel):
    """글 맨 위에 붙는 '가게 한눈에 보기' 카드 (네이버 계열은 글자, 홈페이지·티스토리는 상자)"""
    lines = summary_lines(shop)
    if len(lines) < 3:
        return ""
    if channel in ("naver", "guide", "cafe", "instagram"):
        bar = "━━━━━━━━━━━━━━━━"
        return f"<p>{bar}</p><h3>{H.escape(lines[0])}</h3>" + "".join(f"<p>{H.escape(x)}</p>" for x in lines[1:]) + f"<p>{bar}</p>"
    rows = "".join(f'<div style="padding:4px 0">{H.escape(x)}</div>' for x in lines[1:])
    return ('<div class="shop-card" style="border:2px solid #f08c00;border-radius:14px;padding:14px 16px;margin:0 0 18px;background:#fff9f0;line-height:1.7">'
            f'<div style="font-weight:800;font-size:1.1em;margin-bottom:6px">{H.escape(lines[0])}</div>{rows}</div>')


def apply(body_html, channel, shop, block=None, position="bottom", place=False, summary=False):
    """position: top | bottom | img1..img7 (N번째 이미지 아래)"""
    if block:
        piece = render_block(block, channel)
        m = re.match(r"img(\d)", position or "")
        if position == "top":
            body_html = piece + body_html
        elif m and f"[[IMG:{int(m.group(1)) - 1}]]" in body_html:
            mk = f"[[IMG:{int(m.group(1)) - 1}]]"
            body_html = body_html.replace(mk, mk + piece, 1)
        else:
            body_html = body_html + piece
    if summary:
        body_html = summary_card(shop, channel) + body_html
    if place:
        pid = shop.get("naverPlaceId")
        has_url = bool(pid and f"place/{pid}" in body_html)
        if summary:   # 위에 '한눈에 보기'가 있으니 아래에는 지도 링크만
            if pid and not has_url:
                url = f"https://map.naver.com/p/entry/place/{pid}"
                body_html += (f"<p>🗺 네이버 지도: {url}</p>" if channel in ("naver", "guide", "cafe", "instagram")
                              else f'<p><a href="{url}">🗺 네이버 지도에서 보기 →</a></p>')
        else:
            body_html += place_card(shop, channel, with_url=not has_url)
    return body_html
