# -*- coding: utf-8 -*-
"""아산 원주통닭(충남 아산 온천동 본점) - AI 글 생성기

※ 상호 '원주통닭'의 '원주'는 지명이 아닙니다. 가게는 충남 아산시 시민로 386(온천동), 홈페이지는 원주.kr(xn--sp5bu3b.kr)
※ 가게 사실은 config.json 의 shop 항목(플레이스에서 가져오거나 사장님이 고친 값)만 사용합니다.

- 키워드: 계정별로 돌려 쓰고, 그 계정이 최근 쓴 키워드와 오늘 다른 계정이 쓴 키워드는 피함
- 구성(템플릿×구조×말투×주제)과 계정별 목소리를 바꿔 글마다·계정마다 다른 글
- 사진: 자료함에서 키워드·주제에 맞는 3~6장을 골라 [[IMG:n]] 자리에 배치
- Claude 키가 없으면 '테스트 모드'에서만 예시 글(mock)을 만듦 (실제 발행용으로는 절대 안 씀)
"""
import csv, json, os, random, re, sqlite3, time
from datetime import datetime, timedelta, date

from . import paths
ROOT = paths.data_dir()      # 쓰기 가능한 데이터 폴더 (설정·DB·로그). 테스트에서 바꿀 수 있음
RES = paths.resource_dir()   # 읽기 전용 리소스 (기본 스타일·샘플 키워드)
from .compliance import check_text, PROMPT_RULES

PRIORITY_W = {"A": 5.0, "B": 3.0, "C": 1.0}


def load_config():
    """설정 읽기. 파일이 깨졌으면(정전·강제 종료 등) 깨진 파일은 따로 보관하고 마지막 정상 설정 → 기본 설정으로 되살림"""
    p = os.path.join(ROOT, "config.json")
    try:
        with open(p, encoding="utf-8") as f:
            cfg = json.load(f)
        if not isinstance(cfg, dict) or "shop" not in cfg:
            raise ValueError("설정 내용이 비었음")
        return cfg
    except FileNotFoundError:
        raise
    except (ValueError, UnicodeDecodeError) as e:
        import shutil
        from .util import log
        bad = p + f".broken-{datetime.now():%Y%m%d-%H%M%S}"
        try:
            shutil.copy(p, bad)
        except OSError:
            pass
        for src in (p + ".lastgood", os.path.join(RES, "config.json")):
            try:
                with open(src, encoding="utf-8") as f:
                    cfg = json.load(f)
                if isinstance(cfg, dict) and "shop" in cfg:
                    shutil.copy(src, p)
                    log("ERROR", f"설정 파일이 깨져 있어서({str(e)[:60]}) {'마지막 정상 설정' if src.endswith('lastgood') else '기본 설정'}으로 되살렸어요 (깨진 파일: {os.path.basename(bad)})")
                    return cfg
            except (OSError, ValueError):
                continue
        raise


def resolve(p):
    """상대경로: 데이터 폴더에 있으면 그것, 없으면 리소스 폴더"""
    if os.path.isabs(p):
        return p
    d = os.path.normpath(os.path.join(ROOT, p))
    return d if os.path.exists(d) else os.path.normpath(os.path.join(RES, p))


def db():
    os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
    con = sqlite3.connect(os.path.join(ROOT, "data", "history.db"), timeout=30)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, ts TEXT, channel TEXT, keyword TEXT, title TEXT,
        fingerprint TEXT, structure TEXT, dry INTEGER, account TEXT, material TEXT);
    CREATE TABLE IF NOT EXISTS style_usage(id INTEGER PRIMARY KEY, ts TEXT, channel TEXT, combo TEXT,
        template_id TEXT, structure TEXT, tone TEXT, topic TEXT, account TEXT);
    CREATE TABLE IF NOT EXISTS llm_usage(id INTEGER PRIMARY KEY, ts TEXT, provider TEXT, model TEXT, channel TEXT, account TEXT,
        keyword TEXT, input_tokens INTEGER, output_tokens INTEGER, cache_write INTEGER, cache_read INTEGER);""")
    for tbl, col in (("posts", "account TEXT"), ("style_usage", "account TEXT"), ("posts", "material TEXT"), ("posts", "body TEXT")):  # 예전 DB 호환
        try:
            con.execute(f"ALTER TABLE {tbl} ADD COLUMN {col}")
        except sqlite3.OperationalError:
            pass
    return con


# ---------------- 키워드 ----------------
def _weight(raw):
    raw = (raw or "").strip().upper()
    if raw in PRIORITY_W:
        return PRIORITY_W[raw]
    try:
        return max(float(raw), 0.1)
    except ValueError:
        return 1.0


def load_keywords(cfg):
    """sources 순서대로 '존재하는 첫 파일'을 읽음. 열: group, keyword, status, priority(A/B/C 또는 숫자), note"""
    rows, used = [], None
    for p in [resolve(p) for p in cfg["keywords"]["sources"]]:
        if not os.path.exists(p):
            continue
        used = p
        with open(p, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                k = (r.get("keyword") or r.get("키워드") or "").strip()
                if not k:
                    continue
                w = _weight(r.get("priority") or r.get("우선순위"))
                if (r.get("status") or "").startswith("제안"):
                    w *= 0.7
                rows.append({"keyword": k, "weight": w, "group": (r.get("group") or "").strip(),
                             "intent": (r.get("intent") or r.get("note") or "").strip()[:80]})
        break
    seen, out = set(), []
    for r in rows:
        if r["keyword"] not in seen:
            seen.add(r["keyword"])
            out.append(r)
    return out, used


def keyword_pool(cfg):
    """대시보드 목록용: 제외 규칙 적용한 전체 키워드 + 직접 추가"""
    kws, src = load_keywords(cfg)
    ex = cfg["keywords"].get("excludeKeywordRegex")
    kws = [k for k in kws if not (ex and re.search(ex, k["keyword"]))]
    have = {k["keyword"] for k in kws}
    kws += [{"keyword": c, "weight": 3.0, "group": "직접 추가", "intent": ""} for c in cfg["keywords"].get("custom", []) if c not in have]
    return kws, src


def _in_window(today, ev):
    def parse(s):
        return date.fromisoformat(s) if len(s) == 10 else date(today.year, int(s[:2]), int(s[3:5]))
    try:
        s, e = parse(ev["start"]), parse(ev["end"])
    except (KeyError, ValueError):
        return False
    if e < s:
        e = date(e.year + 1, e.month, e.day)
    return s - timedelta(days=ev.get("leadDays", 14)) <= today <= e + timedelta(days=ev.get("afterDays", 3))


def apply_seasonal(kws, cfg, today=None):
    today = today or date.today()
    events = [ev for ev in cfg.get("seasonal", []) if ev.get("enabled", True)]
    out = []
    for k in kws:
        w = k["weight"]
        for ev in events:
            if re.search(ev["match"], k["keyword"]):
                w = w * ev.get("boost", 3) if _in_window(today, ev) else w * ev.get("offSeasonFactor", 0.2)
        out.append({**k, "weight": w})
    return out


# ---------------- 시즌·이벤트 캠페인 (마케팅 관리에서 켜고 끄고 고칠 수 있음) ----------------
DEFAULT_CAMPAIGNS = [
    {"id": "yearend", "name": "연말 모임", "start": "12-01", "end": "12-31", "enabled": True,
     "theme": "연말 모임·회식 시즌. 여럿이 나눠 먹기 좋은 메뉴 조합, 예약·포장 안내(가게 정보에 있는 서비스만).",
     "keywords": ["아산 연말 모임", "아산 회식 치킨", "온양 송년회 장소"]},
    {"id": "xmas", "name": "크리스마스", "start": "12-18", "end": "12-25", "enabled": True,
     "theme": "크리스마스 가족 저녁·포장. 할인·이벤트는 사장님이 따로 적은 경우에만.", "keywords": ["아산 크리스마스 치킨", "크리스마스 포장 치킨 아산"]},
    {"id": "winter", "name": "겨울 야식", "start": "12-01", "end": "02-28", "enabled": True,
     "theme": "추운 겨울 밤 따끈한 통닭 야식, 포장해 가는 길 식지 않게 하는 팁.", "keywords": ["아산 겨울 야식", "온양 야식 포장"]},
    {"id": "suneung", "name": "시험 끝 가족 저녁", "start": "11-10", "end": "11-30", "enabled": True,
     "theme": "시험이 끝난 학생과 가족의 저녁 한 끼. 응원 메시지는 담백하게.", "keywords": ["수능 끝나고 치킨", "아산 가족 외식"]},
    {"id": "spring", "name": "봄 나들이", "start": "04-01", "end": "05-15", "enabled": True,
     "theme": "신정호·현충사 등 아산 나들이 뒤 저녁(거리·동선은 사실만, 모르면 쓰지 않음).",
     "keywords": ["신정호 근처 맛집", "현충사 근처 맛집", "아산 나들이 저녁"]},
    {"id": "family", "name": "가정의 달", "start": "05-01", "end": "05-31", "enabled": True,
     "theme": "어린이날·어버이날 가족 외식. 아이와 함께 먹기 좋은 메뉴(가게 메뉴만).", "keywords": ["아산 가족 외식", "어버이날 외식 아산"]},
    {"id": "summer", "name": "여름 밤 야식", "start": "06-15", "end": "08-31", "enabled": True,
     "theme": "더운 여름 밤 야식·포장. 술은 가게 정보에 있을 때만 언급하고 과음 권하지 않기.", "keywords": ["아산 여름 야식", "아산 야식 포장"]},
    {"id": "holiday", "name": "명절 연휴 (날짜 직접 입력)", "start": "2027-02-05", "end": "2027-02-09", "enabled": False,
     "theme": "명절 연휴 영업 안내와 가족 모임 야식. 영업일·시간은 사장님이 적은 것만.", "keywords": ["아산 명절 야식", "명절 연휴 영업 아산"]},
]


def campaigns(cfg):
    m = cfg.get("marketing") or {}
    return m.get("campaigns") if m.get("campaigns") is not None else DEFAULT_CAMPAIGNS


def _campaign_on(c, today):
    def parse(v):
        v = str(v)
        return (v, True) if len(v) == 10 else (v, False)
    (st, full_s), (en, full_e) = parse(c.get("start", "")), parse(c.get("end", ""))
    if full_s or full_e:
        d = today.isoformat()
        st = st if full_s else f"{today.year}-{st}"
        en = en if full_e else f"{today.year}-{en}"
        return st <= d <= en
    md = today.strftime("%m-%d")
    return (st <= md <= en) if st <= en else (md >= st or md <= en)   # 12-01 ~ 02-28 처럼 해를 넘김


def active_campaigns(cfg, today=None):
    today = today or date.today()
    return [c for c in campaigns(cfg) if c.get("enabled", True) and _campaign_on(c, today)]


def campaign_brief(cfg):
    act = active_campaigns(cfg)
    if not act:
        return ""
    return "\n[지금 진행 중인 시즌 테마 - 글 흐름에 자연스럽게 한 번만, 없는 할인·이벤트 지어내기 금지]\n" + \
        "\n".join(f"- {c['name']}: {c.get('theme', '')}" for c in act[:2])


KW_TOOL = {"name": "submit_keywords", "description": "키워드 아이디어 제출", "input_schema": {"type": "object", "properties": {
    "keywords": {"type": "array", "items": {"type": "object", "properties": {
        "keyword": {"type": "string", "description": "검색어 (2~5어절, 띄어쓰기 포함)"}, "group": {"type": "string", "description": "동네/상황/메뉴/관광/시즌/노포 중 하나"},
        "reason": {"type": "string", "description": "왜 이 검색어로 찾아올지 한 줄"}}, "required": ["keyword", "group"]}}},
    "required": ["keywords"]}}


def suggest_keywords(cfg, n=20):
    """키워드 아이디어: 가게 사실(동네·메뉴·서비스)로 만들 수 있는 검색어만. 키가 없으면 조합 규칙으로"""
    from . import llm
    shop = cfg["shop"]
    have = {k["keyword"].replace(" ", "") for k in keyword_pool(cfg)[0]}
    ex = cfg["keywords"].get("excludeKeywordRegex")
    out = []
    if llm.api_key():
        facts = {k: shop.get(k) for k in ("address", "hours", "menu", "neighborhood", "features", "since", "nearby", "services")}
        try:
            r, _ = llm.call_tool(cfg, "", f"충남 아산 온천동 통닭집 '{shop['name']}'(상호의 '원주'는 지명 아님) 블로그용 검색 키워드 {n + 10}개를 제안해 주세요. "
                                 f"가게 정보: {json.dumps(facts, ensure_ascii=False)}\n"
                                 "규칙: 실제 손님이 네이버에 칠 법한 자연스러운 검색어, 아산·온양 지역 기준, 가게 정보로 사실대로 쓸 수 있는 것만"
                                 "(배달·가마솥·국내산 등 정보에 없는 것 금지), 다른 가게·프랜차이즈 이름·'내돈내산'·'1등' 금지, 강원도 원주 금지.",
                                 KW_TOOL, 2000, "text", {"channel": "keywords", "keyword": "키워드 아이디어"})
            out = [{"keyword": str(x.get("keyword", "")).strip()[:40], "group": "확장-" + str(x.get("group", "AI")).strip()[:8], "reason": str(x.get("reason", ""))[:80]}
                   for x in r.get("keywords") or [] if isinstance(x, dict)]
        except Exception as e:  # noqa: BLE001
            from .util import log
            log("WARN", f"[키워드 아이디어] AI 실패 → 조합 규칙으로: {str(e)[:100]}")
    if not out:
        hoods = [h for h in (shop.get("neighborhood") or []) if not h.startswith("(")] or ["온천동"]
        menus = [m["name"] if isinstance(m, dict) else str(m) for m in shop.get("menu") or []][:4] or ["통닭"]
        sits = ["포장", "야식", "가족 외식", "모임"] + (["주차"] if (shop.get("services") or {}).get("무료주차") else [])
        out = [{"keyword": f"{h} {m}", "group": "확장-동네", "reason": "동네 + 메뉴"} for h in hoods for m in menus] + \
              [{"keyword": f"아산 {m} {st}", "group": "확장-상황", "reason": "메뉴 + 상황"} for m in menus[:2] for st in sits]
    seen, res = set(), []
    for x in out:
        k = re.sub(r"\s+", " ", x["keyword"]).strip()
        key = k.replace(" ", "")
        if len(k) < 3 or key in have or key in seen or check_text(k) or (ex and re.search(ex, k)) or "원주시" in k or "강원" in k:
            continue
        seen.add(key)
        res.append({**x, "keyword": k})
    return res[:n]


def pick_keyword(cfg, channel, con, rng, subset=None, account=""):
    """계정별 키워드 돌려쓰기: 이 계정이 최근 N일 안에 쓴 키워드와 오늘 다른 계정이 쓴 키워드는 피함"""
    kws, src = keyword_pool(cfg)
    have = {k["keyword"] for k in kws}
    for c in active_campaigns(cfg):   # 진행 중인 시즌 키워드는 더 자주
        kws = kws + [{"keyword": k, "weight": 3.0, "group": f"시즌:{c['name']}", "intent": c.get("theme", "")} for k in c.get("keywords") or [] if k not in have]
    sel = set(cfg["keywords"].get("selected") or [])
    if channel == "instagram" and not subset and cfg.get("instagram", {}).get("keywords"):
        subset = cfg["instagram"]["keywords"]
    if subset:  # 계정 전용 키워드 (계정마다 다른 키워드)
        by = {k["keyword"]: k for k in kws}
        kws = [by.get(s) or {"keyword": s, "weight": 2.0, "group": "계정 키워드", "intent": ""} for s in subset]
    elif sel:   # 자료함에서 체크한 키워드만 (+ 진행 중인 시즌 키워드)
        kws = [k for k in kws if k["keyword"] in sel or k["group"].startswith("시즌:")]
    kws = [k for k in kws if not check_text(k["keyword"])]
    topics = [k for k in kws if k["group"] not in cfg["keywords"].get("excludeGroupsForTopics", []) and not k["keyword"].startswith("#")] or kws
    if not topics:
        raise RuntimeError("쓸 키워드가 없어요. 자료함에서 키워드를 고르거나 직접 입력해 주세요")
    gw = cfg["keywords"].get("groupWeights", {})
    topics = [{**k, "weight": k["weight"] * gw.get(k["group"], 1.0)} for k in apply_seasonal(topics, cfg)]
    since = (datetime.now() - timedelta(days=int(cfg["keywords"].get("noRepeatDays", 14)))).isoformat()
    recent = {r[0] for r in con.execute("SELECT keyword FROM posts WHERE channel=? AND account=? AND ts>=?", (channel, account, since))}
    last = {r[0]: r[1] for r in con.execute("SELECT keyword, MAX(ts) FROM posts WHERE channel=? AND account=? GROUP BY keyword", (channel, account))}
    today_other = {r[0] for r in con.execute("SELECT keyword FROM posts WHERE ts>=? AND account!=?", (datetime.now().strftime("%Y-%m-%d"), account))}
    pool = [k for k in topics if k["keyword"] not in recent and k["keyword"] not in today_other]
    if not pool:
        pool = [k for k in topics if k["keyword"] not in today_other] or topics
        pool = sorted(pool, key=lambda k: last.get(k["keyword"], ""))[:3]   # 가장 오래전에 쓴 것
    pool.sort(key=lambda k: (last.get(k["keyword"], ""), -k["weight"]))
    pool = pool[:max(3, len(pool) // 3)]
    return rng.choices(pool, weights=[p["weight"] for p in pool])[0], src


# ---------------- 스타일 조합 (템플릿 × 구조 × 말투 × 주제) + 계정별 목소리 ----------------
TOPICS = {
    "매장일상": "오늘 매장 하루(준비·마감·날씨에 따른 분위기). 사장님이 직접 겪은 일만.",
    "오늘튀긴닭": "닭 손질·염지·튀김 과정의 디테일. 가게 정보에 있는 조리 정보만 구체적으로.",
    "메뉴소개": "가게 메뉴 중 하나를 사장님이 직접 소개(맛 설명, 같이 먹기 좋은 조합). 가격은 가게 정보에 있을 때만.",
    "손님모습": "사장님이 본 손님들의 일반적인 모습을 간접 서술(예: 포장이 많은 시간대). 인용·후기·별점·특정인 묘사 금지.",
    "동네정보": "가게 주변 동네 이야기(가게 정보의 neighborhood 에 있는 것만). 다른 가게 이름 언급 금지.",
    "이용안내": "처음 오시는 분을 위한 안내(위치·주차·포장·예약·영업시간). 가게 정보에 있는 사실만.",
    "특장점안내": "[A] 처음 오는 분께 우리 가게의 강점(역사·조리 방식·메뉴 구성·위치)을 한눈에 정리. 가게 정보에 있는 사실만, 없는 수식어(가마솥·국내산·수제 등) 금지.",
    "고민해결": "[E] 손님이 흔히 하는 고민(치킨값·배달비 부담, 식으면 눅눅함, 몇 마리 시킬지, 주차)을 사장님이 직접 풀어 주는 글. 다른 가게 비교·비방 금지, 가격은 가게 정보에 있을 때만.",
    "비하인드": "[F] 손님이 못 보는 준비 과정(닭 손질·염지·기름 관리·청소·마감)을 투명하게 보여 주는 글. 사장님이 실제로 하는 일과 가게 정보·사진에 있는 것만, 인증·수치 지어내기 금지.",
}
GUIDE_TOPICS = {  # 손님용 블로그(파워블로그): 손님에게 알려주는 안내글
    "메뉴가격안내": "메뉴 구성과 가격(가게 정보에 있는 것만), 처음 오는 손님에게 맞는 메뉴 고르는 법.",
    "찾아오는길주차": "찾아오는 길·주변 지하철역·주차 정보(가게 정보에 있는 것만).",
    "포장예약방법": "전화 포장·예약 방법, 기다리지 않는 팁, 포장 상태 유지 방법.",
    "상황별추천": "가족 저녁·야식·모임 등 상황별로 어울리는 메뉴 조합 안내(가게 메뉴만).",
    "영업시간이용팁": "영업시간·붐비는 시간대·이용 팁(사장님이 본 일반적인 모습만, 후기·인용 금지).",
    "동네와함께": "온양온천역·온천동 주변 동선과 함께 들르기 좋은 시간대 안내(다른 가게 이름 금지).",
    "고민해결안내": "손님이 자주 묻는 고민(몇 마리 시킬지, 포장해 가면 눅눅하지 않은지, 주차·대기)에 가게가 직접 답하는 Q&A형 안내.",
    "특장점정리": "처음 오는 손님을 위한 가게 소개(역사·메뉴 구성·위치) 한눈에 보기. 가게 정보에 있는 사실만.",
}
CAFE_TOPICS = {  # 네이버 카페(동네 커뮤니티) 소통글: 광고 없이 사장님 본인 이야기
    "사장일기": "[B] 통닭집을 운영하며 느끼는 보람과 애환(새벽 준비, 바쁜 저녁, 마감 후 생각). 가게 홍보 문구 없이 담백하게.",
    "휴무일상": "[B] 쉬는 날 사장님의 일상(산책, 장보기, 가족과 시간). 사진·메모에 있는 것만. 가게 이야기는 한 줄 이하.",
    "동네이야기": "[B] 온천동·온양 동네에서 요즘 느낀 점(날씨, 계절, 동네 분위기). 다른 가게 이름·평가 금지.",
    "운영이야기": "[F] 장사하며 배운 것(재료 준비, 위생 관리, 손님 응대에서 느낀 점)을 이웃에게 이야기하듯. 홍보·주문 유도 금지.",
}
DAILY_TOPICS = {"오늘의일상": "사장님이 오늘 찍은 사진으로 쓰는 가게 하루 기록. 사진에 보이는 것과 사장님 메모만 사실로 사용."}
LIFE_TOPICS = {"개인일상": ("[개인 일상] 가게 밖 사장님의 하루(여행·나들이·산책·집청소·운동·가족과 보낸 시간 등). "
                          "사진과 메모에 있는 것만 사실로 쓰고, 가게·치킨 홍보는 하지 않음.")}
PERSONAL_KINDS = ("visit", "life")   # 가게 홍보 없이 쓰는 글 (다른 가게 방문기·개인 일상)
VISIT_TOPICS = {"다른가게방문기": ("[C] 사장님이 쉬는 날 직접 다녀온 다른 식당(치킨집 제외) 이야기. 사장님 메모와 사진에 있는 사실만 쓰고, "
                                 "별점·점수·'최고' 같은 평가 금지, 메모에 없는 메뉴·가격·맛 묘사 금지, 우리 가게 홍보 금지.")}
STRUCTURES = [  # 사장님 일상 블로그(일기) 흐름 - 글마다 바뀜
    "아침·오후 준비 장면으로 시작 → 오늘 있었던 일 2~3장면 → 주제 이야기 → 저녁·마감 → 오늘의 한 줄 일기",
    "오늘 날씨·계절 이야기로 시작 → 사진 따라 하루 흐름 → 주제를 사장님 생각으로 풀기 → 내일 다짐",
    "혼잣말 같은 질문으로 시작 → 그 답을 찾아가는 하루 이야기 → 주제 정리 → 소소한 마무리 인사",
    "가게 문 열기 전 루틴 → 손질·튀김 과정 디테일 → 주제 이야기 → 마감 후 정리하며 든 생각",
    "요즘 근황 수다로 시작 → 사진 한 장씩 짧은 에피소드 → 주제 → 이웃에게 건네는 한마디",
    "시간 순서 일기(오후 2시 → 저녁 → 밤 1시 마감) 속에 주제 녹이기 → 오늘의 감사 한 줄",
    "사장 30년 차의 작은 깨달음으로 시작 → 그걸 느낀 오늘 장면들 → 주제 → 담백한 마무리",
]
TONES = ["다정한 해요체 일기(~했어요, ~더라고요)", "담백한 사장님 일기체(~했다, ~이다, 짧은 문장)", "수다스러운 해요체(~했지 뭐예요, ~잖아요)",
         "차분한 존댓말 일기(~했습니다, 가끔 혼잣말)"]
# 손님용 블로그(파워블로그형): 글쓴이 = 블로그 운영자. 사장님 말투·손님 체험담 둘 다 쓰지 않음
GUIDE_STRUCTURES = ["결론 먼저 → 이유 3가지 → 이용 안내", "질문 → 답 → 팁 목록 → 이용 안내", "체크리스트형(번호 목록) → 한 줄 요약 → 이용 안내",
                    "상황별 추천(가족·야식·모임) → 요약 표 → 이용 안내", "Q&A 5개 → 요약 → 이용 안내", "한눈에 보기 요약 → 자세히 → 이용 팁"]
GUIDE_TONES = ["친근한 해요체", "담백한 합니다체", "발랄한 블로거 말투(~랍니다, ~해요!)"]
GUIDE_VOICES = [
    "아산·온양 맛집과 동네 정보를 정리하는 파워블로거의 친근한 말투. 이모지 적당히, 핵심은 굵게·목록으로.",
    "꼼꼼한 정보 정리형 블로거. 깔끔한 목록·체크리스트·한 줄 요약을 좋아함.",
    "밝고 수다스러운 동네 정보 블로거. 질문으로 시작해 답을 정리해 주는 구성을 좋아함.",
    "차분한 생활정보 블로거. 상황별 추천과 이용 팁 중심, 과장 없는 문장.",
]
GUIDE_RULE = ("- 글쓴이는 이 손님 안내 블로그의 운영자(파워블로거 스타일 '저'). 가게는 3인칭('아산 원주통닭은', '이곳은')으로 소개. "
              "사장님인 척('사장입니다', '저희 가게', '제가 튀겨요')도, 손님인 척(방문기·먹어 본 후기·내돈내산·솔직후기·체험단·협찬)도 쓰지 말 것. "
              "직접 먹어 본 체험담 대신 정보 정리·상황별 추천·이용 팁으로 씀.")
OWNER_VOICE_RE = re.compile(r"사장(입니다|이에요|이예요|이\s?(직접|인사))|저희\s?(가게|집|매장|통닭)|제가\s?(직접\s?)?(튀|만들|손질|준비|운영)")
VOICES = [  # 계정마다 다른 목소리 (계정 설정에서 바꿀 수 있음)
    "30년 넘게 통닭을 튀겨 온 사장님의 소탈하고 정 많은 일기. 이모지는 따뜻한 것 위주(🍗😊🙏✨).",
    "꼼꼼한 사장님의 기록 일기. 시간·순서를 잘 적고, 소제목 대신 '오늘의 장면 1, 2' 같은 흐름. 이모지 적당히(📝⏰🔥).",
    "감성적인 사장님 일기. 계절·날씨·냄새·소리 묘사를 좋아하고 짧은 문장과 여백. 이모지(🌙☔🍂🌸).",
    "유쾌한 사장님 수다 일기. 혼잣말·질문·감탄이 많고 'ㅎㅎ', '~했지 뭐예요' 같은 말버릇. 이모지 다양하게(😂👍🤤🎉).",
]


def load_styles():
    tpl = []
    for p in (os.path.join(RES, "styles", "style_library.default.json"), os.path.join(ROOT, "data", "style_library.json")):
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                tpl += json.load(f).get("templates", [])
    return tpl


# ---------------- 글 모드 (AI가 글마다 알아서 바꿈: 가게 이야기 ↔ 생활 에세이 ↔ 팁 ↔ 계절 ↔ Q&A, 홍보 강도도 같이) ----------------
CONTENT_MODES = {
    "shop": {"name": "가게 이야기", "promo": "normal", "w": 3.0, "prompt": "owner"},
    "promo": {"name": "홍보 집중", "promo": "strong", "w": 2.0, "prompt": "info"},
    "essay": {"name": "생활 에세이", "promo": "none", "w": 2.0, "prompt": "diary"},
    "tips": {"name": "생활·음식 팁", "promo": "light", "w": 2.0, "prompt": "info"},
    "season": {"name": "계절·동네 이야기", "promo": "light", "w": 1.5, "prompt": "diary"},
    "qna": {"name": "자주 묻는 질문", "promo": "normal", "w": 1.0, "prompt": "info"},
}
MODE_TOPICS = {
    "essay": {"사장의생각": "오래 장사하며 든 생각·인생 이야기. 특정 사건·인물을 지어내지 말고 생각과 느낌 중심으로.",
              "계절에세이": "요즘 계절·날씨에 드는 생각, 하루의 소소한 감상. 지어낸 일정·사건 없이.",
              "동네풍경": "온천동·온양을 오가며 느끼는 일반적인 동네 풍경과 감상. 특정 사건·가게 이름 지어내기 금지."},
    "tips": {"치킨보관데우기": "남은 치킨 보관·데우는 법, 눅눅하지 않게 먹는 팁(일반 상식).",
             "야식고르기": "야식 고르는 법·양 조절·같이 먹기 좋은 조합(일반 상식, 가게 메뉴는 가볍게만).",
             "주방상식": "튀김 기름·닭 손질·염지 같은 주방 상식을 쉽게(사장님 경험담 톤, 수치 지어내기 금지)."},
    "season": {"이번주날씨와한끼": "오늘 날짜 기준 계절·날씨에 어울리는 한 끼 이야기.",
               "동네계절소식": "아산·온양의 계절 분위기(축제·행사는 확실한 것만, 모르면 쓰지 않기)."},
    "qna": {"자주묻는질문": "손님들이 자주 묻는 것(포장·주차·예약·메뉴 고르기)에 답하는 Q&A. 가게 정보 사실만."},
}
PROMO_GUIDE = {
    "strong": "홍보 비중 높게: 대표 메뉴 소개, 끝부분 '📌 이런 날 들러 주세요' 3줄, 방문·포장 안내를 분명하게.",
    "normal": "홍보는 자연스럽게: 대표 메뉴 한 가지를 사장님 말로 2~3문장, 끝에 짧은 방문·포장 안내.",
    "light": "홍보는 아주 살짝: 정보·이야기가 중심, 글 끝에 가게 한 줄 언급과 홈페이지 링크 정도만.",
    "none": "광고 없는 글: 메뉴·가격·방문 권유·링크를 쓰지 말 것. 통닭집 사장이라는 건 한 번쯤 자연스럽게만.",
}
MODE_CHANNELS = ("naver", "tistory", "wonju")   # 사장님 블로그: 글마다 모드를 알아서 바꿈


def pick_mode(cfg, con, channel, account, rng, acc=None):
    """최근 이 계정 글 모드 2개는 피하고 가중치 무작위. 계정에서 모드를 정했으면(acc['mode']) 그것"""
    if channel not in MODE_CHANNELS or (cfg.get("autoModes") is False):
        return "shop"
    fixed = (acc or {}).get("mode")
    if fixed in CONTENT_MODES:
        return fixed
    recent = []
    for (m,) in con.execute("SELECT material FROM posts WHERE channel=? AND account=? ORDER BY id DESC LIMIT 2", (channel, account)):
        try:
            recent.append(json.loads(m or "{}").get("mode"))
        except ValueError:
            pass
    weights = {**{k: v["w"] for k, v in CONTENT_MODES.items()}, **((cfg.get("modeWeights") or {}))}
    pool = [(k, float(w)) for k, w in weights.items() if k in CONTENT_MODES and k not in recent and float(w) > 0] or \
        [(k, float(w)) for k, w in weights.items() if k in CONTENT_MODES and float(w) > 0] or [("shop", 1.0)]
    return rng.choices([k for k, _ in pool], weights=[w for _, w in pool])[0]


def topic_desc(topic):
    for d in [TOPICS, GUIDE_TOPICS, CAFE_TOPICS, DAILY_TOPICS, VISIT_TOPICS, LIFE_TOPICS] + list(MODE_TOPICS.values()):
        if topic in d:
            return d[topic]
    return ""


def topics_for(channel, daily=False):
    if daily:
        k = daily.get("kind") if isinstance(daily, dict) else ""
        return VISIT_TOPICS if k == "visit" else LIFE_TOPICS if k == "life" else DAILY_TOPICS
    return GUIDE_TOPICS if channel == "guide" else CAFE_TOPICS if channel in ("cafe", "band") else TOPICS


def all_topics():
    """화면(계정별 주제 고르기)용"""
    return {"blog": list(TOPICS), "guide": list(GUIDE_TOPICS), "cafe": list(CAFE_TOPICS)}


def pick_combo(con, channel, rng, account="", avoid_last=12, daily=False, allowed=None, tone_pref=None, mode=None):
    """allowed: 계정에 고른 주제만 / tone_pref: 학습한 기존 글 말투(70%는 그 말투로) / mode: 글 모드(에세이·팁 등은 그 모드 주제)"""
    tpls = load_styles()
    if mode in MODE_TOPICS and not daily:
        tops = list(MODE_TOPICS[mode])
    else:
        tops = [t for t in topics_for(channel, daily) if not allowed or t in allowed] or list(topics_for(channel, daily))
    all_tones = GUIDE_TONES if channel == "guide" and not daily else TONES
    structs = GUIDE_STRUCTURES if channel == "guide" and not daily else STRUCTURES
    tones = [tone_pref] if tone_pref in all_tones and rng.random() < 0.7 else all_tones
    combos = [(t["id"], s, tone, topic) for t in tpls for s in structs for tone in tones for topic in tops]
    recent = [r[0] for r in con.execute("SELECT combo FROM style_usage WHERE channel=? AND account=? ORDER BY id DESC LIMIT ?",
                                        (channel, account, avoid_last))]
    used = set(recent)
    rec_parts = [c.split("||") for c in recent[:3]]
    tone_recent = {p[2] for p in rec_parts[:1] if len(p) > 2}
    # 오늘 다른 계정이 쓴 템플릿·구조는 피함 → 계정마다 다른 글 모양
    today = [r[0].split("||") for r in con.execute("SELECT combo FROM style_usage WHERE ts>=? AND account!=?",
                                                   (datetime.now().strftime("%Y-%m-%d"), account))]
    t_today, s_today = {p[0] for p in today if p}, {p[1] for p in today if len(p) > 1}

    if len(tones) == 1:
        tone_recent = set()
    one_topic = len(tops) == 1

    def ok(c):  # 이 계정 직전 3개 글과 템플릿·구조·주제가 겹치지 않게, 직전 말투와도 다르게
        return "||".join(c) not in used and c[2] not in tone_recent and \
            all(c[0] != p[0] and c[1] != p[1] and (one_topic or len(p) < 4 or c[3] != p[3]) for p in rec_parts if len(p) > 1)
    base = [c for c in combos if ok(c)] or [c for c in combos if "||".join(c) not in used] or combos
    pool = [c for c in base if c[0] not in t_today and c[1] not in s_today] or [c for c in base if c[1] not in s_today] or base
    c = rng.choice(pool)
    t = next(x for x in tpls if x["id"] == c[0])
    return {"template": t, "structure": c[1], "tone": c[2], "topic": c[3], "combo": "||".join(c)}


def account_voice(cfg, channel, account_obj):
    if account_obj and account_obj.get("voice"):
        return account_obj["voice"]
    from . import accounts as A
    lst = A.list_accounts(cfg, channel)
    idx = next((i for i, a in enumerate(lst) if account_obj and a["id"] == account_obj.get("id")), 0)
    off = {"naver": 0, "guide": 1, "cafe": 2, "tistory": 1, "wonju": 2, "instagram": 3, "x": 3, "threads": 3, "facebook": 0, "band": 2, "manual": 1}.get(channel, 0)
    vs = GUIDE_VOICES if channel == "guide" else VOICES
    return vs[(idx + off) % len(vs)]


# ---------------- 프롬프트 ----------------
CHANNEL_GUIDE = {
    "wonju": "가게 공식 홈페이지의 '사장님 일기' 게시판. 그날의 일상 + 주제 이야기, 소제목(<h2>) 2~3개, 1,800~2,500자, 이모지 적당히.",
    "naver": ("네이버 블로그 '사장님 일상 일기'. 사람이 그날그날 쓰는 일상 블로그처럼: 1~2문장마다 줄바꿈, 소제목(<h2>)은 2~4개의 짧은 장면 이름, "
              "2,000~3,000자(사진 설명 포함). 사진마다 2~4문장으로 그때의 상황·소리·냄새·온도를 구체적으로."),
    "tistory": ("티스토리 '통닭집 사장 일기'. 하루 흐름 속에 주제 정보를 녹이고, 소제목(<h2>/<h3>) 2~4개, 중간에 짧은 목록(<ul>) 1개, "
                "1,800~2,600자."),
    "instagram": "인스타그램 게시물. caption 이 핵심(3~8줄, 이모지 약간, 마지막 줄에 위치·주문 안내). body_html 은 caption 을 <p>로 감싼 짧은 글.",
    "guide": ("손님용 네이버 블로그(파워블로그 스타일 안내글). 손님이 궁금한 정보를 소제목·목록·짧은 문단으로 정리, 1,800~2,600자, 이모지로 포인트. "
              "손님인 척하는 방문기·후기 형식 금지. 가게가 직접 알려 드리는 안내글임을 자연스럽게 밝힘."),
    "cafe": ("네이버 카페(동네 커뮤니티) 회원 글. 이웃에게 말하듯 편한 구어체, 짧은 문단, 600~1,200자. 소제목 0~1개. "
             "가게 홍보 문구·링크·전화번호·주문/방문 권유 금지(카페 규칙). 가게 이야기는 자연스러운 한두 줄까지만."),
    "threads": "스레드(Threads) 게시물. caption 에 한국어 150~300자, 말하듯 편한 2~4문장(이모지 0~2개, 링크·해시태그는 쓰지 말 것). hashtags 1~3개. body_html 은 caption 을 <p>로 감싼 것.",
    "facebook": "페이스북 페이지 게시물. caption 에 4~8줄(첫 줄에 핵심, 이모지 약간, 마지막 줄에 위치·주문 안내). body_html 은 caption 을 <p>로 감싼 것. hashtags 3~5개.",
    "band": ("네이버 밴드(동네·모임 밴드) 회원 글. 이웃에게 말하듯 편한 구어체, 짧은 문단, 400~900자. 소제목 없이. "
             "가게 홍보 문구·링크·전화번호·주문/방문 권유 금지(밴드 규칙). 가게 이야기는 자연스러운 한두 줄까지만."),
    "manual": "가게 소식 원고(사장님이 복사해서 올림).",
    "x": "X(트위터) 게시물. caption 에 한국어 90자 이내 한두 문장(이모지 0~1개, 해시태그·링크 쓰지 말 것). hashtags 3개. body_html 은 caption 을 <p>로 감싼 것.",
}
GUIDE_DISCLOSURE = "※ 이 블로그는 {name}에서 손님 안내를 위해 운영하는 정보 블로그입니다."
GUIDE_MARK = "운영하는 정보 블로그"
OLD_GUIDE_PERSONA = "아산 원주통닭이 운영하는 손님 안내용 블로그의 글쓴이. 맛집 파워블로그처럼 읽기 쉽고 친절하게, 손님이 실제로 궁금해하는 메뉴·가격·주차·포장·영업시간을 정리합니다. 과장 없이 가게 정보에 있는 사실만 쓰고, 손님 후기처럼 쓰지 않습니다."
GUIDE_PERSONA = ("아산·온양 맛집과 동네 정보를 정리하는 파워블로거 스타일의 안내 블로그 운영자. 손님이 실제로 궁금해하는 메뉴·가격·주차·포장·영업시간을 "
                 "블로거 시점으로 보기 쉽게 정리하고, 가게는 3인칭으로 소개합니다. 사장님 말투('사장입니다', '저희 가게')나 손님 체험담·후기처럼 쓰지 않고, 가게 정보에 있는 사실만 씁니다.")
DEFAULT_PERSONA = ("1993년부터 아산 온천동에서 통닭을 튀겨 온 사장님. 말투는 소박하고 따뜻하며, 과장 없이 오늘 매장에서 있었던 일과 "
                   "닭 손질·튀김 이야기, 메뉴 소개, 동네 이야기를 솔직하게 씁니다.")

SHORT_CH = ("instagram", "x", "threads", "facebook", "manual", "band")   # 사진 자리 표시 없이 쓰는 채널
POST_TOOL = {
    "name": "submit_post",
    "description": "완성된 글을 제출합니다.",
    "input_schema": {"type": "object", "properties": {
        "title": {"type": "string", "description": "글 제목 (핵심 키워드 1회 포함, 40자 이내)"},
        "body_html": {"type": "string", "description": "본문 HTML (<p>, <h2>, <h3>, <ul><li>, <strong>, <a> 만 사용). 사진 자리는 [[IMG:번호]]"},
        "tags": {"type": "array", "items": {"type": "string"}, "description": "블로그 태그 5~10개"},
        "caption": {"type": "string", "description": "인스타그램용 캡션(다른 채널도 짧게 작성)"},
        "hashtags": {"type": "array", "items": {"type": "string"}, "description": "해시태그(#포함) 10~25개"}},
        "required": ["title", "body_html", "tags", "caption", "hashtags"]}}


DEFAULT_PROMPTS = [
    {"id": "owner", "name": "사장님 1인칭 (기본)", "text": DEFAULT_PERSONA},
    {"id": "info", "name": "정보형 안내 (사장님)", "text": "사장님이 손님 입장에서 궁금할 정보(위치·주차·포장 방법·메뉴 구성·영업시간)를 차분하게 정리해 주는 안내문. 소제목과 목록을 활용합니다."},
    {"id": "diary", "name": "사장님 일기", "text": "사장님의 짧은 하루 일기. 오늘 날씨, 장사 준비, 마감 후 느낌을 짧은 문장으로 담백하게 씁니다."},
    {"id": "guide", "name": "손님용 블로그 (파워블로거형 안내글)", "text": GUIDE_PERSONA},
    {"id": "daily", "name": "오늘의 일상 (사진 글)", "text": "사장님이 오늘 찍은 사진을 보며 하루를 기록하는 따뜻한 일상 글. 사진에 보이는 장면과 사장님 메모만 사실로 씁니다."},
    {"id": "cafe", "name": "카페 소통글 (사장님 일상)", "text": "아산 온천동에서 통닭집을 하는 동네 주민 사장님. 카페 이웃들에게 오늘 있었던 일, 장사하며 느낀 보람과 고생, 쉬는 날 일상을 꾸밈없이 이야기합니다. 광고처럼 쓰지 않습니다."},
    {"id": "short", "name": "짧은 SNS 글 (X·인스타)", "text": "짧고 담백한 SNS 글. 한두 문장으로 오늘 가게 소식을 전하고 방문·포장을 부드럽게 권합니다."},
]
DEFAULT_PROMPT_BY_CHANNEL = {"threads": "short", "facebook": "owner", "band": "cafe", "manual": "owner", "naver": "owner", "guide": "guide", "cafe": "cafe", "tistory": "info", "wonju": "info", "instagram": "owner", "x": "short", "daily": "daily"}


def prompt_id_for(cfg, channel, account_obj=None, prompt_id=None, daily=False):
    """프롬프트 고르는 순서: 작업에서 고른 것 → 계정에 정한 것 → 채널 기본 → 전체 기본"""
    by = {**DEFAULT_PROMPT_BY_CHANNEL, **(cfg.get("promptByChannel") or {})}
    return prompt_id or (account_obj or {}).get("prompt") or (by.get("daily") if daily else by.get(channel)) or cfg.get("defaultPrompt") or "owner"


def persona_text(cfg, prompt_id=None):
    ps = cfg.get("prompts") or DEFAULT_PROMPTS
    p = next((x for x in ps if x.get("id") == (prompt_id or cfg.get("defaultPrompt"))), None) \
        or next((x for x in DEFAULT_PROMPTS if x["id"] == prompt_id), None) or (ps[0] if ps else None)
    text = (p or {}).get("text") or DEFAULT_PERSONA
    if text.strip() == OLD_GUIDE_PERSONA:      # 예전 기본값 → 새 파워블로거형 기본값
        text = GUIDE_PERSONA
    extra = str(cfg.get("promptExtra") or "").strip()
    return text + (f"\n[사장님 추가 지시 - 항상 지킬 것]\n{extra}" if extra else "")


def photo_brief(photos):
    if not photos:
        return "\n사진: 없음 ([[IMG:번호]] 표시를 쓰지 마세요)."
    rows = "\n".join(f"[[IMG:{i}]] 라벨: {', '.join(p.get('labels') or [])}" + (f" / 설명: {p['caption']}" if p.get("caption") else "")
                     for i, p in enumerate(photos))
    return (f"\n사진 {len(photos)}장(사장님이 직접 찍은 실제 사진): 본문 흐름에 맞는 자리에 각 [[IMG:번호]]를 정확히 한 번씩 단독 줄로 넣고, "
            "그 바로 앞 문단은 해당 사진 내용(라벨·설명)과 맞게 쓰세요. 사진에 없는 것을 묘사하지 마세요.\n" + rows)


def style_brief(st):
    """기존 글에서 배운 이 계정의 글버릇 (style.py 학습 결과)"""
    if not st or not st.get("summary"):
        return ""
    return f"\n[이 계정 기존 글의 글버릇 - 비슷하게 맞출 것, 문장은 베끼지 말 것]\n{st['summary']}"


def prompt_parts(cfg, channel, kw, combo, persona, photos=None, voice="", daily=None, account_style=None, manual_target="", mode=None):
    """(고정 부분, 글마다 바뀌는 부분). 고정 부분은 Claude 프롬프트 캐시로 재사용 → 입력 토큰 절약"""
    t = combo["template"]
    shop = cfg["shop"]
    svc = shop.get("services", {})
    svc_txt = ", ".join(f"{k} {'가능' if v else '안 함(언급 금지)'}" for k, v in svc.items())
    facts = {k: v for k, v in shop.items() if k not in ("factsNote", "placeSyncedAt", "naverPlaceId")}
    visit = bool(daily and daily.get("kind") in PERSONAL_KINDS)
    life = bool(daily and daily.get("kind") == "life")
    who = (f"당신은 충남 아산시 온천동 통닭집 '{shop['name']}'을 소개하는 손님 안내용 블로그(파워블로거 스타일)의 운영자입니다. "
           f"블로거 시점으로 쓰고 가게는 3인칭으로 소개합니다. 사장님 1인칭이 아니며, 손님 체험담도 아닙니다."
           if channel == "guide" else f"당신은 충남 아산시 온천동 통닭집 '{shop['name']}'의 사장님 본인입니다. 사장님 1인칭으로 직접 쓰는 글입니다.")
    if life:
        who += (" 이번 글은 가게 이야기가 아니라 사장님의 '개인 일상 일기'(여행·나들이·산책·집청소·운동·가족 시간 등)입니다. "
                "사장님이 실제로 한 일(사진·메모)만 사실로 쓰고, 장소 이름·시간·함께한 사람은 메모에 있을 때만 씁니다. "
                "치킨·가게·메뉴·가격·주문 안내는 쓰지 않습니다(통닭집 사장이라는 건 자연스럽게 한 번 정도만 언급 가능). "
                "별점·순위 같은 평가, 메모에 없는 일정·사건은 지어내지 않습니다.")
    elif visit:
        who += (" 이번 글은 사장님이 쉬는 날 '직접' 다녀온 다른 식당 이야기라서 사장님 본인의 방문 경험으로 씁니다. "
                "사장님 메모와 사진에 있는 것만 사실로 쓰고, 별점·점수·순위·'최고' 평가, 메모에 없는 맛·가격 묘사, 우리 가게 홍보는 쓰지 않습니다.")
    rules = PROMPT_RULES
    if channel == "guide" and not daily:
        rules = "\n".join(GUIDE_RULE if ln.startswith("- 글쓴이는 항상") else ln for ln in PROMPT_RULES.split("\n"))
    link_rule = ("- 홈페이지·전화번호·주문 권유를 쓰지 말 것(카페·밴드/방문기 글)." if channel in ("cafe", "band") or visit
                 else f"- 본문 끝 부근에 홈페이지 {shop['url']} 를 자연스럽게 1회 안내.")
    promo = CONTENT_MODES.get(mode or "", {}).get("promo")
    mode_line = (f"\n글 모드: {CONTENT_MODES[mode]['name']} — {PROMO_GUIDE[promo]}" if promo else "")
    if promo in ("light", "none"):
        link_rule = ("- 홈페이지·전화번호·주문 권유를 쓰지 말 것(광고 없는 글)." if promo == "none"
                     else f"- 글 맨 끝에만 홈페이지 {shop['url']} 를 한 줄로 가볍게.")
    promo_rule = ("- 개인 일상·방문기 글: 가게 홍보·메뉴 소개·방문 안내를 넣지 말고, 그날의 경험과 느낌을 사진 순서대로 생생하게." if visit else
                  f"- {PROMO_GUIDE[promo]} 가게 주소·영업시간·전화·가격 목록은 본문에서 줄줄이 반복하지 말 것." if promo in ("light", "none") else
                  "- 블로그 글은 홍보 효과도 있게: 본문 중간에 '대표 메뉴 한 가지'를 사장님 말로 2~3문장 소개하고, 끝부분에 '📌 이런 날 들러 주세요' 짧은 목록 3줄(가족 저녁·야식·모임 등, 가게 정보의 서비스만)을 넣을 것.\n"
                  "  가게 주소·영업시간·전화·메뉴 가격 목록은 글 맨 위에 '가게 한눈에 보기'로 자동으로 붙으니 본문에서 줄줄이 반복하지 말 것.")
    static = f"""{who}
가게 정보(이것만 사실로 사용): {json.dumps(facts, ensure_ascii=False, separators=(",", ":"))}
서비스: {svc_txt}
상호 표기: 반드시 '아산 원주통닭' 또는 '{shop['name']}'. '원주통닭' 단독 표기 금지(타지역 동명 가게와 혼동). '원주'는 지명이 아니며 가게는 충남 아산에 있음.
[글쓴이 페르소나]
{persona}
{rules}
글쓰기 규칙:
- 사람이 직접 쓴 일상 블로그처럼: 사장님 일기 느낌으로, 그날의 장면(시간·날씨·계절감·가게 안 소리와 냄새·손의 감각·작은 생각)을 구체적으로 묘사.
  가게의 실제 루틴(준비·손질·튀김·포장·마감)과 사진·가게 정보에 있는 것만 사실로 쓰고, 특정 손님과의 대화·사건·후기·숫자는 지어내지 말 것.
- 첫 문장은 매번 다르게(날씨·혼잣말·장면·질문·감탄 등). '안녕하세요 ○○ 사장입니다' 같은 뻔한 인사로 시작하지 말 것.
- 흐름이 보이게 나누고, 채널에 맞게 마무리(블로그는 오늘의 한 줄 일기 + 자연스러운 방문·포장 안내, 카페는 이웃 인사).
{promo_rule}
- 핵심 키워드는 제목 1회, 본문 2~3회만 자연스럽게. 도배 금지. 같은 단어·문장 끝 반복을 피하고 연결어미를 다양하게(사람이 쓴 글처럼, 가끔 'ㅎㅎ'·'…' 같은 말버릇도).
- 스마트폰에서 읽기 좋게 1~2문장마다 줄바꿈. 이모지는 200자당 1~3개, 문장 끝이나 문단 첫머리에 자연스럽게, 같은 이모지 연달아 반복 금지.
- 제목: 일상 블로그 제목처럼 그날의 한 장면이나 느낌 + 키워드(자연스럽게) + 이모지 0~1개. 예) '비 오는 화요일, 기름 온도 맞추다 하루가 갔네요 ☔', '[사장 일기] 오늘은 양념을 새로 끓였어요' — 형태만 참고하고 그대로 쓰지 말 것.
- 다른 블로그 문장을 흉내 내거나 베끼지 말 것.
{link_rule}
- 글은 반드시 마무리 문장까지 끝맺어 완결할 것(중간에 끊기지 않게, 너무 길면 문단 수를 줄일 것).
- '[사진]', '(사진)' 같은 자리 표시 문구를 직접 쓰지 말 것. 사진 위치는 안내된 [[IMG:번호]]만 사용.
- 결과는 반드시 submit_post 도구로 제출."""
    guide_txt = CHANNEL_GUIDE[channel]
    if channel == "manual":
        from .publishers.social import MANUAL_TARGETS
        tname, tguide = MANUAL_TARGETS.get(manual_target or "daangn", MANUAL_TARGETS["daangn"])
        guide_txt = f"{tname}에 올릴 원고. {tguide} body_html 에 원고 본문(<p> 문단), caption 에 같은 내용 요약."
    dynamic = f"""채널: {channel} — {guide_txt}
이 계정의 목소리: {voice}{style_brief(account_style)}{campaign_brief(cfg) if channel not in ("cafe", "band") and not daily else ""}
핵심 키워드: "{kw['keyword']}" (그룹: {kw.get('group')}, 메모: {kw.get('intent') or '-'})
주제: {combo['topic']} — {topic_desc(combo['topic'])}{mode_line}
구성: 제목 패턴 '{t['title_pattern']}'(패턴 설명이며 그대로 쓰지 말 것), 소제목 {t['sections']}개 안팎, 도입 '{t['intro']}', 마무리 '{t['outro']}', 이모지 {t['emoji']}
글 구조: {combo['structure']} / 말투: {combo['tone']}
오늘 날짜: {datetime.now():%Y년 %m월 %d일}{photo_brief(photos) if channel not in SHORT_CH else ""}"""
    if daily:
        dynamic += f"""
[오늘의 일상 글 지시문 - 사장님이 확인한 내용, 반드시 따를 것]
{daily.get('plan') or '-'}
사장님 메모: {daily.get('memo') or '-'}"""
    return static, dynamic


# ---------------- 키 없는 예시 글 (테스트 모드 전용) ----------------
PHOTO_LINES = {
    "후라이드": ["후라이드는 튀김옷을 얇게 입혀서 겉이 바삭하게 나와요", "막 건져 올린 후라이드는 기름을 충분히 빼고 담아요"],
    "양념": ["양념은 겉면에 고루 묻도록 두 번에 나눠 버무려요", "양념 색이 진해 보여도 맛은 달달한 편이에요"],
    "간장": ["간장 소스는 짜지 않게 졸여서 발라요", "간장은 단짠 맛을 좋아하시는 분들이 많이 찾으세요"],
    "반반": ["반반은 후라이드와 양념을 한 번에 맛보실 수 있어요", "고민될 때는 반반으로 시키시는 분이 많아요"],
    "순살": ["순살은 뼈를 발라 한입 크기로 튀겨요", "순살은 아이들이 먹기 편해서 가족 주문에 자주 들어가요"],
    "통닭": ["한 마리 통째로 튀긴 옛날 통닭이에요", "통닭은 튀겨 나오는 모양 그대로 담아 드려요"],
    "매장외관": ["가게 앞 모습이에요. 처음 오시는 분들은 이 간판을 찾으시면 돼요", "밖에서 보면 작은 동네 가게예요"],
    "간판": ["간판 불이 켜져 있으면 영업 중이에요", "멀리서도 보이도록 간판을 밝게 달아 두었어요"],
    "매장내부": ["안쪽 자리는 넓지 않지만 깔끔하게 정리해 두어요", "가게 안은 이렇게 소박한 분위기예요"],
    "테이블": ["테이블에 차려 놓으면 이런 모습이에요", "자리에서 드시면 따뜻할 때 바로 드실 수 있어요"],
    "포장": ["포장은 눅눅해지지 않게 상자에 숨구멍을 내서 담아요", "포장해 가시는 분들이 많아 상자를 넉넉히 준비해 둬요"],
    "메뉴판": ["메뉴는 많지 않고 이 정도로 단출해요", "메뉴판 그대로 찍어 두었어요"],
    "조리과정": ["주방에서 한 마리씩 튀겨 내는 모습이에요", "기름 온도를 맞춰 두고 차례로 튀겨요"],
    "음료": ["시원한 음료를 곁들이면 더 잘 어울려요", "음료는 냉장고에서 바로 꺼내 드려요"],
    "사이드": ["곁들이는 메뉴도 함께 준비해요", "사이드는 통닭이랑 같이 드시기 좋아요"],
    "사장님": ["오늘도 주방을 지키는 제 모습이에요", "직접 손질하고 튀기는 게 제 일이에요"],
    "기타": ["오늘 가게에서 찍은 사진이에요", "이런 모습도 남겨 두고 싶었어요"],
}
INTROS = ["{k} 검색하고 들어오신 분들 반갑습니다. {shop} 사장입니다.", "안녕하세요, {shop} 사장이에요. 오늘은 {k} 이야기를 해 볼게요.",
          "{k} 찾으시는 분들께 사장이 직접 적어 봅니다.", "오늘 하루 가게에서 있었던 일을 {k} 이야기와 함께 사장이 남겨요.",
          "{shop} 주방에서 사장이 인사드려요. 요즘 {k} 문의가 많아서 정리해 봤어요."]
HEADS = ["오늘 있었던 일", "이렇게 준비해요", "한 가지 더", "찾아오시는 길", "먼저 한 줄로", "알아 두시면 좋은 점", "오늘의 일기",
         "사진으로 보면", "앞으로도", "주방에서", "저녁 풍경", "자주 받는 질문"]
MOCK_LINES = {
    "매장일상": ["오늘도 오후에 가게 문을 열고 기름 온도부터 확인했어요.", "저녁이 되니 퇴근길에 들르시는 분들이 하나둘 보였어요.",
             "마감하고 주방 정리까지 끝내면 하루가 금방 지나가요.", "비 오는 날엔 포장 주문이 조금 늘어요."],
    "오늘튀긴닭": ["오늘 들어온 닭을 손질하면서 {menu} 준비를 했어요.", "튀김옷은 얇게, 기름은 자주 갈아 깔끔한 맛을 지키려고 해요.",
              "한 마리씩 튀겨 나올 때 나는 소리가 저는 제일 좋아요.", "염지는 전날 미리 해 두어요."],
    "메뉴소개": ["오늘은 저희 {menu}를 소개해 드릴게요.", "{menu}는 맥주랑도, 밥반찬으로도 잘 어울려요.",
             "가격과 구성은 매장이나 홈페이지에서 확인해 주세요.", "처음 오시면 기본 메뉴부터 드셔 보세요."],
    "손님모습": ["요즘은 포장해 가시는 분들이 부쩍 많아졌어요.", "주말 저녁엔 가족 단위로 오시는 모습이 자주 보여요.",
             "덕분에 포장 상자를 넉넉히 준비해 두고 있어요.", "퇴근길에 전화로 미리 주문하시는 분도 많아요."],
    "동네정보": ["저희 가게는 {hood} 근처에 있어요.", "{hood} 쪽으로 산책 나오셨다가 들르셔도 좋아요.",
             "동네 분들과 인사 나누는 게 장사의 큰 즐거움이에요.", "골목이 조용해서 저녁 산책길로도 괜찮아요."],
    "이용안내": ["처음 오시는 분들을 위해 이용 방법을 정리했어요.", "전화로 미리 주문하시면 기다리지 않고 가져가실 수 있어요.",
             "영업시간 안에는 언제든 편하게 들러 주세요.", "궁금한 점은 전화로 물어보셔도 돼요."],
}


def tone_apply(text, tone):
    if "합니다" in tone or "습니다" in tone:
        for a, b in (("두어요", "둡니다"), ("려요", "립니다"), ("워요", "웁니다"), ("해요", "합니다"), ("있어요", "있습니다"), ("좋아요", "좋습니다"),
                     ("예요", "입니다"), ("이에요", "입니다"), ("돼요", "됩니다"), ("와요", "옵니다"), ("어요", "습니다"), ("세요", "십시오"), ("에요", "입니다")):
            text = re.sub(a + r"([.!]|$)", b + r"\1", text)
    elif "일기체" in tone:
        for a, b in (("두어요", "둔다"), ("려요", "린다"), ("워요", "운다"), ("해요", "했다"), ("있어요", "있다"), ("좋아요", "좋다"), ("예요", "이다"),
                     ("이에요", "이다"), ("돼요", "된다"), ("와요", "온다"), ("어요", "었다"), ("세요", "시길"), ("에요", "이다"), ("습니다", "다")):
            text = re.sub(a + r"([.!]|$)", b + r"\1", text)
    return text

MOCK_ALIAS = {"특장점안내": "이용안내", "고민해결": "이용안내", "비하인드": "오늘튀긴닭", "메뉴가격안내": "메뉴소개", "찾아오는길주차": "이용안내",
              "포장예약방법": "이용안내", "상황별추천": "메뉴소개", "영업시간이용팁": "이용안내", "동네와함께": "동네정보",
              "고민해결안내": "이용안내", "특장점정리": "이용안내", "사장일기": "매장일상", "휴무일상": "동네정보", "동네이야기": "동네정보",
              "운영이야기": "오늘튀긴닭", "오늘의일상": "매장일상", "다른가게방문기": "동네정보", "개인일상": "동네정보",
              "사장의생각": "매장일상", "계절에세이": "동네정보", "동네풍경": "동네정보", "치킨보관데우기": "이용안내", "야식고르기": "메뉴소개",
              "주방상식": "오늘튀긴닭", "이번주날씨와한끼": "메뉴소개", "동네계절소식": "동네정보", "자주묻는질문": "이용안내"}


def mock_post(cfg, kw, channel, combo, rng, photos=None):
    p = _mock_post(cfg, kw, channel, combo, rng, photos)
    if channel == "guide":   # 손님용 블로그 예시 글: 블로거 시점(가게는 3인칭)
        name = cfg["shop"]["name"]
        for k in ("title", "body_html", "caption"):
            t = p[k]
            for i in INTROS:
                t = t.replace(i.format(k=kw["keyword"], shop=name), f"{kw['keyword']} 찾는 분들을 위해 {name} 정보를 정리했어요.")
            p[k] = OWNER_VOICE_RE.sub(lambda m: "이곳" if m.group(0).startswith("저희") else
                                      m.group(0).replace("제가", "사장님이") if m.group(0).startswith("제가") else "", t)
    return p


def _mock_post(cfg, kw, channel, combo, rng, photos=None):
    """API 키 없이(테스트 모드 전용): 사장님 1인칭, 가게 정보 사실만 사용"""
    shop = cfg["shop"]
    k, topic, tone = kw["keyword"], combo["topic"], combo["tone"]
    m = rng.choice(shop.get("menu") or [{"name": "옛날 통닭"}])
    menu = m["name"] if isinstance(m, dict) else str(m)
    hood = rng.choice([h for h in shop.get("neighborhood") or [] if not h.startswith("(")] or ["가게 앞 골목"])
    src = MOCK_LINES.get(topic) or MOCK_LINES[MOCK_ALIAS.get(topic, "매장일상")]
    lines = [x.format(menu=menu, hood=hood) for x in src]
    rng.shuffle(lines)
    heads = rng.sample(HEADS, max(2, min(4, int(combo["template"].get("sections", 3)))))
    photos = photos or []
    per = [[] for _ in heads]
    for i in range(len(photos)):
        per[i * len(heads) // max(len(photos), 1)].append(i)
    secs, used = [], set()
    for si, h in enumerate(heads):
        txt = f"<h2>{h}</h2><p>{tone_apply(lines[si % len(lines)], tone)}</p>"
        for pi in per[si]:
            lab = next((x for x in (photos[pi].get("labels") or ["기타"]) if x in PHOTO_LINES), "기타")
            opts = [x for x in PHOTO_LINES[lab] if x not in used] or PHOTO_LINES[lab]
            sent = rng.choice(opts)
            used.add(sent)
            txt += f"<p>{tone_apply(sent + '.', tone)}</p>[[IMG:{pi}]]"
        secs.append(txt)
    intro = rng.choice(INTROS).format(k=k, shop=shop["name"])
    tail = tone_apply(f"{shop['name']}은 {shop['address']}에 있고, 영업시간은 {shop['hours']}이에요.", tone)
    body = f"<p>{tone_apply(intro, tone)}</p>" + "".join(secs) + f"<p>{tail} 자세한 안내는 <a href=\"{shop['url']}\">{shop['url']}</a> 에서 보실 수 있어요.</p>"
    title = rng.choice([f"{k}, {heads[0]}", f"[{topic}] {k} 이야기", f"{k} | 사장이 정리했어요", f"{k}? 사장이 답해요", f"통닭집 사장의 하루 ({k})"])
    tags = list(dict.fromkeys([k, "아산통닭", "아산치킨", "온양맛집", menu.replace(" ", "")]))
    hashtags = list(dict.fromkeys(["#" + re.sub(r"\s+", "", t) for t in tags] + ["#아산원주통닭", "#온천동맛집"]))
    caption = f"{tone_apply(lines[0], tone)} 🍗\n{tone_apply(lines[1], tone)}\n📍 {shop['address']}\n주문·위치 안내는 {shop['url']}"
    return {"title": title, "body_html": body, "tags": tags, "caption": caption, "hashtags": hashtags}


# ---------------- 정리·검사 ----------------
def place_markers(html, n):
    """[[IMG:n]] 정리: 잘못된 번호·중복 제거, 빠진 사진은 문단 사이에 고르게 넣기"""
    seen = set()

    def keep(m):
        i = int(m.group(1))
        if i >= n or i in seen:
            return ""
        seen.add(i)
        return m.group(0)
    html = re.sub(r"\[\[IMG:(\d+)\]\]", keep, html or "")
    missing = [i for i in range(n) if i not in seen]
    if missing:
        parts = html.split("</p>")
        slots = max(len(parts) - 1, 1)
        for j, i in enumerate(missing):
            pos = min(slots, max(1, (j + 1) * slots // (len(missing) + 1)))
            parts[pos] = f"[[IMG:{i}]]" + parts[pos]
        html = "</p>".join(parts)
    return html


ALLOWED_TAGS = ("p", "h2", "h3", "ul", "ol", "li", "strong", "b", "em", "br", "a")


def sanitize_html(h):
    """AI 본문에서 허용 태그만 남김 (스크립트·스타일·이벤트 속성 제거)"""
    h = re.sub(r"<(script|style|iframe|object)[^>]*>.*?</\1>", "", h or "", flags=re.S | re.I)

    def tag(m):
        close, name, attrs = m.group(1), m.group(2).lower(), m.group(3) or ""
        if name not in ALLOWED_TAGS:
            return ""
        if name == "a" and not close:
            href = re.search(r'href\s*=\s*"(https?://[^"]+|tel:[^"]+)"', attrs, re.I)
            return f'<a href="{href.group(1)}">' if href else "<a>"
        return f"<{close}{name}>"
    return re.sub(r"<(/?)([a-zA-Z0-9]+)([^>]*)>", tag, h)


def strip_html(h):
    h = re.sub(r"\[\[IMG:\d+\]\]", " ", h or "")
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", re.sub(r"<!--.*?-->", "", h, flags=re.S))).strip()


# ---------------- 반복 피하기 (최근 글의 제목·첫 문장·자주 쓴 표현) ----------------
WORD_RE = re.compile(r"[가-힣A-Za-z0-9]+")
STOP_PHRASE = ("원주통닭", "온천동", "아산", "https", "http", "kr", "www", "com")


def _opening(text):
    t = re.sub(r"\s+", " ", text or "").strip()
    m = re.match(r"(.{8,80}?[.!?~…]|.{1,60})", t)
    return (m.group(1) if m else t)[:60]


def _phrases(text):
    w = WORD_RE.findall(text or "")
    return {" ".join(w[i:i + 3]) for i in range(len(w) - 2)}


def _bigrams(t):
    t = re.sub(r"[^가-힣A-Za-z0-9]", "", t or "")
    return {t[i:i + 2] for i in range(len(t) - 1)}


def title_sim(a, b):
    x, y = _bigrams(a), _bigrams(b)
    return len(x & y) / max(len(x | y), 1)


def recent_memory(con, limit=20, fact_words=None):
    """최근 글(모든 채널·계정)에서: 제목, 첫 문장, 3개 이상 글에 나온 3어절 표현"""
    rows = con.execute("SELECT title, body, keyword FROM posts WHERE body IS NOT NULL AND body!='' ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    titles = [r[0] for r in con.execute("SELECT title FROM posts ORDER BY id DESC LIMIT 15") if r[0]]
    openings = [_opening(b.replace(k or "\x00", "")) for _, b, k in rows[:10] if b]   # 키워드만 다른 같은 첫 문장도 같다고 봄
    cnt = {}
    for _, b, _k in rows:
        for ph in _phrases(b):
            cnt[ph] = cnt.get(ph, 0) + 1
    stop = STOP_PHRASE + tuple(fact_words or ())
    over = [ph for ph, c in sorted(cnt.items(), key=lambda x: -x[1]) if c >= 3 and not any(w in ph for w in stop)][:20]
    return {"titles": titles, "openings": openings, "phrases": over}


def memory_brief(mem):
    if not (mem["titles"] or mem["openings"] or mem["phrases"]):
        return ""
    out = ["\n[반복 피하기 - 최근에 올린 글과 다르게 쓸 것]"]
    if mem["titles"]:
        out.append("- 최근 제목(비슷한 제목·같은 단어 조합 금지): " + " / ".join(mem["titles"][:10]))
    if mem["openings"]:
        out.append("- 최근 글 첫 문장(이렇게 시작하지 말 것): " + " / ".join(mem["openings"][:6]))
    if mem["phrases"]:
        out.append("- 최근 글에 자주 나온 표현(이번엔 쓰지 말고 다른 말로): " + ", ".join(mem["phrases"][:15]))
    return "\n".join(out)


def repeat_issues(post, mem, kw=""):
    """다시 쓰게 할 반복 문제 (발행을 막지는 않음 → '[' 로 시작하지 않음)"""
    out = []
    t = post.get("title", "")
    sim = max(((title_sim(t, x), x) for x in mem["titles"]), default=(0, ""))
    if sim[0] >= 0.6:
        out.append(f"반복: 최근 제목 '{sim[1][:30]}'과 비슷한 제목")
    body = strip_html(post.get("body_html", ""))
    words = set((post.get("keyword") or kw or "").split()) | {"아산", "온양", "온천동", "충남", "천안", "원주통닭"}

    def okey(o):   # 키워드·지역 이름만 다른 같은 첫 문장도 같다고 봄
        o = re.sub(r"\s", "", o)
        for w in sorted(words, key=len, reverse=True):
            if len(w) >= 2:
                o = o.replace(w, "")
        return o[:12]
    op = okey(_opening(body.replace(post.get("keyword") or kw or "\x00", "")))
    if len(op) >= 6 and any(okey(o) == op for o in mem["openings"]):
        out.append("반복: 최근 글과 같은 첫 문장")
    used = [ph for ph in mem["phrases"] if ph in " ".join(WORD_RE.findall(body))]
    if len(used) >= 5:
        out.append("반복: 최근 글에 자주 쓴 표현을 또 씀(" + ", ".join(used[:6]) + ")")
    return out


def shingles(t, n=5):
    t = re.sub(r"\s+", "", t)
    return {t[i:i + n] for i in range(max(len(t) - n + 1, 1))}


VISIT_OK = ("[표시광고법] 손님 시점 방문기", "[표시광고법] 후기 사칭 표현")


def quality_check(post, kw, cfg, con, visit=False, channel=""):
    """visit: 사장님이 실제로 다녀온 다른 가게 방문기 → '방문' 표현만 허용 (별점·인용·내돈내산·경쟁업체는 그대로 금지)"""
    issues = []
    text = post.get("title", "") + " " + strip_html(post.get("body_html", "")) + " " + post.get("caption", "")
    cnt = text.count(kw["keyword"])
    if cnt > int(cfg["quality"].get("maxKeywordRepeats", 5)):
        issues.append(f"키워드 과다 반복({cnt}회)")
    issues += [i for i in check_text(text + " " + " ".join(post.get("hashtags", [])), cfg.get("compliance", {}).get("bannedNames", []))
               if not (visit and i in VISIT_OK)]
    if channel == "guide" and OWNER_VOICE_RE.search(text):
        issues.append("[손님용 블로그] 사장님 시점 표현(블로거 시점으로 다시 씀): " + OWNER_VOICE_RE.search(text).group(0))
    for svc, on in (cfg["shop"].get("services") or {}).items():
        if not on and re.search(svc + r"(\s*(가능|돼요|됩니다|해요|해드|서비스|주문))", text):
            issues.append(f"[사실] 제공하지 않는 서비스 언급({svc})")
    plain = strip_html(post.get("body_html", ""))
    fp = shingles(plain)
    # 짧은 SNS 글은 몇 글자만 겹쳐도 비율이 커져서 기준을 높임 (블로그 글은 40% 넘게 겹치면 중복)
    limit = 0.75 if len(re.sub(r"\s", "", plain)) < 300 else min(float(cfg["quality"].get("maxSimilarity", 0.4)), 0.4)
    for (old,) in con.execute("SELECT fingerprint FROM posts ORDER BY id DESC LIMIT 300"):
        o = set(json.loads(old)) if old else set()
        if o and len(fp & o) / max(len(fp | o), 1) > limit:
            issues.append("[중복] 기존 글(다른 계정 포함)과 너무 비슷함")
            break
    return issues, fp


BRAND_RE = re.compile(r"(?<!아산 )(?<!아산)원주통닭")


def normalize_brand(post):
    """'원주통닭' 단독 사용 금지(타지역 동명 상호와 혼동) → 항상 '아산 원주통닭'"""
    for k in ("title", "body_html", "caption"):
        if post.get(k):
            post[k] = BRAND_RE.sub("아산 원주통닭", post[k])
    post["hashtags"] = ["#아산원주통닭" if h.lstrip("#") == "원주통닭" else h for h in post.get("hashtags", [])]
    post["tags"] = ["아산 원주통닭" if t.strip() == "원주통닭" else t for t in post.get("tags", [])]
    return post


def ensure_link(post, cfg):
    url = cfg["shop"]["url"]
    if url not in post.get("body_html", ""):
        post["body_html"] = post.get("body_html", "") + f'<p>자세한 안내: <a href="{url}">{url}</a></p>'
    if url not in post.get("caption", ""):
        post["caption"] = post.get("caption", "") + f"\n{url}"
    return post


def strip_links(post, cfg):
    """카페 글·방문기: 홈페이지 링크·주문 유도 문단 제거, 남은 링크는 글자만"""
    url = cfg["shop"].get("url") or "\x00"
    h = re.sub(r"<p>(?:(?!</p>).)*?(<a [^>]*>|" + re.escape(url) + r")(?:(?!</p>).)*?</p>", "", post.get("body_html", ""), flags=re.S)
    post["body_html"] = re.sub(r"<a [^>]*>(.*?)</a>", r"\1", h, flags=re.S)
    post["caption"] = re.sub(r"\s*(https?://\S+|" + re.escape(url) + r")", "", post.get("caption", "")).strip()
    return post


def merge_hashtags(cfg, ai_tags, limit=25):
    fixed = cfg.get("instagram", {}).get("hashtagSet") or []
    ex = cfg["keywords"].get("excludeKeywordRegex")
    out = []
    for t in list(fixed) + list(ai_tags):
        t = "#" + re.sub(r"[\s#]+", "", str(t))
        if 1 < len(t) <= 20 and t not in out and not check_text(t, cfg.get("compliance", {}).get("bannedNames", [])) \
                and not (ex and re.search(ex, t.lstrip("#"))):
            out.append(t)
    return out[:min(limit, 30)]


def max_tokens(cfg):
    try:
        return max(2000, min(int(cfg.get("llm", {}).get("maxTokens") or 8000), 16000))
    except (TypeError, ValueError):
        return 8000


def has_ai_key():
    from . import llm
    return bool(llm.api_key())


def generate(channel, dry=False, keyword=None, account_obj=None, seed=None, record=True, prompt_id=None, daily=None):
    """글 1개 생성. account_obj: 계정 설정(dict). 반환 post dict (images 포함)"""
    from . import accounts as A, library as lib, llm
    cfg = load_config()
    rng = random.Random(seed if seed is not None else time.time_ns())
    acc = account_obj or A.list_accounts(cfg, channel)[0]
    account = A.profile_name(channel, acc.get("id", "main"))
    use_ai = has_ai_key()
    if not use_ai and not dry:   # 예시 글이 실제로 올라가는 일 방지
        raise RuntimeError("Claude API 키가 없어 실제 발행용 글을 만들 수 없어요. 'AI 설정'에서 키를 입력해 주세요")
    con = db()
    try:
        if daily:
            kw, src = {"keyword": (daily.get("keyword") or keyword or ({"visit": "아산 맛집 탐방", "life": "사장의 휴무 일기"}.get(daily.get("kind"), "아산 원주통닭 오늘"))).strip(), "weight": 1.0, "group": "오늘의 일상", "intent": ""}, ""
        elif keyword:
            kw, src = {"keyword": keyword, "weight": 1.0, "group": "지정", "intent": ""}, ""
        else:
            kw, src = pick_keyword(cfg, channel, con, rng, subset=acc.get("keywords") or None, account=account)
        mode = None if daily else pick_mode(cfg, con, channel, account, rng, acc) if channel in MODE_CHANNELS else None
        pid = prompt_id_for(cfg, channel, acc, prompt_id, bool(daily))
        if mode and not prompt_id and not acc.get("prompt"):   # 프롬프트를 따로 고르지 않았으면 글 모드에 맞춰 AI가 알아서
            pid = CONTENT_MODES[mode]["prompt"]
        persona, voice = persona_text(cfg, pid), account_voice(cfg, channel, acc)
        post, issues, fp, combo, photos, model = None, [], set(), None, [], "mock"
        shop = cfg["shop"]   # 가게 사실(메뉴·서비스·시간)이 들어간 표현은 매번 나와도 괜찮으니 '반복'으로 보지 않음
        facts = [m["name"] if isinstance(m, dict) else str(m) for m in shop.get("menu") or []] + list((shop.get("services") or {}).keys()) + \
            ["영업시간", "주차", "포장", "예약", "전화", "온양온천역", "시장"]
        mem = recent_memory(con, fact_words=[f for f in facts if f])
        tries = 3
        for attempt in range(tries):
            stl = acc.get("style") or {}
            combo = pick_combo(con, channel, rng, account=account, daily=daily or False, allowed=acc.get("topics") or None, tone_pref=stl.get("tone"), mode=mode)
            if daily:
                photos = [p for p in (lib.get_photo(int(i), con) for i in daily.get("photo_ids") or []) if p][:(1 if channel in SHORT_CH else 10)]
            elif channel == "band" or (channel in ("x", "threads") and rng.random() < 0.3):
                photos = []      # 밴드 API 는 글만, X·스레드는 사진 없는 짧은 글도 섞음
            else:
                photos = lib.pick_photos(cfg, kw["keyword"], combo["topic"], "instagram" if channel in SHORT_CH else channel, account, rng, con=con)
            meta = {"channel": channel, "account": account, "keyword": kw["keyword"]}
            if use_ai:
                st, dy = prompt_parts(cfg, channel, kw, combo, persona, photos, voice, daily, stl, acc.get("handle", "") if channel == "manual" else "", mode)
                if channel not in SHORT_CH:
                    dy += memory_brief(mem)
                if issues:   # 앞 시도에서 걸린 문제를 알려 주고 다시 쓰게 함
                    dy += "\n[앞 시도에서 고쳐야 할 점 - 반드시 반영]\n" + "\n".join("- " + i for i in issues[:5])
                raw, model = llm.call_tool(cfg, st, dy, POST_TOOL, max_tokens(cfg), "text", meta)
            else:
                raw = mock_post(cfg, kw, channel, combo, rng, photos if channel not in SHORT_CH else None)
            post = {"title": str(raw.get("title") or "").strip()[:100], "body_html": sanitize_html(str(raw.get("body_html") or "")),
                    "tags": [str(t).strip()[:30] for t in (raw.get("tags") or []) if str(t).strip()][:10],
                    "caption": str(raw.get("caption") or "")[:2000], "hashtags": [str(h) for h in (raw.get("hashtags") or [])][:40]}
            if channel == "x":
                post["caption"] = re.sub(r"(#\S+|https?://\S+)", "", post["caption"]).strip()[:140]
                post["body_html"] = "".join(f"<p>{l}</p>" for l in post["caption"].splitlines() if l.strip())
            if channel == "threads":
                post["caption"] = re.sub(r"(#\S+|https?://\S+)", "", post["caption"]).strip()[:400]
                post["body_html"] = "".join(f"<p>{l}</p>" for l in post["caption"].splitlines() if l.strip())
            if channel in ("instagram", "facebook") and not post["body_html"].strip():
                post["body_html"] = "".join(f"<p>{l}</p>" for l in post["caption"].splitlines() if l.strip())
            short = channel in ("x", "instagram", "threads", "facebook")
            if not post["title"] or len(strip_html(post["body_html"])) < (8 if short else 30):
                issues = ["[형식] 제목 또는 본문이 비었음"]
                continue
            visit = bool(daily and daily.get("kind") in PERSONAL_KINDS)
            no_ad = mode and CONTENT_MODES[mode]["promo"] == "none"
            post = normalize_brand(strip_links(post, cfg) if channel in ("cafe", "band") or visit or no_ad else ensure_link(post, cfg))
            issues, fp = quality_check(post, kw, cfg, con, visit=visit, channel="" if daily else channel)
            if channel not in SHORT_CH:
                issues += repeat_issues(post, mem, kw["keyword"])
            if not issues or (attempt >= 1 and all(not i.startswith("[") for i in issues)):
                break   # 반복 문제만 남았으면 한 번만 다시 써 보고 그 글을 씀 (AI 비용 아끼기, 발행은 막지 않음)
            con.execute("INSERT INTO style_usage(ts,channel,combo,template_id,structure,tone,topic,account) VALUES(?,?,?,?,?,?,?,?)",
                        (datetime.now().isoformat(), channel, combo["combo"], combo["template"]["id"], combo["structure"], combo["tone"],
                         combo["topic"], account + ":rejected"))
            con.commit()
        imgs = lib.as_images(photos, cfg)
        post["body_html"] = place_markers(post["body_html"], len(imgs)) if channel not in SHORT_CH else re.sub(r"\[\[IMG:\d+\]\]", "", post["body_html"])
        if channel in lib.CI_CHANNELS:   # 기업 CI(로고)를 항상 글에 넣음 (로고는 변형하지 않은 원본)
            ci = lib.pick_ci(cfg)
            if ci:
                ci_img = lib.as_images([ci], cfg, variants=False)[0]
                ci_img["ci"] = True
                imgs.append(ci_img)
                mk = f"[[IMG:{len(imgs) - 1}]]"
                post["body_html"] = (mk + post["body_html"]) if lib.ci_settings(cfg).get("position") == "top" else (post["body_html"] + mk)
        if channel == "guide" and GUIDE_MARK not in post["body_html"]:
            post["body_html"] += "<p>" + GUIDE_DISCLOSURE.format(name=cfg["shop"]["name"]) + "</p>"
        if channel == "x":
            post["hashtags"] = merge_hashtags(cfg, post.get("hashtags", []), limit=4)
        elif channel == "instagram":
            post["hashtags"] = merge_hashtags(cfg, post.get("hashtags", []))
        elif channel in ("threads", "facebook"):
            post["hashtags"] = merge_hashtags(cfg, post.get("hashtags", []), limit=3 if channel == "threads" else 5)
        else:
            post["hashtags"] = list(dict.fromkeys(h if h.startswith("#") else "#" + h for h in post.get("hashtags", [])))[:30]
        post.update({"keyword": kw["keyword"], "keyword_group": kw["group"], "keyword_source": src and os.path.basename(src), "channel": channel,
                     "provider": "claude" if use_ai else "mock", "model": model, "voice": voice, "prompt": pid,
                     "style": {k: combo[k] for k in ("structure", "tone", "topic")} | {"template": combo["template"]["id"]},
                     "quality_issues": issues, "images": imgs,
                     "mode": mode, "promo": CONTENT_MODES[mode]["promo"] if mode else None,
                     "material": {"keyword": kw["keyword"], "topic": combo["topic"], "mode": mode,
                                  "photos": [{"id": p["id"], "labels": p["labels"], "match": p.get("match", 0)} for p in photos]}})
        if record:
            now = datetime.now().isoformat()
            con.execute("INSERT INTO posts(ts,channel,keyword,title,fingerprint,structure,dry,account,material,body) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (now, channel, kw["keyword"], post["title"], json.dumps(sorted(fp)[:3000], ensure_ascii=False), combo["combo"],
                         int(dry), account, json.dumps(post["material"], ensure_ascii=False), strip_html(post["body_html"])[:4000]))
            con.execute("INSERT INTO style_usage(ts,channel,combo,template_id,structure,tone,topic,account) VALUES(?,?,?,?,?,?,?,?)",
                        (now, channel, combo["combo"], combo["template"]["id"], combo["structure"], combo["tone"], combo["topic"], account))
            con.commit()
            if photos:
                lib.record_usage(channel, account, kw["keyword"], imgs, post["title"], combo["topic"], dry=dry)
        return post
    finally:
        con.close()


def usage_summary(cfg, now=None):
    """오늘/이번 달 토큰 합계 (API 응답의 실제 사용량)"""
    now = now or datetime.now()
    con = db()
    try:
        def agg(since):
            rows = con.execute("SELECT model, COUNT(*), SUM(input_tokens), SUM(output_tokens), SUM(cache_write), SUM(cache_read) FROM llm_usage WHERE ts>=? GROUP BY model", (since,)).fetchall()
            out = {"calls": 0, "input": 0, "output": 0, "cacheWrite": 0, "cacheRead": 0, "models": []}
            for model, n, i, o, cw, cr in rows:
                i, o, cw, cr = i or 0, o or 0, cw or 0, cr or 0
                out["models"].append({"model": model, "calls": n, "input": i, "output": o, "cacheWrite": cw, "cacheRead": cr})
                out["calls"] += n; out["input"] += i; out["output"] += o; out["cacheWrite"] += cw; out["cacheRead"] += cr
            return out
        return {"today": agg(now.strftime("%Y-%m-%d")), "month": agg(now.strftime("%Y-%m"))}
    finally:
        con.close()
