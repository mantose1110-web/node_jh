# -*- coding: utf-8 -*-
"""Read-only extraction of Telegram references from already visible conversations."""
import re


LINK_RE = re.compile(r"(?<![\w@])(?:https?://)?(?:www\.)?(?:t\.me|telegram\.me)/(?:joinchat/[A-Za-z0-9_-]+|\+[A-Za-z0-9_-]+|[A-Za-z][A-Za-z0-9_]{3,31})(?:/\d+)?", re.I)
HANDLE_RE = re.compile(r"(?<![\w@.])@[A-Za-z][A-Za-z0-9_]{3,31}\b")
PEER_RE = re.compile(r"(?<!\d)-100\d{5,}\b")


def extract_references(text):
    """Return canonical, de-duplicated references; never resolve or join links."""
    found = set()
    body = str(text or "")
    for match in LINK_RE.finditer(body):
        raw = match.group().rstrip(".,;:!?)]}\u3002")
        path = re.split(r"(?:t\.me|telegram\.me)/", raw, maxsplit=1, flags=re.I)[-1]
        head = path.split("/")[0]
        if head.lower() == "joinchat" or head.startswith("+"):
            kind = "invite"
        else:
            kind = "address"
            path = head
        found.add((kind, "https://t.me/" + path))
    for match in HANDLE_RE.finditer(body):
        found.add(("handle", match.group().lower()))
    for match in PEER_RE.finditer(body):
        found.add(("id", match.group()))
    return sorted(found, key=lambda pair: (pair[0], pair[1].casefold()))


async def scan_dialogs(client, messages_per_chat=50, max_chats=200):
    """Scan joined group/channel history with explicit bounds to avoid huge API jobs."""
    messages_per_chat = int(messages_per_chat)
    max_chats = int(max_chats)
    if not 1 <= messages_per_chat <= 200 or not 1 <= max_chats <= 500:
        raise ValueError("대화방은 1~500개, 방별 메시지는 1~200개로 설정해 주세요")
    rows = {}
    chats = 0
    async for dialog in client.iter_dialogs():
        if not (dialog.is_group or dialog.is_channel):
            continue
        if chats >= max_chats:
            break
        chats += 1
        peer_id = str(await client.get_peer_id(dialog.entity))
        source = str(dialog.name or dialog.id)[:120]
        # The peer ID is supplied by Telegram, not guessed from text.
        rows.setdefault(("id", peer_id), {"kind": "id", "value": peer_id, "sources": set()})["sources"].add(source)
        username = getattr(dialog.entity, "username", None)
        if username and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{3,31}", username):
            address = "https://t.me/" + username
            rows.setdefault(("address", address), {"kind": "address", "value": address, "sources": set()})["sources"].add(source)
        async for message in client.iter_messages(dialog.entity, limit=messages_per_chat):
            for kind, value in extract_references(getattr(message, "raw_text", "")):
                rows.setdefault((kind, value), {"kind": kind, "value": value, "sources": set()})["sources"].add(source)
    items = [{"kind": row["kind"], "value": row["value"], "sources": sorted(row["sources"])}
             for row in rows.values()]
    items.sort(key=lambda row: (row["kind"], row["value"].casefold()))
    return {"ok": True, "items": items, "total": len(items), "scannedChats": chats,
            "messagesPerChat": messages_per_chat}
