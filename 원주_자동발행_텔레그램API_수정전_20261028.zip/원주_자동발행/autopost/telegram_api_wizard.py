# -*- coding: utf-8 -*-
"""User-confirmed Telegram API credential capture from my.telegram.org only."""
import os, re, shutil, subprocess, threading, time
from urllib.parse import urlparse

from . import browser, generator as g, secure
from .util import load_config, log


class TelegramApiWizard:
    def __init__(self):
        self._lock = threading.RLock()
        self._capture = threading.Event()
        self._cancel = threading.Event()
        self._state = {"running": False, "status": "idle", "message": "", "found": False}
        self._proc = None

    def status(self):
        with self._lock:
            return dict(self._state)

    def start(self):
        with self._lock:
            if self._state["running"]:
                return {**self._state, "started": False}
            self._capture.clear(); self._cancel.clear()
            self._state = {"running": True, "status": "opening", "message": "텔레그램 API 센터를 여는 중…", "found": False}
        threading.Thread(target=self._run, daemon=True, name="telegram-api-wizard").start()
        return {**self.status(), "started": True}

    def capture(self):
        with self._lock:
            if not self._state["running"]:
                return {"ok": False, "message": "먼저 텔레그램 API 센터를 열어 주세요"}
            self._state.update(status="capturing", message="현재 공식 페이지에서 API 정보를 확인하는 중…")
            self._capture.set()
        return {"ok": True, "message": "가져오기를 요청했습니다"}

    def cancel(self):
        self._cancel.set(); self._capture.set()
        return {"ok": True}

    def _set(self, **values):
        with self._lock:
            self._state.update(values)

    @staticmethod
    def _extract(page):
        host = (urlparse(page.url).hostname or "").lower()
        if host != "my.telegram.org":
            raise ValueError("my.telegram.org 공식 페이지에서만 가져올 수 있습니다")
        values = page.evaluate("""() => ({
          text: document.body ? document.body.innerText : '',
          fields: Array.from(document.querySelectorAll('input,textarea,[contenteditable=true],.uneditable-input'))
            .map(e => ({id:e.id||'', name:e.name||'', value:(e.value||e.innerText||e.textContent||'').trim(),
                        near:((e.closest('.form-group,.control-group,tr,li,div')||e.parentElement||e).innerText||'').trim()}))
        })""")
        api_id = api_hash = ""
        for field in values.get("fields") or []:
            key = (field.get("id", "") + " " + field.get("name", "") + " " + field.get("near", "")).lower()
            val = str(field.get("value") or "").strip()
            if not api_id and "api" in key and "id" in key and re.fullmatch(r"\d{5,12}", val): api_id = val
            if not api_hash and "hash" in key and re.fullmatch(r"[a-fA-F0-9]{32}", val): api_hash = val.lower()
        text = str(values.get("text") or "")
        if not api_id:
            m = re.search(r"(?:App\s+)?api[_\s-]*id\s*:?\s*(\d{5,12})", text, re.I)
            api_id = m.group(1) if m else ""
        if not api_hash:
            m = re.search(r"(?:App\s+)?api[_\s-]*hash\s*:?\s*([a-f0-9]{32})", text, re.I)
            api_hash = m.group(1).lower() if m else ""
        if not api_id or not api_hash:
            raise ValueError("API ID/Hash가 보이는 'API development tools' 화면까지 이동한 뒤 다시 눌러 주세요")
        return api_id, api_hash

    def _run(self):
        profile = os.path.join(g.ROOT, "temp", "telegram-api-wizard")
        port = browser.free_port(); proc = cdp = None
        try:
            if os.path.isdir(profile): shutil.rmtree(profile, ignore_errors=True)
            os.makedirs(profile, exist_ok=True)
            kind, exe = browser.system_browser(load_config())
            cmd = [exe, f"--user-data-dir={profile}", f"--remote-debugging-port={port}", "--no-first-run",
                   "--no-default-browser-check", "--new-window", "https://my.telegram.org/apps"]
            flags = 0x00000200 if os.name == "nt" else 0
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                                    creationflags=flags, start_new_session=(os.name != "nt"))
            self._proc = proc; self._set(status="waiting", message="로그인 후 API development tools 화면을 열고 'API 정보 가져오기'를 누르세요")
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                end = time.time() + 900
                while time.time() < end and not self._cancel.is_set():
                    if cdp is None:
                        try: cdp = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}", timeout=3000)
                        except Exception:
                            if proc.poll() is not None: raise RuntimeError("브라우저 창이 닫혔습니다")
                            time.sleep(0.7); continue
                    if self._capture.wait(0.5):
                        self._capture.clear()
                        if self._cancel.is_set(): break
                        try:
                            pages = [p for ctx in cdp.contexts for p in ctx.pages if (urlparse(p.url).hostname or "").lower() == "my.telegram.org"]
                            if not pages: raise ValueError("텔레그램 공식 API 센터 탭을 찾지 못했습니다")
                            api_id, api_hash = self._extract(pages[-1])
                            secure.set_many({"TG_API_ID": api_id, "TG_API_HASH": api_hash})
                            self._set(status="done", message=f"API ID {api_id}와 API Hash를 암호화 저장했습니다", found=True)
                            break
                        except ValueError as e:
                            self._set(status="waiting", message=str(e), found=False)
                else:
                    if not self._cancel.is_set(): self._set(status="timeout", message="15분이 지나 연결 창을 종료했습니다")
                try: cdp.new_browser_cdp_session().send("Browser.close")
                except Exception: pass
        except Exception as e:
            self._set(status="error", message=f"API 연결 창 오류: {type(e).__name__}: {str(e)[:120]}")
            log("WARN", self.status()["message"])
        finally:
            if proc and proc.poll() is None:
                try: proc.terminate(); proc.wait(5)
                except Exception:
                    try: proc.kill()
                    except Exception: pass
            if cdp:
                try: cdp.close()
                except Exception: pass
            time.sleep(0.5); shutil.rmtree(profile, ignore_errors=True)
            self._proc = None; self._set(running=False)


wizard = TelegramApiWizard()
