@echo off
setlocal
rem JH-NODE one-click installer (runs installer\install.ps1)
cd /d "%~dp0"
if not exist "%~dp0installer\install.ps1" (
  echo [ERROR] installer\install.ps1 not found. Please unzip the whole folder first.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\install.ps1"
set ERR=%ERRORLEVEL%
if not "%ERR%"=="0" if not "%ERR%"=="2" (
  echo.
  echo Install stopped. See install_log.txt
  pause
)
exit /b %ERR%
