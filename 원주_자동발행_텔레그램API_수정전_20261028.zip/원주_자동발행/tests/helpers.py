# -*- coding: utf-8 -*-
"""테스트 공통: 임시 데이터 폴더, 가짜 서버(Claude·네이버·티스토리·인스타·FTP) 실행, 테스트 사진 만들기
실제 계정·키는 전혀 쓰지 않음. 바깥 인터넷도 쓰지 않음."""
import glob, io, json, os, shutil, socket, sys, tempfile, time

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT_DIR)
sys.path.insert(0, os.path.join(ROOT_DIR, "tests", "fakes"))


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def find_chromium():
    for pat in ("/opt/pw-browsers/chromium-*/chrome-linux/chrome", os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux/chrome")):
        hits = sorted(glob.glob(pat))
        if hits:
            return hits[-1]
    return None


HOME = tempfile.mkdtemp(prefix="wonju-test-")
HTTP = free_port()
FTP_ROOT = os.path.join(HOME, "_ftp")
BASE = f"http://127.0.0.1:{HTTP}"
os.environ.update({
    "AUTOPOST_HOME": HOME, "ANTHROPIC_BASE_URL": BASE, "AUTOPOST_GRAPH_BASE": BASE, "AUTOPOST_X_BASE": BASE,
    "AUTOPOST_LOGIN_URL_NAVER": f"{BASE}/naver/login?auto=1", "AUTOPOST_LOGIN_DOMAIN_NAVER": "127.0.0.1",
    "AUTOPOST_LOGIN_HOSTS_NAVER": "/nid.naver.com/,/naver/login", "AUTOPOST_NAVER_MYBLOG_URL": f"{BASE}/naver/MyBlog.naver",
    "AUTOPOST_NAVER_WRITE_URL": f"{BASE}/naver/{{id}}?Redirect=Write",
    "AUTOPOST_LOGIN_URL_TISTORY": f"{BASE}/tistory/login?auto=1", "AUTOPOST_LOGIN_DOMAIN_TISTORY": "127.0.0.1",
    "AUTOPOST_LOGIN_HOSTS_TISTORY": "/tistory/login", "AUTOPOST_TISTORY_WRITE_URL": f"{BASE}/tistory/{{blog}}/manage/newpost/",
    "AUTOPOST_LOGIN_HEADLESS": "1", "AUTOPOST_PUBLISH_WAIT_MS": "15000", "AUTOPOST_LOGIN_TIMEOUT": "90",
    "AUTOPOST_TIME_SCALE": "60",
    "AUTOPOST_CAFE_HOSTS": "127.0.0.1", "AUTOPOST_CAFE_BASE": f"{BASE}/cafe", "AUTOPOST_CAFE_API": f"{BASE}/capi", "AUTOPOST_BAND_BASE": f"{BASE}/band", "AUTOPOST_THREADS_BASE": f"{BASE}/threads", "AUTOPOST_THREADS_WAIT": "8", "AUTOPOST_TISTORY_RSS_URL": f"{BASE}/trss/{{id}}", "AUTOPOST_NAVER_RSS_URL": f"{BASE}/rss/{{id}}.xml", "AUTOPOST_NAVER_POST_URL": f"{BASE}/m/{{id}}/{{no}}",
})
if find_chromium():
    os.environ["AUTOPOST_BROWSER_EXE"] = find_chromium()
for k in ("HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy"):
    os.environ.pop(k, None)   # 가짜 서버(127.0.0.1)에 바로 연결

import fake_services as FS      # noqa: E402
from mini_ftp import MiniFTP    # noqa: E402

_started = {}


def start_fakes():
    if not _started:
        FS.start(HTTP, FTP_ROOT)
        ftp = MiniFTP(FTP_ROOT, "wonju", "ftp-pass-QA")
        _started["ftp_port"] = ftp.start()
        _started["ftp"] = ftp
        for _ in range(50):
            try:
                socket.create_connection(("127.0.0.1", HTTP), 1).close()
                break
            except OSError:
                time.sleep(0.1)
    return _started


def bootstrap():
    """데이터 폴더 초기화 + 테스트용 설정(헤드리스 브라우저, 짧은 간격)"""
    from autopost import main as M, generator as g
    M._bootstrap()
    from autopost.util import load_config, save_config
    cfg = load_config()
    cfg["browser"] = {"channel": "auto", "headless": True, "slowMo": 0}
    cfg["images"]["publicBaseUrl"] = f"{BASE}/site/html/photos"
    cfg["autoModes"] = False                      # 기존 테스트는 '가게 이야기' 고정 (모드 테스트에서만 켬)
    cfg["ci"] = {**(cfg.get("ci") or {}), "enabled": False}   # CI 테스트에서만 켬
    save_config(cfg)
    return g.ROOT


def reset_db():
    from autopost import generator as g
    for f in glob.glob(os.path.join(g.ROOT, "data", "history.db*")) + [os.path.join(g.ROOT, "data", "engine_state.json")]:
        try:
            os.remove(f)
        except OSError:
            pass
    shutil.rmtree(os.path.join(g.ROOT, "data", "library"), ignore_errors=True)


def make_photo(color, size=(640, 480), gps=True, name="p.jpg"):
    """라벨별 색 사진 (+ GPS 위치정보 EXIF 포함)"""
    from PIL import Image
    im = Image.new("RGB", size, color)
    buf = io.BytesIO()
    if gps:
        exif = Image.Exif()
        exif[0x010F] = "TestCam"                     # Make
        exif[0x8825] = {1: "N", 2: (36.0, 47.0, 0.0), 3: "E", 4: (127.0, 0.0, 0.0)}   # GPS
        im.save(buf, "JPEG", exif=exif.tobytes())
    else:
        im.save(buf, "JPEG")
    return buf.getvalue()


COLORS = {"후라이드": (230, 160, 40), "양념": (200, 30, 30), "매장외관": (40, 90, 200), "포장": (240, 240, 240),
          "테이블": (120, 70, 30), "음료": (30, 180, 200), "조리과정": (60, 60, 60)}


def fill_library(n_each=2):
    from autopost import library as lib
    from autopost.util import load_config
    cfg = load_config()
    added = []
    for lab, col in COLORS.items():
        for i in range(n_each):
            c = tuple(max(0, min(255, x + i * 3)) for x in col)
            p, _ = lib.add_photo(make_photo(c), f"IMG_{lab}_{i}.jpg", cfg, label=True)
            added.append(p)
    return added


def set_key(on=True):
    from autopost import secure
    secure.set_many({"ANTHROPIC_API_KEY": FS.API_KEY if on else None})


def fake_state():
    import urllib.request
    return json.loads(urllib.request.urlopen(BASE + "/state", timeout=5).read())


def fake_post(path, body=None):
    import urllib.request
    data = json.dumps(body).encode() if body is not None else b""
    urllib.request.urlopen(urllib.request.Request(BASE + path, data=data, method="POST", headers={"Content-Type": "application/json"}), timeout=5).read()
