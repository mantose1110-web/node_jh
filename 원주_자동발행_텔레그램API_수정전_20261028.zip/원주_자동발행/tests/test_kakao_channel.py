import os, tempfile, unittest
from datetime import datetime


class KakaoChannelTests(unittest.TestCase):
    def setUp(self):
        from autopost import generator as g, secure
        self.tmp = tempfile.TemporaryDirectory()
        g.ROOT = self.tmp.name
        secure._cache.update(mtime=None, data=None, path=None)

    def tearDown(self):
        self.tmp.cleanup()

    def test_keyword_and_handoff_responses(self):
        from autopost import kakao_channel as k
        ch = k.new_channel("테스트")
        ch["id"] = "abcdef123456"
        payload = {"userRequest": {"utterance": "가격이 궁금해요", "user": {"id": "u1"}}}
        out = k.handle(ch, payload)
        self.assertIn("견적", out["template"]["outputs"][0]["simpleText"]["text"])
        payload["userRequest"]["utterance"] = "상담원 연결"
        out = k.handle(ch, payload)
        self.assertIn("접수", out["template"]["outputs"][0]["simpleText"]["text"])
        self.assertEqual(out["version"], "2.0")

    def test_closed_hours_and_anonymous_logging(self):
        from autopost import kakao_channel as k
        ch = k.new_channel(); ch["id"] = "123456abcdef"
        ch["businessHours"] = {"enabled": True, "start": "09:00", "end": "18:00"}
        self.assertFalse(k._is_open(ch["businessHours"], datetime(2026, 1, 1, 22, 0)))
        k.handle(ch, {"userRequest": {"utterance": "비밀 문의", "user": {"id": "raw-user-id"}}})
        db = k._db()
        try:
            row = db.execute("SELECT user_hash,message FROM events").fetchone()
        finally:
            db.close()
        self.assertNotEqual(row[0], "raw-user-id")
        self.assertEqual(row[1], "")

    def test_sanitize(self):
        from autopost import kakao_channel as k
        ch = k.new_channel(); ch["id"] = "aaaabbbbcccc"
        ch["rules"] = [{"keywords": ["a"], "response": "b"}]
        clean = k.sanitize_channel(ch, ch)
        self.assertEqual(clean["rules"][0]["response"], "b")
        self.assertLessEqual(clean["maxPerMinute"], 60)


if __name__ == "__main__":
    unittest.main()
