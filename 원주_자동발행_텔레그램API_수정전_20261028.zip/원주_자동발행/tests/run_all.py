# -*- coding: utf-8 -*-
"""전체 테스트를 여러 번 반복 실행하고 결과를 tests/테스트결과.txt 로 저장
사용: python tests/run_all.py 3"""
import os, re, subprocess, sys, time
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
SUITES = ["test_unit", "test_flow", "test_ui"]


def main(rounds=3):
    lines = [f"아산 원주통닭 자동발행 테스트 결과 ({datetime.now():%Y-%m-%d %H:%M}, {sys.platform}, Python {sys.version.split()[0]})", ""]
    ok_all = True
    for r in range(1, rounds + 1):
        for s in SUITES:
            t0 = time.time()
            p = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", s, "-v"], cwd=HERE, capture_output=True, text=True, encoding="utf-8")
            out = p.stderr
            tests = re.findall(r"^(test_\S+) \((\S+)\)\n?(.*?) \.\.\. (ok|FAIL|ERROR)", out, re.M | re.S)
            summ = (re.findall(r"^(Ran \d+ tests? in [\d.]+s)", out, re.M) or ["?"])[-1]
            res = "OK" if p.returncode == 0 else "실패"
            ok_all &= p.returncode == 0
            lines.append(f"[{r}회차] {s}: {res} - {summ} ({time.time() - t0:.0f}초)")
            if r == 1:
                for name, cls, doc, st in tests:
                    doc = doc.strip().splitlines()[0] if doc.strip() else ""
                    lines.append(f"    {'✔' if st == 'ok' else '✘'} {cls.split('.')[-2]}.{name}" + (f"  - {doc}" if doc and not doc.startswith('[') else ""))
            if p.returncode != 0:
                lines.append(out[-3000:])
            print(lines[-1] if r > 1 else "\n".join(lines[-len(tests) - 1:]), flush=True)
    lines += ["", "전체: " + ("모두 통과" if ok_all else "실패 있음")]
    with open(os.path.join(HERE, "테스트결과.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main(int(sys.argv[1]) if len(sys.argv) > 1 else 3))
