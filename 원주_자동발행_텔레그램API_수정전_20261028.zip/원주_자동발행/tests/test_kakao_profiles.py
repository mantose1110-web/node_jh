import copy
import unicodedata

import pytest

from autopost import kakao_profiles
from autopost import kakao_auto_reply, kakao_window
from autopost import kakao_send_queue
from autopost import paths
from autopost.kakao_auto_reply import KakaoAutoReplyManager


def test_chat_window_title_normalization(monkeypatch):
    title = unicodedata.normalize("NFD", "동생")
    monkeypatch.setattr(kakao_window, "windows", lambda: [{"hwnd": 7, "pid": 2, "title": title,
                                                            "width": 400, "height": 500}])
    assert kakao_window.room_window("동생")["hwnd"] == 7


def _memory_config(monkeypatch, initial=None):
    state = copy.deepcopy(initial or {})
    monkeypatch.setattr(kakao_profiles, "load_config", lambda: copy.deepcopy(state))

    def save(value):
        state.clear()
        state.update(copy.deepcopy(value))

    monkeypatch.setattr(kakao_profiles, "save_config", save)
    return state


def test_migrate_old_rules_and_keep_account_rules_separate(monkeypatch):
    state = _memory_config(monkeypatch, {"kakaoAutoReply": {
        "rooms": [{"name": "기존 그룹", "enabled": True, "reply": "확인"}],
        "intervalValue": 3, "intervalUnit": "minutes"}})
    assert kakao_profiles.get_account("default")["rooms"][0]["kind"] == "group"
    second = kakao_profiles.create_account("회사 계정")
    kakao_profiles.save_account(second["id"], {"rooms": [
        {"name": "오픈채팅 방", "kind": "open", "enabled": True,
         "mode": "keywords", "keywords": ["공지"], "reply": "알겠습니다"},
        {"name": "일반 대화", "kind": "normal", "enabled": False}],
        "intervalValue": 2, "intervalUnit": "hours"})
    assert kakao_profiles.get_account("default")["rooms"][0]["name"] == "기존 그룹"
    assert [x["kind"] for x in kakao_profiles.get_account(second["id"])["rooms"]] == ["open", "normal"]
    assert state["kakaoTalk"]["accounts"][1]["intervalUnit"] == "hours"


def test_manual_send_refuses_unknown_room_without_starting_thread(monkeypatch):
    manager = KakaoAutoReplyManager()
    monkeypatch.setattr(manager, "settings", lambda account_id: {
        "id": account_id, "rooms": [{"name": "확인된 그룹", "kind": "group"}]})
    monkeypatch.setattr(manager, "_require_account", lambda account_id: True)
    with pytest.raises(ValueError, match="저장되지 않은 방"):
        manager.start_send("account", ["다른 방"], "공지입니다")
    assert manager._send_thread is None


def test_manual_send_requires_fresh_unambiguous_scan(monkeypatch):
    manager = KakaoAutoReplyManager()
    monkeypatch.setattr(manager, "settings", lambda account_id: {
        "id": account_id, "rooms": [{"name": "회사 그룹", "kind": "group"}]})
    monkeypatch.setattr(manager, "_require_account", lambda account_id: True)
    with pytest.raises(ValueError, match="새로 읽고"):
        manager.start_send("account", ["회사 그룹"], "공지입니다")
    manager._rooms = [{"name": "회사 그룹"}]
    manager._ambiguous_names = {"회사 그룹"}
    with pytest.raises(ValueError, match="같은 이름"):
        manager.start_send("account", ["회사 그룹"], "공지입니다")
    assert manager._send_thread is None


def test_stop_all_cancels_reply_scan_and_manual_send(monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "data_dir", lambda: str(tmp_path))
    manager = KakaoAutoReplyManager()
    manager.stop_all()
    assert manager._stop.is_set()
    assert manager._scan_cancel.is_set()
    assert manager._send_stop.is_set()
    assert manager.status()["running"] is False
    assert manager.send_status()["running"] is False


def test_scheduled_queue_sends_in_order_closes_each_room_and_encrypts_text(monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "data_dir", lambda: str(tmp_path))
    manager = KakaoAutoReplyManager()
    names = ["첫 방", "둘째 방"]
    monkeypatch.setattr(manager, "settings", lambda _: {"rooms": [{"name": name} for name in names]})
    monkeypatch.setattr(manager, "_require_account", lambda _: True)
    manager._rooms = [{"name": name} for name in names]
    monkeypatch.setattr(manager, "_start_queue_thread", lambda: None)
    calls = []
    monkeypatch.setattr(manager, "_send_one", lambda _account, name, message: calls.append(("send", name, message)) or {"hwnd": len(calls), "pid": 10})
    monkeypatch.setattr(kakao_window, "close_room", lambda _chat, name: calls.append(("close", name)))
    monkeypatch.setattr(manager._send_stop, "wait", lambda _: False)
    manager.start_send("account", names, "공통", {"intervalMinutes": 3, "messages": {"둘째 방": "개별"}})
    saved = kakao_send_queue.load()
    assert saved["items"][1]["dueAt"] - saved["items"][0]["dueAt"] == 180
    assert b"\xea\xb3\xb5\xed\x86\xb5" not in (tmp_path / "kakao_send_queue.json").read_bytes()
    manager._run_queue()
    assert calls == [("send", "첫 방", "공통"), ("close", "첫 방"),
                     ("send", "둘째 방", "개별"), ("close", "둘째 방")]
    assert manager.send_status()["state"] == "complete"
    assert manager.send_status()["sent"] == 2


def test_scheduled_queue_stops_on_uncertain_send_without_retry(monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "data_dir", lambda: str(tmp_path))
    manager = KakaoAutoReplyManager()
    names = ["첫 방", "둘째 방"]
    monkeypatch.setattr(manager, "settings", lambda _: {"rooms": [{"name": name} for name in names]})
    monkeypatch.setattr(manager, "_require_account", lambda _: True)
    manager._rooms = [{"name": name} for name in names]
    monkeypatch.setattr(manager, "_start_queue_thread", lambda: None)
    calls = []
    def fail(_account, name, _message):
        calls.append(name)
        raise RuntimeError("채팅창을 확인하지 못했어요")
    monkeypatch.setattr(manager, "_send_one", fail)
    monkeypatch.setattr(manager._send_stop, "wait", lambda _: False)
    manager.start_send("account", names, "안내", {"intervalMinutes": 3})
    manager._run_queue()
    status = manager.send_status()
    assert calls == ["첫 방"]
    assert status["state"] == "error"
    assert [item["status"] for item in status["items"]] == ["review", "pending"]
    with pytest.raises(ValueError, match="확인 필요"):
        manager.resume_send("account")
    manager.resolve_send_item(0, "skipped")
    assert manager.send_status()["items"][0]["status"] == "skipped"


def test_restart_pauses_queue_and_never_resends_inflight_item(monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "data_dir", lambda: str(tmp_path))
    queue = {"accountId": "account", "state": "running", "items": [
        {"name": "첫 방", "status": "sending", "dueAt": 1, "message": "encrypted", "error": ""},
        {"name": "둘째 방", "status": "pending", "dueAt": 2, "message": "encrypted", "error": ""}]}
    kakao_send_queue.save(queue)
    status = KakaoAutoReplyManager().send_status()
    assert status["state"] == "paused"
    assert [item["status"] for item in status["items"]] == ["review", "pending"]


def test_close_failure_marks_message_sent_and_pauses_next_room(monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "data_dir", lambda: str(tmp_path))
    manager = KakaoAutoReplyManager()
    names = ["첫 방", "둘째 방"]
    monkeypatch.setattr(manager, "settings", lambda _: {"rooms": [{"name": name} for name in names]})
    monkeypatch.setattr(manager, "_require_account", lambda _: True)
    manager._rooms = [{"name": name} for name in names]
    monkeypatch.setattr(manager, "_start_queue_thread", lambda: None)
    sent = []
    monkeypatch.setattr(manager, "_send_one", lambda _account, name, _message: sent.append(name) or {"hwnd": 2, "pid": 10})
    monkeypatch.setattr(kakao_window, "close_room", lambda *_: (_ for _ in ()).throw(RuntimeError("창을 닫지 못했어요")))
    monkeypatch.setattr(manager._send_stop, "wait", lambda _: False)
    manager.start_send("account", names, "안내", {"intervalMinutes": 3})
    manager._run_queue()
    status = manager.send_status()
    assert sent == ["첫 방"]
    assert status["state"] == "error"
    assert [item["status"] for item in status["items"]] == ["sent", "pending"]


def test_pause_while_waiting_does_not_open_any_room(monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "data_dir", lambda: str(tmp_path))
    manager = KakaoAutoReplyManager()
    monkeypatch.setattr(manager, "settings", lambda _: {"rooms": [{"name": "시험 방"}]})
    monkeypatch.setattr(manager, "_require_account", lambda _: True)
    manager._rooms = [{"name": "시험 방"}]
    monkeypatch.setattr(manager, "_start_queue_thread", lambda: None)
    monkeypatch.setattr(manager, "_send_one", lambda *_: pytest.fail("중지 후 채팅창을 열면 안 돼요"))
    manager.start_send("account", ["시험 방"], "안내", {"intervalMinutes": 3})
    manager.stop_send()
    manager._run_queue()
    assert manager.send_status()["state"] == "paused"
    assert manager.send_status()["items"][0]["status"] == "pending"


def test_friends_tab_is_not_accepted_as_chat_list():
    window = {"width": 449, "height": 1040}
    assert not kakao_auto_reply._chat_list_visible([{"text": "친구", "x": 82, "y": 44}], window)
    assert kakao_auto_reply._chat_list_visible([{"text": "전체", "x": 95, "y": 86}], window)


def test_chat_window_waits_for_delayed_kakao_window(monkeypatch):
    manager = KakaoAutoReplyManager()
    main = {"hwnd": 1, "pid": 10}
    chat = {"hwnd": 2, "pid": 10}
    attempts = iter((None, None, chat))
    monkeypatch.setattr(kakao_window, "room_window", lambda *a, **k: next(attempts))
    monkeypatch.setattr(kakao_auto_reply.time, "sleep", lambda _: None)
    assert manager._wait_room_window(main, "동생") == chat


def test_failed_reply_does_not_consume_cooldown(monkeypatch, tmp_path):
    monkeypatch.setattr(paths, "data_dir", lambda: str(tmp_path))
    manager = KakaoAutoReplyManager()
    assert manager._cooldown_ok("시험 방", "message-hash", 60)
    assert manager._cooldown_ok("시험 방", "message-hash", 60)
    manager._mark_sent("시험 방", "message-hash")
    assert not manager._cooldown_ok("시험 방", "message-hash", 60)


def test_auto_reply_ignores_outgoing_and_timestamp_backgrounds():
    from PIL import Image, ImageDraw

    image = Image.new("RGB", (400, 400), (186, 206, 224))
    draw = ImageDraw.Draw(image)
    draw.rectangle((50, 100, 180, 145), fill="white")
    draw.rectangle((230, 200, 370, 245), fill=(254, 229, 0))
    assert kakao_auto_reply._incoming_bubble(image, {"x": 70, "y": 112, "w": 40, "h": 15})
    assert not kakao_auto_reply._incoming_bubble(image, {"x": 245, "y": 212, "w": 40, "h": 15})
    assert not kakao_auto_reply._incoming_bubble(image, {"x": 80, "y": 300, "w": 40, "h": 15})


def test_auto_reply_sends_once_for_new_confirmed_incoming_bubble(monkeypatch):
    from PIL import Image, ImageDraw

    manager = KakaoAutoReplyManager()
    main = {"hwnd": 1, "pid": 10}
    chat = {"hwnd": 2, "pid": 10, "width": 400, "height": 500}
    image = Image.new("RGB", (400, 500), (186, 206, 224))
    ImageDraw.Draw(image).rectangle((60, 220, 210, 265), fill="white")
    changed_image = image.copy()
    changed_image.putpixel((120, 230), (100, 100, 100))
    captures = iter((image, changed_image))
    seen = iter(("이전 질문", "새 질문"))
    sent, marked = [], []
    monkeypatch.setattr(manager, "settings", lambda _: {"rooms": [
        {"name": "시험 방", "enabled": True, "reply": "확인했습니다", "mode": "all"}],
        "intervalValue": 1, "intervalUnit": "minutes"})
    monkeypatch.setattr(manager, "_require_account", lambda _: main)
    monkeypatch.setattr(manager, "prepare_window", lambda: main)
    monkeypatch.setattr(manager, "_locate_room", lambda *a: True)
    monkeypatch.setattr(manager, "_wait_room_window", lambda *a: chat)
    monkeypatch.setattr(manager, "_capture", lambda _: next(captures, changed_image))
    monkeypatch.setattr(manager, "_read", lambda *a, **k: [
        {"text": next(seen), "x": 70, "y": 230, "w": 65, "h": 15, "score": .99}])
    monkeypatch.setattr(manager, "_cooldown_ok", lambda *a: True)
    monkeypatch.setattr(manager, "_mark_sent", lambda *a: marked.append(a))

    def send(_window, text):
        sent.append(text)
        manager._stop.set()
        return True

    monkeypatch.setattr(manager, "_send_reply", send)
    monkeypatch.setattr(manager._stop, "wait", lambda _: None)
    monkeypatch.setattr(kakao_auto_reply, "load_config", lambda: {"auto": True})
    monkeypatch.setattr(kakao_auto_reply, "_focus_window", lambda *a, **k: True)
    monkeypatch.setattr(kakao_auto_reply, "log", lambda *a: None)
    monkeypatch.setattr(kakao_window, "dock_right", lambda window: window)
    monkeypatch.setattr(kakao_window, "room_window", lambda *a, **k: chat)
    monkeypatch.setattr(kakao_window, "set_topmost", lambda *a: None)

    manager._run("account")
    assert sent == ["확인했습니다"]
    assert marked == [("account:시험 방", kakao_auto_reply.hashlib.sha256("새 질문".encode()).hexdigest())]
