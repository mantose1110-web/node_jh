import unittest

from autopost.telegram_api_wizard import TelegramApiWizard


class _Page:
    def __init__(self, url, values): self.url, self.values = url, values
    def evaluate(self, _): return self.values


class TelegramApiWizardTests(unittest.TestCase):
    def test_extracts_only_credentials(self):
        page = _Page("https://my.telegram.org/apps", {"text": "App api_id: 30291648\nApp api_hash: 0123456789abcdef0123456789abcdef\npassword: do-not-read", "fields": []})
        self.assertEqual(TelegramApiWizard._extract(page), ("30291648", "0123456789abcdef0123456789abcdef"))

    def test_rejects_lookalike_domain(self):
        page = _Page("https://my.telegram.org.evil.example/apps", {"text": "api_id: 30291648 api_hash: 0123456789abcdef0123456789abcdef", "fields": []})
        with self.assertRaises(ValueError): TelegramApiWizard._extract(page)

    def test_requires_both_values(self):
        page = _Page("https://my.telegram.org/apps", {"text": "App api_id: 30291648", "fields": []})
        with self.assertRaises(ValueError): TelegramApiWizard._extract(page)


if __name__ == "__main__": unittest.main()
