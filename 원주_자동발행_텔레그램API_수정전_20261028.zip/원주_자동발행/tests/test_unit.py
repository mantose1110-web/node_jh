# -*- coding: utf-8 -*-
"""단위 테스트: 암호화 저장, Claude 모델 자동 선택(404 재시도), 글 생성 다양성·사장님 시점, 사진(EXIF 제거·라벨·선택), 일정 배치"""
import json, os, random, re, unittest
from datetime import datetime
import helpers as H


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        H.start_fakes()
        H.bootstrap()


class TestSecure(Base):
    def test_encrypted_on_disk_and_masked(self):
        from autopost import secure
        secure.set_many({"FTP_PASSWORD": "pw-SECRET-12345", "FTP_HOST": "example.kr", "ANTHROPIC_API_KEY": "sk-ant-zzzzzzzzzzzz"})
        raw = open(os.path.join(H.HOME, "data", "secure", "secrets.bin"), "rb").read()
        self.assertTrue(raw.startswith(b"WAP1"))
        self.assertNotIn(b"pw-SECRET-12345", raw)
        self.assertNotIn(b"sk-ant-zzzz", raw)
        self.assertEqual(secure.get("FTP_PASSWORD"), "pw-SECRET-12345")
        m = secure.masked()
        self.assertEqual(m["FTP_PASSWORD"], "••••••••")
        self.assertEqual(m["FTP_HOST"], "example.kr")
        secure.set_many({"FTP_PASSWORD": None, "ANTHROPIC_API_KEY": None, "FTP_HOST": None})
        self.assertEqual(secure.get("FTP_PASSWORD"), "")

    def test_not_allowed_key_ignored(self):
        from autopost import secure
        secure.set_many({"EVIL": "x", "PATH": "y"})
        self.assertNotIn("EVIL", secure.all_values())

    def test_plain_env_migrated_and_deleted(self):
        from autopost import secure
        p = os.path.join(H.HOME, ".env")
        with open(p, "w", encoding="utf-8") as f:
            f.write("FTP_USER=olduser\nFTP_PASSWORD=oldpw123\n")
        secure._cache["data"] = None
        self.assertEqual(secure.get("FTP_USER"), "olduser")
        self.assertFalse(os.path.exists(p))
        secure.set_many({"FTP_USER": None, "FTP_PASSWORD": None})

    def test_log_redacts_secrets(self):
        from autopost import secure
        from autopost.util import redact
        secure.set_many({"FTP_PASSWORD": "abcdef-SECRET"})
        self.assertNotIn("abcdef-SECRET", redact("login with abcdef-SECRET ok"))
        self.assertNotIn("sk-ant-api03-xyz", redact("key sk-ant-api03-xyzxyzxyz"))
        self.assertNotIn("NID_SES=abc", redact("cookie NID_SES=abc123;"))
        secure.set_many({"FTP_PASSWORD": None})

    def test_no_secret_files_in_source(self):
        bad = []
        for d, _, fs in os.walk(H.ROOT_DIR):
            normalized = d.replace("\\", "/")
            if "/tests" in normalized or "__pycache__" in normalized or "/.venv" in normalized:
                continue
            for f in fs:
                if f.endswith((".py", ".json", ".html", ".bat", ".ps1", ".md", ".csv", ".txt", ".spec")):
                    with open(os.path.join(d, f), encoding="utf-8", errors="ignore") as fh:
                        t = fh.read()
                    if re.search(r"sk-ant-api|EAA[A-Za-z0-9]{20}|FTP_PASSWORD\s*=\s*\S", t):
                        bad.append(f)
        self.assertEqual(bad, [])


class TestLLM(Base):
    def setUp(self):
        from autopost import llm
        H.set_key(True)
        llm._bad_models.clear()
        try:
            os.remove(llm._cache_path())
        except OSError:
            pass

    def test_no_hardcoded_model_names(self):
        for f in ("generator.py", "llm.py", "library.py", "dashboard.py"):
            src = open(os.path.join(H.ROOT_DIR, "autopost", f), encoding="utf-8").read()
            self.assertIsNone(re.search(r'"claude-(sonnet|opus|haiku)-[0-9]', src), f)

    def test_models_listed_and_ranked(self):
        from autopost import llm
        ms = llm.list_models(force=True)
        self.assertGreaterEqual(len(ms), 3)
        text = [m["id"] for m in llm.rank(ms, "text")]
        vis = [m["id"] for m in llm.rank(ms, "vision")]
        self.assertIn("sonnet", text[0])
        self.assertIn("haiku", vis[0])

    def test_404_falls_back_to_next_model(self):
        """목록 맨 위 모델이 404 → 다음 모델로 자동 재시도해서 성공 (실제로 난 오류 A)"""
        from autopost import llm
        from autopost.util import load_config
        before = len(H.fake_state()["models_tried"])
        out, model = llm.call_tool(load_config(), "sys", "핵심 키워드: \"아산 치킨\"", {"name": "submit_post", "description": "x", "input_schema": {
            "type": "object", "properties": {}, "required": ["title", "body_html", "tags", "caption", "hashtags"]}}, 2000)
        tried = H.fake_state()["models_tried"][before:]
        self.assertEqual(tried[0], "claude-sonnet-5-0-20260901")       # 최신(퇴역) 모델 먼저 시도 → 404
        self.assertEqual(model, "claude-sonnet-4-6-20260201")         # 다음 모델로 성공
        self.assertTrue(out["title"])

    def test_pinned_unknown_model_falls_back(self):
        from autopost import llm
        from autopost.util import load_config
        cfg = load_config()
        cfg["llm"]["model"] = "claude-sonnet-4-5"    # 예전에 고정돼 있던 이름 → 404
        out, model = llm.call_tool(cfg, "", "핵심 키워드: \"x\"", {"name": "submit_labels", "description": "x", "input_schema": {"type": "object", "properties": {}, "required": []}}, 1000)
        self.assertNotEqual(model, "claude-sonnet-4-5")

    def test_truncated_output_retried_with_bigger_budget(self):
        """글이 최대 토큰에서 잘리면(stop_reason=max_tokens) 잘린 글은 버리고 더 큰 한도로 다시 만들어 완성된 글만 씀"""
        from autopost import generator as g
        H.fake_post("/admin/truncate?n=1")
        p = g.generate("naver", dry=False)
        self.assertTrue(p["title"] and len(g.strip_html(p["body_html"])) > 100)
        self.assertEqual(H.fake_state().get("truncated"), [8000])
        self.assertGreater(H.fake_state()["anthropic"][-1]["max_tokens"], 8000)

    def test_bad_key_message(self):
        from autopost import llm, secure
        secure.set_many({"ANTHROPIC_API_KEY": "sk-ant-wrong-key-000000"})
        with self.assertRaises(llm.ClaudeError) as c:
            llm.list_models(force=True)
        self.assertIn("올바르지", str(c.exception))
        H.set_key(True)


class TestLibrary(Base):
    def setUp(self):
        H.reset_db()

    def test_exif_gps_removed_and_vision_labels(self):
        from PIL import Image
        H.set_key(True)
        photos = H.fill_library(1)
        self.assertEqual(len(photos), len(H.COLORS))
        for p in photos:
            im = Image.open(p["path"])
            self.assertEqual(len(im.getexif()), 0, "EXIF/GPS 가 남아 있음")
            self.assertNotIn(b"Exif", open(p["path"], "rb").read()[:200])
        from autopost import library as lib
        labs = {p["labels"][0] for p in lib.list_photos()}
        self.assertTrue({"후라이드", "양념", "매장외관"} <= labs)
        self.assertTrue(all(p["labelSrc"] == "vision" for p in lib.list_photos()))

    def test_duplicate_upload_ignored(self):
        from autopost import library as lib
        from autopost.util import load_config
        data = H.make_photo((1, 2, 3))
        _, c1 = lib.add_photo(data, "a.jpg", load_config(), label=False)
        _, c2 = lib.add_photo(data, "b.jpg", load_config(), label=False)
        self.assertTrue(c1)
        self.assertFalse(c2)

    def test_not_image_rejected(self):
        from autopost import library as lib
        from autopost.util import load_config
        with self.assertRaises(ValueError):
            lib.add_photo(b"not an image at all", "x.jpg", load_config())

    def test_pick_3_to_6_matching_photos(self):
        H.set_key(True)
        H.fill_library(2)
        from autopost import library as lib, generator as g
        from autopost.util import load_config
        con = g.db()
        for _ in range(10):
            ps = lib.pick_photos(load_config(), "아산 양념치킨", "메뉴소개", "naver", "naver", random.Random(), con=con)
            self.assertTrue(3 <= len(ps) <= 6)
            self.assertIn("양념", ps[0]["labels"])
        ig = lib.pick_photos(load_config(), "온양 치킨", "메뉴소개", "instagram", "instagram", random.Random(), con=con)
        self.assertEqual(len(ig), 1)
        con.close()


class TestPhotoVariety(Base):
    def test_random_variety_and_no_same_set(self):
        """사진을 매번 같은 것만 쓰지 않음: 여러 번 뽑으면 다양한 조합, 쓴 기록이 쌓이면 덜 쓴 사진이 나옴, 앞 글과 같은 묶음 피함"""
        H.reset_db()
        H.fill_library(4)
        from autopost import library as lib, generator as g
        from autopost.util import load_config
        cfg = load_config()
        con = g.db()
        try:
            combos, used = set(), {}
            for i in range(12):
                ps = lib.pick_photos(cfg, "아산 치킨", "매장일상", "naver", f"acct{i % 3}", random.Random(i), con=con)
                self.assertTrue(3 <= len(ps) <= 6)
                ids = tuple(sorted(p["id"] for p in ps))
                combos.add(ids)
                for p in ps:
                    used[p["id"]] = used.get(p["id"], 0) + 1
                lib.record_usage("naver", f"acct{i % 3}", "아산 치킨", lib.as_images(ps, cfg), "t", "매장일상", dry=True)
                if i:
                    self.assertLessEqual(len(set(ids) & set(prev)), 1, "앞 글과 같은 사진 묶음")
                prev = ids
            self.assertEqual(len(combos), 12)                      # 12번 모두 다른 조합
            want = lib.wanted_labels("아산 치킨", "매장일상")
            matching = [p for p in lib.list_photos(con) if any(want.get(l, 0) > 0 for l in p["labels"])]
            self.assertGreaterEqual(len(used), int(len(matching) * 0.9))   # 맞는 사진들을 골고루 돌려 씀
            self.assertLessEqual(max(used.values()), 5)            # 한 사진만 계속 쓰지 않음
        finally:
            con.close()


class TestPhotoCopies(Base):
    def test_each_post_gets_a_different_file(self):
        """같은 사진도 글마다 살짝 다른 사본(크기·밝기·화질·여백)으로 → 파일이 매번 다름, 위치정보 없음"""
        import hashlib
        from PIL import Image
        H.reset_db()
        H.fill_library(1)
        from autopost import library as lib
        from autopost.util import load_config
        p = lib.list_photos()[0]
        hs = set()
        for _ in range(5):
            im = lib.as_images([p], load_config())[0]
            self.assertNotEqual(im["path"], p["path"])
            data = open(im["path"], "rb").read()
            hs.add(hashlib.sha256(data).hexdigest())
            with Image.open(im["path"]) as a, Image.open(p["path"]) as b:
                self.assertGreater(a.width, b.width * 0.85)
                self.assertEqual(len(a.getexif()), 0)
        self.assertEqual(len(hs), 5)
        self.assertEqual(lib.as_images([p], load_config(), variants=False)[0]["path"], p["path"])


class TestGenerator(Base):
    def setUp(self):
        H.reset_db()
        H.set_key(True)

    def test_accounts_get_different_posts(self):
        """같은 날 계정 3개: 키워드·구성·말투가 서로 다르고 사장님 시점, 가짜 후기 없음"""
        from autopost import generator as g, accounts as A
        from autopost.compliance import check_text
        from autopost.util import load_config, save_config
        H.fill_library(2)
        cfg = load_config()
        lst = A.list_accounts(cfg, "naver")
        while len(lst) < 3:
            lst.append(A.new_account(A.new_id(cfg, "naver"), f"ID {len(lst) + 1}"))
        save_config(cfg)
        posts = [g.generate("naver", dry=False, account_obj=a) for a in lst[:3]]
        kws = [p["keyword"] for p in posts]
        self.assertEqual(len(set(kws)), 3, kws)
        self.assertEqual(len({p["style"]["structure"] for p in posts}), 3)
        self.assertEqual(len({p["voice"] for p in posts}), 3)
        for p in posts:
            self.assertEqual(p["provider"], "claude")
            self.assertEqual(check_text(g.strip_html(p["body_html"]) + p["title"]), [])
            self.assertTrue(3 <= len(p["images"]) <= 6)
            self.assertEqual(sorted(set(re.findall(r"\[\[IMG:(\d+)\]\]", p["body_html"]))), [str(i) for i in range(len(p["images"]))])

    def test_keyword_rotation_avoids_recent(self):
        from autopost import generator as g
        seen = [g.generate("naver", dry=True)["keyword"] for _ in range(6)]
        self.assertEqual(len(set(seen)), 6, seen)

    def test_prompt_rules_owner_and_asan(self):
        from autopost import generator as g
        from autopost.util import load_config
        cfg = load_config()
        st, dy = g.prompt_parts(cfg, "naver", {"keyword": "온양 치킨", "group": "x"}, g.pick_combo(g.db(), "naver", random.Random()), "p", [], "v")
        self.assertIn("사장님 본인", st)
        self.assertIn("충남 아산", st)
        self.assertIn("시민로 386", st)
        self.assertIn("후기", st)

    def test_mock_never_live(self):
        from autopost import generator as g
        H.set_key(False)
        with self.assertRaises(RuntimeError):
            g.generate("naver", dry=False)
        self.assertEqual(g.generate("naver", dry=True)["provider"], "mock")
        H.set_key(True)

    def test_brand_and_fake_review_checks(self):
        from autopost import generator as g
        from autopost.compliance import check_text
        p = g.normalize_brand({"title": "원주통닭 이야기", "body_html": "<p>원주통닭 본점</p>", "caption": "", "hashtags": ["#원주통닭"], "tags": []})
        self.assertTrue(p["title"].startswith("아산 원주통닭"))
        self.assertEqual(p["hashtags"], ["#아산원주통닭"])
        self.assertTrue(check_text("내돈내산 솔직후기 ★★★★★"))
        self.assertTrue(check_text('손님이 "여기 최고"라고 하셨어요'))
        self.assertEqual(check_text("포장해 가시는 분들이 많았어요"), [])

    def test_html_sanitized(self):
        from autopost import generator as g
        h = g.sanitize_html('<p onclick="x()">a</p><script>alert(1)</script><a href="javascript:x">b</a><img src=x onerror=y>')
        self.assertNotIn("script", h)
        self.assertNotIn("onclick", h)
        self.assertNotIn("javascript", h)
        self.assertNotIn("<img", h)


class TestPlace(Base):
    def test_parse_owner_info_without_reviews(self):
        from autopost import place
        state = json.load(open(os.path.join(H.ROOT_DIR, "tests", "fixtures", "place_apollo.json"), encoding="utf-8"))
        info = place.parse_apollo(state)
        self.assertEqual(info["address"], "충남 아산시 테스트로 1")
        self.assertEqual(info["menu"][0], {"name": "옛날통닭", "price": "19,000원"})
        self.assertIn("13:00~01:00", info["hours"])
        self.assertNotIn("리뷰", json.dumps(info, ensure_ascii=False))
        self.assertEqual(place.parse_place_id("https://m.place.naver.com/restaurant/17232917/home"), "17232917")
        self.assertEqual(place.parse_place_id("17232917"), "17232917")

    def test_place_photos_into_library_without_exif(self):
        from autopost import library as lib, generator as g
        from autopost.util import load_config
        from PIL import Image
        H.reset_db()
        d = os.path.join(g.ROOT, "photos", "place")
        os.makedirs(d, exist_ok=True)
        for i, col in enumerate([(200, 30, 30), (40, 90, 200)]):
            with open(os.path.join(d, f"place-{'menu' if i == 0 else 'store'}-{i:012d}.jpg"), "wb") as f:
                f.write(H.make_photo(col))
        n = lib.import_place_photos(load_config())
        self.assertEqual(n, 2)
        for p in lib.list_photos():
            self.assertEqual(p["source"], "place")
            self.assertEqual(len(Image.open(p["path"]).getexif()), 0)


class TestPlanner(Base):
    def test_gap_and_interleave(self):
        from autopost.engine import plan_accounts
        for _ in range(50):
            res, dropped = plan_accounts(["main", "main", "a2", "a2", "a3"], (600, 1260), 90)
            mins = [m for m, _ in res]
            self.assertEqual(dropped, [])
            self.assertTrue(all(b - a >= 90 for a, b in zip(mins, mins[1:])))
            accs = [a for _, a in res]
            self.assertTrue(all(a != b for a, b in zip(accs, accs[1:])))

    def test_too_many_dropped(self):
        from autopost.engine import plan_accounts
        res, dropped = plan_accounts(["main"] * 10, (600, 900), 90)
        self.assertEqual(len(res), 4)
        self.assertEqual(len(dropped), 6)

    def test_plan_today_creates_jobs_only_in_auto(self):
        from autopost import engine as E, tasks as T
        from autopost.util import load_config, save_config
        H.reset_db()
        cfg = load_config()
        cfg["auto"] = False
        save_config(cfg)
        self.assertEqual(E.plan_today(cfg, datetime(2026, 10, 19, 8, 0), force=True), [])
        cfg["auto"] = True
        save_config(cfg)
        plan = E.plan_today(cfg, datetime.now().replace(hour=8, minute=0), force=True)
        from autopost import accounts as A
        want = sum(int(a.get("postsPerDay") or 0) for ch in ("naver", "tistory", "wonju", "instagram") for a in A.list_accounts(cfg, ch) if a.get("enabled", True))
        self.assertEqual(len(plan), want)  # 계정별 하루 발행 수 합계
        self.assertTrue(all(T.get(p["id"])["status"] == T.S_WAIT for p in plan))
        cfg["auto"] = False
        save_config(cfg)
        E.plan_today(cfg, force=True)
        self.assertTrue(all(T.get(p["id"]) is None for p in plan))


class TestStyleAndCafe(Base):
    def test_style_analyze_tone_and_emoji(self):
        from autopost import style
        hamnida = ["오늘도 가게 문을 열었습니다. 닭을 손질했습니다. 손님을 기다립니다.\n준비를 마쳤습니다. 감사합니다. 내일도 열심히 하겠습니다."] * 2
        st = style.analyze(hamnida)
        from autopost.generator import TONES
        self.assertEqual(st["tone"], TONES[3])
        self.assertEqual(st["emojiPer200"], 0)
        haeyo = ["오늘 비가 와요 😊 손님이 적었어요.\n그래도 단골분들이 전화 주셨어요 🍗\n내일은 맑대요! 기대해 볼게요. 다들 감기 조심하세요~ 정말 고마워요."] * 2
        st = style.analyze(haeyo)
        self.assertEqual(st["tone"], TONES[0])
        self.assertGreater(st["emojiPer200"], 1)
        self.assertIn("해요체", style.rule_summary(st))
        with self.assertRaises(ValueError):
            style.analyze(["짧음"])

    def test_cafe_url_only_naver_cafe(self):
        from autopost import connect
        os.environ.pop("AUTOPOST_CAFE_HOSTS", None)
        self.assertTrue(connect.cafe_url_ok("https://cafe.naver.com/ca-fe/cafes/123/articles/write?boardType=L&menuId=4"))
        self.assertFalse(connect.cafe_url_ok("http://cafe.naver.com/x"))          # https 만
        self.assertFalse(connect.cafe_url_ok("https://cafe.naver.com.evil.kr/x"))
        self.assertFalse(connect.cafe_url_ok("javascript:alert(1)"))
        self.assertEqual(connect.write_url("cafe", "https://cafe.naver.com/a/b"), "https://cafe.naver.com/a/b")

    def test_keyword_merge_once(self):
        import tempfile
        from autopost import paths
        d = tempfile.mkdtemp()
        src, dst, mk = (os.path.join(d, n) for n in ("src.csv", "dst.csv", "m.txt"))
        open(src, "w", encoding="utf-8").write("group,keyword\n확장 키워드,아산 노포 치킨\n확장 키워드,있는 키워드\n기타,안 넣음\n")
        open(dst, "w", encoding="utf-8").write("group,keyword\n핵심,있는 키워드")
        self.assertEqual(paths.merge_keywords(src, dst, mk), 1)
        rows = open(dst, encoding="utf-8").read().splitlines()
        self.assertEqual(rows[-1], "확장 키워드,아산 노포 치킨")
        open(dst, "w", encoding="utf-8").write("group,keyword\n핵심,있는 키워드\n")   # 사장님이 지운 키워드는 다시 넣지 않음
        self.assertEqual(paths.merge_keywords(src, dst, mk), 0)

    def test_profile_not_restored_after_forced_close(self):
        import json as _j, tempfile
        from autopost import browser
        d = tempfile.mkdtemp()
        os.makedirs(os.path.join(d, "Default", "Sessions"))
        open(os.path.join(d, "Default", "Sessions", "Session_1"), "w").write("x")
        open(os.path.join(d, "Default", "Current Tabs"), "w").write("x")
        _j.dump({"profile": {"exit_type": "Crashed"}, "session": {"restore_on_startup": 1}}, open(os.path.join(d, "Default", "Preferences"), "w"))
        browser.no_restore(d)
        p = _j.load(open(os.path.join(d, "Default", "Preferences")))
        self.assertEqual(p["profile"]["exit_type"], "Normal")
        self.assertEqual(p["session"]["restore_on_startup"], 5)
        self.assertEqual(os.listdir(os.path.join(d, "Default", "Sessions")), [])
        self.assertFalse(os.path.exists(os.path.join(d, "Default", "Current Tabs")))

    def test_guide_block_is_text_not_markdown_link(self):
        from autopost import blocks
        shop = {"name": "아산 원주통닭 본점", "address": "충남 아산시 시민로 386", "naverPlaceId": "17232917", "hours": "14:00~01:00", "phone": "041"}
        for ch in ("guide", "cafe"):
            h = blocks.place_card(shop, ch)
            self.assertNotIn("<a ", h)
            self.assertIn("https://map.naver.com/p/entry/place/17232917", h)
        body = blocks.apply("<p>x</p>", "guide", shop, {"text": "문의", "buttons": [{"label": "길찾기", "url": "https://map.naver.com/p/entry/place/17232917"}]}, "bottom", True)
        self.assertEqual(body.count("place/17232917"), 1)

    def test_summary_card_at_top(self):
        """가게 한눈에 보기: 글 맨 위, 가게 정보에 있는 것만, 아래 지도 안내는 링크 한 줄만"""
        from autopost import blocks
        from autopost.util import load_config
        shop = load_config()["shop"]
        body = blocks.apply("<p>본문</p>", "naver", shop, None, "bottom", True, summary=True)
        self.assertTrue(body.startswith("<p>━"))
        self.assertIn("한눈에 보기", body)
        self.assertIn(shop["hours"], body)
        self.assertIn("대표 메뉴", body)
        self.assertNotIn("배달", body)                                   # 안 하는 서비스는 안 씀
        self.assertEqual(body.count("map.naver.com/p/entry/place/"), 1)
        self.assertLess(body.index("한눈에"), body.index("본문"))
        html = blocks.apply("<p>본문</p>", "tistory", shop, None, "bottom", False, summary=True)
        self.assertIn('class="shop-card"', html)
        self.assertNotIn("한눈에", blocks.apply("<p>본문</p>", "naver", shop, None, "bottom", False, summary=False))

    def test_strip_links_for_cafe(self):
        from autopost import generator as g
        p = g.strip_links({"body_html": '<p>안녕하세요</p><p>메뉴는 <a href="https://원주.kr">여기</a></p><p>https://원주.kr 참고</p><p>끝</p>', "caption": "a https://원주.kr"},
                          {"shop": {"url": "https://원주.kr"}})
        self.assertEqual(p["body_html"], "<p>안녕하세요</p><p>끝</p>")
        self.assertEqual(p["caption"], "a")



if __name__ == "__main__":
    unittest.main()
