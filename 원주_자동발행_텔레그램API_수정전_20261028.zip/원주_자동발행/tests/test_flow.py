# -*- coding: utf-8 -*-
"""전체 흐름 테스트 (실제 크로미움 + 가짜 네이버·티스토리·인스타·FTP·Claude 서버)

B  로그인 창(일반 크롬, 자동화 표시 없음)과 발행 브라우저가 같은 프로필·같은 세션 → '로그인 만료' 없이 발행
   NID_AUT + NID_SES 쿠키와 실제 글쓰기 화면으로 판단 / 연결 안 된 계정은 글을 만들지 않음(토큰 0)
C  같은 계정 동시 실행 금지 + 간격, 'Target page, context or browser has been closed' 없음
D  발행 실패 → 만든 글 그대로 '다시 시도'
E  스마트에디터 제목·본문·사진 업로드·공개/비공개 발행, 실패 시 스크린샷과 원인
"""
import os, threading, time, unittest
import helpers as H


def wait(fn, timeout=60, step=0.5):
    end = time.time() + timeout
    while time.time() < end:
        v = fn()
        if v:
            return v
        time.sleep(step)
    return None


class Flow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        H.start_fakes()
        H.bootstrap()
        H.reset_db()
        H.set_key(True)
        H.fill_library(2)
        from autopost.util import load_config, save_config
        from autopost import accounts as A
        cfg = load_config()
        cfg["live"] = True
        cfg["auto"] = False
        for ch in ("naver", "tistory", "wonju", "instagram"):
            cfg["accounts"][ch]["list"] = cfg["accounts"][ch]["list"][:1]
        cfg["accounts"]["naver"]["list"].append(A.new_account("a2", "ID 2"))
        cfg["accounts"]["tistory"]["list"][0]["handle"] = "wonjublog"
        save_config(cfg)

    # ---------- 도우미 ----------
    def engine_run(self, rounds=40, until=None):
        from autopost.engine import Engine
        e = Engine(tick=0.1)
        for _ in range(rounds):
            e.tick()
            if until and until():
                return True
            time.sleep(0.3)
        return False

    def job(self, jid):
        from autopost import tasks as T
        return T.get(jid)

    def claude_calls(self):
        return len(H.fake_state()["anthropic"])

    def login(self, ch, aid):
        from autopost import connect
        from autopost.util import load_config
        r = connect.connect_login(ch, load_config(), aid)
        self.assertTrue(r["started"], r)
        prof = ch if aid == "main" else f"{ch}-{aid}"
        st = wait(lambda: connect.session_status().get(prof, {}).get("state") in ("connected", "failed", "cancelled", "notfound", "timeout")
                  and not connect.is_waiting(prof), 90)
        self.assertTrue(st, "로그인 확인이 끝나지 않음")
        self.assertEqual(connect.session_status()[prof]["state"], "connected", connect.session_status()[prof])

    # ---------- 테스트 (이름 순서대로 실행) ----------
    def test_01_unconnected_no_generation(self):
        """연결 안 된 계정: 실제 발행 모드에서 글을 만들지 않고 '연결 필요' (Claude 호출 0회)"""
        from autopost import tasks as T
        before = self.claude_calls()
        jid = T.add("naver", "main", "ID 1")
        T.generate_job(jid)
        self.assertEqual(self.job(jid)["status"], T.S_NEED)
        self.assertEqual(self.job(jid)["title"], "")
        self.assertEqual(self.claude_calls(), before)
        self.__class__.waiting_job = jid

    def test_02_login_same_profile_and_resume(self):
        """로그인 창 → 쿠키 2개 + 글쓰기 화면 확인 → 연결됨, 블로그 아이디 자동 입력, 기다리던 작업 자동 재개"""
        from autopost import tasks as T, browser, accounts as A
        from autopost.util import load_config
        self.login("naver", "main")
        self.assertEqual(A.get(load_config(), "naver", "main")["handle"], "qa_user")
        saved = {c["name"]: c for c in browser.load_cookies("naver")}
        self.assertIn("NID_AUT", saved)
        self.assertIn("NID_SES", saved)
        self.assertEqual(saved["NID_SES"].get("expires", -1), -1)      # 세션 쿠키도 저장됨
        raw = open(os.path.join(H.HOME, "data", "secure", "session-naver.bin"), "rb").read()
        self.assertNotIn(b"NID_SES", raw)                                # 암호화 저장
        self.assertEqual(self.job(self.waiting_job)["status"], T.S_WAIT)  # 연결되자 자동 재개
        self.engine_run(60, lambda: self.job(self.waiting_job)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED))
        j = self.job(self.waiting_job)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        pub = H.fake_state()["naver"][-1]
        self.assertEqual(pub["title"], j["title"])
        self.assertEqual(pub["visibility"], "open_public")
        self.assertTrue(pub["text"].lstrip().startswith("━"))          # 맨 위 '가게 한눈에 보기'
        self.assertIn("한눈에 보기", pub["text"][:200])
        self.assertEqual(len(pub["images"]), len(j["images"]))
        self.assertTrue(3 <= len(pub["images"]) <= 6)
        self.assertIn(j["keyword"], pub["text"] + pub["title"])
        self.assertRegex(j["url"], r"PostView.*logNo=\d+")

    def test_03_second_account_and_distinct_content_and_gap(self):
        """계정 2 연결 → 계정마다 다른 글, 같은 브라우저 동시 실행 없음, 같은 계정 간격 지킴"""
        from autopost import tasks as T
        self.login("naver", "a2")
        ids = [T.add("naver", "main", "ID 1"), T.add("naver", "a2", "ID 2"), T.add("naver", "main", "ID 1"), T.add("naver", "a2", "ID 2")]
        self.engine_run(200, lambda: all(self.job(i)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_REVIEW) for i in ids))
        jobs = [self.job(i) for i in ids]
        for j in jobs:
            self.assertEqual(j["status"], T.S_DONE, j["error"])
        self.assertEqual(len({j["title"] for j in jobs}), 4)
        self.assertEqual(len({j["keyword"] for j in jobs}), 4)
        from datetime import datetime
        for aid in ("main", "a2"):
            ts = sorted(datetime.fromisoformat(j["published_at"]) for j in jobs if j["account_id"] == aid)
            self.assertGreaterEqual((ts[1] - ts[0]).total_seconds(), 5 - 1)   # 5분(시험에서는 60배 빠르게 5초) 간격
        st = H.fake_state()
        accts = {p["cookie"] for p in st["naver"][-4:]}
        self.assertEqual(len(accts), 2)   # 두 계정이 서로 다른 세션으로 올림

    def test_04_expired_session_waits_then_resumes(self):
        """서버에서 세션 만료 → 발행 때 '연결 필요'(글 유지, 스크린샷) → 다시 로그인하면 같은 글로 발행"""
        from autopost import tasks as T, connect
        jid = T.add("naver", "main", "ID 1")
        T.generate_job(jid)
        title = self.job(jid)["title"]
        calls = self.claude_calls()
        H.fake_post("/admin/expire")
        self.engine_run(20, lambda: self.job(jid)["status"] != T.S_READY)
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_NEED, j["error"])
        self.assertEqual(j["title"], title)
        self.assertEqual(connect.session_status()["naver"]["state"], "expired")
        self.login("naver", "main")
        self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        self.assertEqual(j["title"], title)
        self.assertEqual(self.claude_calls(), calls)      # 다시 만들지 않음
        H.fake_post("/admin/expire")   # 모든 세션 만료 → 다음 테스트를 위해 두 계정 다시 연결
        self.login("naver", "main")
        self.login("naver", "a2")

    def test_05_publish_fail_retry_keeps_post(self):
        """발행 실패(자동 재시도 2회 포함) → '발행 실패' + 스크린샷 → 다시 시도는 같은 글로 발행만"""
        from autopost import tasks as T
        from autopost.util import load_config, save_config
        cfg = load_config()
        cfg["schedule"]["retryMinutes"] = 0
        save_config(cfg)
        jid = T.add("naver", "a2", "ID 2")
        T.generate_job(jid)
        before = self.job(jid)
        calls = self.claude_calls()
        H.fake_post("/admin/fail_publish?n=3")
        self.engine_run(80, lambda: self.job(jid)["status"] == T.S_PUB_FAIL)
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_PUB_FAIL, j["error"])
        self.assertIn("발행 버튼", j["error"])
        self.assertTrue(j["shot"] and os.path.exists(j["shot"]), "스크린샷 없음")
        self.assertTrue(T.retry_publish(jid))
        self.engine_run(40, lambda: self.job(jid)["status"] == T.S_DONE)
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        self.assertEqual((j["title"], j["body_html"]), (before["title"], before["body_html"]))
        self.assertEqual(self.claude_calls(), calls)
        logtxt = "\n".join(open(f, encoding="utf-8").read() for f in __import__("glob").glob(os.path.join(H.HOME, "logs", "*.log")))
        self.assertIn("'발행 버튼' 단계 실패", logtxt)
        self.assertIn("스크린샷:", logtxt)

    def test_06_private_publish(self):
        from autopost import tasks as T
        jid = T.add("naver", "main", "ID 1", settings={"private": True})
        self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL))
        self.assertEqual(self.job(jid)["status"], T.S_DONE, self.job(jid)["error"])
        self.assertEqual(H.fake_state()["naver"][-1]["visibility"], "open_private")

    def test_07_concurrent_publish_never_overlaps(self):
        """여러 스레드가 동시에 발행을 시도해도 같은 프로필은 한 번에 하나 → 'Target ... closed' 없음"""
        from autopost import tasks as T
        from autopost.engine import Engine
        ids = []
        for aid in ("main", "a2", "main"):
            jid = T.add("naver", aid, aid)
            T.generate_job(jid)
            ids.append(jid)
        errs = []

        end = time.time() + 150

        def worker():
            e = Engine(tick=0.1)
            while time.time() < end and not all(self.job(i)["status"] == T.S_DONE for i in ids):
                try:
                    e.publish_one()
                except Exception as ex:  # noqa: BLE001
                    errs.append(str(ex))
                time.sleep(0.2)
        logf = __import__("glob").glob(os.path.join(H.HOME, "logs", "*.log"))[0]
        start_len = os.path.getsize(logf)
        ths = [threading.Thread(target=worker) for _ in range(3)]
        [t.start() for t in ths]
        [t.join() for t in ths]
        jobs = [self.job(i) for i in ids]
        with open(logf, encoding="utf-8") as f:
            f.seek(start_len)
            seq = [("open" if "글쓰기 화면 열기" in l else "done") for l in f.read().splitlines() if "[네이버 naver" in l and ("글쓰기 화면 열기" in l or "발행 완료" in l)]
        self.assertEqual(seq, ["open", "done"] * 3)      # 브라우저 작업이 겹치지 않고 하나씩
        self.assertEqual(errs, [])
        for j in jobs:
            self.assertEqual(j["status"], T.S_DONE, j["error"])
            self.assertNotIn("closed", j["error"])
        logtxt = "\n".join(open(f, encoding="utf-8").read() for f in __import__("glob").glob(os.path.join(H.HOME, "logs", "*.log")))
        self.assertNotIn("Target page, context or browser has been closed", logtxt)

    def test_08_tistory(self):
        from autopost import tasks as T
        self.login("tistory", "main")
        jid = T.add("tistory", "main", "ID 1")
        self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        p = H.fake_state()["tistory"][-1]
        self.assertEqual(p["visibility"], "public")
        self.assertEqual(p["html"].count("<img"), len(j["images"]))
        self.assertGreaterEqual(len(j["images"]), 3)
        self.assertEqual(p["wrongFile"], 0)          # '파일' 첨부 칸에 사진을 넣지 않음

    def test_09_wonju_ftp(self):
        from autopost import tasks as T, secure
        from autopost.publishers.wonju import ftp_test
        secure.set_many({"FTP_HOST": f"127.0.0.1:{H._started['ftp_port']}", "FTP_USER": "wonju", "FTP_PASSWORD": "ftp-pass-QA"})
        self.assertIsInstance(ftp_test(), list)
        from autopost import connect
        connect.set_state("wonju", ok=True, state="connected")
        jid = T.add("wonju", "main", "원주.kr")
        self.engine_run(30, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        name = j["url"].rsplit("/", 1)[-1]
        self.assertTrue(os.path.exists(os.path.join(H.FTP_ROOT, "html", "blog", name)))
        html = open(os.path.join(H.FTP_ROOT, "html", "blog", name), encoding="utf-8").read()
        for im in j["images"]:
            self.assertIn(im["name"], html)
            self.assertTrue(os.path.exists(os.path.join(H.FTP_ROOT, "html", "photos", im["name"])))
        self.assertIn("아산", html)

    def test_10_instagram(self):
        from autopost import tasks as T, secure, connect
        secure.set_many({"META_APP_ID": "123", "META_APP_SECRET": H.FS.META_SECRET})
        r = connect.exchange_instagram_token("EAAshort-token-123")
        self.assertTrue(r["ok"], r)
        jid = T.add("instagram", "main", "ID 1")
        self.engine_run(30, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        p = H.fake_state()["ig_published"][-1]
        self.assertIn("#아산원주통닭", p["caption"])
        self.assertLessEqual(p["caption"].count("#"), 30)
        self.assertTrue(p["image_url"].startswith(H.BASE + "/site/html/photos/"))
        self.assertGreater(p["bytes"], 1000)

    def test_11_test_mode_never_touches_browser(self):
        """테스트 모드: 브라우저를 열지 않고 '테스트 완료' (미리보기만)"""
        from autopost import tasks as T
        from autopost.util import load_config, save_config
        cfg = load_config()
        cfg["live"] = False
        save_config(cfg)
        opens = H.fake_state()["editor_opens"]
        n_pub = len(H.fake_state()["naver"])
        jid = T.add("naver", "main", "ID 1")
        self.engine_run(20, lambda: self.job(jid)["status"] in (T.S_TEST, T.S_PUB_FAIL, T.S_GEN_FAIL))
        self.assertEqual(self.job(jid)["status"], T.S_TEST)
        self.assertEqual(H.fake_state()["editor_opens"], opens)
        self.assertEqual(len(H.fake_state()["naver"]), n_pub)
        cfg["live"] = True
        save_config(cfg)

    def test_12_auto_mode_full_day(self):
        """자동 모드: 계획 → 시간 되면 생성 → 발행. 연결 안 된 인스타 계정 2는 '연결 필요'(토큰 0)"""
        from autopost import tasks as T, engine as E, accounts as A
        from autopost.util import load_config, save_config
        from datetime import datetime, timedelta
        cfg = load_config()
        cfg["auto"] = True
        cfg["accounts"]["instagram"]["list"].append(A.new_account("a2", "ID 2"))
        cfg["schedule"]["activeHours"] = [0, 24]
        cfg["schedule"]["accountGapMinutes"] = 10
        save_config(cfg)
        plan = E.plan_today(cfg, force=True)
        self.assertEqual(len(plan), 6)
        for p in plan:   # 시험: 예약 시각을 지금으로 당김
            T.update(p["id"], scheduled_at=(datetime.now() - timedelta(seconds=1)).isoformat(timespec="seconds"))
        calls = self.claude_calls()
        self.engine_run(300, lambda: all(self.job(p["id"])["status"] in T.FINAL + (T.S_NEED, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_REVIEW) for p in plan))
        st = {(self.job(p["id"])["channel"], self.job(p["id"])["account_id"]): self.job(p["id"]) for p in plan}
        self.assertEqual(st[("instagram", "a2")]["status"], T.S_NEED)
        for k, j in st.items():
            if k != ("instagram", "a2"):
                self.assertEqual(j["status"], T.S_DONE, (k, j["error"]))
        self.assertTrue(5 <= self.claude_calls() - calls <= 10)   # 글 5개(반복이면 1번씩만 다시 씀), 연결 안 된 계정 몫은 호출 안 함
        self.assertEqual(st[("instagram", "a2")]["title"], "")
        cfg = load_config()
        cfg["auto"] = False
        save_config(cfg)

    def _publish_naver(self, settings=None, ch="naver", aid="main"):
        from autopost import tasks as T
        jid = T.add(ch, aid, aid, settings=settings or {})
        self.engine_run(80, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
        return self.job(jid)

    def test_13_map_search_tries_queries_and_picks_right_place(self):
        """'아산 원주통닭 본점'은 검색 결과 없음 → 다음 검색어 '원주통닭' → 대구·안산·배방점은 건너뛰고 시민로 386 만 선택"""
        from autopost import tasks as T
        from autopost.util import load_config, save_config
        cfg = load_config()
        cfg["place"] = {"mapQueries": ["아산 원주통닭 본점", "원주통닭"], "mapMatch": ["시민로 386"]}
        save_config(cfg)
        before = len(H.fake_state().get("place_queries", []))
        j = self._publish_naver()
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        qs = H.fake_state()["place_queries"][before:]
        self.assertEqual(qs[:2], ["아산 원주통닭 본점", "원주통닭"])
        place = H.fake_state()["naver"][-1]["place"]
        self.assertIn("시민로 386", place)
        self.assertFalse(H.fake_state()["naver"][-1]["libClosed"])   # 옆 '라이브러리' 창은 건드리지 않음
        self.assertEqual(H.fake_state()["naver"][-1]["materialTyped"], "")   # 아래 '글감 검색' 칸에 잘못 입력하지 않음 (실제 오류)
        self.assertNotIn("대구", place)

    def test_14_map_not_found_skips_map_only(self):
        """주소가 맞는 결과가 없으면 엉뚱한 가게를 넣지 않고 지도만 빼고 발행 (본문 아래 안내는 유지)"""
        from autopost import tasks as T
        from autopost.util import load_config, save_config
        cfg = load_config()
        cfg["place"] = {"mapQueries": ["원주통닭"], "mapMatch": ["없는주소 999"]}
        save_config(cfg)
        j = self._publish_naver()
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        pub = H.fake_state()["naver"][-1]
        self.assertIsNone(pub["place"])
        self.assertIn("map.naver.com", pub["text"])
        self.assertEqual(pub["text"].count("map.naver.com/p/entry/place"), 1)   # 지도 주소(링크 카드)는 한 번만
        self.assertEqual(pub["materialTyped"], "")
        self.assertIn("지도 첨부는 건너뛰고", self.logtext())
        cfg["place"] = {}
        save_config(cfg)

    def logtext(self):
        import glob
        return "\n".join(open(f, encoding="utf-8").read() for f in glob.glob(os.path.join(H.HOME, "logs", "*.log")))

    def test_15_late_popup_does_not_break_publish(self):
        """글쓰기 도중 늦게 뜨는 도움말 창이 화면을 가려도 닫고 이어서 발행 (네이버가 입력을 못 받는 문제)"""
        from autopost import tasks as T
        H.fake_post("/admin/glitch?on=1")
        try:
            for _ in range(2):
                j = self._publish_naver()
                self.assertEqual(j["status"], T.S_DONE, j["error"])
                pub = H.fake_state()["naver"][-1]
                self.assertEqual(pub["title"], j["title"])
                self.assertEqual(len(pub["images"]), len(j["images"]))
                self.assertEqual(pub["visibility"], "open_public")   # id 없는 '전체 공개' 라벨도 찾음
            j = self._publish_naver(settings={"private": True})
            self.assertEqual(j["status"], T.S_DONE, j["error"])
            self.assertEqual(H.fake_state()["naver"][-1]["visibility"], "open_private")
        finally:
            H.fake_post("/admin/glitch?on=0")

    def test_16_guide_blog_channel(self):
        """손님용 블로그: 따로 로그인한 프로필로, 손님 안내글 프롬프트 + '가게가 직접 작성' 문구로 발행"""
        from autopost import tasks as T, accounts as A
        from autopost.util import load_config
        from autopost.compliance import check_text
        self.login("guide", "main")
        self.assertEqual(A.get(load_config(), "guide", "main")["handle"], "qa_user")
        j = self._publish_naver(ch="guide")
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        self.assertEqual(j["settings"]["promptUsed"], "guide")
        pub = H.fake_state()["naver"][-1]
        self.assertIn("운영하는 정보 블로그", pub["text"])
        self.assertNotIn("사장입니다", pub["text"])           # 손님용 블로그 = 블로거 시점 (사장님 말투 아님)
        self.assertEqual(check_text(pub["text"]), [])
        sysmsg = H.fake_state()["anthropic"][-1]["system"]
        self.assertIn("손님 안내용 블로그", sysmsg)
        self.assertTrue(os.path.isdir(os.path.join(H.HOME, "profiles", "guide")))

    def test_16b_guide_owner_voice_rewritten(self):
        """손님용 블로그에 사장님 말투('사장입니다')가 나오면 고칠 점을 알려 주고 블로거 시점으로 다시 씀"""
        from autopost import generator as g, accounts as A
        from autopost.util import load_config
        H.fake_post("/admin/owner_voice?n=1")
        post = g.generate("guide", dry=True, account_obj=A.get(load_config(), "guide", "main"), record=False)
        self.assertNotIn("사장입니다", post["body_html"])
        self.assertEqual([i for i in post["quality_issues"] if i.startswith("[")], [])
        calls = H.fake_state()["anthropic"]
        self.assertIn("고쳐야 할 점", calls[-1]["user"])
        self.assertIn("사장님 시점 표현", calls[-1]["user"])
        self.assertIn("블로그의 운영자(파워블로거 스타일", calls[-1]["system"])
        self.assertNotIn("사장님 일기체", calls[-1]["user"])

    def test_17_x_publish(self):
        """X: OAuth 1.0a 서명(가짜 서버가 검증) → 사진 업로드 → 280칸 안의 글 + 해시태그 + 링크"""
        from autopost import tasks as T, secure, connect
        from autopost.publishers import x as X
        k = H.FS.X_KEYS
        secure.set_many({"X_API_KEY": k["api_key"], "X_API_SECRET": k["api_secret"], "X_ACCESS_TOKEN": k["token"], "X_ACCESS_SECRET": k["token_secret"]})
        r = X.check("main")
        self.assertTrue(r["ok"], r)
        connect.set_state("x", ok=True, state="connected", username=r["username"])
        secure.set_many({"X_ACCESS_SECRET": "wrong-secret"})
        self.assertFalse(X.check("main")["ok"])      # 서명이 틀리면 거절됨 = 서명 검증이 실제로 동작
        secure.set_many({"X_ACCESS_SECRET": k["token_secret"]})
        for _ in range(2):
            jid = T.add("x", "main", "ID 1")
            self.engine_run(30, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED))
            j = self.job(jid)
            self.assertEqual(j["status"], T.S_DONE, j["error"])
            post = H.fake_state()["x_posts"][-1]
            self.assertLessEqual(X.weighted_len(post["text"]), 280)
            self.assertIn("원주.kr", post["text"])
            self.assertIn("#", post["text"])
            self.assertEqual(len(post["media"]), len(j["images"]))
        long = {"caption": "가" * 400, "hashtags": ["#아산원주통닭", "#아산맛집", "#온양맛집", "#아산통닭", "#치킨"]}
        from autopost.util import load_config
        self.assertLessEqual(X.weighted_len(X.build_text(long, load_config())), 280)

    def test_18_daily_photos_to_post(self):
        """일상 글: 오늘 사진 3장 → AI가 글 계획(지시문) → 지시문대로 네이버·X 글 생성, 사진은 올린 순서대로"""
        from autopost import tasks as T, library as lib, daily
        from autopost.util import load_config
        cfg = load_config()
        ids = [lib.add_photo(H.make_photo((10 + i * 40, 50, 90)), f"today_{i}.jpg", cfg, source="daily", label=False)[0]["id"] for i in range(3)]
        plan = daily.plan(cfg, ids, "비가 와서 포장 손님이 많았음")
        self.assertTrue(plan["ai"])
        self.assertEqual(len(plan["photos"]), 3)
        self.assertEqual(lib.get_photo(ids[0])["caption"], "주방에서 통닭을 튀기는 모습 1")
        st = {"daily": {"photo_ids": ids, "plan": plan["prompt"] + " (사장님이 고침)", "memo": "비", "keyword": plan["keyword"]}, "hold": True}
        jn = T.add("naver", "main", "ID 1", keyword=plan["keyword"], settings=dict(st))
        jx = T.add("x", "main", "ID 1", keyword=plan["keyword"], settings=dict(st))
        self.engine_run(40, lambda: all(self.job(i)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_REVIEW) for i in (jn, jx)))
        n, x = self.job(jn), self.job(jx)
        self.assertEqual(n["status"], T.S_HOLD, n["error"])   # 확인 후 등록: 자동으로 올리지 않음
        self.assertEqual([i["photoId"] for i in n["images"]], ids)
        self.assertEqual(len(x["images"]), 1)
        users = [a["user"] for a in H.fake_state()["anthropic"][-2:]]
        self.assertTrue(all("FAKE-PLAN-MARK" in u and "사장님이 고침" in u for u in users))
        self.assertTrue(T.release(jn) and T.release(jx))
        self.engine_run(60, lambda: all(self.job(i)["status"] in (T.S_DONE, T.S_PUB_FAIL) for i in (jn, jx)))
        self.assertEqual(self.job(jn)["status"], T.S_DONE, self.job(jn)["error"])
        self.assertEqual(self.job(jx)["status"], T.S_DONE, self.job(jx)["error"])
        self.assertEqual(len(H.fake_state()["naver"][-1]["images"]), 3)

    def test_19_work_settings_hold_flow_and_custom_prompt(self):
        """작업 설정: 작업 추가 → (기다림) → 글 생성 시작 → 생성됨(확인) → 등록 시작 → 완료. 사장님이 고친 프롬프트가 실제로 쓰임"""
        from autopost import tasks as T
        from autopost.util import load_config, save_config
        cfg = load_config()
        cfg["prompts"] = [{"id": "owner", "name": "사장님", "text": "테스트용 프롬프트 ZZ-PROMPT-MARK 로 써 주세요."}]
        cfg["promptExtra"] = "이번 주는 YY-EXTRA-MARK 를 지켜요"
        save_config(cfg)
        jid = T.add("naver", "main", "ID 1", keyword="온양 치킨", scheduled_at="9999-12-31T00:00:00", settings={"hold": True, "prompt": "owner"})
        self.engine_run(3)
        self.assertEqual(self.job(jid)["status"], T.S_WAIT)
        self.assertTrue(T.start_generation(jid))
        self.engine_run(20, lambda: self.job(jid)["status"] == T.S_HOLD)
        self.assertEqual(self.job(jid)["status"], T.S_HOLD)
        sysmsg = H.fake_state()["anthropic"][-1]["system"]
        self.assertIn("ZZ-PROMPT-MARK", sysmsg)
        self.assertIn("YY-EXTRA-MARK", sysmsg)
        self.assertTrue(T.release(jid))
        self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
        self.assertEqual(self.job(jid)["status"], T.S_DONE, self.job(jid)["error"])
        cfg.pop("prompts")
        cfg["promptExtra"] = ""
        save_config(cfg)

    def test_20_tistory_editor_reload_and_tags(self):
        """티스토리: '이어서 작성' 취소 → 편집기 새로고침('tinymce is not defined' 상황)에도 제목·본문·사진·태그가 다 들어가서 발행"""
        from autopost import tasks as T
        H.fake_post("/admin/glitch?on=1")
        try:
            for _ in range(2):
                jid = T.add("tistory", "main", "ID 1")
                self.engine_run(80, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
                j = self.job(jid)
                self.assertEqual(j["status"], T.S_DONE, j["error"])
                p = H.fake_state()["tistory"][-1]
                self.assertEqual(p["title"], j["title"])
                self.assertEqual(p["html"].count("<img"), len(j["images"]))
                self.assertGreaterEqual(len(p["tags"]), 3)
                self.assertIn(j["keyword"], p["tags"])
                self.assertNotIn("임시저장 글", p["html"])
                self.assertEqual(p["visibility"], "public")     # 숨겨진 라디오여도 '공개' 선택
        finally:
            H.fake_post("/admin/glitch?on=0")

    def test_21_naver_tags_in_field_and_body(self):
        """네이버: 발행 창 태그 칸에 태그 입력 + 본문 끝 #태그"""
        from autopost import tasks as T
        j = self._publish_naver()
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        p = H.fake_state()["naver"][-1]
        self.assertGreaterEqual(len(p["tags"]), 3)
        self.assertIn(j["keyword"].replace(" ", ""), p["tags"])
        self.assertEqual(len(p["tags"]), len(set(p["tags"])))
        self.assertGreaterEqual(len(p["body_tags"]), 3)

    def test_22_missing_photo_file_skipped(self):
        """사진 파일이 없어져도 그 사진만 빼고 발행 (WinError 2 '파일을 찾을 수 없습니다' 상황)"""
        from autopost import tasks as T
        jid = T.add("tistory", "main", "ID 1", settings={"hold": True})
        self.engine_run(20, lambda: self.job(jid)["status"] == T.S_HOLD)
        j = self.job(jid)
        n = len(j["images"])
        self.assertGreaterEqual(n, 2)
        imgs = [dict(i) for i in j["images"]]
        from autopost import library as lib
        orig = lib.get_photo(imgs[0]["photoId"])["path"]             # 사본과 자료함 원본 둘 다 없어진 상황
        os.rename(orig, orig + ".moved")
        gone = imgs[0]["path"] + ".moved"
        os.rename(imgs[0]["path"], gone)
        try:
            T.release(jid)
            self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
            self.assertEqual(self.job(jid)["status"], T.S_DONE, self.job(jid)["error"])
            self.assertEqual(H.fake_state()["tistory"][-1]["html"].count("<img"), n - 1)
            self.assertIn("사진 파일 1장이 없어져", self.logtext())
        finally:
            os.rename(gone, imgs[0]["path"])
            os.rename(orig + ".moved", orig)

    def test_23_deleting_photo_keeps_file_for_pending_post(self):
        from autopost import tasks as T, library as lib
        jid = T.add("naver", "main", "ID 1", settings={"hold": True})
        self.engine_run(20, lambda: self.job(jid)["status"] == T.S_HOLD)
        im = self.job(jid)["images"][0]
        self.assertTrue(lib.delete_photo(im["photoId"]))
        self.assertTrue(os.path.exists(im["path"]))    # 올릴 글이 쓰는 사진 파일은 남김
        T.delete(jid)

    def test_24_naver_cafe_hold_then_publish(self):
        """네이버 카페: 게시판 글쓰기 주소 + 같은 네이버 로그인 방식 → 기본 '확인 후 등록' → 등록 → 링크·지도·홍보 블록 없이 사진·태그와 함께 등록"""
        from autopost import tasks as T, accounts as A, connect
        from autopost.util import load_config, save_config
        cfg = load_config()
        acc = A.get(cfg, "cafe", "main")
        self.assertTrue(acc["hold"])                       # 카페 기본값: 확인 후 등록
        self.assertFalse(connect.cafe_url_ok("https://evil.example.com/write"))
        acc["handle"] = f"{H.BASE}/cafe/ca-fe/cafes/1/articles/write?boardType=L&menuId=7"
        save_config(cfg)
        self.login("cafe", "main")
        jid = T.add("cafe", "main", "ID 1", settings=T.job_defaults(A.get(load_config(), "cafe", "main")))
        self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_REVIEW, T.S_NEED))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_HOLD, j["error"])
        self.assertNotIn("<a ", j["body_html"])
        self.assertNotIn("원주.kr", j["body_html"])
        self.assertFalse(j["settings"]["place"])
        sysmsg = H.fake_state()["anthropic"][-1]["system"]
        self.assertIn("홈페이지·전화번호·주문 권유를 쓰지 말 것", sysmsg)
        self.assertTrue(T.release(jid))
        self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        pub = H.fake_state()["cafe"][-1]
        self.assertEqual(pub["menu"], "7")
        self.assertEqual(pub["title"], j["title"])
        self.assertEqual(len(pub["images"]), len(j["images"]))
        self.assertTrue(pub["tags"])
        self.assertNotIn("원주.kr", pub["text"])
        self.assertRegex(j["url"], r"/articles/\d+")

    def test_25_style_learning_from_blog_and_prompt(self):
        """기존 글 스타일 학습: 공개 RSS + 모바일 글 화면 → 말투·이모지 분석 → AI 요약 → 다음 글 프롬프트에 들어감"""
        from autopost import accounts as A, style, generator as g
        from autopost.util import load_config, save_config
        cfg = load_config()
        acc = A.get(cfg, "naver", "main")
        st = style.learn(cfg, "naver", acc)
        save_config(cfg)
        self.assertEqual(st["samples"], 3)
        self.assertEqual(st["tone"], g.TONES[0])
        self.assertGreater(st["emojiPer200"], 0)
        self.assertIn("FAKE-STYLE", st["summary"])
        self.assertEqual(st["source"], "blog")
        self.assertIn("qa_user", H.fake_state()["rss_hits"])
        cfg = load_config()
        post = g.generate("naver", dry=True, account_obj=A.get(cfg, "naver", "main"), record=False)
        self.assertTrue(post["title"])
        self.assertIn("FAKE-STYLE", H.fake_state()["anthropic"][-1]["user"])   # 글버릇이 프롬프트에 들어감
        self.assertEqual(style.due_accounts(cfg), [])                        # 방금 배움 → 다시 배울 계정 없음

    def test_26_visit_post_needs_memo_and_no_promo(self):
        """다른 가게 방문기: 사장님 사진·메모로만, 우리 가게 링크·지도·홍보 블록 없음, 방문 표현은 허용(별점·인용은 그대로 금지)"""
        from autopost import tasks as T, library as lib, generator as g
        from autopost.util import load_config
        cfg = load_config()
        ids = [lib.add_photo(H.make_photo((90 + i * 30, 120, 60)), f"visit_{i}.jpg", cfg, source="daily", label=False)[0]["id"] for i in range(2)]
        st = {"daily": {"photo_ids": ids, "plan": "메모대로 담백하게", "memo": "휴무날 온천동 칼국수집 다녀옴. 바지락 칼국수, 국물이 시원했음", "keyword": "", "kind": "visit"},
              "hold": True, "place": True, "block": "basic"}
        jid = T.add("naver", "main", "ID 1", settings=st)
        self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_REVIEW))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_HOLD, j["error"])
        self.assertEqual(j["keyword"], "아산 맛집 탐방")
        self.assertFalse(j["settings"]["place"])
        self.assertNotIn("원주.kr", j["body_html"])
        self.assertNotIn("<a ", j["body_html"])
        sysmsg = H.fake_state()["anthropic"][-1]["system"]
        self.assertIn("직접' 다녀온 다른 식당", sysmsg)
        self.assertIn("칼국수", H.fake_state()["anthropic"][-1]["user"])
        kw = {"keyword": "아산 맛집 탐방"}
        con = g.db()
        try:
            iss, _ = g.quality_check({"title": "t", "body_html": "<p>휴무날 칼국수집에 다녀왔어요</p>"}, kw, cfg, con, visit=True)
            self.assertEqual(iss, [])
            iss, _ = g.quality_check({"title": "t", "body_html": "<p>다녀왔어요 별점 5점 ★★★★★</p>"}, kw, cfg, con, visit=True)
            self.assertTrue(any("별점" in i for i in iss))
            iss, _ = g.quality_check({"title": "t", "body_html": "<p>휴무날 칼국수집에 다녀왔어요</p>"}, kw, cfg, con)
            self.assertTrue(iss)                              # 방문기가 아닌 글에서는 그대로 금지
        finally:
            con.close()
        T.delete(jid)

    def test_27_account_topics_and_new_categories(self):
        """계정에 고른 주제(A 특장점·E 고민해결·F 비하인드)만 돌아가며 쓰고, 카페는 카페 주제만"""
        from autopost import generator as g
        import random
        con = g.db()
        try:
            rng = random.Random(1)
            got = {g.pick_combo(con, "naver", rng, account="t27", allowed=["고민해결", "비하인드"])["topic"] for _ in range(20)}
            self.assertEqual(got, {"고민해결", "비하인드"})
            cafe = {g.pick_combo(con, "cafe", rng, account="t27c")["topic"] for _ in range(30)}
            self.assertTrue(cafe <= set(g.CAFE_TOPICS))
            self.assertIn("특장점안내", g.TOPICS)
            tone = [g.pick_combo(con, "naver", random.Random(i), account="t27t", tone_pref=g.TONES[3])["tone"] for i in range(40)]
            self.assertGreater(tone.count(g.TONES[3]), 20)
        finally:
            con.close()

    def test_28_browser_closed_midway_is_delayed_and_cleaned(self):
        """브라우저 탭이 닫히면 즉시 재실행하지 않고 프로필을 정리한 뒤 지연 재시도한다."""
        from autopost import tasks as T
        from autopost.publishers import naver as N
        self.login("naver", "main")
        orig, calls = N.type_body, []

        def flaky(fr, page, *a, **k):
            calls.append(1)
            if len(calls) == 1:
                page.close()          # 입력 도중 탭이 닫힌 상황
            return orig(fr, page, *a, **k)
        N.type_body = flaky
        try:
            n0 = len(H.fake_state()["naver"])
            jid = T.add("naver", "main", "ID 1", settings={"place": False})
            self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_READY, T.S_PUB_FAIL, T.S_GEN_FAIL))
        finally:
            N.type_body = orig
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_READY, j["error"])
        self.assertEqual(len(calls), 1)
        self.assertEqual(len(H.fake_state()["naver"]), n0)
        self.assertIn("자동 재시도", j["error"])

    def test_29_tistory_login_window_closed_right_after_login(self):
        """티스토리: 로그인하자마자 창이 닫혀도(확인 전) '창이 닫혔어요'가 아니라 저장한 로그인으로 확인해서 연결됨"""
        from autopost import connect
        orig, n = connect.check_write_page, []

        def flaky(page, ch, handle):
            n.append(1)
            if len(n) == 1:
                raise RuntimeError("Target page, context or browser has been closed")
            return orig(page, ch, handle)
        connect.check_write_page = flaky
        try:
            self.login("tistory", "main")
        finally:
            connect.check_write_page = orig
        self.assertEqual(len(n), 2)
        self.assertIn("로그인 후 창이 닫혀서", self.logtext())

    def test_30_leftover_chrome_on_profile_is_cleaned(self):
        """이 계정 프로필을 붙잡고 남아 있는 크롬이 있어도 정리하고 연결 확인·발행 (실제 오류: '이 계정의 크롬 창이 아직 열려 있어요')"""
        import subprocess
        from autopost import connect, browser, tasks as T
        from autopost.util import load_config
        d = browser.profile_dir("tistory")
        p = subprocess.Popen([os.environ["AUTOPOST_BROWSER_EXE"], f"--user-data-dir={d}", "--headless=new", "--no-sandbox",
                              "--password-store=basic", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            self.assertTrue(wait(lambda: browser.profile_in_use(d), 20))
            r = connect.verify_session("tistory", load_config(), "main")
            self.assertTrue(r["ok"], r)
            self.assertIsNotNone(p.poll())            # 남은 크롬은 정리됨
            self.assertIn("덜 꺼진 채 남아 있어서 정리", self.logtext())
            jid = T.add("tistory", "main", "ID 1", settings={"place": False})
            self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED))
            self.assertEqual(self.job(jid)["status"], T.S_DONE, self.job(jid)["error"])
        finally:
            if p.poll() is None:
                p.kill()

    def test_31_busy_profile_does_not_disconnect(self):
        """로그인 창이 열려 있어 확인을 못 해도 '연결 실패'로 바꾸지 않음 (작업이 '연결 필요'로 멈추던 문제)"""
        from autopost import connect, browser
        from autopost.util import load_config
        before = connect.session_status()["tistory"]["state"]
        browser.LOGIN_ACTIVE.add("tistory")
        d = browser.profile_dir("tistory")
        import subprocess
        p = subprocess.Popen([os.environ["AUTOPOST_BROWSER_EXE"], f"--user-data-dir={d}", "--headless=new", "--no-sandbox",
                              "--password-store=basic", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            self.assertTrue(wait(lambda: browser.profile_in_use(d), 20))
            r = connect.verify_session("tistory", load_config(), "main")
            self.assertIn("로그인 창이 열려", r["message"])
            self.assertEqual(connect.session_status()["tistory"]["state"], before)
            self.assertIsNone(p.poll())               # 로그인 중인 창은 건드리지 않음
        finally:
            browser.LOGIN_ACTIVE.discard("tistory")
            p.kill()
            p.wait(10)

    def test_32_tistory_photo_upload_without_ftp(self):
        """티스토리 사진(FTP 없이): 미리 있는 사진 칸이 없어도 '첨부 → 사진' 파일 선택으로 올리고, 선택 창이 안 뜨면 끌어다 놓기로 올림
        (실제 오류: '사진 첨부 칸을 찾지 못했어요'로 발행이 아예 안 됨)"""
        from autopost import tasks as T, secure
        saved = {k: secure.get(k) for k in ("FTP_HOST", "FTP_USER", "FTP_PASSWORD")}
        secure.set_many({k: None for k in saved})
        try:
            for mode in ("0", "1"):
                H.fake_post(f"/admin/nochooser?on={mode}")
                jid = T.add("tistory", "main", "ID 1", settings={"place": False})
                self.engine_run(80, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
                j = self.job(jid)
                self.assertEqual(j["status"], T.S_DONE, j["error"])
                p = H.fake_state()["tistory"][-1]
                self.assertGreaterEqual(len(j["images"]), 3)
                self.assertEqual(p["html"].count("<img"), len(j["images"]), mode)
                self.assertIn("/site/_uploads/t_", p["html"])     # 티스토리에 직접 올린 사진
                self.assertEqual(p["wrongFile"], 0)
            self.assertIn("사진 올리기 방법: menu", self.logtext())
            self.assertIn("사진 올리기 방법: drop", self.logtext())
        finally:
            H.fake_post("/admin/nochooser?on=0")
            secure.set_many({k: v for k, v in saved.items() if v})

    def test_33_cafe_home_url_board_list_and_choice(self):
        """카페 주소만 넣어도: 카페 번호 찾기 → 게시판 불러오기(글쓰기 가능한 곳만) → 고른 게시판에 등록.
        카페 API가 막혀도 글쓰기 화면의 게시판 목록에서 이름으로 골라 올림 (실제 문제: 게시판 인식 못 해서 못 올림)"""
        from autopost import tasks as T, accounts as A
        from autopost.readiness import account_ready
        from autopost.publishers import cafe as C
        from autopost.util import load_config, save_config
        cfg = load_config()
        acc = A.get(cfg, "cafe", "main")
        acc.update(handle=f"{H.BASE}/cafe/asanlocal", board={}, clubId="")
        save_config(cfg)
        self.login("cafe", "main")                                   # 카페 주소만으로 로그인 확인 (글쓰기 화면을 알아서 찾음)
        self.assertFalse(account_ready(load_config(), "cafe", "main")["ok"])   # 게시판을 안 골랐으면 글을 만들지 않음
        self.assertIn("게시판", account_ready(load_config(), "cafe", "main")["text"])
        for api_on, pick, want in (("1", "맛집 이야기", "9"), ("0", "동네소식", "7")):
            H.fake_post(f"/admin/cafe_api?on={api_on}")
            cfg = load_config()
            acc = A.get(cfg, "cafe", "main")
            acc["clubId"] = "" if api_on == "0" else acc.get("clubId", "")
            cid, boards = C.fetch_boards(cfg, acc, "cafe")
            self.assertEqual(cid, "31337")
            names = [b["name"] for b in boards]
            self.assertEqual(names, ["자유게시판", "가입인사", "동네소식", "맛집 이야기"])   # 공지·구분선 제외
            b = next(x for x in boards if x["name"] == pick)
            self.assertEqual(b["id"], want if api_on == "1" else "")
            acc.update(clubId=cid, board=b)
            save_config(cfg)
            self.assertTrue(account_ready(load_config(), "cafe", "main")["ok"])
            jid = T.add("cafe", "main", "ID 1")
            self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_REVIEW, T.S_NEED))
            self.assertEqual(self.job(jid)["status"], T.S_HOLD, self.job(jid)["error"])
            T.release(jid)
            self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
            j = self.job(jid)
            self.assertEqual(j["status"], T.S_DONE, j["error"])
            self.assertEqual(H.fake_state()["cafe"][-1]["menu"], want)
        H.fake_post("/admin/cafe_api?on=1")
        self.assertIn("게시판 선택: 동네소식", self.logtext())

    def test_34_tistory_publish_layer_other_layout_public(self):
        """티스토리 발행 창 구조가 달라도(id 없음, 공개 선택이 버튼, 기본값 비공개) '공개'를 골라 '공개 발행' (실제 문제: 발행을 못 찾음)"""
        from autopost import tasks as T
        H.fake_post("/admin/tistory_v2?on=1")
        try:
            jid = T.add("tistory", "main", "ID 1", settings={"place": False})
            self.engine_run(80, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
            j = self.job(jid)
            self.assertEqual(j["status"], T.S_DONE, j["error"])
            self.assertEqual(H.fake_state()["tistory"][-1]["visibility"], "public")
        finally:
            H.fake_post("/admin/tistory_v2?on=0")

    def test_35_scheduled_job_pregenerated_and_published_on_time(self):
        """예약 작업: 예약 시간 전에 글을 미리 만들어 두고(발행 대기), 예약 시간이 되면 바로 발행 (실제 문제: 예약해도 너무 느림)"""
        from datetime import datetime, timedelta
        from autopost import tasks as T
        at = (datetime.now() + timedelta(minutes=10)).isoformat(timespec="seconds")
        jid = T.add("naver", "main", "ID 1", scheduled_at=at, settings={"place": False})
        self.engine_run(30, lambda: self.job(jid)["status"] in (T.S_READY, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_READY, j["error"])     # 10분 전에 이미 글 완성
        self.assertEqual(j["pub_after"], at)                       # 발행은 예약 시간에
        self.engine_run(3)
        self.assertEqual(self.job(jid)["status"], T.S_READY)       # 예약 시간 전에는 올리지 않음
        T.update(jid, pub_after=datetime.now().isoformat(timespec="seconds"))   # 예약 시간이 됨
        t0 = time.time()
        self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
        self.assertEqual(self.job(jid)["status"], T.S_DONE, self.job(jid)["error"])
        self.assertLess(time.time() - t0, 60)

    def test_36_threads_facebook_band_manual_channels(self):
        """새 채널: 스레드(글+사진, 처리 완료 후 공개)·페이스북 페이지(사진)·네이버 밴드(항상 확인 후 등록, 링크 없음)·원고(당근/카톡/플레이스: 자동으로 안 올림)"""
        from autopost import tasks as T, secure, connect, accounts as A
        from autopost.publishers import social
        from autopost.util import load_config, save_config
        secure.set_many({"THREADS_TOKEN": H.FS.THREADS["token"], "FB_PAGE_TOKEN": H.FS.FB_PAGE["token"], "BAND_TOKEN": "wrong-band-token-xx"})
        self.assertFalse(social.check("band", "main")["ok"])                     # 틀린 토큰은 거절
        secure.set_many({"BAND_TOKEN": H.FS.BAND["token"]})
        r = social.check("band", "main")
        self.assertEqual([b["name"] for b in r["bands"]], ["온천동 이웃 모임", "아산 맛집 정보방"])
        cfg = load_config()
        A.get(cfg, "band", "main")["handle"] = "AAAbandKey02"
        A.get(cfg, "manual", "main")["handle"] = "kakao"
        save_config(cfg)
        for ch in ("threads", "facebook", "band"):
            r = social.check(ch, "main", A.get(load_config(), ch, "main").get("handle", ""))
            self.assertTrue(r["ok"], (ch, r))
            connect.set_state(ch, ok=True, state="connected", username=r.get("username", ""))
        done = {}
        for ch in ("threads", "facebook", "band", "manual"):
            jid = T.add(ch, "main", "ID 1", settings=T.job_defaults(A.get(load_config(), ch, "main")))
            self.engine_run(60, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_HOLD, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
            j = self.job(jid)
            if ch in ("band", "manual"):
                self.assertEqual(j["status"], T.S_HOLD, (ch, j["error"]))         # 커뮤니티·원고는 자동으로 올리지 않음
                T.release(jid)
                self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
                j = self.job(jid)
            self.assertEqual(j["status"], T.S_DONE, (ch, j["error"]))
            done[ch] = j
        st = H.fake_state()
        tp = st["threads_posts"][-1]
        self.assertLessEqual(len(tp["text"]), 500)
        self.assertIn("원주.kr", tp["text"])
        self.assertEqual(tp["type"], "IMAGE" if done["threads"]["images"] else "TEXT")
        fb = st["fb_posts"][-1]
        self.assertEqual(fb["edge"], "photos")
        self.assertIn(done["facebook"]["title"], fb["message"])
        bp = st["band_posts"][-1]
        self.assertEqual(bp["band_key"], "AAAbandKey02")
        self.assertNotIn("원주.kr", bp["content"])
        self.assertNotIn("<", bp["content"])
        self.assertEqual(done["manual"]["url"], "")
        self.assertIn("카카오톡 채널", H.fake_state()["anthropic"][-1]["user"] + str([a["user"] for a in H.fake_state()["anthropic"][-6:]]))

    def test_37_edge_cases_overload_config_network_nophoto(self):
        """상황별 변수: Claude 과부하(529) 재시도 · 설정 파일 깨짐 자동 복구 · 밴드 서버 연결 안 됨 → 글 유지·재시도 · 사진이 하나도 없을 때"""
        from autopost import tasks as T, generator as g, accounts as A, library as lib
        from autopost.util import load_config, save_config
        H.fake_post("/admin/overload?n=2")
        post = g.generate("naver", dry=True, account_obj=A.get(load_config(), "naver", "main"), record=False)
        self.assertTrue(post["title"])
        self.assertIn("다시 시도", self.logtext())
        cfg = load_config()
        save_config(cfg)
        p = os.path.join(H.HOME, "config.json")
        open(p, "w", encoding="utf-8").write('{"shop": {"name": "깨짐", ')   # 정전 등으로 반쯤 저장된 파일
        self.assertEqual(load_config()["shop"]["name"], cfg["shop"]["name"])
        self.assertTrue(any(f.startswith("config.json.broken-") for f in os.listdir(H.HOME)))
        old = os.environ["AUTOPOST_BAND_BASE"]
        os.environ["AUTOPOST_BAND_BASE"] = f"http://127.0.0.1:{H.free_port()}/band"      # 밴드 서버 연결 안 됨
        try:
            jid = T.add("band", "main", "ID 1")
            self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
            T.release(jid)
            self.engine_run(20, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_READY) and self.job(jid)["attempts"])
            j = self.job(jid)
            self.assertNotEqual(j["status"], T.S_DONE)
            self.assertTrue(j["title"] and j["error"])                       # 글은 그대로, 이유는 기록
        finally:
            os.environ["AUTOPOST_BAND_BASE"] = old
        T.retry_publish(jid)
        self.engine_run(30, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
        self.assertEqual(self.job(jid)["status"], T.S_DONE, self.job(jid)["error"])
        orig = lib.list_photos
        lib.list_photos = lambda con=None: []
        try:
            post = g.generate("naver", dry=True, account_obj=A.get(load_config(), "naver", "main"), record=False)
        finally:
            lib.list_photos = orig
        self.assertEqual(post["images"], [])
        self.assertNotIn("[[IMG", post["body_html"])

    def test_38_keyword_ideas_and_campaigns(self):
        """키워드 아이디어: 가짜 후기·경쟁사·강원 원주·이미 있는 키워드는 걸러냄 / 시즌 캠페인: 기간에만 테마·키워드 반영"""
        from datetime import date
        from autopost import generator as g
        from autopost.util import load_config
        ideas = [x["keyword"] for x in g.suggest_keywords(load_config())]
        self.assertIn("온천동 통닭 포장", ideas)
        self.assertIn("온양온천역 밤 야식", ideas)                            # 띄어쓰기 정리
        for bad in ("아산 내돈내산 치킨", "아산 BBQ 치킨", "아산 원주통닭", "강원 원주 치킨"):
            self.assertNotIn(bad, ideas)
        cfg = load_config()
        (cfg.get("marketing") or {}).pop("campaigns", None)     # 기본 캠페인으로 확인 (다른 테스트가 바꾼 것 무시)
        names = lambda d: [c["name"] for c in g.active_campaigns(cfg, d)]
        self.assertIn("크리스마스", names(date(2026, 12, 24)))
        self.assertIn("겨울 야식", names(date(2027, 1, 15)))                 # 해를 넘기는 기간
        self.assertNotIn("겨울 야식", names(date(2027, 6, 15)))
        self.assertNotIn("명절 연휴 (날짜 직접 입력)", names(date(2027, 2, 6)))   # 꺼 둔 캠페인

    def test_39_categories_optional_and_selectable(self):
        """카테고리: 블로그에 없는 카테고리·카테고리 칸이 없는 블로그여도 멈추지 않고 기본 카테고리로 발행,
        '카테고리 불러오기'로 실제 카테고리를 읽어 고르면 그 카테고리로 (실제 문제: 카테고리 선택에서 멈춤)"""
        from autopost import tasks as T, accounts as A
        from autopost.publishers import naver as NV, tistory as TS
        from autopost.util import load_config, save_config
        cfg = load_config()
        A.get(cfg, "naver", "main").update(categories=["가게 이야기"], catConfirmed=False)
        save_config(cfg)
        self.assertEqual(A.get(load_config(), "naver", "main")["categories"], [])    # 예전 기본값은 비움
        cfg = load_config()
        self.assertEqual(NV.fetch_categories(cfg, A.get(cfg, "naver", "main"), "naver"), H.FS.CATEGORIES)
        self.assertEqual(TS.fetch_categories(cfg, A.get(cfg, "tistory", "main"), "tistory"), H.FS.CATEGORIES)

        def run(ch, cat):
            jid = T.add(ch, "main", "ID 1", settings={"place": False, "category": cat})
            t0 = time.time()
            self.engine_run(80, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL, T.S_NEED, T.S_REVIEW))
            j = self.job(jid)
            self.assertEqual(j["status"], T.S_DONE, (ch, cat, j["error"]))
            self.assertLess(time.time() - t0, 90)
            return H.fake_state()["naver" if ch == "naver" else "tistory"][-1]
        for ch in ("naver", "tistory"):
            p = run(ch, "가게 이야기")                     # 블로그에 없는 카테고리
            self.assertEqual(p["category"], "")
            self.assertTrue(p["tags"])                       # 카테고리 실패 뒤에도 태그·발행은 정상
            p = run(ch, "치킨 이야기")                     # 불러온 카테고리
            self.assertEqual(p["category"], "치킨 이야기")
            p = run(ch, "__none__")                          # 선택 안 함
            self.assertEqual(p["category"], "")
        H.fake_post("/admin/nocat?on=1")                     # 카테고리 칸이 아예 없는 블로그
        try:
            for ch in ("naver", "tistory"):
                run(ch, "치킨 이야기")
        finally:
            H.fake_post("/admin/nocat?on=0")
        self.assertIn("이(가) 블로그에 없어 기본 카테고리로 발행", self.logtext())

    def test_40_pull_photos_by_keyword_from_own_blog(self):
        """키워드로 사진 가져오기: 자료함에서 찾고 + 사장님 블로그 글 속 사진을 내려받아 키워드 라벨(위치정보 없음) → 그 키워드 글에 우선 사용"""
        from PIL import Image
        from autopost import library as lib, generator as g
        from autopost.util import load_config
        pub = H.fake_state()["naver"][-1]
        kw = next(w for w in pub["title"].split() if len(w) >= 2 and w not in ("아산",))
        n0 = len(lib.list_photos())
        r = lib.pull_by_keyword(load_config(), kw, limit=200)
        self.assertGreaterEqual(len(r["added"]), 1)
        self.assertEqual(len(lib.list_photos()), n0 + len(r["added"]))
        p = r["added"][0]
        self.assertIn(kw.replace(" ", "")[:12], p["labels"])
        self.assertEqual(len(Image.open(p["path"]).getexif()), 0)
        r2 = lib.pull_by_keyword(load_config(), kw, limit=200)        # 두 번 해도 같은 사진은 다시 안 넣음
        self.assertEqual(r2["added"], [])
        con = g.db()
        try:
            hits = 0
            for i in range(6):
                ps = lib.pick_photos(load_config(), kw, "매장일상", "naver", f"kwt{i}", __import__("random").Random(i), con=con)
                hits += any(x["id"] in {a["id"] for a in r["added"]} for x in ps)
            self.assertGreaterEqual(hits, 4)                            # 키워드 사진이 그 키워드 글에 잘 골라짐
        finally:
            con.close()
        with self.assertRaises(ValueError):
            lib.pull_by_keyword(load_config(), "a")

    def test_41_posts_do_not_repeat_titles_openings_phrases(self):
        """반복 방지: 최근 제목·첫 문장·자주 쓴 표현을 프롬프트로 알려 다르게 쓰게 하고, 같은 첫 문장이면 고칠 점을 알려 다시 씀.
        일상·사장님 일기 느낌 + 이모지 + 길게 쓰라는 지시가 들어감"""
        from autopost import generator as g, accounts as A
        from autopost.util import load_config
        titles, opens = [], []
        for i in range(5):
            post = g.generate("naver", dry=True, account_obj=A.get(load_config(), "naver", "main"), record=True)
            titles.append(post["title"])
            opens.append(g._opening(g.strip_html(post["body_html"]))[:12])
        self.assertEqual(len(set(titles)), 5)
        self.assertEqual(len(set(opens)), 5)
        last = H.fake_state()["anthropic"][-1]
        self.assertIn("[반복 피하기", last["user"])
        self.assertIn("최근 제목", last["user"])
        self.assertIn("사장님 일기", last["system"])
        self.assertIn("이모지는 200자당 1~3개", last["system"])
        self.assertIn("2,000~3,000자", last["user"])
        H.fake_post("/admin/owner_intro?on=1")                         # 매번 같은 인사로 시작하는 모델
        try:
            g.generate("naver", dry=True, account_obj=A.get(load_config(), "naver", "main"), record=True)
            n0 = len(H.fake_state()["anthropic"])
            post = g.generate("naver", dry=True, account_obj=A.get(load_config(), "naver", "main"), record=True)
            calls = H.fake_state()["anthropic"][n0:]
        finally:
            H.fake_post("/admin/owner_intro?on=0")
        self.assertEqual(len(calls), 2)                                 # 고칠 점을 알려 주고 한 번 다시 씀 (비용 때문에 반복 문제는 1번만)
        self.assertIn("같은 첫 문장", calls[-1]["user"])
        self.assertTrue(all(not i.startswith("[") for i in post["quality_issues"]))   # 반복 문제만 남으면 발행은 막지 않음

    def test_42_no_duplicate_post_when_publish_result_unclear(self):
        """'발행' 버튼을 눌렀는데 화면이 글 주소로 안 넘어간 경우: 다시 시도 전에 블로그 RSS에서 같은 제목을 찾아 이미 올라갔으면 또 올리지 않음"""
        from datetime import datetime
        from autopost import tasks as T
        H.fake_post("/admin/noredirect?n=1")
        n0 = len(H.fake_state()["naver"])
        jid = T.add("naver", "main", "ID 1", settings={"place": False})
        self.engine_run(80, lambda: (self.job(jid)["attempts"] or 0) >= 1 or self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL, T.S_GEN_FAIL))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_READY, j["error"])           # 자동 재시도 대기
        self.assertTrue(j["settings"].get("pubUncertain"))
        self.assertEqual(len(H.fake_state()["naver"]), n0 + 1)        # 실제로는 이미 올라감
        T.update(jid, pub_after=datetime.now().isoformat(timespec="seconds"))
        self.engine_run(30, lambda: self.job(jid)["status"] in (T.S_DONE, T.S_PUB_FAIL))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_DONE, j["error"])
        self.assertEqual(len(H.fake_state()["naver"]), n0 + 1)        # 두 번 올리지 않음
        self.assertRegex(j["url"], r"/\d{9,}")
        self.assertIn("이미 올라가 있어서 다시 올리지 않았어요", self.logtext())

    def test_43_personal_life_post(self):
        """개인 일상 글(여행·나들이·집청소): 사진·메모로만, 가게 홍보·한눈에 보기·링크·지도 없음, 원하면 끝에 가게 서명 한 줄, 예약 시간 지킴"""
        from datetime import datetime, timedelta
        from autopost import tasks as T, library as lib, daily
        from autopost.util import load_config
        cfg = load_config()
        ids = [lib.add_photo(H.make_photo((30 + i * 50, 140, 200)), f"trip_{i}.jpg", cfg, source="daily", label=False)[0]["id"] for i in range(3)]
        plan = daily.plan(cfg, ids, "쉬는 날 신정호 한 바퀴 걷고 집에 와서 대청소", "life")
        self.assertEqual(plan["kind"], "life")
        at = (datetime.now() + timedelta(minutes=10)).isoformat(timespec="seconds")
        st = {"daily": {"photo_ids": ids, "plan": plan["prompt"], "memo": "쉬는 날 신정호 산책, 집 대청소", "keyword": "", "kind": "life", "sign": True},
              "hold": True, "place": True, "block": "basic", "summary": True}
        jid = T.add("naver", "main", "ID 1", settings=st, scheduled_at=at)
        self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_REVIEW))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_HOLD, j["error"])                  # 예약 10분 전에 미리 만들어 둠
        self.assertEqual(j["keyword"], "사장의 휴무 일기")
        self.assertNotIn("한눈에 보기", j["body_html"])
        self.assertNotIn("원주.kr", j["body_html"])
        self.assertFalse(j["settings"]["place"])
        self.assertIn("통닭 튀기는", j["body_html"])                          # 서명 한 줄
        sysmsg = H.fake_state()["anthropic"][-1]["system"]
        self.assertIn("개인 일상 일기", sysmsg)
        self.assertIn("가게 홍보·메뉴 소개·방문 안내를 넣지 말고", sysmsg)
        self.assertNotIn("이런 날 들러 주세요", sysmsg)
        self.assertEqual([i["photoId"] for i in j["images"]], ids)
        T.release(jid)
        self.assertEqual(self.job(jid)["pub_after"], at)                      # 확인 후 등록해도 예약 시간에 올림
        self.engine_run(3)
        self.assertEqual(self.job(jid)["status"], T.S_READY)
        T.delete(jid)

    def test_44_ci_logo_and_auto_content_modes(self):
        """기업 CI: 블로그·홈페이지 글에 항상(맨 아래/위) · 무작위 사진에는 안 섞임 · 글 종류 자동: 연달아 같은 종류 안 나옴, 에세이는 홍보·링크 없음"""
        import json
        import random
        from autopost import tasks as T, generator as g, library as lib, accounts as A
        from autopost.util import load_config, save_config
        from autopost import readiness
        if not readiness.account_status(load_config(), "naver", A.get(load_config(), "naver", "main"))["ok"]:
            self.login("naver", "main")
        cfg = load_config()
        cfg.setdefault("ci", {})["defaultImported"] = False
        save_config(cfg)
        lib.ensure_default_ci(load_config())
        cis = lib.ci_photos()
        self.assertEqual(len(cis), 2)
        self.assertEqual(sorted(p["caption"] for p in cis), ["가로형 로고", "아이콘 로고"])
        self.assertNotIn("CI", lib.summary()["labels"])                  # 자료함 목록·통계에는 안 섞임
        cfg = load_config()
        cfg["ci"].update({"enabled": True, "position": "bottom", "which": "wide"})
        save_config(cfg)
        for i in range(5):
            ps = lib.pick_photos(load_config(), "아산 치킨", "매장일상", "naver", "main", random.Random(i))
            self.assertFalse([p for p in ps if p.get("source") == "ci"])   # CI는 무작위 사진으로 안 뽑힘
        jid = T.add("naver", "main", "ID 1", settings={**T.job_defaults(A.get(load_config(), "naver", "main")), "hold": True})
        self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_REVIEW))
        j = self.job(jid)
        self.assertEqual(j["status"], T.S_HOLD, j["error"])
        ci = [n for n, im in enumerate(j["images"]) if im.get("ci")]
        self.assertEqual(len(ci), 1)
        self.assertTrue(j["body_html"].rstrip().endswith(f"[[IMG:{ci[0]}]]"), j["body_html"][-200:])
        self.assertIn("가로", next(p for p in cis if p["id"] == j["images"][ci[0]]["photoId"])["caption"])
        T.delete(jid)
        cfg = load_config()
        cfg["ci"]["position"] = "top"
        save_config(cfg)
        post = g.generate("wonju", dry=True)
        self.assertTrue(post["body_html"].startswith("[[IMG:"), post["body_html"][:80])
        self.assertTrue(post["images"][int(post["body_html"][6:post["body_html"].index("]]")])].get("ci"))
        post = g.generate("instagram", dry=True)
        self.assertFalse([i for i in post.get("images") or [] if i.get("ci")])   # SNS 사진 한 장에는 CI 안 넣음
        cfg = load_config()
        cfg["ci"]["enabled"] = False
        cfg["autoModes"] = True
        save_config(cfg)
        # 글 종류 자동: 최근 2개와 다른 종류
        con = g.db()
        try:
            modes = []
            for i in range(8):
                m = g.pick_mode(load_config(), con, "tistory", "mtest", random.Random(i))
                con.execute("INSERT INTO posts(channel, account, keyword, title, material) VALUES(?,?,?,?,?)",
                            ("tistory", "mtest", "k", f"t{i}", json.dumps({"mode": m})))
                modes.append(m)
            for a, b in zip(modes, modes[1:]):
                self.assertNotEqual(a, b, modes)
            self.assertGreaterEqual(len(set(modes)), 3)
            self.assertEqual(g.pick_mode(load_config(), con, "instagram", "mtest", random.Random(1)), "shop")
            self.assertEqual(g.pick_mode(load_config(), con, "tistory", "mtest", random.Random(1), {"mode": "tips"}), "tips")
        finally:
            con.execute("DELETE FROM posts WHERE account='mtest'")
            con.commit()
            con.close()
        cfg = load_config()
        A.get(cfg, "naver", "main")["mode"] = "essay"
        save_config(cfg)
        try:
            jid = T.add("naver", "main", "ID 1", settings={**T.job_defaults(A.get(load_config(), "naver", "main")), "hold": True, "summary": True, "place": True})
            self.engine_run(40, lambda: self.job(jid)["status"] in (T.S_HOLD, T.S_GEN_FAIL, T.S_REVIEW))
            j = self.job(jid)
            self.assertEqual(j["status"], T.S_HOLD, j["error"])
            self.assertNotIn("원주.kr", j["body_html"])
            self.assertNotIn("한눈에 보기", j["body_html"])
            self.assertNotIn("map.naver.com", j["body_html"])
            sysmsg = H.fake_state()["anthropic"][-1]["system"] + H.fake_state()["anthropic"][-1]["user"]
            self.assertIn("생활 에세이", sysmsg)
            T.delete(jid)
        finally:
            cfg = load_config()
            A.get(cfg, "naver", "main").pop("mode", None)
            cfg["autoModes"] = False
            save_config(cfg)


class Dashboard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        H.start_fakes()
        H.bootstrap()
        from autopost.dashboard import create_app
        cls.port = H.free_port()
        cls.app = create_app(None, port=cls.port)
        cls.c = cls.app.test_client()
        cls.tok = cls.app.config["CSRF"]
        cls.base = {"base_url": f"http://127.0.0.1:{cls.port}"}

    def post(self, path, body=None, headers=None, **kw):
        return self.c.post(path, json=body or {}, headers=headers or {}, **{**self.base, **kw})

    def test_csrf_required(self):
        self.assertEqual(self.post("/api/settings", {"auto": True}).status_code, 403)
        self.assertEqual(self.post("/api/settings", {"auto": False}, {"X-CSRF-Token": "wrong"}).status_code, 403)
        self.assertEqual(self.post("/api/settings", {"auto": False}, {"X-CSRF-Token": self.tok}).status_code, 200)

    def test_cross_origin_rejected(self):
        h = {"X-CSRF-Token": self.tok, "Origin": "https://evil.example"}
        self.assertEqual(self.post("/api/settings", {"auto": False}, h).status_code, 403)
        h = {"X-CSRF-Token": self.tok, "Sec-Fetch-Site": "cross-site"}
        self.assertEqual(self.post("/api/settings", {"auto": False}, h).status_code, 403)
        h = {"X-CSRF-Token": self.tok, "Origin": f"http://127.0.0.1:{self.port}"}
        self.assertEqual(self.post("/api/settings", {"auto": False}, h).status_code, 200)

    def test_host_header_rebinding_blocked(self):
        r = self.c.get("/api/state", base_url="http://evil.example:5858")
        self.assertEqual(r.status_code, 403)

    def test_token_in_page_and_secrets_masked(self):
        from autopost import secure
        secure.set_many({"FTP_PASSWORD": "visible-pw-9999"})
        html = self.c.get("/", **self.base).get_data(as_text=True)
        self.assertIn(self.tok, html)
        st = self.c.get("/api/state", **self.base).get_data(as_text=True)
        self.assertNotIn("visible-pw-9999", st)
        self.assertNotIn(H.FS.API_KEY, st)

    def test_live_requires_connection(self):
        from autopost.util import load_config, save_config
        from autopost import connect
        cfg = load_config()
        cfg["live"] = False
        save_config(cfg)
        for p in ("naver", "naver-a2", "tistory", "wonju"):
            connect.set_state(p, ok=False, state="none")
        from autopost import secure, accounts as A
        secure.set_many({A.env_key(k, a): None for k in A.IG_ENV for a in ("main", "a2")})
        r = self.post("/api/settings", {"live": True}, {"X-CSRF-Token": self.tok}).get_json()
        self.assertFalse(r["live"])
        self.assertIn("연결", r["error"])

    def test_upload_strips_exif(self):
        import io
        from PIL import Image
        data = {"files": [(io.BytesIO(H.make_photo((5, 6, 7))), "gps.jpg")]}
        r = self.c.post("/api/library/upload", data=data, headers={"X-CSRF-Token": self.tok}, content_type="multipart/form-data", **self.base)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        from autopost import library as lib
        p = lib.list_photos()[0]
        self.assertEqual(len(Image.open(p["path"]).getexif()), 0)

    def test_cafe_style_topics_and_visit_api(self):
        h = {"X-CSRF-Token": self.tok}
        r = self.post("/api/accounts/cafe", {"action": "save", "accounts": [{"id": "main", "handle": "https://evil.example/write"}]}, h)
        self.assertEqual(r.status_code, 400)                                     # 카페 주소만 받음
        r = self.post("/api/accounts/naver", {"action": "save", "accounts": [{"id": "main", "topics": ["고민해결", "없는주제"], "hold": True}]}, h)
        self.assertEqual(r.status_code, 200)
        from autopost.util import load_config
        from autopost import accounts as A
        a = A.get(load_config(), "naver", "main")
        self.assertEqual(a["topics"], ["고민해결"])
        self.assertTrue(a["hold"])
        self.post("/api/accounts/naver", {"action": "save", "accounts": [{"id": "main", "topics": [], "hold": False}]}, h)   # 다른 테스트에 영향 없게 되돌림
        r = self.post("/api/style/naver", {"aid": "main", "texts": "오늘도 가게 문을 열었습니다. 닭을 손질했습니다. 손님을 기다립니다. 준비를 마쳤습니다.\n---\n"
                                                              "비가 왔습니다. 포장 손님이 많았습니다. 감사합니다. 내일도 열심히 하겠습니다."}, h)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(r.get_json()["style"]["source"], "paste")
        self.assertEqual(r.get_json()["style"]["samples"], 2)
        self.assertEqual(self.post("/api/style/naver", {"aid": "main", "clear": True}, h).get_json()["style"], {})
        r = self.post("/api/daily/create", {"photoIds": [], "kind": "visit"}, h)
        self.assertEqual(r.status_code, 400)
        r = self.post("/api/daily/create", {"photoIds": [1], "prompt": "x", "kind": "life", "scheduled_at": "내일", "targets": [{"channel": "naver"}]}, h)
        self.assertEqual(r.status_code, 400)
        cv = self.c.get("/api/config", **self.base).get_json()
        self.assertIn("cafe", {p["id"] for p in cv["prompts"]})
        self.assertIn("사장일기", cv["topics"]["cafe"])
        st = self.c.get("/api/state", **self.base).get_json()
        self.assertIn("cafe", st["accounts"])

    def test_new_channel_and_marketing_api(self):
        h = {"X-CSRF-Token": self.tok}
        self.assertEqual(self.post("/api/social/band/token", {"aid": "main", "token": "bad token"}, h).status_code, 400)
        self.assertEqual(self.post("/api/social/band/token", {"aid": "main", "token": H.FS.BAND["token"]}, h).status_code, 200)
        r = self.post("/api/social/band/check", {"aid": "main"}, h).get_json()
        self.assertTrue(r["ok"])
        self.assertEqual(len(r["bands"]), 2)
        st = self.c.get("/api/state", **self.base).get_data(as_text=True)
        self.assertNotIn(H.FS.BAND["token"], st)                           # 토큰은 화면에 안 나옴
        self.assertEqual(self.post("/api/accounts/band", {"action": "save", "accounts": [{"id": "main", "handle": "<script>"}]}, h).status_code, 400)
        self.assertEqual(self.post("/api/accounts/band", {"action": "save", "accounts": [{"id": "main", "handle": "AAAbandKey01"}]}, h).status_code, 200)
        self.assertEqual(self.post("/api/social/nope/check", {"aid": "main"}, h).status_code, 404)
        self.assertEqual(self.post("/api/categories/x", {"aid": "main"}, h).status_code, 404)
        r = self.post("/api/accounts/tistory", {"action": "save", "accounts": [{"id": "main", "categories": ""}]}, h)
        self.assertEqual(r.status_code, 200)
        from autopost.util import load_config
        from autopost import accounts as A
        a = A.get(load_config(), "tistory", "main")
        self.assertEqual(a["categories"], [])
        self.assertTrue(a["catConfirmed"])
        r = self.post("/api/config/marketing", {"campaigns": [{"name": "x", "start": "13월", "end": "12-31"}]}, h)
        self.assertEqual(r.status_code, 400)
        r = self.post("/api/config/marketing", {"campaigns": [{"name": "가을 야식", "start": "09-01", "end": "10-31", "theme": "선선한 밤", "keywords": "아산 가을 야식, 온양 야식"}],
                                                "topicBlocks": {"이용안내": "visit", "메뉴소개": "없는블록"}}, h)
        self.assertEqual(r.status_code, 200)
        cv = r.get_json()["config"]
        self.assertEqual(cv["campaigns"][0]["keywords"], ["아산 가을 야식", "온양 야식"])
        self.assertEqual(cv["topicBlocks"]["이용안내"], "visit")
        self.assertEqual(cv["topicBlocks"]["메뉴소개"], "basic")              # 없는 블록은 무시 → 기본값
        self.assertIn("group", {b["id"] for b in cv["blocks"]})               # 새 기본 블록
        r = self.post("/api/keywords/suggest", {}, h)
        self.assertEqual(r.status_code, 200)
        html = self.c.get("/", **self.base).get_data(as_text=True)
        for t in ("p_threads", "p_facebook", "p_band", "p_manual", "kwIdea", "campaigns", "topicBlocks"):
            self.assertIn(t, html)

    def test_upload_mixed_files_heic_and_broken(self):
        """사진 올리기: 한 장이 깨졌거나 아이폰 HEIC(지원 안 될 때)여도 나머지는 들어가고, 이유를 장마다 알려 줌. 같은 사진은 '이미 있음'"""
        import io
        from autopost import library as lib
        good = H.make_photo((11, 22, 33))
        heic = b"\x00\x00\x00\x18ftypheic" + b"\x00" * 200
        data = {"files": [(io.BytesIO(good), "a.jpg"), (io.BytesIO(b"not an image"), "broken.jpg"), (io.BytesIO(heic), "IMG_0001.HEIC"),
                          (io.BytesIO(good), "a_copy.jpg")]}
        r = self.c.post("/api/library/upload", data=data, headers={"X-CSRF-Token": self.tok}, content_type="multipart/form-data", **self.base)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        j = r.get_json()
        res = {x["name"]: x for x in j["results"]}
        self.assertTrue(res["a.jpg"]["ok"])
        self.assertFalse(res["broken.jpg"]["ok"])
        self.assertEqual(j["dup"], 1)
        if not lib.HEIC_OK:
            self.assertIn("HEIC", res["IMG_0001.HEIC"]["error"])
        r = self.c.post("/api/daily/upload", data={"files": [(io.BytesIO(b"x"), "bad.jpg"), (io.BytesIO(H.make_photo((44, 55, 66))), "ok.jpg")]},
                        headers={"X-CSRF-Token": self.tok}, content_type="multipart/form-data", **self.base)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(r.get_json()["photos"]), 1)
        self.assertEqual(len(r.get_json()["errors"]), 1)

    def test_modes_and_edit_api(self):
        import io
        from autopost import tasks as T
        from autopost.util import load_config, save_config
        h = {"X-CSRF-Token": self.tok}
        # 글 종류 섞기
        self.assertEqual(self.post("/api/config/modes", {"weights": {k: 0 for k in ("shop", "promo", "essay", "tips", "season", "qna")}}, h).status_code, 400)
        r = self.post("/api/config/modes", {"autoModes": True, "weights": {"essay": 5, "promo": 0, "bogus": 3}}, h).get_json()
        self.assertTrue(r["config"]["autoModes"])
        self.assertEqual(r["config"]["modes"]["essay"]["w"], 5)
        self.assertEqual(r["config"]["modes"]["promo"]["w"], 0)
        self.assertNotIn("bogus", load_config()["modeWeights"])
        cfg = load_config()
        cfg["autoModes"] = False
        cfg.pop("modeWeights", None)
        save_config(cfg)
        # 로고 바꾸기: 같은 종류는 새 로고로 바뀜
        from autopost import library as lib
        lib.ensure_default_ci(load_config())
        n_ci = len(lib.ci_photos())
        r = self.c.post("/api/ci/upload", data={"files": [(io.BytesIO(H.make_photo((200, 30, 30), gps=True)), "new_icon.png")]},
                        headers=h, content_type="multipart/form-data", **self.base)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        cis = lib.ci_photos()
        self.assertEqual(len(cis), max(n_ci, 1))
        self.assertIn(r.get_json()["photos"][0]["id"], [p["id"] for p in cis])
        self.assertNotIn(r.get_json()["photos"][0]["id"], [p["id"] for p in self.c.get("/api/library", **self.base).get_json()["photos"]])
        # 올리기 전 직접 고치기
        jid = T.add("naver", "main", "ID 1")
        T.update(jid, status=T.S_HOLD, title="원래 제목", body_html="<p>원래 첫 문단</p>[[IMG:0]]<h2>소제목</h2><p>둘째 문단</p>")
        page = self.c.get(f"/preview/{jid}", **self.base).get_data(as_text=True)
        self.assertIn("직접 고치기", page)
        self.assertIn(self.tok, page)
        self.assertEqual(self.post(f"/api/jobs/{jid}/edit", {"title": "새 제목", "text": "고친 문단입니다 충분히 길게"}, {}).status_code, 403)
        txt = "고친 첫 문단 <script>alert(1)</script>\n\n[[IMG:0]]\n\n## 새 소제목\n둘째 줄도 고쳤어요"
        r = self.post(f"/api/jobs/{jid}/edit", {"title": "새 제목", "text": txt}, h)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        j = T.get(jid)
        self.assertEqual(j["title"], "새 제목")
        self.assertNotIn("<script>", j["body_html"])
        self.assertIn("[[IMG:0]]", j["body_html"])
        self.assertIn("<h2>새 소제목</h2>", j["body_html"])
        self.assertEqual(j["status"], T.S_HOLD)
        r = self.post(f"/api/jobs/{jid}/edit", {"title": "새 제목", "text": "내돈내산 솔직후기 남겨요 아주 맛있어요"}, h).get_json()
        self.assertEqual(T.get(jid)["status"], T.S_REVIEW)          # 고친 글도 표시광고법 검사
        self.assertIn("검토 필요", r["warning"])
        T.update(jid, status=T.S_DONE)
        self.assertEqual(self.post(f"/api/jobs/{jid}/edit", {"title": "새 제목", "text": "이미 올라간 글은 못 고쳐요 길게"}, h).status_code, 400)
        T.delete(jid)

    def test_no_manual_posting_endpoint(self):
        for path in ("/api/tasks", "/api/manual", "/api/posts"):
            self.assertIn(self.post(path, {"title": "x", "body": "y"}, {"X-CSRF-Token": self.tok}).status_code, (404, 405))
        html = self.c.get("/", **self.base).get_data(as_text=True)
        self.assertNotIn("수동 포스팅", html)


if __name__ == "__main__":
    unittest.main()
