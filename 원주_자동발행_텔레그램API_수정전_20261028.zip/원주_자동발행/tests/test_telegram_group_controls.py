# -*- coding: utf-8 -*-
"""The group reply starts only after the user saves rules and presses Start."""
import copy
from types import SimpleNamespace
from unittest.mock import patch

from autopost import dashboard, telegram_reply


def test_group_reply_explicit_start_stop_and_required_settings():
    state = {"telegram": {"accounts": [{"id": "a1", "label": "업무", "enabled": False,
                                          "groups": [], "replyText": "", "replyImage": ""}]}}

    def save(value):
        state.clear()
        state.update(copy.deepcopy(value))

    with (patch.object(dashboard, "load_config", side_effect=lambda: copy.deepcopy(state)),
          patch.object(dashboard, "save_config", side_effect=save),
          patch("autopost.library.ensure_default_ci", return_value=None),
          patch.object(telegram_reply.manager, "list_groups", return_value=[{"id": "-1001", "title": "시험 그룹"}]),
          patch.object(telegram_reply.manager, "clients", {"a1": SimpleNamespace(is_connected=lambda: True)}),
          patch.object(telegram_reply.manager, "handlers", {"a1": object()})):
        app = dashboard.create_app()
        client = app.test_client()
        headers = {"X-CSRF-Token": app.config["CSRF"]}
        assert client.post("/api/telegram/accounts/a1/reply/start", json={}, headers=headers).status_code == 400
        saved = client.post("/api/telegram/accounts/a1/settings", json={
            "groups": [{"id": "-1001", "enabled": True}], "replyText": "확인했습니다"}, headers=headers)
        assert saved.status_code == 200
        assert state["telegram"]["accounts"][0]["enabled"] is False
        started = client.post("/api/telegram/accounts/a1/reply/start", json={}, headers=headers)
        assert started.status_code == 200
        assert state["telegram"]["accounts"][0]["enabled"] is True
        stopped = client.post("/api/telegram/accounts/a1/reply/stop", json={}, headers=headers)
        assert stopped.status_code == 200
        assert state["telegram"]["accounts"][0]["enabled"] is False
