# -*- coding: utf-8 -*-
# 빌드된 exe 로 실제 흐름 확인: 키 저장 → 사진 업로드 → 네이버 로그인(일반 크롬+확인) → 실제 발행 → 완료
import json, os, re, subprocess, sys, time, urllib.request
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import helpers as H
H.start_fakes()
H.bootstrap()
port = H.free_port()
env = {**os.environ, "AUTOPOST_PORT": str(port), "AUTOPOST_TICK": "1"}
exe = sys.argv[1]  # 빌드된 exe 경로
proc = subprocess.Popen([exe, "--no-browser", "--no-tray"], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
base = f"http://127.0.0.1:{port}"
for _ in range(100):
    try: urllib.request.urlopen(base + "/api/ping", timeout=1); break
    except Exception: time.sleep(0.3)
tok = re.search(r'name="csrf" content="([^"]+)"', urllib.request.urlopen(base + "/").read().decode()).group(1)
def call(p, b=None, ct="application/json", raw=None):
    req = urllib.request.Request(base + p, data=raw if raw is not None else (None if b is None else json.dumps(b).encode()), headers={"Content-Type": ct, "X-CSRF-Token": tok})
    return json.loads(urllib.request.urlopen(req, timeout=60).read())
def step(name, ok):
    print(("[OK] " if ok else "[FAIL] ") + name, flush=True)
    if not ok:
        proc.terminate(); sys.exit(1)
call("/api/secrets", {"ANTHROPIC_API_KEY": H.FS.API_KEY})
# 사진 업로드 (multipart)
bnd = "----x"
body = b""
for i, (lab, col) in enumerate(list(H.COLORS.items())[:5]):
    body += (f"--{bnd}\r\nContent-Disposition: form-data; name=\"files\"; filename=\"p{i}.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").encode() + H.make_photo(col) + b"\r\n"
body += f"--{bnd}--\r\n".encode()
r = call("/api/library/upload", raw=body, ct=f"multipart/form-data; boundary={bnd}")
step(f"사진 {r['added']}장 업로드", r["added"] == 5)
time.sleep(4)
lib = json.loads(urllib.request.urlopen(base + "/api/library").read())
step("Claude 비전 라벨 자동 부착", all(p["labelSrc"] == "vision" for p in lib["photos"]))
st = json.loads(urllib.request.urlopen(base + "/api/state").read())
step("모델 목록 자동 확인: " + ", ".join(m[0] for m in st["llm"]["models"]), len(st["llm"]["models"]) >= 3)
call("/api/settings", {"live": True})
st = json.loads(urllib.request.urlopen(base + "/api/state").read())
step("연결 없으면 실제 발행 안 켜짐", st["live"] is False)
r = call("/api/connect/naver", {"aid": "main"})
step("로그인 창 열림", r.get("started"))
for _ in range(120):
    st = json.loads(urllib.request.urlopen(base + "/api/state").read())
    a = st["accounts"]["naver"][0]
    if a["status"].get("ok"): break
    time.sleep(0.5)
step("네이버 연결됨 + 아이디 자동 입력: " + a["handle"], a["status"].get("ok") and a["handle"] == "qa_user")
r = call("/api/settings", {"live": True})
step("실제 발행 켜짐", r.get("live"))
jid = call("/api/run/naver", {"aid": "main"})["id"]
for _ in range(240):
    j = next(x for x in json.loads(urllib.request.urlopen(base + "/api/jobs").read())["jobs"] if x["id"] == jid)
    if j["status"] in ("완료", "발행 실패", "생성 실패", "연결 필요", "검토 필요"): break
    time.sleep(0.5)
step(f"exe 로 실제 발행: {j['status']} {j['url']} 사진 {j['images']}장", j["status"] == "완료")
pub = H.fake_state()["naver"][-1]
step("가짜 네이버에 올라간 글 제목 일치", pub["title"] == j["title"] and len(pub["images"]) == j["images"])
st = json.loads(urllib.request.urlopen(base + "/api/state").read())
step("404 난 모델은 빼고 자동 선택: " + st["llm"]["chosen"] + " (제외: " + ",".join(st["llm"]["bad"]) + ")", st["llm"]["chosen"] == "claude-sonnet-4-6-20260201" and "claude-sonnet-5-0-20260901" in st["llm"]["bad"])
call("/api/quit", {})
proc.wait(20)
step("정상 종료", proc.returncode == 0)
