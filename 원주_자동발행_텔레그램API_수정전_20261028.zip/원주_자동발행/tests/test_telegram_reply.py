# -*- coding: utf-8 -*-
import os
import sys
import tempfile
import unittest
import types
from unittest.mock import patch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from autopost.telegram_reply import TelegramReplyManager, _cooldown_seconds


class TelegramReplyClaimTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.manager = TelegramReplyManager()
        self.data_patch = patch("autopost.telegram_reply._data_dir", return_value=self.tmp.name)
        self.data_patch.start()

    def tearDown(self):
        self.data_patch.stop()
        self.tmp.cleanup()

    def test_group_cooldown_is_per_sender(self):
        self.assertTrue(self.manager._allow_reply("account-a", "-1001", "user-1", 1, 180, True))
        self.assertTrue(self.manager._allow_reply("account-a", "-1001", "user-2", 2, 180, True))
        self.assertFalse(self.manager._allow_reply("account-a", "-1001", "user-1", 3, 180, True))

    def test_sender_can_be_answered_after_configured_wait(self):
        with patch("autopost.telegram_reply.time.time", return_value=1_000):
            self.assertTrue(self.manager._allow_reply("account-a", "-1001", "user-1", 10, 180, True))
        with patch("autopost.telegram_reply.time.time", return_value=1_181):
            self.assertTrue(self.manager._allow_reply("account-a", "-1001", "user-1", 11, 180, True))

    def test_minute_setting_is_converted_to_seconds(self):
        self.assertEqual(_cooldown_seconds({"groupCooldownMinutes": 3}, "group"), 180)
        self.assertEqual(_cooldown_seconds({"privateCooldownMinutes": 5}, "private"), 300)
        self.assertEqual(_cooldown_seconds({"groupCooldownValue": 10, "groupCooldownUnit": "seconds"}, "group"), 10)
        self.assertEqual(_cooldown_seconds({"groupCooldownValue": 2, "groupCooldownUnit": "hours"}, "group"), 7200)

    def test_private_cooldown_is_isolated_per_account(self):
        self.assertTrue(self.manager._allow_reply("account-a", "user-1", "user-1", 1, 60, True))
        self.assertTrue(self.manager._allow_reply("account-b", "user-1", "user-1", 1, 60, True))

    def test_duplicate_incoming_switch_can_be_disabled(self):
        self.assertTrue(self.manager._allow_reply("account-a", "-1001", "user-1", 99, 0, False))
        self.assertTrue(self.manager._allow_reply("account-a", "-1001", "user-1", 99, 0, False))
        self.assertTrue(self.manager._allow_reply("account-b", "-1001", "user-1", 99, 0, True))
        self.assertFalse(self.manager._allow_reply("account-b", "-1001", "user-1", 99, 0, True))

    def test_event_handler_registration_is_idempotent(self):
        class FakeClient:
            def __init__(self):
                self.handlers = []
            def add_event_handler(self, handler, _event):
                self.handlers.append(handler)
            def remove_event_handler(self, handler):
                self.handlers = [item for item in self.handlers if item is not handler]
        client = FakeClient()
        fake_telethon = types.SimpleNamespace(events=types.SimpleNamespace(NewMessage=lambda **_kwargs: object()))
        with patch.dict(sys.modules, {"telethon": fake_telethon}):
            self.manager._add_handler("account-a", client)
            self.manager._add_handler("account-a", client)
        self.assertEqual(len(client.handlers), 1)


if __name__ == "__main__":
    unittest.main()
