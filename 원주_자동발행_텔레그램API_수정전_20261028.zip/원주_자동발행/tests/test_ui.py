# -*- coding: utf-8 -*-
"""대시보드 화면 테스트: 실제 프로그램을 띄워 PC(1440px)·휴대폰(390px)에서 모든 화면을 열고
가로 넘침(깨짐)·자바스크립트 오류가 없는지, 주요 버튼이 동작하는지 확인. 화면 캡처는 tests/screens/ 에 저장"""
import json, os, subprocess, sys, time, unittest, urllib.request
import helpers as H

SHOTS = os.path.join(H.ROOT_DIR, "tests", "screens")
PAGES = [(p, None) for p in ("work", "naver", "guide", "cafe", "tistory", "instagram", "x", "threads", "facebook", "band", "manual", "wonju", "daily", "library", "keywords", "marketing",
                              "place", "prompts", "settings")]


class UI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        H.start_fakes()
        H.bootstrap()
        H.set_key(True)
        os.makedirs(SHOTS, exist_ok=True)
        cls.port = H.free_port()
        env = {**os.environ, "AUTOPOST_PORT": str(cls.port), "AUTOPOST_TICK": "1"}
        cls.proc = subprocess.Popen([sys.executable, "-m", "autopost", "--no-browser", "--no-tray"], cwd=H.ROOT_DIR, env=env,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        cls.url = f"http://127.0.0.1:{cls.port}/"
        for _ in range(80):
            try:
                urllib.request.urlopen(cls.url + "api/ping", timeout=1)
                break
            except Exception:  # noqa: BLE001
                time.sleep(0.25)
        from playwright.sync_api import sync_playwright
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(executable_path=H.find_chromium(), headless=True)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
        try:
            urllib.request.urlopen(urllib.request.Request(cls.url + "api/quit", data=b"{}", method="POST"), timeout=2)
        except Exception:  # noqa: BLE001
            pass
        cls.proc.terminate()
        cls.proc.wait(10)

    def open(self, width, height):
        ctx = self.browser.new_context(viewport={"width": width, "height": height}, locale="ko-KR",
                                       is_mobile=width < 500, has_touch=width < 500, device_scale_factor=1)
        page = ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" and "favicon" not in m.text else None)
        page.goto(self.url)
        page.wait_for_selector("#steps li", state="attached")
        return ctx, page, errors

    def nav(self, page, p):
        if page.is_visible("#menuBtn"):
            page.click("#menuBtn")
            page.wait_for_timeout(300)
        page.click(f"nav a[data-p={p}]")
        page.wait_for_selector(f"#p_{p}.on")

    def check_pages(self, width, height, tag):
        ctx, page, errors = self.open(width, height)
        for p, sub in PAGES:
            self.nav(page, p)
            page.wait_for_timeout(500)
            over = page.evaluate("() => document.documentElement.scrollWidth - window.innerWidth")
            self.assertLessEqual(over, 1, f"{tag} {p}/{sub} 가로로 {over}px 넘침")
            wide = page.evaluate("""() => [...document.querySelectorAll('section.page.on *')].filter(e => {
                const r = e.getBoundingClientRect(); return r.width > 0 && r.right > window.innerWidth + 1 && getComputedStyle(e).position !== 'fixed'
                && !e.closest('.kwlist,.log,nav,[style*="overflow-x"]')}).map(e => e.tagName + '.' + e.className).slice(0, 5)""")
            self.assertEqual(wide, [], f"{tag} {p}/{sub} 화면 밖으로 나간 요소")
            page.screenshot(path=os.path.join(SHOTS, f"{tag}_{p}{'_' + sub if sub else ''}.png"), full_page=True)
            if p in ("naver", "cafe", "daily", "band", "marketing"):    # 상세 설정(주제·스타일 학습)·방문기 선택도 펼쳐서 확인
                page.evaluate("() => { document.querySelectorAll('section.page.on details').forEach(d => d.open = true); const v = document.querySelector('[name=dk][value=visit]'); if (v && document.querySelector('#p_daily.on')) v.click() }")
                page.wait_for_timeout(300)
                over = page.evaluate("() => document.documentElement.scrollWidth - window.innerWidth")
                self.assertLessEqual(over, 1, f"{tag} {p} 상세 설정 펼침: 가로로 {over}px 넘침")
                page.screenshot(path=os.path.join(SHOTS, f"{tag}_{p}_detail.png"), full_page=True)
        self.assertEqual(errors, [])
        ctx.close()

    def test_1_pc_pages(self):
        self.check_pages(1440, 900, "pc")

    def test_kakao_send_and_reply_are_separate_menus(self):
        ctx, page, errors = self.open(1440, 900)
        page.click('nav a[data-p="kakao_send"]')
        page.wait_for_selector('#p_kakao_auto.on')
        self.assertEqual(page.locator('#pageTitle').inner_text(), '카카오톡 직접 발송')
        self.assertTrue(page.locator('#kaQuickStart').is_visible())
        page.click('#kaOpenSettings')
        self.assertTrue(page.locator('[data-ka-panel="send"]').is_visible())
        self.assertFalse(page.locator('[data-ka-panel="reply"]').is_visible())
        page.evaluate('KA_ROOMS=[{name:"첫 방",kind:"normal",enabled:false,reply:""},{name:"둘째 방",kind:"normal",enabled:false,reply:""}];renderKakaoAuto()')
        self.assertTrue(page.locator('[data-ka-send]').first.is_visible())
        self.assertFalse(page.locator('[data-ka-enabled]').first.is_visible())
        page.locator('[data-ka-send]').first.check()
        page.locator('[data-ka-send]').last.check()
        self.assertEqual(page.locator('#kaSendEditor .acct').count(), 2)
        page.locator('[data-ka-move="up"]').last.click()
        self.assertIn('둘째 방', page.locator('#kaSendEditor .acct').first.inner_text())
        page.locator('[data-ka-override]').first.fill('개별 문구')
        page.locator('#kaSendInterval').fill('3')
        self.assertEqual(page.input_value('#kaSendInterval'), '3')
        page.locator('#kaMessageImport').set_input_files({"name": "notice.txt", "mimeType": "text/plain",
                                                          "buffer": "카카오 공지 문구".encode("utf-8")})
        self.assertEqual(page.input_value('#kaMessage'), '카카오 공지 문구')
        page.screenshot(path=os.path.join(SHOTS, "pc_kakao_send.png"), full_page=True)

        page.click('#kaCloseSettings')
        page.click('nav a[data-p="kakao_reply"]')
        page.wait_for_selector('#p_kakao_auto.on')
        self.assertEqual(page.locator('#pageTitle').inner_text(), '카카오톡 자동응답')
        page.click('#kaOpenSettings')
        self.assertFalse(page.locator('[data-ka-panel="send"]').is_visible())
        self.assertTrue(page.locator('[data-ka-panel="reply"]').is_visible())
        page.evaluate('KA_ROOMS=[{name:"테스트 방",kind:"normal",enabled:false,reply:""}];renderKakaoAuto()')
        self.assertFalse(page.locator('[data-ka-send]').is_visible())
        self.assertTrue(page.locator('[data-ka-enabled]').is_visible())
        page.screenshot(path=os.path.join(SHOTS, "pc_kakao_reply.png"), full_page=True)
        self.assertEqual(errors, [])
        ctx.close()

    def test_kakao_send_mobile_layout(self):
        ctx, page, errors = self.open(390, 844)
        page.click('#menuBtn')
        page.click('nav a[data-p="kakao_send"]')
        page.wait_for_selector('#p_kakao_auto.on')
        page.click('#kaOpenSettings')
        page.evaluate('KA_ROOMS=[{name:"시험 방",kind:"normal",enabled:false,reply:""}];renderKakaoAuto()')
        page.locator('[data-ka-send]').check()
        self.assertEqual(page.locator('#kaSendEditor .acct').count(), 1)
        self.assertLessEqual(page.evaluate('document.documentElement.scrollWidth - window.innerWidth'), 1)
        page.screenshot(path=os.path.join(SHOTS, 'mobile_kakao_send.png'), full_page=True)
        self.assertEqual(errors, [])
        ctx.close()

    def test_telegram_account_cards_and_settings_dialogs(self):
        ctx, page, errors = self.open(1440, 900)
        recurring_starts = []
        def fake_telegram(route):
            path = route.request.url.split("/api/telegram/", 1)[-1]
            result = {"ok": True}
            if path == "status":
                result.update(accounts=[])
            elif path.endswith("/join/status") or "/join/status?" in path:
                result.update(phase="idle", running=False, total=0, results=[])
            elif path.endswith("/groups"):
                result["groups"] = []
            elif path.endswith("/addresses"):
                result.update(items=[], total=0, public=0)
            elif path.endswith("/recurring/targets"):
                result.update(items=[{"id": "123", "name": "시험 대화", "kind": "person"}], total=1)
            elif path.endswith("/recurring/status"):
                result.update(running=False, phase="idle", settings={"targetIds": ["123"],
                              "text": "안내", "hours": 0, "minutes": 3, "seconds": 0,
                              "formatMode": "plain"})
            elif path.endswith("/recurring/start"):
                recurring_starts.append(route.request.post_data_json)
                result.update(running=True, phase="running", message="발송 시작")
            route.fulfill(status=200, content_type="application/json", body=json.dumps(result))
        page.route("**/api/telegram/**", fake_telegram)
        self.nav(page, "telegram")
        page.wait_for_timeout(500)
        page.evaluate("""() => {TG_ACCOUNTS=[{id:'a1',label:'업무 계정',enabled:false,groups:[],status:{text:'연결됨'}}];TG_GROUPS['a1']=[];renderTelegram()}""")
        self.assertTrue(page.locator('[data-tg-reply-start]').is_visible())
        page.locator('[data-tg-settings]').click()
        self.assertTrue(page.locator('[data-tg-dialog]').is_visible())
        page.locator('[data-tg-format]').select_option('html')
        page.locator('[data-tg-text]').fill('안내')
        page.locator('[data-tg-style="bold"]').click()
        self.assertIn('<b>', page.locator('[data-tg-text]').input_value())
        page.screenshot(path=os.path.join(SHOTS, "pc_telegram_settings.png"))
        page.locator('[data-tg-close]').click()
        self.nav(page, "telegram_private")
        page.wait_for_timeout(500)
        page.evaluate("""() => {TG_PRIVATE_ACCOUNTS=[{id:'a1',label:'업무 계정',status:{text:'연결됨'}}];renderTelegramPrivate()}""")
        self.assertTrue(page.locator('[data-recurring-start]').first.is_visible())
        page.locator('[data-private-settings]').click()
        self.assertTrue(page.locator('[data-private-dialog]').is_visible())
        self.assertTrue(page.locator('[data-recurring-hours]').is_visible())
        page.screenshot(path=os.path.join(SHOTS, "pc_telegram_private_settings.png"))
        page.locator('[data-private-dialog] details').first.evaluate('(node) => node.open = true')
        page.locator('[data-private-text-import]').set_input_files({"name": "message.txt", "mimeType": "text/plain", "buffer": "오늘 19시 안내".encode("utf-8")})
        self.assertEqual(page.locator('[data-private-message]').input_value(), '오늘 19시 안내')
        page.locator('[data-private-close]').click()
        page.on("dialog", lambda dialog: dialog.accept())
        page.locator('[data-tg-private-card="a1"] > .row [data-recurring-start]').click()
        for _ in range(20):
            if recurring_starts:
                break
            page.wait_for_timeout(100)
        self.assertEqual(recurring_starts[0]["targetIds"], ["123"])
        self.assertEqual(errors, [])
        ctx.close()

    def test_2_mobile_pages(self):
        self.check_pages(390, 844, "mobile")

    def test_3_buttons_work(self):
        ctx, page, errors = self.open(1440, 900)
        page.on("dialog", lambda d: d.accept())
        files = []
        for i, (lab, col) in enumerate(list(H.COLORS.items())[:4]):
            f = os.path.join(H.HOME, f"ui_{i}.jpg")
            with open(f, "wb") as fh:
                fh.write(H.make_photo(col))
            files.append(f)
        # 자료함: 여러 장 올리기 → AI 라벨
        self.nav(page, "library")
        page.set_input_files("#files", files)
        page.wait_for_function("() => document.querySelectorAll('#libgrid .ph').length >= 4", timeout=20000)
        page.wait_for_function("() => [...document.querySelectorAll('#libgrid .muted')].some(e => e.textContent.includes('AI 라벨'))", timeout=30000)
        # 키워드 직접 입력
        self.nav(page, "keywords")
        page.fill("#kwAdd", "온양온천역 통닭 포장")
        page.click("#kwAddBtn")
        page.wait_for_selector("#kwlist [data-k='온양온천역 통닭 포장']")
        self.assertTrue(page.is_checked("#kwlist [data-k='온양온천역 통닭 포장']"))
        # AI 프롬프트 고치기 → 저장 → 다시 열어도 남아 있음
        self.nav(page, "prompts")
        page.locator("#prompts [data-p=text]").first.fill("UI에서 고친 프롬프트 내용")
        page.fill("#promptExtra", "배달 이야기는 쓰지 마세요")
        page.click("#promptSave")
        page.wait_for_timeout(800)
        page.reload()
        page.wait_for_selector("#steps li", state="attached")
        self.nav(page, "prompts")
        self.assertEqual(page.locator("#prompts [data-p=text]").first.input_value(), "UI에서 고친 프롬프트 내용")
        self.assertEqual(page.input_value("#promptExtra"), "배달 이야기는 쓰지 마세요")
        # 마케팅 블록 추가·저장 / 장소 검색어 저장
        self.nav(page, "marketing")
        n = page.locator("#blocks .block").count()
        page.click("#blockAdd")
        page.locator("#blocks .block").last.locator("[data-b=name]").fill("주차 안내")
        page.locator("#blocks .block").last.locator("[data-b=buttons]").fill("길찾기|https://map.naver.com/p/entry/place/17232917")
        page.click("#blockSave")
        page.wait_for_function(f"() => document.querySelectorAll('#blocks .block').length === {n + 1}")
        self.nav(page, "place")
        page.fill("#pl_queries", "원주통닭 온천동\n원주통닭")
        page.click("#placeSave")
        page.wait_for_timeout(500)
        # 블로그 관리: 계정 추가 + 상세 설정(프롬프트) 저장
        self.nav(page, "naver")
        n = page.locator("[data-acc=naver] .acct").count()
        page.click("[data-add=naver]")
        page.wait_for_function(f"() => document.querySelectorAll('[data-acc=naver] .acct').length === {n + 1}")
        last = page.locator("[data-acc=naver] .acct").last
        last.locator("[data-a=postsPerDay]").fill("2")
        last.locator("summary").click()
        last.locator("[data-a=prompt]").select_option("info")
        page.click("[data-save=naver]")
        page.wait_for_timeout(1000)
        # 작업 설정: 작업 추가 → 글 생성 시작 → 생성됨 → 등록 시작 → 테스트 완료
        self.nav(page, "work")
        page.fill("#w_keywords", "온양 치킨")
        page.click("#btnAdd")
        page.wait_for_function("() => [...document.querySelectorAll('#jobs .st')].some(e => e.textContent === '생성 대기')", timeout=15000)
        page.click("#btnGen")
        page.wait_for_function("() => [...document.querySelectorAll('#jobs .st')].some(e => e.textContent === '생성됨')", timeout=60000)
        page.click("#btnPub")
        page.wait_for_function("() => [...document.querySelectorAll('#jobs .st')].some(e => e.textContent === '테스트 완료')", timeout=60000)
        with ctx.expect_page() as pg:
            page.locator("#jobs [data-j=prev]").first.click()
        prev = pg.value
        prev.wait_for_load_state()
        self.assertIn("온양 치킨", prev.content())
        prev.close()
        # 일상 글: 사진 2장 → AI 계획 → 글 만들기 → 작업 목록에 일상 글
        self.nav(page, "daily")
        page.set_input_files("#dFiles", files[:2])
        page.wait_for_function("() => document.querySelectorAll('#dPhotos .ph').length === 2")
        page.fill("#dMemo", "비 오는 날")
        page.click("#dPlanBtn")
        page.wait_for_selector("#dPlanCard", state="visible", timeout=30000)
        self.assertTrue(page.input_value("#dPrompt").strip())
        page.screenshot(path=os.path.join(SHOTS, "pc_daily_plan.png"), full_page=True)
        page.click("#dCreate")
        page.wait_for_selector("#p_work.on")
        page.wait_for_function("() => [...document.querySelectorAll('#jobs .meta')].some(e => e.textContent.includes('일상 글'))", timeout=15000)
        page.screenshot(path=os.path.join(SHOTS, "pc_work_after_test.png"), full_page=True)
        # 실제 발행 스위치: 연결된 계정이 없으면 켜지지 않음 / 자동 모드
        page.click("#liveSw .sw span")
        page.wait_for_timeout(1500)
        self.assertFalse(page.is_checked("#live"))
        page.click("label.sw-wrap:has(#auto) .sw span")
        page.wait_for_timeout(1500)
        self.assertTrue(page.is_checked("#auto"))
        page.click("label.sw-wrap:has(#auto) .sw span")
        self.assertEqual(errors, [])
        ctx.close()

if __name__ == "__main__":
    unittest.main()
