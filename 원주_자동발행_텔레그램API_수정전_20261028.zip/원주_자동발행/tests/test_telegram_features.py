# -*- coding: utf-8 -*-
"""No live account or messages: deterministic checks for formatting, scanning and scheduling."""
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from autopost.telegram_extract import extract_references, scan_dialogs
from autopost.telegram_format import format_message
from autopost.telegram_recurring import TelegramRecurringSender


def test_format_modes_and_keyword_escaping():
    assert format_message("<b>{회사}</b> {날짜}", "html", {"회사": "A&B"})[0].startswith("<b>A&amp;B</b>")
    body, mode = format_message("*{회사}* _안내_ [사이트](https://example.com)",
                                "markdownv2", {"회사": "A_B"})
    assert body == '<b>A_B</b> <i>안내</i> <a href="https://example.com">사이트</a>'
    assert mode == "html"
    with pytest.raises(ValueError, match="값이 없어요"):
        format_message("{미등록}", "plain")


def test_extract_deduplicates_public_private_handle_and_id():
    rows = extract_references("https://telegram.me/channelabc t.me/channelabc @personabc "
                              "https://t.me/+Invite_123 t.me/joinchat/Hash_2 -1001234567890 "
                              "t.me/channelabc")
    assert ("address", "https://t.me/channelabc") in rows
    assert ("invite", "https://t.me/+Invite_123") in rows
    assert ("invite", "https://t.me/joinchat/Hash_2") in rows
    assert ("handle", "@personabc") in rows
    assert ("id", "-1001234567890") in rows
    assert len([row for row in rows if row[0] == "address"]) == 1


def test_scan_dialogs_reads_only_joined_group_and_channel_history():
    asyncio.run(_scan_dialogs_reads_only_joined_group_and_channel_history())


async def _scan_dialogs_reads_only_joined_group_and_channel_history():
    class Client:
        def __init__(self):
            self.read = []

        async def iter_dialogs(self):
            for kind, ident in (("group", -1001234567890), ("channel", -1009876543210), ("person", 42)):
                yield SimpleNamespace(is_group=kind == "group", is_channel=kind == "channel",
                                      is_user=kind == "person", name=kind, id=ident,
                                      entity=SimpleNamespace(id=ident, username="publicgroup" if kind == "group" else ""))

        async def get_peer_id(self, entity):
            return entity.id

        async def iter_messages(self, entity, limit):
            self.read.append((entity.id, limit))
            yield SimpleNamespace(raw_text="@somebody and t.me/+PrivateHash")

    client = Client()
    result = await scan_dialogs(client, messages_per_chat=3, max_chats=2)
    assert result["scannedChats"] == 2
    assert client.read == [(-1001234567890, 3), (-1009876543210, 3)]
    assert any(row["kind"] == "invite" and len(row["sources"]) == 2 for row in result["items"])
    assert any(row["value"] == "https://t.me/publicgroup" for row in result["items"])


def test_recurring_send_starts_and_stops_without_second_message():
    asyncio.run(_recurring_send_starts_and_stops_without_second_message())


async def _recurring_send_starts_and_stops_without_second_message():
    class Client:
        def __init__(self):
            self.send_message = AsyncMock()

        def is_connected(self):
            return True

        async def iter_dialogs(self):
            yield SimpleNamespace(is_user=True, is_group=False, is_channel=False,
                                  name="받는 사람", entity="peer")

        async def get_peer_id(self, _entity):
            return 123

    client = Client()
    sender = TelegramRecurringSender(lambda _: client)
    await sender.refresh("account")
    started = await sender.start("account", ["123"], "안내 {이름}", 0, 0, 10)
    assert started["running"]
    for _ in range(10):
        if client.send_message.await_count:
            break
        await asyncio.sleep(0.01)
    assert client.send_message.await_args.args == ("peer", "안내 받는 사람")
    await sender.stop("account")
    await asyncio.wait_for(sender.tasks["account"], timeout=1)
    assert sender.status("account")["phase"] == "stopped"
    assert client.send_message.await_count == 1
