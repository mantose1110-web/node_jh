# -*- coding: utf-8 -*-
"""Offline checks for explicitly selected private Telegram messages."""
import asyncio
import os
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from telethon.tl.types import User

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from autopost.telegram_private import TelegramPrivateSender
from autopost.telegram_reply import TelegramReplyManager


class FakeTelegram:
    def __init__(self, dialogs=(), contacts=()):
        self.dialogs = dialogs
        self.contacts = contacts
        self.sent = []
        self.send_message = AsyncMock(side_effect=self._send)

    async def get_me(self):
        return User(id=1, first_name="Me", is_self=True)

    async def iter_dialogs(self, limit=500):
        for user in self.dialogs:
            yield SimpleNamespace(is_user=True, entity=user)

    async def __call__(self, request, **kwargs):
        return SimpleNamespace(users=self.contacts)

    async def _send(self, user, text, **kwargs):
        self.sent.append((user.id, text))


class TelegramPrivateTests(unittest.IsolatedAsyncioTestCase):
    async def test_refresh_excludes_self_and_bots_and_deduplicates_contacts(self):
        alice = User(id=2, first_name="Alice", username="alice")
        bob = User(id=3, first_name="Bob")
        fake = FakeTelegram(dialogs=[alice, User(id=1, first_name="Me", is_self=True),
                                     User(id=4, first_name="Bot", bot=True)], contacts=[alice, bob])
        sender = TelegramPrivateSender(lambda _aid: fake)
        result = await sender.refresh("account")
        self.assertEqual([row["id"] for row in result["recipients"]], ["2", "3"])
        self.assertEqual(result["recipients"][0]["sources"], ["대화", "연락처"])
        fake.send_message.assert_not_awaited()

    async def test_send_requires_refreshed_explicit_selection_and_stops_between_people(self):
        alice = User(id=2, first_name="Alice")
        bob = User(id=3, first_name="Bob")
        fake = FakeTelegram(dialogs=[alice, bob])
        sender = TelegramPrivateSender(lambda _aid: fake)
        with self.assertRaises(ValueError):
            await sender.send("account", ["2"], "공지")
        fake.send_message.assert_not_awaited()
        await sender.refresh("account")
        with self.assertRaises(ValueError):
            await sender.send("account", ["999"], "공지")
        entered, release = asyncio.Event(), asyncio.Event()

        async def hold_first(user, text, **_kwargs):
            fake.sent.append((user.id, text))
            entered.set()
            await release.wait()

        fake.send_message.side_effect = hold_first
        await sender.send("account", ["2", "3"], "오늘 19시부터 23시까지입니다")
        await asyncio.wait_for(entered.wait(), 2)
        await sender.stop("account")
        release.set()
        await asyncio.wait_for(sender.tasks["account"], 2)
        self.assertEqual(fake.sent, [(2, "오늘 19시부터 23시까지입니다")])
        self.assertEqual(sender.status("account")["phase"], "stopped")
        with self.assertRaises(ValueError):
            await sender.send("account", ["2", "3"], "오늘 19시부터 23시까지입니다")
        await sender.close()

    async def test_private_reply_uses_its_own_text_when_group_reply_is_off(self):
        manager = TelegramReplyManager()
        callbacks = []
        client = SimpleNamespace(add_event_handler=lambda fn, _kind: callbacks.append(fn),
                                 remove_event_handler=lambda fn: None,
                                 send_message=AsyncMock())
        config = {"telegram": {"accounts": [{"id": "account", "enabled": False,
                   "replyPrivate": True, "privateReplyText": "개인 답장", "replyText": "그룹 답장",
                   "groups": [], "dedupeIncoming": False}]}}
        event = SimpleNamespace(out=False, chat_id=2, is_group=False, is_private=True,
                                message=SimpleNamespace(action=None), sender_id=2, id=10,
                                get_input_chat=AsyncMock(return_value="private-peer"))
        with patch("autopost.telegram_reply.load_config", return_value=config), \
             patch("autopost.telegram_reply.log"), \
             patch.object(manager, "_allow_reply", return_value=True):
            manager._add_handler("account", client)
            await callbacks[0](event)
            self.assertEqual(client.send_message.await_args.args[1], "개인 답장")
            self.assertEqual(client.send_message.await_count, 1)
            config["telegram"]["accounts"][0]["replyPrivate"] = False
            await callbacks[0](event)
            self.assertEqual(client.send_message.await_count, 1)


if __name__ == "__main__":
    unittest.main()
