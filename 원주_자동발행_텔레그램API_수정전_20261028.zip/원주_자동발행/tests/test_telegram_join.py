# -*- coding: utf-8 -*-
"""Offline queue lifecycle checks; no Telegram login or network access is used."""
import asyncio
import copy
import json
import os
import sys
import time
import unittest
from unittest.mock import AsyncMock, Mock, patch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from autopost.telegram_join import TelegramJoinQueue


class FloodWaitError(Exception):
    def __init__(self, seconds):
        super().__init__("server-requested delay")
        self.seconds = seconds


class TelegramJoinQueueTests(unittest.IsolatedAsyncioTestCase):
    ACCOUNT = "a1b2c3d4e5f6"
    STORE_NAME = "telegram-joins-a1b2c3d4e5f6"

    async def asyncSetUp(self):
        self.blobs = {}
        self.queues = []
        self.get_client = Mock(return_value=object())

        def save_blob(name, value):
            self.blobs[name] = copy.deepcopy(value)

        def load_blob(name, default=None):
            return copy.deepcopy(self.blobs.get(name, default))

        self.save_patch = patch("autopost.telegram_join.secure.save_json", side_effect=save_blob)
        self.load_patch = patch("autopost.telegram_join.secure.load_json", side_effect=load_blob)
        self.delete_patch = patch("autopost.telegram_join.secure.delete_json", side_effect=lambda name: self.blobs.pop(name, None))
        self.save_blob = self.save_patch.start()
        self.load_patch.start()
        self.delete_patch.start()

    async def asyncTearDown(self):
        try:
            for queue in self.queues:
                await queue.close()
        finally:
            self.delete_patch.stop()
            self.load_patch.stop()
            self.save_patch.stop()

    def queue(self):
        queue = TelegramJoinQueue(self.get_client)
        self.queues.append(queue)
        return queue

    async def until(self, queue, predicate):
        async def poll():
            while True:
                result = await queue.status(self.ACCOUNT)
                if predicate(result):
                    return result
                await asyncio.sleep(0.001)
        return await asyncio.wait_for(poll(), timeout=3)

    async def finish_one_then_pause(self, queue, outcome):
        """Pause while a request is in flight, then let that request finish."""
        entered, release = asyncio.Event(), asyncio.Event()
        calls = []

        async def join_one(_client, item):
            calls.append(copy.deepcopy(item))
            entered.set()
            await release.wait()
            return {"status": outcome, "title": "Company group", "message": outcome}

        queue._join_one = join_one
        await queue.start(self.ACCOUNT, "@companyfirst\n@companysecond", interval_seconds=30)
        await asyncio.wait_for(entered.wait(), 3)
        pause_task = asyncio.create_task(queue.pause(self.ACCOUNT))
        await asyncio.sleep(0)
        release.set()
        await asyncio.wait_for(pause_task, 3)
        result = await self.until(queue, lambda state: not state["running"])
        return result, calls

    async def test_draft_uses_secure_blob_and_restores_without_network(self):
        queue = self.queue()
        queue._join_one = AsyncMock()
        links = "@CompanyGroup\nhttps://t.me/+AbCdEfghijkLMN12"
        saved = await queue.save(self.ACCOUNT, links, interval_seconds=30)

        self.assertEqual(saved["total"], 2)
        self.assertEqual(saved["pending"], 2)
        self.assertFalse(saved["running"])
        self.assertIn(self.STORE_NAME, self.blobs)
        self.save_blob.assert_called()
        self.get_client.assert_not_called()
        queue._join_one.assert_not_awaited()

        restored = self.queue()
        result = await restored.status(self.ACCOUNT, include_links=True)
        self.assertEqual(result["total"], 2)
        self.assertEqual(result["pending"], 2)
        self.assertFalse(result["running"])
        self.assertIn("AbCdEfghijkLMN12", result["links"])

    async def test_equivalent_links_dedupe_and_bad_rows_remain_visible(self):
        queue = self.queue()
        result = await queue.save(self.ACCOUNT, "\n".join([
            "@CompanyGroup",
            "https://t.me/companygroup",
            "https://t.me/+AbCdEfghijkLMN12;https://t.me/joinchat/AbCdEfghijkLMN12",
            "https://example.com/offer",
            "https://t.me/c/123/4",
        ]))

        self.assertEqual(result["duplicates"], 2)
        self.assertEqual(result["pending"], 2)
        self.assertEqual(result["total"], 4)
        self.assertEqual(sum(row["status"] == "invalid" for row in result["results"]), 2)
        self.get_client.assert_not_called()

    async def test_default_status_does_not_expose_private_invite_token(self):
        queue = self.queue()
        token = "PrivateInviteSecretToken987"
        await queue.save(self.ACCOUNT, "https://t.me/+" + token)

        public = await queue.status(self.ACCOUNT)
        self.assertNotIn(token, json.dumps(public, ensure_ascii=False))
        self.assertNotIn("links", public)
        editable = await queue.status(self.ACCOUNT, include_links=True)
        self.assertIn(token, editable["links"])

    async def test_pause_finishes_current_request_and_leaves_next_pending(self):
        queue = self.queue()
        state, calls = await self.finish_one_then_pause(queue, "joined")
        self.assertEqual(len(calls), 1)
        self.assertEqual(state["joined"], 1)
        self.assertEqual(state["pending"], 1)
        self.assertTrue(state["canResume"])

        queue._states[self.ACCOUNT]["nextAt"] = 0  # Simulate the ordinary inter-item delay elapsing.
        queue._join_one = AsyncMock(return_value={"status": "already", "title": "Second group", "message": "already"})
        await queue.resume(self.ACCOUNT)
        completed = await self.until(queue, lambda row: not row["running"] and row["pending"] == 0)
        queue._join_one.assert_awaited_once()
        self.assertEqual(completed["joined"], 1)
        self.assertEqual(completed["already"], 1)

    async def test_restart_resume_skips_joined_and_approval_pending_items(self):
        for terminal in ("joined", "requested"):
            with self.subTest(terminal=terminal):
                self.blobs.clear()
                first = self.queue()
                before, _ = await self.finish_one_then_pause(first, terminal)
                await first.close()

                restored = self.queue()
                paused = await restored.status(self.ACCOUNT)
                self.assertFalse(paused["running"])
                self.assertEqual(paused["phase"], "paused")
                self.assertEqual(paused["pending"], 1)
                self.assertEqual(paused["batchId"], before["batchId"])
                restored._states[self.ACCOUNT]["nextAt"] = 0
                restored._join_one = AsyncMock(return_value={"status": "joined", "title": "Second group", "message": "joined"})
                await restored.resume(self.ACCOUNT)
                completed = await self.until(restored, lambda row: not row["running"] and row["pending"] == 0)
                restored._join_one.assert_awaited_once()
                item = restored._join_one.await_args.args[1]
                self.assertEqual(item["value"], "companysecond")
                self.assertEqual(completed["done"], 2)
                self.assertEqual(completed["requested"], int(terminal == "requested"))
                await restored.close()

    async def test_server_wait_survives_new_draft_and_process_restart(self):
        queue = self.queue()
        queue._join_one = AsyncMock(side_effect=FloodWaitError(3600))
        await queue.start(self.ACCOUNT, "@companyfirst\n@companysecond")
        waiting = await self.until(queue, lambda state: state["retryAt"] > time.time() + 3000)
        self.assertEqual(waiting["done"], 0)
        self.assertEqual(waiting["pending"], 2)
        await queue.pause(self.ACCOUNT)
        await self.until(queue, lambda state: not state["running"])

        saved = await queue.save(self.ACCOUNT, "@companythird")
        self.assertGreaterEqual(saved["retryAt"], waiting["retryAt"])
        await queue.close()
        restored = self.queue()
        state = await restored.status(self.ACCOUNT)
        self.assertGreaterEqual(state["retryAt"], waiting["retryAt"])
        restored._join_one = AsyncMock(return_value={"status": "joined", "title": "Third group", "message": "joined"})
        await restored.resume(self.ACCOUNT)
        await asyncio.sleep(0.02)
        restored._join_one.assert_not_awaited()

    async def test_oversized_list_is_rejected_without_overwriting_saved_draft(self):
        queue = self.queue()
        original = await queue.save(self.ACCOUNT, "@companyfirst")
        with self.assertRaises(ValueError):
            await queue.save(self.ACCOUNT, "\n".join("@companygroup%03d" % index for index in range(51)))
        remaining = await queue.status(self.ACCOUNT, include_links=True)
        self.assertEqual(remaining["batchId"], original["batchId"])
        self.assertEqual(remaining["total"], 1)
        self.assertIn("companyfirst", remaining["links"])


if __name__ == "__main__":
    unittest.main()
