# -*- coding: utf-8 -*-
"""검증용 로컬 가짜 서버 (실제 계정 없이 발행 코드 경로 전체를 실행)
- Anthropic Messages API (/v1/messages): 키·버전·캐시 헤더 확인, usage 토큰 반환
- Instagram Graph API (/v21.0/...): 토큰 교환, me/accounts, 컨테이너 생성(이미지 URL 실제 다운로드 확인)/상태/발행, 해시태그 검색
- 네이버 스마트에디터 ONE 복제 화면 (/naver/...): 로그인 쿠키, iframe#mainFrame, 제목/본문/사진 업로드/장소/카테고리/태그/발행
- 티스토리 글쓰기 복제 화면 (/tistory/...): tinymce 대체, 사진 첨부, 카테고리, 태그, 공개 발행
- FTP (pyftpdlib) + 그 폴더를 HTTP로 공개 (/site/...) → 인스타가 받아 갈 공개 이미지 주소
발행 결과는 /state 에서 확인. 사용: python fake_services.py <http포트> <ftp포트> <ftp루트>
"""
import hashlib, json, os, random, re, threading, time
from flask import Flask, jsonify, request, redirect, send_from_directory, make_response, abort, Response

FTP_ROOT = os.environ.get("FAKE_FTP_ROOT") or "/tmp/fake-ftp"
UPLOADS = os.path.join(FTP_ROOT, "_uploads")


def configure(ftp_root):
    global FTP_ROOT, UPLOADS
    FTP_ROOT = ftp_root
    UPLOADS = os.path.join(FTP_ROOT, "_uploads")
    os.makedirs(UPLOADS, exist_ok=True)
API_KEY = "sk-ant-fake-QA-0000000000000000"
META_SECRET = "fake-meta-secret-123"
CATEGORIES = ["일상", "치킨 이야기", "공지사항"]   # 실제처럼 사장님 블로그마다 다름 ('가게 이야기' 같은 기본값은 없음)
S = {"anthropic": [], "naver": [], "tistory": [], "ig_containers": {}, "ig_published": [], "ig_tokens": set(), "logins": [], "errors": [], "cache": set(),
     "sessions": set(), "models_tried": [], "fail_publish": 0, "editor_opens": 0, "concurrent": 0, "max_concurrent": 0}
LOCK = threading.Lock()
app = Flask(__name__)


def err(msg, code=400):
    S["errors"].append(msg)
    return jsonify({"error": {"message": msg, "type": "invalid_request_error"}}), code


# ---------------- Anthropic ----------------
SENT = ["오늘은 오후 세 시부터 기름을 데우고 닭을 손질했어요.", "포장 주문이 몰리는 시간에는 미리 전화 주시면 덜 기다리세요.",
        "튀김옷은 얇게 입혀서 바삭함을 살리려고 해요.", "가게 앞 골목에 저녁 바람이 불면 장사가 바빠집니다.",
        "양념은 매일 아침 조금씩 새로 만들어 둡니다.", "옛날 통닭은 통째로 튀겨서 겉이 더 바삭해요.",
        "마감 후에는 튀김기 기름을 걸러 내고 바닥 청소까지 하고 퇴근해요.", "아이들과 함께 오시는 가족 손님이 많은 요일이 있어요.",
        "반반 메뉴는 두 가지 맛을 한 번에 드시고 싶을 때 좋아요.", "비 오는 날에는 포장 손님이 조금 더 늘어나는 편입니다.",
        "닭은 그날 들어온 것만 쓰려고 매일 아침 확인합니다.", "주차는 가게 근처 공간을 이용하시면 됩니다.",
        "기름 온도는 하루에도 여러 번 확인해요.", "떡볶이는 국물을 넉넉하게 해서 통닭과 같이 드시기 좋아요.",
        "무는 직접 담가서 새콤하게 맞췄어요.", "동네 단골분들 얼굴을 보면 하루 피로가 풀립니다.",
        "처음 오시는 분께는 후라이드부터 권해 드려요.", "양념치킨 소스는 너무 달지 않게 맞추고 있어요.",
        "주말 저녁은 일찍 주문해 주시면 좋아요.", "가게 안 테이블은 많지 않아서 포장이 편하실 수 있어요."]
SENT += ["오늘은 손님이 몰리기 전에 기름을 새로 갈았어요.", "포장 상자는 접어서 미리 쌓아 둡니다.", "비 오는 날엔 전화 주문이 늘어요.",
         "무는 직접 썰어서 하루 숙성해요.", "닭은 매일 아침 받아서 바로 손질합니다.", "늦은 시간에도 주방 불은 켜 둬요.",
         "처음 오신 분들께는 기본 메뉴를 권해 드려요.", "가게 앞 간판 불이 켜지면 영업 시작이에요.", "튀김 소리가 잦아들면 건질 때예요.",
         "반반은 두 가지 맛을 한 번에 드시기 좋아요.", "주말 낮에는 비교적 한산한 편이에요.", "단골분들은 미리 전화로 주문해 두세요."]
HEADS = ["오늘 준비 이야기", "튀기는 과정", "메뉴 한 가지", "찾아오시는 길", "포장 안내", "사장 메모", "주방에서", "저녁 풍경", "동네 산책길", "오늘의 정리"]


LINK_LINES = ["메뉴판은 홈페이지에 올려 뒀어요 📋", "자세한 건 여기 있어요 👉", "궁금하시면 홈페이지 한번 들러 주세요 🙏", "가게 소식은 여기서도 보실 수 있어요 ✨",
              "위치랑 영업시간은 여기 정리해 뒀어요 📍", "주문 전에 메뉴 먼저 보고 오셔도 좋아요 😊"]
PHOTO_LINES = ["이건 오늘 찍은 {lab} 사진이에요 📸", "{lab} 쪽을 한 장 남겨 봤어요.", "찰칵, {lab} 장면이에요 😊", "{lab} 모습도 같이 올려요 ✨",
               "오늘의 {lab} 기록이에요.", "{lab} 사진 보시면 분위기가 느껴지실 거예요 🍗"]


def gen_sentences(rng, n):
    """조합으로 만든 다양한 일상 문장 (테스트용)"""
    t = ["오후 두 시쯤", "해 질 무렵", "저녁 장사 전에", "마감 직전에", "비가 그친 뒤", "손님이 뜸할 때", "주말 오후에", "늦은 밤에", "점심 무렵"]
    a = ["튀김기 기름을 걸렀", "무를 새로 담갔", "닭을 손질했", "포장 상자를 접어 뒀", "양념 소스를 조금 끓였", "바닥 청소를 했", "가게 앞을 쓸었",
         "튀김옷 반죽을 새로 했", "냉장고 정리를 했", "간판 불을 켰", "앞치마를 새로 바꿨", "창문을 활짝 열어 환기했"]
    e = ["어요.", "답니다 😊", "네요 🍗", "지 뭐예요 ㅎㅎ", "어요 ✨", "습니다.", "는데 기분이 좋더라고요 🙏"]
    return [f"{rng.choice(t)} {rng.choice(a)}{rng.choice(e)}" for _ in range(n)]


RETIRED = {"claude-sonnet-5-0-20260901"}   # 목록에는 있지만 호출하면 404 (실제로 겪은 오류 재현)
FAKE_MODELS = [{"type": "model", "id": "claude-sonnet-5-0-20260901", "display_name": "Claude Sonnet 5.0 (retired)", "created_at": "2026-09-01T00:00:00Z"},
               {"type": "model", "id": "claude-sonnet-4-6-20260201", "display_name": "Claude Sonnet 4.6", "created_at": "2026-02-01T00:00:00Z"},
               {"type": "model", "id": "claude-opus-4-5-20251101", "display_name": "Claude Opus 4.5", "created_at": "2025-11-01T00:00:00Z"},
               {"type": "model", "id": "claude-haiku-4-5-20251001", "display_name": "Claude Haiku 4.5", "created_at": "2025-10-01T00:00:00Z"}]


@app.get("/v1/models")
def models():
    if request.headers.get("x-api-key") != API_KEY:
        return err("invalid x-api-key", 401)
    return jsonify({"data": FAKE_MODELS, "has_more": False})


@app.post("/v1/messages")
def messages():
    if request.headers.get("x-api-key") != API_KEY:
        return err("invalid x-api-key", 401)
    if request.headers.get("anthropic-version") != "2023-06-01":
        return err("anthropic-version header required")
    b = request.get_json(force=True)
    if not b.get("model") or not isinstance(b.get("max_tokens"), int) or b["max_tokens"] > 64000:
        return err("model/max_tokens invalid")
    S["models_tried"].append(b["model"])
    if S.get("overload", 0) > 0:     # Claude 서버 과부하 재현
        S["overload"] -= 1
        return jsonify({"type": "error", "error": {"type": "overloaded_error", "message": "Overloaded"}}), 529
    if b["model"] in RETIRED or b["model"] not in {m["id"] for m in FAKE_MODELS}:
        return jsonify({"type": "error", "error": {"type": "not_found_error", "message": f"model: {b['model']}"}}), 404
    msgs = b.get("messages") or []
    if not msgs or msgs[0].get("role") != "user":
        return err("messages must start with user")
    c0 = msgs[0].get("content")
    if (b.get("tool_choice") or {}).get("name") == "submit_plan":   # 일상 글 계획 (사진 여러 장)
        n = sum(1 for x in c0 if x.get("type") == "image") if isinstance(c0, list) else 0
        if not n:
            return err("plan needs images")
        S.setdefault("plans", []).append(n)
        out = {"photos": [{"index": i, "description": f"주방에서 통닭을 튀기는 모습 {i + 1}", "labels": ["조리과정"]} for i in range(n)],
               "summary": "오늘은 비가 와서 포장 손님이 많았어요.", "keyword": "아산 통닭", "title_ideas": ["비 오는 날 통닭집", "오늘의 주방", "포장 많은 날"],
               "prompt": "사진 1부터 순서대로 오늘 주방 이야기를 쓰세요. [FAKE-PLAN-MARK]"}
        return _reply(b, out, {"input_tokens": 900, "output_tokens": 200})
    if (b.get("tool_choice") or {}).get("name") == "submit_keywords":   # 키워드 아이디어 (걸러져야 할 것 포함)
        return _reply(b, {"keywords": [{"keyword": "온천동 통닭 포장", "group": "상황", "reason": "포장"}, {"keyword": "아산 내돈내산 치킨", "group": "상황"},
                                       {"keyword": "아산 BBQ 치킨", "group": "메뉴"}, {"keyword": "아산 원주통닭", "group": "메뉴"},
                                       {"keyword": "강원 원주 치킨", "group": "동네"}, {"keyword": "온양온천역  밤 야식", "group": "동네", "reason": "역 근처"}]},
                      {"input_tokens": 300, "output_tokens": 100})
    if (b.get("tool_choice") or {}).get("name") == "submit_style":   # 기존 글 스타일 요약
        S.setdefault("style_calls", []).append(str(c0)[:3000])
        return _reply(b, {"summary": "- 말투: 친근한 해요체\n- 1~2문장마다 줄바꿈\n- 이모지는 가끔 [FAKE-STYLE]"}, {"input_tokens": 500, "output_tokens": 60})
    if isinstance(c0, list) and any(x.get("type") == "image" for x in c0):  # 비전: 사진 평균 색 → 라벨 (테스트 사진은 라벨별 색으로 만듦)
        return _vision(b, c0)
    system = b.get("system") or []
    sys_text = "".join(x.get("text", "") for x in system) if isinstance(system, list) else str(system)
    cached = isinstance(system, list) and any(x.get("cache_control") for x in system)
    user = msgs[0]["content"] if isinstance(msgs[0]["content"], str) else json.dumps(msgs[0]["content"])
    kw = (re.search(r'핵심 키워드: "(.*?)"', user) or re.search(r'핵심 키워드: "(.*?)"', sys_text))
    kw = kw.group(1) if kw else "아산 통닭"
    url = (re.search(r"홈페이지 (\S+) 를", sys_text + user) or [None, "https://원주.kr"])[1]
    rng = random.Random(hashlib.sha256((user + str(time.time_ns())).encode()).hexdigest())
    heads = rng.sample(HEADS, 3)
    # 성실한 모델처럼: '자주 나온 표현'·'최근 첫 문장'·'최근 제목' 목록을 피해서 씀
    avoid = (re.search(r"자주 나온 표현\(이번엔 쓰지 말고 다른 말로\): (.*)", user) or [None, ""])[1].split(", ")
    avoid = [a.strip() for a in avoid if a.strip()]
    pool = [x for x in SENT + gen_sentences(rng, 40) if not any(a in " ".join(re.findall(r"[가-힣A-Za-z0-9]+", x)) for a in avoid)] or SENT
    sents = rng.sample(pool, min(9, len(pool)))
    guide = "파워블로거 스타일)의 운영자" in sys_text
    opens = ["오늘은 하늘이 유난히 맑았어요 ☀️", "기름 온도계가 170도를 가리킬 때 하루가 시작돼요 🔥", "요즘 해가 정말 짧아졌죠? 🍂",
             "가게 셔터를 올리는 소리로 오후를 열었어요.", "솔직히 오늘은 좀 피곤했어요 ㅎㅎ", "바람이 차가워지니 통닭 생각나는 계절이에요 🍗",
             "주방 창문에 김이 서리기 시작했어요.", "오늘 일기는 짧게 쓰려다가 길어졌어요 😅", "포장 상자를 접다 보니 벌써 저녁이에요.",
             "비 냄새가 나는 오후였어요 ☔", "오늘은 무를 평소보다 많이 썰었어요.", "손님이 뜸한 시간, 커피 한 잔 들고 적어 봐요 ☕"]
    recent_open = (re.search(r"최근 글 첫 문장\(이렇게 시작하지 말 것\): (.*)", user) or [None, ""])[1]
    opens = [o for o in opens if o[:12] not in recent_open] or opens
    owner = bool(S.get("owner_intro"))
    if guide and S.get("owner_voice", 0) > 0:     # 손님용 블로그인데 사장님 말투로 쓴 글 (실제로 생긴 문제 재현)
        S["owner_voice"] -= 1
        guide, owner = False, True
    intro = (rng.choice(["{k} 찾는 분들을 위해 아산 원주통닭 정보를 한눈에 정리했어요.", "오늘은 {k} 궁금증을 하나씩 풀어 볼게요 ✨", "{k} 검색하셨다면 이 글 하나로 끝내 보세요!",
                         "{k}, 처음 가는 분들이 제일 많이 묻는 것부터 정리했어요 📝", "{k} 관련해서 알아 두면 좋은 것들 모아 봤어요."]).format(k=kw) if guide else
             (f"{kw} 찾아오신 분들 반갑습니다. 아산 원주통닭 사장입니다." if owner else f"{rng.choice(opens)} " + rng.choice(["{k} 이야기를 조금 적어 볼게요.", "오늘은 {k} 얘기예요.", "{k} 생각하면서 하루를 보냈어요.", "{k} 궁금하셨던 분들께 써 봐요.", "그래서 오늘 주제는 {k}!", "{k}, 오늘 일기에 담아 볼게요."]).format(k=kw)))
    body = f"<p>{intro}</p>" + "".join(
        f"<h2>{h}</h2><p>{' '.join(sents[i * 3:(i + 1) * 3])}</p>" for i, h in enumerate(heads)) + f'<p>{rng.choice(LINK_LINES)} <a href="{url}">{url}</a></p>'
    photos = re.findall(r"\[\[IMG:(\d+)\]\] 라벨: ([^\n/]+)", user)
    if photos:  # 사진 목록이 오면 사진 내용에 맞춘 문장 + 표시를 본문에 넣음
        extra = "".join(f"<p>{rng.choice(PHOTO_LINES).format(lab=lab.strip())}</p>[[IMG:{i}]]" for i, lab in photos)
        body = body.replace("</h2>", "</h2>" + extra, 1)
    tforms = ["[사장 일기] {h}, {k} 이야기 {e}", "{d} {h} - {k} {e}", "{k}, 오늘은 {h}부터 {e}", "{h} 하다 보니 하루가 갔네요 {e} | {k}",
              "통닭집 {n}번째 기록: {h} ({k})", "{k} 고민하는 분께, {h} {e}"]
    recent_titles = (re.search(r"최근 제목\(비슷한 제목·같은 단어 조합 금지\): (.*)", user) or [None, ""])[1]
    for _ in range(10):
        title = rng.choice(tforms).format(h=heads[0], k=kw, e=rng.choice("🍗😊✨🔥🍂☔🙏"), d=rng.choice(["화요일", "주말", "늦은 밤", "오후"]), n=rng.randint(2, 999))
        if title not in recent_titles:
            break
    out = {"title": f"{kw}, 한눈에 정리한 {heads[0]}" if guide else title, "body_html": body, "tags": [kw, "아산통닭"], "caption": sents[0] + "\n" + url,
           "hashtags": ["#" + kw.replace(" ", ""), "#아산원주통닭"]}
    text = json.dumps(out, ensure_ascii=False)
    key = hashlib.sha256(sys_text.encode()).hexdigest()
    first = key not in S["cache"]
    S["cache"].add(key)
    sys_tok, user_tok = len(sys_text) // 2, len(user) // 2
    usage = {"input_tokens": user_tok, "output_tokens": len(text) // 2,
             "cache_creation_input_tokens": sys_tok if (cached and first) else 0, "cache_read_input_tokens": sys_tok if (cached and not first) else 0}
    if not cached:
        usage["input_tokens"] += sys_tok
    with LOCK:
        S["anthropic"].append({"model": b["model"], "max_tokens": b["max_tokens"], "cached": cached, "keyword": kw, "usage": usage,
                               "system": sys_text[:6000], "user": user[:6000]})
    return _reply(b, out, usage)


VISION_COLORS = {"후라이드": (230, 160, 40), "양념": (200, 30, 30), "매장외관": (40, 90, 200), "포장": (240, 240, 240),
                 "테이블": (120, 70, 30), "음료": (30, 180, 200), "조리과정": (60, 60, 60)}


def _vision(b, content):
    import base64, io
    from PIL import Image
    img = next(x for x in content if x.get("type") == "image")
    im = Image.open(io.BytesIO(base64.b64decode(img["source"]["data"]))).convert("RGB").resize((1, 1))
    c = im.getpixel((0, 0))
    lab = min(VISION_COLORS, key=lambda k: sum((a - b_) ** 2 for a, b_ in zip(VISION_COLORS[k], c)))
    usage = {"input_tokens": 400, "output_tokens": 30, "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0}
    with LOCK:
        S.setdefault("vision", []).append({"model": b["model"], "label": lab})
    return _reply(b, {"labels": [lab], "caption": f"{lab} 사진"}, usage)


def _reply(b, out, usage):
    """tools + tool_choice 가 오면 tool_use 블록으로, 아니면 JSON 텍스트로"""
    if S.get("truncate", 0) > 0 and b.get("max_tokens", 0) < 12000:   # 글이 잘리는 상황 재현
        S["truncate"] -= 1
        S.setdefault("truncated", []).append(b["max_tokens"])
        part = {k: v for k, v in out.items() if k in ("title",)}
        return jsonify({"id": "msg_fake", "type": "message", "role": "assistant", "model": b["model"], "stop_reason": "max_tokens",
                        "content": [{"type": "tool_use", "id": "toolu_fake", "name": (b.get("tool_choice") or {}).get("name", "x"), "input": part}], "usage": usage})
    tools = b.get("tools") or []
    tc = b.get("tool_choice") or {}
    if tools:
        if tc.get("type") != "tool" or tc.get("name") not in {t["name"] for t in tools}:
            return err("tool_choice invalid")
        schema = next(t for t in tools if t["name"] == tc["name"])["input_schema"]
        missing = [k for k in schema.get("required", []) if k not in out]
        if missing:
            return err(f"fake: missing {missing}")
        content = [{"type": "tool_use", "id": "toolu_fake", "name": tc["name"], "input": out}]
        stop = "tool_use"
    else:
        content, stop = [{"type": "text", "text": json.dumps(out, ensure_ascii=False)}], "end_turn"
    return jsonify({"id": "msg_fake", "type": "message", "role": "assistant", "model": b["model"], "stop_reason": stop, "content": content, "usage": usage})


# ---------------- Instagram Graph ----------------
IG_USERS = ["17841400000000001", "17841400000000002"]


def _tok():
    t = request.values.get("access_token", "")
    if t not in S["ig_tokens"]:
        abort(make_response(jsonify({"error": {"message": "Invalid OAuth access token", "code": 190}}), 400))
    return t


@app.get("/<ver>/oauth/access_token")
def oauth(ver):
    a = request.args
    if a.get("grant_type") != "fb_exchange_token" or a.get("client_secret") != META_SECRET or not a.get("client_id"):
        return err("bad oauth request")
    if not a.get("fb_exchange_token", "").startswith(("EAA", "EAALONG")):
        return err("bad short token")
    t = "EAALONG" + hashlib.sha1(a["fb_exchange_token"].encode() + os.urandom(4)).hexdigest()
    S["ig_tokens"].add(t)
    return jsonify({"access_token": t, "token_type": "bearer", "expires_in": 5184000})


@app.get("/<ver>/me/accounts")
def me_accounts(ver):
    _tok()
    return jsonify({"data": [{"name": f"페이지{i + 1}", "id": f"10{i}", "instagram_business_account": {"id": u}} for i, u in enumerate(IG_USERS)]})


@app.get("/<ver>/ig_hashtag_search")
def ht_search(ver):
    _tok()
    return jsonify({"data": [{"id": "ht_" + hashlib.md5(request.args.get("q", "").encode()).hexdigest()[:10]}]})


@app.get("/<ver>/<oid>/<edge>")
def ht_media(ver, oid, edge):
    _tok()
    if edge not in ("top_media", "recent_media"):
        abort(404)
    return jsonify({"data": [{"id": f"{oid}_{edge}_{i}", "caption": f"오늘 저녁 #아산치킨 #온양맛집 {i}", "like_count": 10 + i, "comments_count": i,
                              "permalink": f"https://instagram.com/p/{oid}{i}", "media_type": "IMAGE", "timestamp": "2026-10-18T10:00:00+0000"} for i in range(3)]})


FB_PAGE = {"token": "fbpage-QA-token-123", "id": "5550001", "name": "아산 원주통닭 페이지"}


@app.get("/<ver>/<oid>")
def ig_get(ver, oid):
    if oid == "me" and request.values.get("access_token", "").startswith("fbpage-"):
        if request.values.get("access_token") != FB_PAGE["token"]:
            return jsonify({"error": {"message": "Invalid OAuth access token.", "code": 190}}), 400
        return jsonify({"id": FB_PAGE["id"], "name": FB_PAGE["name"]})
    _tok()
    if oid in S["ig_containers"]:
        c = S["ig_containers"][oid]
        c["polls"] += 1
        return jsonify({"status_code": "FINISHED" if c["polls"] >= 2 else "IN_PROGRESS", "id": oid})
    if oid in IG_USERS:
        return jsonify({"username": "wonju_qa_" + oid[-1], "id": oid})
    abort(404)


def _fetch_img(url):
    import urllib.request
    data = urllib.request.urlopen(url, timeout=10).read()
    if not (data[:3] == b"\xff\xd8\xff" or data[:8] == b"\x89PNG\r\n\x1a\n"):
        raise ValueError("not an image")
    return data


@app.post("/<ver>/<pid>/photos")
@app.post("/<ver>/<pid>/feed")
def fb_post(ver, pid):
    if request.values.get("access_token") != FB_PAGE["token"] or pid != FB_PAGE["id"]:
        return jsonify({"error": {"message": "(#200) permission", "code": 200}}), 403
    edge = request.path.rsplit("/", 1)[-1]
    rec = {"edge": edge, "message": request.values.get("message") or request.values.get("caption") or "", "link": request.values.get("link", "")}
    if edge == "photos":
        try:
            rec["bytes"] = len(_fetch_img(request.values.get("url", "")))
        except Exception as e:  # noqa: BLE001
            return jsonify({"error": {"message": f"url fetch failed: {e}", "code": 100}}), 400
    S.setdefault("fb_posts", []).append(rec)
    n = len(S["fb_posts"])
    return jsonify({"id": f"{FB_PAGE['id']}_{900 + n}", "post_id": f"{FB_PAGE['id']}_{900 + n}"})


# ---------------- Threads API ----------------
THREADS = {"token": "thr-QA-token-123", "id": "17841499", "username": "asan_wonju_threads"}


def _thr_ok():
    return request.values.get("access_token") == THREADS["token"]


@app.get("/threads/v1.0/me")
def thr_me():
    if not _thr_ok():
        return jsonify({"error": {"message": "Invalid OAuth access token", "code": 190}}), 401
    return jsonify({"id": THREADS["id"], "username": THREADS["username"]})


@app.post("/threads/v1.0/<uid>/threads")
def thr_create(uid):
    if not _thr_ok() or uid != THREADS["id"]:
        return jsonify({"error": {"message": "auth", "code": 190}}), 401
    mt, text = request.values.get("media_type"), request.values.get("text", "")
    if mt not in ("TEXT", "IMAGE") or len(text.encode("utf-8")) > 500 * 3 or len(text) > 500:
        return jsonify({"error": {"message": f"bad params ({mt}, {len(text)})", "code": 100}}), 400
    if mt == "IMAGE":
        try:
            _fetch_img(request.values.get("image_url", ""))
        except Exception as e:  # noqa: BLE001
            return jsonify({"error": {"message": f"image_url: {e}", "code": 100}}), 400
    cid = "tc" + str(len(S.setdefault("thr_containers", {})) + 1)
    S["thr_containers"][cid] = {"text": text, "type": mt, "polls": 0}
    return jsonify({"id": cid})


@app.get("/threads/v1.0/<cid>")
def thr_status(cid):
    c = S.get("thr_containers", {}).get(cid)
    if not c or not _thr_ok():
        abort(404)
    c["polls"] += 1
    return jsonify({"id": cid, "status": "FINISHED" if c["polls"] >= 2 else "IN_PROGRESS"})


@app.post("/threads/v1.0/<uid>/threads_publish")
def thr_publish(uid):
    c = S.get("thr_containers", {}).get(request.values.get("creation_id", ""))
    if not _thr_ok() or not c:
        return jsonify({"error": {"message": "bad creation_id", "code": 100}}), 400
    if c["polls"] < 2:      # 처리 전에 공개하면 실패 (공식 안내: 처리 완료 후 공개)
        return jsonify({"error": {"message": "Media Not Ready", "code": 24}}), 400
    S.setdefault("threads_posts", []).append(c)
    return jsonify({"id": "th" + str(len(S["threads_posts"]))})


# ---------------- BAND Open API ----------------
BAND = {"token": "band-QA-token-123", "bands": [{"band_key": "AAAbandKey01", "name": "온천동 이웃 모임"}, {"band_key": "AAAbandKey02", "name": "아산 맛집 정보방"}]}


@app.get("/band/v2.1/bands")
def band_list():
    if request.args.get("access_token") != BAND["token"]:
        return jsonify({"result_code": 211, "result_data": {"message": "invalid access token"}})
    return jsonify({"result_code": 1, "result_data": {"bands": BAND["bands"]}})


@app.post("/band/v2.2/band/post/create")
def band_post():
    if request.values.get("access_token") != BAND["token"]:
        return jsonify({"result_code": 211, "result_data": {"message": "invalid access token"}})
    key, content = request.values.get("band_key", ""), request.values.get("content", "")
    if key not in {b["band_key"] for b in BAND["bands"]}:
        return jsonify({"result_code": 1003, "result_data": {"message": "band not found"}})
    if not content.strip():
        return jsonify({"result_code": 1002, "result_data": {"message": "content empty"}})
    S.setdefault("band_posts", []).append({"band_key": key, "content": content, "do_push": request.values.get("do_push")})
    return jsonify({"result_code": 1, "result_data": {"band_key": key, "post_key": "AAApost" + str(len(S["band_posts"]))}})


@app.post("/<ver>/<uid>/media")
def ig_media(ver, uid):
    _tok()
    if uid not in IG_USERS:
        return err("unknown ig user")
    url, cap = request.form.get("image_url", ""), request.form.get("caption", "")
    import urllib.request
    try:
        data = urllib.request.urlopen(url, timeout=10).read()
    except Exception as e:  # noqa: BLE001
        return err(f"image_url fetch failed: {e}")
    if not (data[:3] == b"\xff\xd8\xff" or data[:8] == b"\x89PNG\r\n\x1a\n"):
        return err("image_url is not jpeg/png")
    if len(cap) > 2200 or cap.count("#") > 30:
        return err("caption too long / too many hashtags")
    cid = "c" + hashlib.md5((url + cap + str(time.time_ns())).encode()).hexdigest()[:12]
    S["ig_containers"][cid] = {"uid": uid, "image_url": url, "bytes": len(data), "caption": cap, "polls": 0}
    return jsonify({"id": cid})


@app.post("/<ver>/<uid>/media_publish")
def ig_publish(ver, uid):
    _tok()
    c = S["ig_containers"].get(request.form.get("creation_id", ""))
    if not c or c["uid"] != uid or c["polls"] < 2:
        return err("container not ready")
    mid = "m" + hashlib.md5(request.form["creation_id"].encode()).hexdigest()[:12]
    S["ig_published"].append({**c, "media_id": mid})
    return jsonify({"id": mid})


# ---------------- 공개 사진 (FTP 루트) ----------------
@app.get("/site/<path:p>")
def site(p):
    return send_from_directory(FTP_ROOT, p)


# ---------------- 네이버 로그인/스마트에디터 ONE 복제 ----------------
LOGIN_HTML = """<!doctype html><meta charset=utf-8><title>로그인</title><h1>{svc} 로그인 (가짜)</h1>
<form method=post><input name=id value="qa_user"><input name=pw type=password value="x"><button id=log.login>로그인</button></form>
<script>{auto}</script>"""


def _naver_ok():
    """둘 다 있어야 로그인: NID_AUT(유지 쿠키) + NID_SES(세션 쿠키, 서버 세션 목록에 있어야 함)"""
    return bool(request.cookies.get("NID_AUT")) and request.cookies.get("NID_SES") in S["sessions"]


def _tistory_ok():
    return request.cookies.get("TSSESSION") in S["sessions"]


@app.route("/naver/login", methods=["GET", "POST"], defaults={"svc": "naver"})
@app.route("/tistory/login", methods=["GET", "POST"], defaults={"svc": "tistory"})
def login(svc):
    if svc not in ("naver", "tistory"):
        abort(404)
    if request.method == "POST":
        S["logins"].append(svc)
        tok = "qa-" + os.urandom(8).hex()
        S["sessions"].add(tok)
        if svc == "naver":
            r = make_response(redirect("/naver/MyBlog.naver"))
            r.set_cookie("NID_AUT", "aut-" + os.urandom(6).hex(), max_age=86400 * 30, httponly=True)
            r.set_cookie("NID_SES", tok, httponly=True)          # 세션 쿠키 (브라우저를 닫으면 사라짐)
        else:
            r = make_response(redirect("/tistory/home"))
            r.set_cookie("TSSESSION", tok, httponly=True)
        return r
    auto = "setTimeout(()=>document.forms[0].submit(),1500)" if request.args.get("auto") else ""
    return LOGIN_HTML.format(svc=svc, auto=auto)


@app.get("/naver/home", defaults={"svc": "naver"})
@app.get("/tistory/home", defaults={"svc": "tistory"})
def home(svc):
    return f"<meta charset=utf-8><h1>{svc} 홈 (로그인됨)</h1>"


@app.get("/naver/MyBlog.naver")
def myblog():
    if not _naver_ok():
        return redirect("/nid.naver.com/nidlogin.login")
    return redirect("/naver/qa_user")


@app.post("/admin/expire")
def admin_expire():
    S["sessions"].clear()
    return jsonify({"ok": True})


@app.post("/admin/fail_publish")
def admin_fail():
    S["fail_publish"] = int(request.args.get("n", 1))
    return jsonify({"ok": True})


@app.get("/nid.naver.com/nidlogin.login")
def nid():
    return "<meta charset=utf-8>로그인 필요"


@app.get("/naver/<blog>")
def naver_write(blog):
    if request.args.get("Redirect") != "Write":
        return f"<meta charset=utf-8><h1>{blog} 블로그 홈</h1>"
    if not _naver_ok():
        return redirect("/nid.naver.com/nidlogin.login")
    return f"""<!doctype html><meta charset=utf-8><title>글쓰기</title><body style="margin:0">
<div style="height:40px;background:#03c75a;color:#fff">NAVER 블로그 · {blog}</div>
<iframe id="mainFrame" name="mainFrame" src="/naver/editor?blog={blog}" style="width:100%;height:860px;border:0"></iframe></body>"""


NAVER_EDITOR = r"""<!doctype html><html><head><meta charset=utf-8><style>
body{font-family:sans-serif;margin:0}.bar{display:flex;gap:6px;padding:6px;border-bottom:1px solid #ddd}
.se-documentTitle .se-text-paragraph{font-size:28px;min-height:40px;border-bottom:1px solid #eee;padding:8px;outline:0}
#body{min-height:400px;padding:8px;outline:0}.se-component.se-image img{max-width:200px}.se-popup{position:fixed;inset:0;background:#0006;display:flex;align-items:center;justify-content:center}
.layer{display:none;position:fixed;right:10px;top:50px;background:#fff;border:1px solid #333;padding:10px;width:320px}.layer.on{display:block}
[class*=option_list]{display:none}[class*=option_list].on{display:block}#placePanel{display:none;position:fixed;left:120px;top:80px;width:820px;height:520px;background:#fff;border:1px solid #999;padding:6px;z-index:40}#placePanel.on{display:block}
.se-place-map-search-result-item{padding:8px;border-bottom:1px solid #eee}.se-place-map-search-result-item .se-place-add-button{display:none}.se-place-map-search-result-item:hover .se-place-add-button{display:inline-block}
.libpanel{position:fixed;right:0;top:40px;width:200px;height:400px;background:#fafafa;border-left:1px solid #ddd}
</style></head><body>
<div class="bar"><button class="se-image-toolbar-button" type="button">사진</button><button class="se-map-toolbar-button" type="button">장소</button>
<span style="flex:1"></span><button class="publish_btn__m9KHH" type="button">발행</button></div>
<input type="file" id="file" accept="image/*" style="display:none">
<div class="se-material-search" style="position:fixed;bottom:0;left:300px;background:#fff;border:1px solid #ccc;padding:4px"><input type="text" class="se-material-input" placeholder="글감을 검색해 보세요." oninput="S.materialTyped=(S.materialTyped||'')+this.value"></div>
<div class="libpanel"><b>라이브러리</b><button class="libpanel-close-button" type="button" onclick="S.libClosed=true;this.parentElement.remove()">X</button></div>
<div id="placePanel" class="se-popup-placesMap"><button class="se-popup-close-button" type="button" onclick="this.parentElement.classList.remove('on')">X</button>
 <input class="se-place-search-input" placeholder="장소명을 입력하세요."><p class="se-place-no-result" style="display:none">검색 결과가 없습니다.</p><ul id="placeList"></ul>
 <button class="se-popup-button se-popup-button-confirm" type="button" disabled>확인</button></div>
<div class="se-help-panel" id="help" style="display:none;position:fixed;inset:0;background:#fffe;z-index:50"><h3>도움말</h3><button class="se-help-panel-close-button" type="button" onclick="document.getElementById('help').remove()">닫기</button></div>
<div class="se-documentTitle"><p class="se-text-paragraph" contenteditable="true"></p></div>
<div id="body" contenteditable="true"><div class="se-component se-text"><p class="se-text-paragraph"><br></p></div></div>
<div class="layer" id="pub"><div><button class="selectbox_button__jb1Dt" type="button">카테고리: <b id="cat">게시판</b></button>
 <ul class="option_list__yR8Ux">__CATS__</ul></div>
 <div>태그 <input id="tag-input"><span id="tags"></span></div>
 <div id="visbox"><input type="radio" name="open" id="open_public" value="open_public" checked><label for="open_public">전체공개</label>
 <input type="radio" name="open" id="open_neighbor" value="open_neighbor"><label for="open_neighbor">이웃공개</label>
 <input type="radio" name="open" id="open_private" value="open_private"><label for="open_private">비공개</label></div><button class="confirm_btn__WEaBq" type="button">발행</button></div>
<div class="se-popup"><div style="background:#fff;padding:20px">작성 중인 글이 있습니다 <button class="se-popup-button-cancel" type="button">취소</button></div></div>
<script>
const B=new URLSearchParams(location.search).get("blog");const S={images:[],tags:[],category:"",place:null};
document.querySelector(".se-popup-button-cancel").onclick=()=>document.querySelector(".se-popup").remove();
function caretToEnd(){const b=document.getElementById("body");b.focus();const r=document.createRange();r.selectNodeContents(b);r.collapse(false);const s=getSelection();s.removeAllRanges();s.addRange(r)}
document.querySelector(".se-image-toolbar-button").onclick=()=>document.getElementById("file").click();
document.getElementById("file").onchange=async e=>{const f=e.target.files[0];const fd=new FormData();fd.append("file",f);
  const r=await (await fetch("/naver/upload",{method:"POST",body:fd})).json();S.images.push(r);
  setTimeout(()=>{document.getElementById("body").insertAdjacentHTML("beforeend",`<div class="se-component se-image" contenteditable="false"><img src="${r.url}"></div><div class="se-component se-text"><p class="se-text-paragraph"><br></p></div>`);caretToEnd()},600)};
document.querySelector(".se-map-toolbar-button").onclick=()=>document.getElementById("placePanel").classList.add("on");
document.querySelector(".se-place-search-input").addEventListener("keydown",async e=>{if(e.key!=="Enter")return;const r=await (await fetch("/naver/place?q="+encodeURIComponent(e.target.value))).json();
  S.place=null;document.querySelector(".se-place-no-result").style.display=r.length?"none":"block";
  document.getElementById("placeList").innerHTML=r.map(p=>`<li class="se-place-map-search-result-item" data-id="${p.id}"><b>${p.name}</b> <span>${p.address}</span> <button class="se-place-add-button" type="button">+ 추가</button></li>`).join("");
  document.querySelector(".se-popup-button-confirm").disabled=true;e.target.value=""});
// 실제처럼: 줄을 눌러서는 선택되지 않고, 마우스를 올리면 나오는 '+ 추가'를 눌러야 '확인'이 켜짐
document.getElementById("placeList").onclick=e=>{const b=e.target.closest(".se-place-add-button");if(!b)return;const li=b.closest("li");
  S.place={id:li.dataset.id,name:li.querySelector("b").textContent+" "+li.querySelector("span").textContent};li.style.background="#cfc";document.querySelector(".se-popup-button-confirm").disabled=false};
if(__GLITCH__){  // 실제 화면처럼 id 없는 라디오 + '전체 공개' 띄어쓰기·여러 줄 라벨
  document.getElementById("visbox").innerHTML=`<label class="radio_label__x"><input type="radio" name="open" value="open_public"><span>전체</span> <span>공개</span></label>
   <label class="radio_label__x"><input type="radio" name="open" value="open_neighbor"><span>이웃</span> <span>공개</span></label>
   <label class="radio_label__x"><input type="radio" name="open" value="open_private"><span>비공개</span></label>`;
  setTimeout(()=>{const h=document.getElementById("help");if(h)h.style.display="block"},2600)}   // 늦게 뜨는 도움말(입력을 가림)
document.querySelector(".se-popup-button-confirm").onclick=()=>{if(!S.place)return;document.getElementById("body").insertAdjacentHTML("beforeend",`<div class="se-component se-placesMap" contenteditable="false">📍 ${S.place.name}</div>`);document.getElementById("placePanel").classList.remove("on")};
document.querySelector("[class*=publish_btn]").onclick=()=>(document.getElementById("placePanel")||{classList:{contains:()=>false}}).classList.contains("on")?null:document.getElementById("pub").classList.add("on");
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.getElementById("pub").classList.remove("on")});   // 실제처럼 Esc 는 발행 창을 닫음
if(__NOCAT__)document.querySelector("[class*=selectbox_button]").parentElement.remove();
document.querySelector("[class*=selectbox_button]")&&(document.querySelector("[class*=selectbox_button]").onclick=()=>document.querySelector("[class*=option_list]").classList.toggle("on"));
document.querySelector("[class*=option_list]")&&(document.querySelector("[class*=option_list]").onclick=e=>{const it=e.target.closest("[class*=item]");if(!it)return;S.category=it.textContent.trim();document.getElementById("cat").textContent=S.category;e.currentTarget.classList.remove("on")});
document.getElementById("tag-input").addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.value.trim()){S.tags.push(e.target.value.trim());document.getElementById("tags").textContent=S.tags.join(",");e.target.value=""}});
document.querySelector("[class*=confirm_btn]").onclick=async()=>{const b=document.getElementById("body");
  const r=await (await fetch("/naver/api/publish",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({blog:B,title:document.querySelector(".se-documentTitle .se-text-paragraph").innerText.trim(),
   text:b.innerText,html:b.innerHTML,images:S.images.map(i=>i.name),category:S.category,tags:S.tags,place:(document.querySelector(".se-placesMap")||{}).textContent||null,libClosed:!!S.libClosed,materialTyped:S.materialTyped||"",visibility:(document.querySelector("input[name=open]:checked")||{}).value||"none"})})).json();
  if(r.stay)return;if(r.logNo)window.top.location="/naver/PostView.naver?blogId="+B+"&logNo="+r.logNo;else alert(r.error)};
</script></body></html>"""


@app.get("/naver/editor")
def naver_editor():
    if not _naver_ok():
        abort(403)
    S["editor_opens"] += 1
    return NAVER_EDITOR.replace("__CATS__", "".join(f'<li class="item__wQ2T9">{c}</li>' for c in CATEGORIES)).replace("__GLITCH__", "true" if S.get("glitch") else "false").replace("__NOCAT__", "true" if S.get("nocat") else "false")


def _save_upload(prefix):
    f = request.files.get("file")
    data = f.read() if f else b""
    if not (data[:3] == b"\xff\xd8\xff" or data[:8] == b"\x89PNG\r\n\x1a\n"):
        abort(400)
    name = prefix + hashlib.md5(data).hexdigest()[:10] + os.path.splitext(f.filename)[1]
    open(os.path.join(UPLOADS, name), "wb").write(data)
    return {"name": f.filename, "url": f"/site/_uploads/{name}", "bytes": len(data)}


@app.post("/naver/upload")
def naver_upload():
    if not _naver_ok():
        abort(403)
    return jsonify(_save_upload("n_"))


@app.get("/naver/place")
def naver_place():
    """실제 네이버 장소 검색처럼: 등록 이름과 다른 검색어('아산 원주통닭 본점')는 결과 없음, '원주통닭'은 다른 지역 동명 가게가 먼저 나옴"""
    q = request.args.get("q", "").strip()
    S.setdefault("place_queries", []).append(q)
    places = [{"id": "11", "name": "원주통닭", "address": "대구 북구 침산동 123"}, {"id": "12", "name": "원주통닭 안산점", "address": "경기 안산시 상록구 본오동 55"},
              {"id": "13", "name": "원주통닭 배방점", "address": "충남 아산시 배방읍 장재리 7"},
              {"id": "17232917", "name": "원주통닭", "address": "충남 아산시 시민로 386 (온천동)"}]
    toks = [t for t in q.split() if t]
    if "원주통닭" not in toks and not q.startswith("충남 아산시 시민로"):
        return jsonify([])
    if q.startswith("충남 아산시 시민로"):
        return jsonify([places[3]])
    others = [t for t in toks if t != "원주통닭"]
    return jsonify([p for p in places if all(t in p["name"] + " " + p["address"] for t in others)])


@app.post("/admin/truncate")
def admin_truncate():
    S["truncate"] = int(request.args.get("n", 1))
    return jsonify({"ok": True})


@app.post("/admin/owner_voice")
def admin_owner_voice():
    S["owner_voice"] = int(request.args.get("n", 1))
    return jsonify({"ok": True})


@app.post("/admin/owner_intro")
def admin_owner_intro():
    S["owner_intro"] = request.args.get("on", "1") == "1"
    return jsonify({"ok": True})


@app.post("/admin/overload")
def admin_overload():
    S["overload"] = int(request.args.get("n", 1))
    return jsonify({"ok": True})


@app.post("/admin/glitch")
def admin_glitch():
    S["glitch"] = request.args.get("on", "1") == "1"
    return jsonify({"ok": True})


@app.post("/naver/api/publish")
def naver_api_publish():
    if not _naver_ok():
        return jsonify({"error": "login"}), 403
    b = request.get_json(force=True)
    if S["fail_publish"] > 0:
        S["fail_publish"] -= 1
        return jsonify({"error": "일시 오류(테스트)"}), 500
    if not b.get("title") or len(b.get("text", "").strip()) < 50:
        return jsonify({"error": "제목/본문이 비었습니다"}), 400
    with LOCK:
        log_no = str(223000000000 + len(S["naver"]) + 1)
        S["naver"].append({**b, "logNo": log_no, "cookie": request.cookies.get("NID_AUT"), "body_tags": re.findall(r"#(\S+)", b.get("text", ""))})
        if S.get("noredirect", 0) > 0:      # 글은 올라갔는데 화면이 글 주소로 안 넘어감 (실제로 중복 발행이 생기는 상황)
            S["noredirect"] -= 1
            return jsonify({"logNo": log_no, "stay": True})
    return jsonify({"logNo": log_no})


@app.get("/naver/PostView.naver")
def naver_view():
    p = next((x for x in S["naver"] if x["logNo"] == request.args.get("logNo")), None)
    return (f"<meta charset=utf-8><h1>{p['title']}</h1>" if p else abort(404))


# ---------------- 네이버 카페 글쓰기 복제 (새 카페 글쓰기: 제목 textarea + 스마트에디터 + 태그 + 등록) ----------------
CAFE_EDITOR = r"""<!doctype html><html><head><meta charset=utf-8><style>#body{min-height:300px;border:1px solid #ddd;padding:8px}.se-component.se-image img{max-width:160px}</style></head><body>
<div class="FormHead">카페 글쓰기</div>
<div class="FormSelectBox"><button type="button" class="button" id="boardBtn">__CUR__</button>
 <ul class="option_list" id="boardList" style="display:none">__OPTS__</ul></div>
<textarea class="textarea_input" placeholder="제목을 입력해 주세요."></textarea>
<div class="se-toolbar"><button class="se-image-toolbar-button" type="button">사진</button></div><input type="file" id="file" style="display:none">
<div id="body" contenteditable="true"><div class="se-component se-text"><p class="se-text-paragraph"><br></p></div></div>
<div class="tag_input_box"><input placeholder="태그를 입력해주세요"><span id="tags"></span></div>
<a href="#" role="button" class="BaseButton BaseButton--skinGreen">등록</a>
<script>const T=[],I=[];let MENU="__MENU__";
document.getElementById("boardBtn").onclick=()=>{const l=document.getElementById("boardList");l.style.display=l.style.display==="none"?"block":"none"};
document.getElementById("boardList").onclick=e=>{const li=e.target.closest("li");if(!li)return;MENU=li.dataset.id;document.getElementById("boardBtn").textContent=li.textContent.trim();e.currentTarget.style.display="none"};
function caretToEnd(){const b=document.getElementById("body");b.focus();const r=document.createRange();r.selectNodeContents(b);r.collapse(false);const s=getSelection();s.removeAllRanges();s.addRange(r)}
document.querySelector(".se-image-toolbar-button").onclick=()=>document.getElementById("file").click();
document.getElementById("file").onchange=async e=>{const fd=new FormData();fd.append("file",e.target.files[0]);const r=await (await fetch("/naver/upload",{method:"POST",body:fd})).json();I.push(r.name);
  document.getElementById("body").insertAdjacentHTML("beforeend",`<div class="se-component se-image" contenteditable="false"><img src="${r.url}"></div><div class="se-component se-text"><p class="se-text-paragraph"><br></p></div>`);caretToEnd()};
document.querySelector(".tag_input_box input").addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.value.trim()){T.push(e.target.value.trim());e.target.value=""}});
document.querySelector(".BaseButton--skinGreen").onclick=async e=>{e.preventDefault();const b=document.getElementById("body");
  if(!MENU){alert("게시판을 선택해 주세요.");return}
  const r=await (await fetch("/cafe/api/publish",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({menu:MENU,title:document.querySelector(".textarea_input").value,text:b.innerText,html:b.innerHTML,images:I,tags:T})})).json();
  if(r.id)location="/cafe/ca-fe/cafes/1/articles/"+r.id;else alert(r.error)};
</script></body></html>"""


CAFE_BOARDS = [("3", "자유게시판"), ("5", "가입인사"), ("7", "동네소식"), ("9", "맛집 이야기")]   # 글쓰기 가능한 게시판 (공지 게시판 '1'은 글쓰기 목록에 없음)


@app.get("/cafe/<name>")
def cafe_home(name):
    """카페 첫 화면 (실제처럼 카페 번호가 페이지 안에만 있음)"""
    if name != "asanlocal":
        abort(404)
    return '<meta charset=utf-8><title>아산 동네 카페</title><script>var g_sClubId = "31337";</script><h1>아산 동네 카페</h1>'


@app.get("/capi/cafe-web/cafe2/CafeGateInfo.json")
def cafe_gate():
    if not S.get("cafe_api", True):
        abort(404)
    if request.args.get("cluburl") != "asanlocal":
        return jsonify({"message": {"status": "500", "error": {"msg": "no cafe"}}}), 500
    return jsonify({"message": {"status": "200", "result": {"cafeInfoView": {"cafeId": 31337, "cafeUrl": "asanlocal"}}}})


@app.get("/capi/cafe-web/cafe2/SideMenuList")
def cafe_menus():
    if not S.get("cafe_api", True) or not _naver_ok():
        abort(404 if not S.get("cafe_api", True) else 401)
    menus = [{"menuId": 1, "menuName": "공지사항", "menuType": "B"}, {"menuId": 2, "menuName": "-----", "menuType": "S"}] + \
            [{"menuId": int(i), "menuName": n, "menuType": "B"} for i, n in CAFE_BOARDS]
    return jsonify({"message": {"status": "200", "result": {"menus": menus}}})


@app.post("/admin/cafe_api")
def admin_cafe_api():
    S["cafe_api"] = request.args.get("on", "1") == "1"
    return jsonify({"ok": True})


@app.get("/cafe/ca-fe/cafes/<cid>/articles/write")
def cafe_write(cid):
    if not _naver_ok():
        return redirect("/nid.naver.com/nidlogin.login")
    if cid not in ("1", "31337"):
        abort(404)
    menu = request.args.get("menuId", "")
    cur = dict(CAFE_BOARDS).get(menu, "게시판을 선택해 주세요.")
    opts = "".join(f'<li class="item" data-id="{i}"><button type="button" class="option">{n}</button></li>' for i, n in CAFE_BOARDS)
    return CAFE_EDITOR.replace("__MENU__", menu if menu in dict(CAFE_BOARDS) else "").replace("__CUR__", cur).replace("__OPTS__", opts)


@app.post("/cafe/api/publish")
def cafe_publish():
    if not _naver_ok():
        return jsonify({"error": "login"}), 403
    b = request.get_json(force=True)
    if not b.get("title") or len(b.get("text", "").strip()) < 30:
        return jsonify({"error": "제목/본문이 비었습니다"}), 400
    with LOCK:
        S.setdefault("cafe", []).append(b)
        n = len(S["cafe"])
    return jsonify({"id": 1000 + n})


@app.get("/cafe/ca-fe/cafes/<cid>/articles/<int:aid>")
def cafe_view(cid, aid):
    return "<meta charset=utf-8><h1>카페 글</h1>"


# ---------------- 네이버 블로그 공개 RSS / 모바일 글 (스타일 학습) ----------------
STYLE_POSTS = {"223100000001": ["오늘은 비가 와서 손님이 적었어요 😊", "그래도 단골분들이 전화 주셔서 힘이 났어요.", "내일은 날이 갠다고 하니 기대해 볼게요!"],
               "223100000002": ["아침에 닭이 들어오면 바로 손질을 시작해요.", "염지는 하루 전에 해 두고요 🍗", "튀김 기름은 매일 확인하고 있어요."],
               "223100000003": ["요즘 포장 주문이 많아졌어요.", "상자는 미리 접어 두면 덜 기다리세요.", "늘 감사합니다 🙏 다음에 또 들러 주세요."]}


@app.get("/rss/<bid>.xml")
def blog_rss(bid):
    S.setdefault("rss_hits", []).append(bid)
    import html as H
    items = "".join(f"<item><title>글 {n}</title><link>https://blog.naver.com/{bid}/{n}?fromRss=true</link><description><![CDATA[{STYLE_POSTS[n][0]}]]></description></item>"
                    for n in STYLE_POSTS)
    items += "".join(f"<item><title><![CDATA[{p['title']}]]></title><link>https://blog.naver.com/{bid}/{p['logNo']}?fromRss=true</link>"
                     f"<description>{H.escape(p.get('text', '')[:80])}</description></item>" for p in reversed(S["naver"]) if p.get("blog") == bid)
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><rss><channel><title>{bid}</title>{items}</channel></rss>', mimetype="application/xml")


@app.get("/trss/<blog>")
def tistory_rss(blog):
    import html as H
    items = "".join(f"<item><title>{H.escape(p['title'])}</title><link>https://{blog}.tistory.com/{p['id']}</link></item>" for p in reversed(S["tistory"]) if p.get("blog") == blog)
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><rss><channel>{items}</channel></rss>', mimetype="application/xml")


@app.post("/admin/noredirect")
def admin_noredirect():
    S["noredirect"] = int(request.args.get("n", 1))
    return jsonify({"ok": True})


@app.get("/m/<bid>/<no>")
def blog_mobile(bid, no):
    pub = next((p for p in S["naver"] if p["logNo"] == no), None)
    if pub:   # 올라간 글: 본문 + 사진 (실제 모바일 화면처럼 절대 주소)
        imgs = "".join(f'<img src="{request.host_url.rstrip("/")}{u}" data-lazy-src="{request.host_url.rstrip("/")}{u}">' for u in re.findall(r'src="(/site/_uploads/[^"]+)"', pub.get("html", "")))
        return f'<meta charset=utf-8><div class="se-main-container"><p class="se-text-paragraph">{pub["title"]}</p>{imgs}</div>'
    paras = "".join(f'<p class="se-text-paragraph se-text-paragraph-align-">{t}</p>' for t in STYLE_POSTS.get(no, []))
    return f'<meta charset=utf-8><div class="se-main-container">{paras}{paras}</div>'


# ---------------- 티스토리 글쓰기 복제 ----------------
TISTORY_EDITOR = r"""<!doctype html><html><head><meta charset=utf-8><style>#editor-tistory_ifr{width:100%;height:320px;border:1px solid #ccc}#layer{display:none}#layer.on{display:block}#category-list{display:none}#category-list.on{display:block;position:fixed;left:0;right:0;bottom:0;height:200px;background:#fff;z-index:30;margin:0;overflow:auto}</style></head><body>
<textarea id="post-title-inp" placeholder="제목을 입력하세요"></textarea>
<div id="catbox"><button id="category-btn" type="button">카테고리</button><ul id="category-list"><li role="option">카테고리 없음</li>__CATS__</ul></div>
<div id="mceu_0" class="mce-widget mce-btn mce-menubtn"><button id="mceu_0-open" type="button">첨부</button>
 <div class="mce-menu" id="attachMenu" style="display:none"><div class="mce-menu-item" data-k="photo">사진</div><div class="mce-menu-item" data-k="file">파일</div></div></div>
<input type="file" name="attach-file" id="attach-file" style="display:none">
<iframe id="editor-tistory_ifr" srcdoc="<html><body contenteditable='true' style='font-family:sans-serif'></body></html>"></iframe>
<div class="tag-box"><input id="tagText" placeholder="태그입력"><span id="tags"></span></div>
<button id="publish-layer-btn" type="button">완료</button>
<div id="layer"><label><input type="radio" name="vis" id="open0" checked>비공개</label><label><input type="radio" name="vis" id="open20">공개</label><button id="publish-btn" type="button">공개 발행</button></div>
<script>
const BLOG="__BLOG__",GLITCH=__GLITCH__;const S={tags:[],category:""};
if(GLITCH)document.querySelectorAll("#layer input[type=radio]").forEach(r=>r.style.display="none");   // 실제처럼 숨겨진 라디오(디자인 버튼)
const body=()=>document.getElementById("editor-tistory_ifr").contentDocument.body;
function initEditor(){window.tinymce={activeEditor:{setContent:h=>{body().innerHTML=h},getContent:()=>body().innerHTML,insertContent:h=>body().insertAdjacentHTML("beforeend",h),
  getBody:()=>body(),fire:()=>{},focus:()=>{},selection:{select:()=>{},collapse:()=>{}}}}}
// 실제 티스토리처럼: 잠시 뒤 '이어서 작성' 확인창 → '취소'하면 편집기를 새로 불러옴(새로고침) → 그동안 tinymce 없음
setTimeout(()=>{initEditor();
  setTimeout(()=>{const again=!sessionStorage.getItem("reloaded");if(confirm("저장된 글이 있습니다. 이어서 작성하시겠습니까?")){body().innerHTML="<p>임시저장 글</p>"}
    else if(GLITCH&&again){sessionStorage.setItem("reloaded","1");delete window.tinymce;location.reload()}},GLITCH?1200:300)},GLITCH?1500:500);
// 실제처럼: 미리 있는 사진 칸이 없음. '첨부' → '사진'을 누르면 그때 파일 칸을 만들어 파일 선택 창을 띄움
async function upload(f){const fd=new FormData();fd.append("file",f);const r=await (await fetch("/tistory/upload",{method:"POST",body:fd})).json();
  setTimeout(()=>tinymce.activeEditor.insertContent(`<p><img src="${r.url}" data-name="${r.name}"></p>`),500)}
document.getElementById("mceu_0-open").onclick=()=>{const m=document.getElementById("attachMenu");m.style.display=m.style.display==="none"?"block":"none"};
document.getElementById("attachMenu").onclick=e=>{const it=e.target.closest(".mce-menu-item");if(!it)return;e.currentTarget.style.display="none";
  if(it.dataset.k!=="photo"){document.getElementById("attach-file").click();return}
  if(__NOCHOOSER__)return;   // 파일 선택 창이 안 뜨는 환경 재현 → 끌어다 놓기로 올려야 함
  const inp=document.createElement("input");inp.type="file";inp.accept="image/*";inp.style.display="none";document.body.appendChild(inp);
  inp.onchange=()=>{upload(inp.files[0]);inp.remove()};inp.click()};
document.getElementById("attach-file").onchange=()=>{S.wrongFile=(S.wrongFile||0)+1};
function wireDrop(){const b=body();if(!b||b.dataset.drop)return;b.dataset.drop=1;b.addEventListener("drop",e=>{e.preventDefault();for(const f of e.dataTransfer.files)upload(f)})}
setInterval(wireDrop,200);
document.getElementById("tagText").addEventListener("keydown",e=>{if(e.key==="Enter"&&e.target.value.trim()){S.tags.push(e.target.value.trim());document.getElementById("tags").textContent=S.tags.join(",");e.target.value=""}});
if(__NOCAT__)document.getElementById("catbox").innerHTML="";
document.getElementById("category-btn")&&(document.getElementById("category-btn").onclick=()=>document.getElementById("category-list").classList.toggle("on"));
document.getElementById("category-list")&&(document.getElementById("category-list").onclick=e=>{const li=e.target.closest("li");if(!li)return;S.category=li.textContent.trim();document.getElementById("category-btn").textContent=S.category;e.currentTarget.classList.remove("on")});
document.getElementById("publish-layer-btn").onclick=()=>document.getElementById("layer").classList.add("on");
async function doPublish(vis){const r=await (await fetch("/tistory/api/publish",{method:"POST",headers:{"Content-Type":"application/json"},
  body:JSON.stringify({wrongFile:S.wrongFile||0,blog:BLOG,title:document.getElementById("post-title-inp").value,html:body().innerHTML,tags:S.tags,category:S.category,visibility:vis})})).json();
  if(r.id){sessionStorage.removeItem("reloaded");location="/tistory/"+BLOG+"/manage/posts?published="+r.id}else alert(r.error)}
document.getElementById("publish-btn").onclick=()=>doPublish(document.getElementById("open20").checked?"public":"private");
if(__V2__){   // 다른 화면 구조(id 없음, 버튼형 공개 선택, 기본값 비공개) - 글자로 찾아야 함
  const pl=document.getElementById("publish-layer-btn");pl.removeAttribute("id");
  const L=document.getElementById("layer");L.innerHTML=`<div class="radio_group"><button type="button" role="radio" aria-checked="false" data-v="public">공개</button>
   <button type="button" role="radio" aria-checked="false" data-v="protected">보호</button><button type="button" role="radio" aria-checked="true" data-v="private">비공개</button></div>
   <button type="button" class="btn_temp">임시저장</button><button type="button" class="btn_publish">비공개 저장</button>`;
  pl.onclick=()=>L.classList.add("on");
  L.querySelectorAll("[role=radio]").forEach(b=>b.onclick=()=>{L.querySelectorAll("[role=radio]").forEach(x=>x.setAttribute("aria-checked","false"));b.setAttribute("aria-checked","true");
    L.querySelector(".btn_publish").textContent=b.dataset.v==="public"?"공개 발행":"비공개 저장"});
  L.querySelector(".btn_temp").onclick=()=>{S.temp=1;alert("임시저장 되었습니다")};
  L.querySelector(".btn_publish").onclick=()=>doPublish(L.querySelector("[role=radio][aria-checked=true]").dataset.v)}
</script></body></html>"""


@app.get("/tistory/<blog>/manage/newpost/")
def tistory_new(blog):
    if not _tistory_ok():
        return redirect("/tistory/login?auth/login")
    return TISTORY_EDITOR.replace("__BLOG__", blog).replace("__CATS__", "".join(f'<li role="option">{c}</li>' for c in CATEGORIES)).replace("__GLITCH__", "true" if S.get("glitch") else "false").replace("__NOCHOOSER__", "true" if S.get("nochooser") else "false").replace("__V2__", "true" if S.get("tistory_v2") else "false").replace("__NOCAT__", "true" if S.get("nocat") else "false")


@app.post("/admin/nocat")
def admin_nocat():
    S["nocat"] = request.args.get("on", "1") == "1"
    return jsonify({"ok": True})


@app.post("/admin/tistory_v2")
def admin_tistory_v2():
    S["tistory_v2"] = request.args.get("on", "1") == "1"
    return jsonify({"ok": True})


@app.post("/admin/nochooser")
def admin_nochooser():
    S["nochooser"] = request.args.get("on", "1") == "1"
    return jsonify({"ok": True})


@app.post("/tistory/upload")
def tistory_upload():
    if not _tistory_ok():
        abort(403)
    return jsonify(_save_upload("t_"))


@app.post("/tistory/api/publish")
def tistory_api_publish():
    if not _tistory_ok():
        return jsonify({"error": "login"}), 403
    b = request.get_json(force=True)
    if not b.get("title") or len(re.sub(r"<[^>]+>", "", b.get("html", ""))) < 50:
        return jsonify({"error": "제목/본문이 비었습니다"}), 400
    if "임시저장 글" in b.get("html", ""):
        return jsonify({"error": "임시저장 글이 섞였습니다"}), 400
    with LOCK:
        pid = len(S["tistory"]) + 1
        S["tistory"].append({**b, "id": pid})
    return jsonify({"id": pid})


@app.get("/tistory/<blog>/manage/posts")
def tistory_posts(blog):
    return f"<meta charset=utf-8><h1>{blog} 글 목록</h1>"


# ---------------- X API v2 (OAuth 1.0a 서명 검증) ----------------
X_KEYS = {"api_key": "xkey-QA", "api_secret": "xsecret-QA", "token": "xtok-QA", "token_secret": "xtoksec-QA"}


def _x_auth():
    import base64, hmac, hashlib, urllib.parse as up
    h = request.headers.get("Authorization", "")
    if not h.startswith("OAuth "):
        return False
    parts = dict(re.findall(r'(\w+)="([^"]*)"', h))
    parts = {k: up.unquote(v) for k, v in parts.items()}
    if parts.get("oauth_consumer_key") != X_KEYS["api_key"] or parts.get("oauth_token") != X_KEYS["token"]:
        return False
    sig = parts.pop("oauth_signature", "")
    params = {**{k: v for k, v in request.args.items()}, **{k: v for k, v in parts.items() if k.startswith("oauth_")}}
    pct = lambda x: up.quote(str(x), safe="~")
    pstr = "&".join(f"{pct(k)}={pct(v)}" for k, v in sorted(params.items()))
    url = request.base_url
    base = "&".join([request.method, pct(url), pct(pstr)])
    key = f"{pct(X_KEYS['api_secret'])}&{pct(X_KEYS['token_secret'])}"
    good = base64.b64encode(hmac.new(key.encode(), base.encode(), hashlib.sha1).digest()).decode()
    return hmac.compare_digest(good, sig)


@app.get("/2/users/me")
def x_me():
    if not _x_auth():
        return jsonify({"title": "Unauthorized", "detail": "Unauthorized", "status": 401}), 401
    return jsonify({"data": {"id": "999", "username": "asan_wonju_qa", "name": "아산 원주통닭"}})


@app.post("/2/media/upload")
def x_media():
    if not _x_auth():
        return jsonify({"title": "Unauthorized", "status": 401}), 401
    f = request.files.get("media")
    data = f.read() if f else b""
    if request.form.get("media_category") != "tweet_image" or data[:3] != b"\xff\xd8\xff":
        return jsonify({"title": "Invalid Request", "detail": "bad media"}), 400
    mid = str(1800000000000000000 + len(S.setdefault("x_media", [])))
    S["x_media"].append({"id": mid, "bytes": len(data)})
    return jsonify({"data": {"id": mid, "media_key": "3_" + mid, "size": len(data)}})


@app.post("/2/tweets")
def x_tweet():
    if not _x_auth():
        return jsonify({"title": "Unauthorized", "status": 401}), 401
    b = request.get_json(force=True)
    text = b.get("text", "")
    w = sum(1 if ord(c) <= 4351 else 2 for c in re.sub(r"https?://\S+", "x" * 23, text))
    if not text or w > 280:
        return jsonify({"title": "Invalid Request", "detail": f"text too long ({w})"}), 400
    if any(t["text"] == text for t in S.setdefault("x_posts", [])):
        return jsonify({"title": "Forbidden", "detail": "You are not allowed to create a Tweet with duplicate content."}), 403
    tid = str(1900000000000000000 + len(S["x_posts"]))
    S["x_posts"].append({"id": tid, "text": text, "weight": w, "media": (b.get("media") or {}).get("media_ids", [])})
    return jsonify({"data": {"id": tid, "text": text}})


@app.get("/state")
def state():
    return jsonify({k: (list(v) if isinstance(v, set) else v) for k, v in S.items() if k not in ("ig_tokens", "cache")})


@app.post("/reset")
def reset():
    for k in ("anthropic", "naver", "tistory", "ig_published", "logins", "errors"):
        S[k] = []
    S["ig_containers"] = {}
    return jsonify({"ok": True})


def start(port, ftp_root):
    """테스트에서 스레드로 실행"""
    import logging
    from werkzeug.serving import make_server
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    configure(ftp_root)
    srv = make_server("127.0.0.1", port, app, threaded=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
