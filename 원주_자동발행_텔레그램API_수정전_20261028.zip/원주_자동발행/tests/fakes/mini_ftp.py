# -*- coding: utf-8 -*-
"""테스트용 아주 작은 FTP 서버 (PASV 전송, USER/PASS/CWD/MKD/STOR/NLST/LIST/PWD) - 외부 패키지 없이"""
import os, socket, socketserver, threading


class Handler(socketserver.StreamRequestHandler):
    def send(self, line):
        self.wfile.write((line + "\r\n").encode("utf-8"))

    def handle(self):
        root = os.path.realpath(self.server.root)
        cwd, user, authed, pasv = "/", "", False, None
        self.send("220 mini ftp")
        while True:
            raw = self.rfile.readline()
            if not raw:
                break
            line = raw.decode("utf-8", "replace").rstrip("\r\n")
            cmd, _, arg = line.partition(" ")
            cmd = cmd.upper()

            def real(p):
                path = os.path.normpath(os.path.join(cwd, p) if not p.startswith("/") else p).replace("\\", "/")
                full = os.path.realpath(os.path.join(root, path.lstrip("/")))
                if not full.startswith(root):
                    raise PermissionError
                return path, full
            try:
                if cmd == "USER":
                    user = arg
                    self.send("331 password")
                elif cmd == "PASS":
                    if user == self.server.user and arg == self.server.pw:
                        authed = True
                        self.send("230 ok")
                    else:
                        self.send("530 login incorrect")
                elif cmd == "QUIT":
                    self.send("221 bye")
                    break
                elif not authed:
                    self.send("530 not logged in")
                elif cmd in ("SYST",):
                    self.send("215 UNIX")
                elif cmd in ("TYPE", "OPTS", "MODE", "STRU"):
                    self.send("200 ok")
                elif cmd == "FEAT":
                    self.send("211 end")
                elif cmd == "PWD":
                    self.send(f'257 "{cwd}"')
                elif cmd == "CWD":
                    path, full = real(arg)
                    if os.path.isdir(full):
                        cwd = path if path.startswith("/") else "/" + path
                        self.send("250 ok")
                    else:
                        self.send("550 no such dir")
                elif cmd == "MKD":
                    path, full = real(arg)
                    os.makedirs(full, exist_ok=True)
                    self.send(f'257 "{path}" created')
                elif cmd == "PASV":
                    pasv = socket.socket()
                    pasv.bind(("127.0.0.1", 0))
                    pasv.listen(1)
                    p = pasv.getsockname()[1]
                    self.send(f"227 Entering Passive Mode (127,0,0,1,{p >> 8},{p & 255})")
                elif cmd in ("STOR", "NLST", "LIST"):
                    if not pasv:
                        self.send("425 use PASV")
                        continue
                    self.send("150 opening")
                    conn, _ = pasv.accept()
                    if cmd == "STOR":
                        path, full = real(arg)
                        with open(full, "wb") as f:
                            while True:
                                b = conn.recv(65536)
                                if not b:
                                    break
                                f.write(b)
                        self.server.stored.append(path)
                    else:
                        _, full = real(arg or ".")
                        names = sorted(os.listdir(full)) if os.path.isdir(full) else []
                        conn.sendall(("\r\n".join(names) + ("\r\n" if names else "")).encode("utf-8"))
                    conn.close()
                    pasv.close()
                    pasv = None
                    self.send("226 done")
                else:
                    self.send("502 not implemented")
            except PermissionError:
                self.send("550 denied")
            except Exception as e:  # noqa: BLE001
                self.send(f"451 error {e}")


class MiniFTP(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, root, user, pw, port=0):
        self.root, self.user, self.pw, self.stored = root, user, pw, []
        os.makedirs(root, exist_ok=True)
        super().__init__(("127.0.0.1", port), Handler)

    def start(self):
        threading.Thread(target=self.serve_forever, daemon=True).start()
        return self.server_address[1]
