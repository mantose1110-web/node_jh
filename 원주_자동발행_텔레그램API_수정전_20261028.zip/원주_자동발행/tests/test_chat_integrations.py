import json, tempfile, unittest
from unittest.mock import patch


class _Response:
    def __enter__(self): return self
    def __exit__(self, *_): return False
    def read(self, _limit): return json.dumps({"ok": True, "result": {"id": 123, "username": "jhnode_bot", "first_name": "JH"}}).encode()


class ChatIntegrationTests(unittest.TestCase):
    def setUp(self):
        from autopost import generator as g, secure
        self.tmp = tempfile.TemporaryDirectory(); g.ROOT = self.tmp.name
        secure._cache.update(mtime=None, data=None, path=None)

    def tearDown(self): self.tmp.cleanup()

    @patch("urllib.request.urlopen", return_value=_Response())
    def test_telegram_token_fetches_account(self, _):
        from autopost import chat_integrations as c
        account = c.verify_telegram("123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghi")
        self.assertEqual(account["username"], "jhnode_bot")

    def test_tokens_are_allowed_and_secret(self):
        from autopost import chat_integrations as c, secure
        item = c.new_connection("naver_talk")
        key = c.naver_key(item["id"])
        self.assertTrue(secure.allowed(key)); self.assertTrue(secure.is_secret(key))
        self.assertEqual(c.validate_naver_token("ct_abcdefghijklmnopqrstuvwxyz")["status"], "형식 확인")

    def test_bad_token_rejected(self):
        from autopost import chat_integrations as c
        with self.assertRaises(ValueError): c.verify_telegram("not-a-token")
        with self.assertRaises(ValueError): c.validate_naver_token("short")


if __name__ == "__main__": unittest.main()
